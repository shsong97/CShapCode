Option Strict Off
Option Explicit On
Module mod_DragDrop
	
	Public ga_itmXs() As String
    Public gnodDrag As TreeNode
	Public gs_itmTag As String
	
	Public gs_nodTag As String
    Public gnodDrop As TreeNode
	
    Public gnodParentX As TreeNode
	
	Public gs_PermissionTag As String
    Public gs_listCode As String
    Public glivX As ListView
    Public gitmX As ListViewItem
    Private iCnt As Short

    '   �����信 ����� �����ϰ� ������ ä���ִ´�.
    Sub g_DisplayListview(ByRef g As GRSClass)

        Select Case gs_CurMgmt


            Case "U" '����� ����

                For inx As Integer = 0 To g.RowCount - 1
                    gitmX = glivX.Items.Add("")
                    With gitmX

                        Select Case gnodX.Tag
                            Case "C_U"
                                .Tag = "U_X"
                                .ImageIndex = 0
                            Case "C_G"
                                .Tag = "G_X"
                                .ImageIndex = 1
                            Case "G_X"
                                .Tag = g.gRS("User_type") & "_X"
                                If g.gRS("User_type") = "U" Then
                                    .ImageIndex = 0
                                Else
                                    .ImageIndex = 1
                                End If
                        End Select
                        .Text = g.gRS(0) 'user_id or group_id
                        .SubItems.Add(g.gRS(1)) 'user_name or group_name
                        .SubItems.Add(g.gRS(2)) ' ���ȵ��
                        .SubItems.Add(g.gRS("chng_date"))
                        .SubItems.Add(g.gRS("chng_id"))
                    End With
                    g.MoveNext()
                Next
                ' ----------------------------------------------------------------------------------------------------
            Case "A" '�������α׷�

                Select Case gnodX.Tag

                    Case "M_A" '�ֻ��� ���� ������

                        For inx As Integer = 0 To g.RowCount - 1
                            gitmX = glivX.Items.Add("")
                            With gitmX
                                .Text = g.gRS(0)
                                .Tag = "DMX"
                                .ImageIndex = 2
                            End With
                            g.MoveNext()
                        Next

                    Case "DMX"

                        For inx As Integer = 0 To g.RowCount - 1
                            gitmX = glivX.Items.Add("")
                            With gitmX
                                .Text = g.gRS(0)
                                .SubItems.Add(g.gRS(1))
                                .SubItems.Add(g.gRS("chng_date"))
                                .SubItems.Add(g.gRS("chng_id"))
                                .Tag = "APX"
                                .ImageIndex = 4
                            End With
                            g.MoveNext()
                        Next

                    Case "APX"
                        For inx As Integer = 0 To g.RowCount - 1
                            gitmX = glivX.Items.Add("")
                            With gitmX
                                .Text = g.gRS(0)
                                .SubItems.Add(g.gRS(1))
                                .SubItems.Add(g.gRS("chng_date"))
                                .SubItems.Add(g.gRS("chng_id"))
                                .Tag = "P_X"
                                .ImageIndex = 5
                            End With
                            g.MoveNext()
                        Next

                    Case "P_X"
                        For inx As Integer = 0 To g.RowCount - 1
                            gitmX = glivX.Items.Add("")
                            With gitmX
                                .Text = g.gRS(0)
                                .SubItems.Add(g.gRS(1) & " " & g.gRS(2))
                                .SubItems.Add(g.gRS("chng_date"))
                                .SubItems.Add(g.gRS("chng_id"))
                                If g.gRS("User_type") = "G" Then
                                    .Tag = "G_X"
                                    .ImageIndex = 1
                                Else
                                    .Tag = "U_X"
                                    .ImageIndex = 0
                                End If


                            End With
                            g.MoveNext()
                        Next


                    Case Else

                End Select


                ' ----------------------------------------------------------------------------------------------------
            Case "P" '���α׷�
                Select Case gnodX.Tag

                    Case "M_P"
                        For inx As Integer = 0 To g.RowCount - 1
                            gitmX = glivX.Items.Add("")
                            With gitmX
                                .Text = g.gRS(0)
                                .SubItems.Add(g.gRS(1))
                                .SubItems.Add(g.gRS(2))
                                .SubItems.Add(g.gRS("chng_date"))
                                .SubItems.Add(g.gRS("chng_id"))
                                .Tag = "P_X"
                                .ImageIndex = 5
                            End With
                            g.MoveNext()
                        Next
                    Case "P_X"


                    Case Else

                End Select


            Case Else

                MsgBox(gs_CurMgmt & "what!!!")

        End Select


    End Sub

    '����Ʈ�信�� gnodX�� �����ϴ� �������� ã�� select�Ѵ�.
    Sub gFindListItem()

        Dim itmFound As ListViewItem
        If glivX.Items.Count <= 0 Then Exit Sub
        If gnodX Is Nothing Then Exit Sub
        'If gitmX Is Nothing Then Exit Sub

        'glivX.MultiSelect = False
        itmFound = glivX.FindItemWithText(gnodX.Name)

        If itmFound Is Nothing Then ' If no match, inform user and exit.
            gitmX = Nothing
            Exit Sub
        End If
        'glivX.Focus()
        'glivX.Items(1).Selected = True
        'itmFound.EnsureVisible() ' Scroll ListView to show found ListItem.
        'itmFound.Selected = True ' Select the ListItem.
        'glivX.MultiSelect = True
        gitmX = itmFound

    End Sub

    '�����׸� ���� ����� �����Ѵ�.
    Sub g_DisplayListviewHeader()

        Select Case gs_CurMgmt

            Case "U" '����� ����
                glivX.Columns.Add("�̸�", 100)
                glivX.Columns.Add("�ѱ��̸�", 100)
                glivX.Columns.Add("����", 50)

            Case "D" '����Ÿ���̽�

                glivX.Columns.Add("�̸�", 100)
                glivX.Columns.Add("�ѱ��̸�", 100)
                glivX.Columns.Add("��  ��", 100)

            Case "A" '�������α׷�

                glivX.Columns.Add("�������α׷���", 150)
                glivX.Columns.Add("���λ���", 150)

            Case "J" '�����з�

                glivX.Columns.Add("�����з�", 100)
                glivX.Columns.Add("��������", 100)

            Case "L"

                glivX.Columns.Add("�̸�", 100)
                glivX.Columns.Add("���", 100)
                glivX.Columns.Add("����", 100)

            Case "P" '���α׷�

                glivX.Columns.Add("�̸�", 100)
                glivX.Columns.Add("�ѱ��̸�", 150)
                glivX.Columns.Add("��  ��", 100)

            Case Else
                Exit Sub

        End Select

        glivX.Columns.Add("��������", 150)
        glivX.Columns.Add("������", 100)

    End Sub

    '���ؾ� �� �׸� ���߾� �ش� �����츦 ����.
    Function gF_AddData(ByRef ConX As System.Windows.Forms.Control) As String

        Dim sAddItem As String

        gF_AddData = "X"

        If ConX Is glivX Then
            If gitmX Is Nothing Then Exit Function
            sAddItem = gitmX.Tag
        Else
            'Ʈ������ ��� �ڽ� ��ϸ� �켱���Ѵ�.
            If gnodX Is Nothing Then Exit Function
            sAddItem = gnodX.Tag

            Select Case sAddItem
                Case "C_U" : sAddItem = "U_X" '����ڵ��
                Case "C_G" : sAddItem = "G_X" '�׷� ���

                Case "M_A" : sAddItem = "DMX" '�������α׷� ���
                Case "DMX" : sAddItem = "APX" '�������α׷� ���

                Case "M_P" : sAddItem = "P_X" '���α׷� ���
            End Select

        End If

        Select Case sAddItem
            Case "U_X" '����ڵ��
                If gnodX.Parent.Tag = "C_U" Or gnodX.Tag = "C_U" Then
                    frm_UserAdd.txt_ID.Text = ""
                    frm_UserAdd.cmdOK.Text = "���"
                    VB6.ShowForm(frm_UserAdd, 1, frm_CEM_MDI)
                Else
                    Exit Function
                End If
            Case "G_X" '�׷� ���
                frm_GroupAdd.Text = "�׷� ���"
                frm_GroupAdd.cmdOK.Text = "���"
                frm_GroupAdd.txt_ID.Text = ""
                frm_GroupAdd.txt_ID.Enabled = True
                VB6.ShowForm(frm_GroupAdd, 1, frm_CEM_MDI)
            Case "DMX"
                frm_AppAdd.Text = "�������α׷� ���"
                VB6.ShowForm(frm_AppAdd, 1, frm_CEM_MDI)
            Case "APX" '�������α׷� ���
                frm_AppAdd.Text = "�������α׷� ���"
                '������䱸�ϴ� ���� ����
                frm_AppAdd.txt_Domain.Text = IIf(gnodX.Tag = "DMX", gnodX.Name, gnodX.Parent.Name)
                frm_AppAdd.txt_Domain.Enabled = False
                frm_AppAdd.txt_Domain.Enabled = True
                frm_AppAdd.cmdOK.Text = "���"
                frm_AppAdd.txt_ID.Text = ""
                frm_AppAdd.txt_ID.Enabled = True

                VB6.ShowForm(frm_AppAdd, 1, frm_CEM_MDI)
            Case "P_X" '���α׷� ���
                frm_ProgAdd.Text = "���α׷� ���"
                frm_ProgAdd.cmdOk.Text = "���"
                frm_ProgAdd.txt_ID.Text = ""
                frm_ProgAdd.txt_ID.Enabled = True

                If gnodX.Tag = "M_P" Then
                    VB6.ShowForm(frm_ProgAdd, 1, frm_CEM_MDI)
                Else
                    If gnodX.Parent.Tag = "M_P" Then
                        VB6.ShowForm(frm_ProgAdd, 1, frm_CEM_MDI)
                    Else
                        Exit Function
                    End If
                End If
            Case Else
                Exit Function
        End Select
        gF_AddData = sAddItem

    End Function

    Sub g_EditData(ByRef ConX As System.Windows.Forms.Control)

        On Error GoTo Line_Error


        Dim sEditItem As String '���ؾ� �� �׸�
        Dim sEditName As String
        Dim ls_Temp As String
        Dim frmRef As System.Windows.Forms.Form


        If ConX Is glivX Then
            If gitmX Is Nothing Then Exit Sub
            sEditItem = gitmX.Tag
            sEditName = gitmX.Text
        Else 'Ʈ���信 ��Ŀ���� ���� ��
            If gnodX Is Nothing Then Exit Sub
            sEditItem = gnodX.Tag
            sEditName = gnodX.Text
        End If

        Select Case sEditItem

            Case "U_X" '����� ����
                If gnodX.Parent.Tag = "C_U" Then
                    frm_UserAdd.Text = "����� ����"
                    frm_UserAdd.cmdOK.Text = "����"

                    frm_UserAdd.txt_ID.Text = sEditName
                    frm_UserAdd.txt_ID.Enabled = False

                    If frm_UserAdd.F_DBRecordDisplay Then
                        VB6.ShowForm(frm_UserAdd, 1, frm_CEM_MDI)
                    Else
                        frm_UserAdd.Close()
                    End If

                Else
                    MsgBox("����ڼ����� ����ڰ������� �Ͻñ� �ٶ��ϴ�.", , "Ȯ��")
                    Exit Sub
                End If
            Case "G_X" '�׷� ����
                If gnodX.Parent.Tag = "C_G" Then
                    frm_GroupAdd.Text = "�׷� ����"
                    frm_GroupAdd.cmdOK.Text = "����"
                    frm_GroupAdd.txt_ID.Text = sEditName
                    frm_GroupAdd.txt_ID.Enabled = False

                    If frm_GroupAdd.F_DBRecordDisplay Then
                        VB6.ShowForm(frm_GroupAdd, 1, frm_CEM_MDI)
                    Else
                        frm_GroupAdd.Close()
                    End If
                Else
                    MsgBox("�׷������ ����ڰ������� �Ͻñ� �ٶ��ϴ�.", , "Ȯ��")
                    Exit Sub
                End If
            Case "APX" '�������α׷� ����
                frm_AppAdd.txt_Domain.Text = gnodX.Parent.Name
                frm_AppAdd.txt_Domain.Enabled = False
                frm_AppAdd.cmdOK.Text = "����"
                frm_AppAdd.txt_ID.Text = sEditName
                frm_AppAdd.txt_ID.Enabled = False

                If frm_AppAdd.F_DBRecordDisplay Then
                    VB6.ShowForm(frm_AppAdd, 1, frm_CEM_MDI)
                Else
                    frm_AppAdd.Close()
                End If

            Case "P_X" '���α׷� ����
                If gnodX.Parent.Tag = "M_P" Then
                    frm_ProgAdd.Text = "���α׷� ����"
                    frm_ProgAdd.cmdOk.Text = "����"
                    frm_ProgAdd.txt_ID.Text = sEditName
                    frm_ProgAdd.txt_ID.Enabled = False

                    If frm_ProgAdd.F_DBRecordDisplay Then
                        VB6.ShowForm(frm_ProgAdd, 1, frm_CEM_MDI)
                    Else
                        frm_ProgAdd.Close()
                    End If
                Else
                    MsgBox("���α׷������� ���α׷��������� �Ͻñ� �ٶ��ϴ�.", , "Ȯ��")

                    Exit Sub
                End If
            Case Else
                Exit Sub
        End Select

        Exit Sub
Line_Error:
        MsgBox(ErrorToString())
        Exit Sub
        Resume

    End Sub

    'delete
    Sub g_DeleteData(ByRef ConX As System.Windows.Forms.Control)

        Dim sDeleteItem As String

        If ConX Is glivX Then '����Ʈ�信 ��Ŀ���� ���� ��
            If gitmX Is Nothing Then
                MsgBox("���� �����ϰ����� �������� �����ϼ���!")
                Exit Sub
            Else
                If gnodX.Tag Like "M_*" Then
                    Exit Sub
                Else
                    sDeleteItem = gitmX.Tag
                End If
            End If
        Else
            If gnodX Is Nothing Then '���õ� ���?
                MsgBox("���� �����ϰ����� �������� �����ϼ���!")
                Exit Sub
            Else
                If gnodX.Tag Like "M_*" Then
                    Exit Sub
                Else
                    sDeleteItem = gnodX.Tag
                End If
            End If
        End If

        g_DeleteDBData(sDeleteItem)

    End Sub


    Private Sub g_DeleteDBData(ByRef sDeleteItem As String)

        Dim ls_T As String
        Dim MsgStr As String
        Dim MsgStrGB As String
        Dim Parm3 As String

        On Error GoTo Err_Handler

        If Not CheckRequestNo() Then
            MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�.")
            Exit Sub
        End If

        If MsgBox("'" & gnodX.Text & "'�� ������ �����Ͻðڽ��ϱ�? ", MsgBoxStyle.OkCancel) = MsgBoxResult.Cancel Then
            Exit Sub
        End If

        Select Case sDeleteItem '������ �׸�

            Case "U_X", "G_X" '����� ����

                Select Case gnodX.Parent.Tag
                    ' parent�� �׷��̸� �׷��������� �����Ѵ�.
                    Case "G_X"
                        Gsql = "exec sp_grouping_info_del '"

                        Gsql = Gsql & "A" & "','"
                        Gsql = Gsql & gnodX.Parent.Name & "','"
                        Gsql = Gsql & Left(sDeleteItem, 1) & "','"
                        Gsql = Gsql & gnodX.Name & "','"
                        Gsql = Gsql & gRequestNo & "'"
                        g = New GRSClass(Gsql)
                        ' parent�� ����ڸ� ����������� �����Ѵ�.
                    Case "C_U"

                        MsgStr = "����������� �����մϴ�."
                        MsgStr = MsgStr & Chr(13) & Chr(13) & "����� <����ó��> ������ => (��Y)"
                        MsgStr = MsgStr & Chr(13) & "����� <����ó��> ������ => (�ƴϿ�N)"
                        MsgStr = MsgStr & Chr(13) & "          <�۾����> ��       => (���)"
                        MsgStrGB = CStr(MsgBox(MsgStr, MsgBoxStyle.YesNoCancel, "�������������"))
                        Select Case MsgStrGB
                            Case "6" '����ó��
                                Parm3 = "T"
                            Case "7" '����ó��
                                Parm3 = "D"
                            Case Else
                                Exit Sub
                        End Select

                        Gsql = "exec sp_user_info_del '"
                        Gsql = Gsql & gnodX.Name & "','"
                        Gsql = Gsql & gRequestNo & "','"
                        Gsql = Gsql & Parm3 & "'"
                        g = New GRSClass(Gsql)

                        gtrvX.Nodes.Remove(gnodX)
                        glivX.Items.Remove(glivX.FindItemWithText(gitmX.Text))
                        ' parent�� �׷��̸� �׷������� �����Ѵ�.
                    Case "C_G"
                        Gsql = "exec sp_group_info_del '"
                        Gsql = Gsql & gnodX.Name & "','"
                        Gsql = Gsql & gRequestNo & "'"
                        g = New GRSClass(Gsql)
                        ' parent�� ���α׷����������̸� ���������� �����Ѵ�.
                    Case "P_X"

                        Gsql = "exec sp_prog_security_del '"

                        Gsql = Gsql & "A" & "','"
                        Gsql = Gsql & gnodX.Parent.Parent.Parent.Name & "','"
                        Gsql = Gsql & gnodX.Parent.Parent.Name & "','"
                        Gsql = Gsql & gnodX.Parent.Name & "','"
                        Gsql = Gsql & Left(sDeleteItem, 1) & "','"
                        Gsql = Gsql & gnodX.Name & "','"
                        Gsql = Gsql & gRequestNo & "'"
                        g = New GRSClass(Gsql)

                    Case Else

                End Select

            Case "APX" '�������α׷�

                Gsql = "exec sp_app_prog_info_del '"
                Gsql = Gsql & gnodX.Parent.Name & "','"
                Gsql = Gsql & gnodX.Name & "'"
                g = New GRSClass(Gsql)

            Case "P_X" '���α׷�

                Select Case gnodX.Parent.Tag

                    Case "M_P" ' parent�� ���α׷��׷��̸� ���α׷��� �����Ѵ�.

                        Gsql = "exec sp_program_info_del '"
                        Gsql = Gsql & gnodX.Name & "','"
                        Gsql = Gsql & gRequestNo & "'"
                        g = New GRSClass(Gsql)
                        
                        gtrvX.Nodes.Remove(gnodX)
                        glivX.Items.Remove(glivX.FindItemWithText(gitmX.Text))

                    Case "APX" ' parent�� �������α׷��̸� �������α׷���������� �����Ѵ�.

                        Gsql = "exec sp_app_prog_mem_info_del '"
                        Gsql = Gsql & "A" & "','"
                        Gsql = Gsql & gnodX.Parent.Parent.Name & "','"
                        Gsql = Gsql & gnodX.Parent.Name & "','"
                        Gsql = Gsql & gnodX.Name & "'"
                        g = New GRSClass(Gsql)
                End Select

            Case Else

        End Select

        Exit Sub

Err_Handler:

        Select Case gF_Error_Handler
            Case "X" : Exit Sub
            Case "N" : Resume Next
            Case "R" : Resume
            Case Else
        End Select

    End Sub

	'�巡�� ������ ���������� �Ǵ�. - ����Ʈ�信�� ȣ��
	Function gF_isDragabledItem() As Boolean
		
		gF_isDragabledItem = False
        If gitmX.Tag Like "?_X" Then 'U_X,G_X,P_X
            Select Case gitmX.Tag
                Case "U_X", "G_X"
                    If Left(gnodX.Tag, 2) = "C_" Then gF_isDragabledItem = True
                Case "P_X"
                    If gnodX.Tag = "M_P" Then gF_isDragabledItem = True
            End Select
        End If
		
	End Function
	
	
	Function gF_isMatchingDragItemDropNode() As Boolean
		'�巡�׵���� ������ �������� �Ǵ�
		'G <- U
		'T,S,V,CTU <- U,G
		
		On Error Resume Next
        Dim nodT As TreeNode
		
		gF_isMatchingDragItemDropNode = False
		
		Select Case gs_nodTag 'DROPED PALCE��
			Case "G_X"
				If gs_itmTag = "U_X" Or gs_itmTag = "G_X" Then gF_isMatchingDragItemDropNode = True
			Case "APX" '�������α׷�
				If gs_itmTag = "P_X" Then gF_isMatchingDragItemDropNode = True
			Case "P_X" '���α׷�
				'����ڰ� �θ� APX�� ��忡 ��������
				If gs_itmTag = "U_X" Or gs_itmTag = "G_X" Then
					If gnodDrop.Parent.Tag = "APX" Then gF_isMatchingDragItemDropNode = True
				End If
			Case Else
				
		End Select
		
		If gF_isMatchingDragItemDropNode = False Then
			MsgBox("�巡�׵���� ������ ������ �ƴմϴ�.")
		End If
		
	End Function

    '�巡�׵�ӿ����� DB insert
    Sub g_SetRelatonDragDrop()
        On Error GoTo Err_Handler

        Dim li_Cnt As Integer
        Dim li_DragCnt As Integer
        Dim nodT As TreeNode

        li_DragCnt = 1
        If li_DragCnt = 0 Then Exit Sub
        Call g_ExpandNode()
        li_DragCnt = 1

        If li_DragCnt <> 0 Then
            '��Ȳ�� ���� �ٸ� relation�� ������ش�.
            Select Case gs_itmTag
                '------------------------------------------
                'drag�� �����  �����
                Case "U_X", "G_X"

                    'drop�� ��ġ��.
                    Select Case gs_nodTag
                        Case "G_X"  '�������� �׷쿡 �Ҽӽ�Ų��.

                            If CheckRequestNo() Then
                                If gRequestNo = "" Then
                                    MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�." + vbCrLf + "mod_DragDrop - g_SetRelatonDragDrop(G_X)")
                                    Exit Select
                                End If
                                
                                For li_Cnt = 1 To li_DragCnt
                                    '����ڱ׷� �������
                                    Gsql = " exec sp_grouping_info_add '"
                                    Gsql = Gsql & gUSERID & "','"
                                    Gsql = Gsql & gnodDrag.Name & "','"
                                    Gsql = Gsql & Left(gs_itmTag, 1) & "','"
                                    Gsql = Gsql & gitmX.Text & "','" 'Gsql = Gsql & ga_itmXs(li_Cnt) & "','"
                                    Gsql = Gsql & "R" & "','"
                                    Gsql = Gsql & gRequestNo & "'"
                                    g = New GRSClass(Gsql)
                                Next
                            Else
                                Exit Sub
                            End If


                        Case "P_X"  '���α׷� ������������ �ش�.

                            gs_PermissionTag = "W"
                            If gs_PermissionTag = "X" Then
                                Exit Sub
                            Else
                                If CheckRequestNo() Then
                                    If gRequestNo = "" Then
                                        MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�." + vbCrLf + "mod_DragDrop - g_SetRelatonDragDrop(P_X)")
                                        Exit Select
                                    End If

                                    Gsql = "exec sp_prog_security_add '"
                                    Gsql = Gsql & gUSERID & "','"
                                    Gsql = Gsql & gnodParentX.Parent.Name & "','"
                                    Gsql = Gsql & gnodParentX.Name & "','"
                                    Gsql = Gsql & gnodDrag.Name & "','"
                                    Gsql = Gsql & Left(gs_itmTag, 1) & "','"
                                    Gsql = Gsql & gitmX.Text & "','"
                                    Gsql = Gsql & gs_PermissionTag & "','"
                                    Gsql = Gsql & gRequestNo & "'"

                                    g = New GRSClass(Gsql)
                                Else
                                    Exit Sub
                                End If
                            End If

                    End Select


                Case "P_X"

                    Select Case gs_nodTag

                        '���α׷��� �������α׷��� ������ ��
                        Case "APX"
                            For li_Cnt = 1 To li_DragCnt
                                Gsql = " exec sp_app_prog_mem_info_add '"
                                Gsql = Gsql & gUSERID & "','"
                                Gsql = Gsql & gnodParentX.Name & "','"
                                Gsql = Gsql & gnodDrag.Name & "','"
                                Gsql = Gsql & gitmX.Text & "'"
                                g = New GRSClass(Gsql)
                            Next


                    End Select

            End Select

            frm_CEM_Main.g_Refresh(gnodDrag)

        Else
            MsgBox("�̹� ��ϵǾ� �ִ� ������Դϴ�.")
        End If

        Exit Sub

Err_Handler:

        Select Case gF_Error_Handler()
            Case "X" : Exit Sub
            Case "N" : Resume Next
            Case "R" : Resume
            Case Else
        End Select

    End Sub
End Module