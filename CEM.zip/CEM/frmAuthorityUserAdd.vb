Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmAuthorityUserAdd
	Inherits System.Windows.Forms.Form
	
	Private Sub frmAuthorityUserAdd_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call lsAddComboBox()
	End Sub
	
	Private Sub lsAddComboBox()
		Dim i As Integer
        Dim g As GRSClass
		
		'���ø����̼�
		Gsql = ""
		Gsql = Gsql & " SELECT app_program_desc,app_program "
		Gsql = Gsql & "   FROM app_prog_info "
		Gsql = Gsql & "  WHERE status = 'S' "
		Gsql = Gsql & "  ORDER BY app_program_desc"
		
        g = New GRSClass(Gsql)

		cboApplication.Items.Clear()
		cboApplication.Items.Add("")
		
        For i = 0 To g.RowCount - 1
            cboApplication.Items.Add(g.gRS(0) & Space(50) & g.gRS(1))
            g.MoveNext()
        Next i
		
        cboApplication.SelectedIndex = 0

	End Sub
	
	
	
	
	
	Private Sub IsGroupCopy()
		Dim inx As Short
		Dim userID As String
		Dim GroupID As String
		Dim strWhere As String
		Dim DataCnt As Integer
		
		userID = Trim(txtCode2.Text)
		
        '����ڱ׷� �������
        Dim g As GRSClass

        For inx = 1 To spdSpreadGroup1.Sheets(0).RowCount
            If gSpreadUnitDataFetch(spdSpreadGroup1, inx, 1) = "1" Then
                GroupID = gSpreadUnitDataFetch(spdSpreadGroup1, inx, 2)

                strWhere = ""
                strWhere = strWhere & " where group_id = '" & GroupID & "'"
                strWhere = strWhere & "   and user_id = '" & userID & "'"

                DataCnt = llCheckGroupingDataCnt(strWhere)

                If DataCnt = 0 Then
                    If gRequestNo = "" Then
                        MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�.")
                        Exit Sub
                    Else
                        Gsql = "exec sp_grouping_info_add '" & gUSERID & "','"
                        Gsql = Gsql & GroupID & "','"
                        Gsql = Gsql & "U" & "','"
                        Gsql = Gsql & userID & "','"
                        Gsql = Gsql & "R" & "','"
                        Gsql = Gsql & gRequestNo & "','"

                        g = New GRSClass(Gsql)
                    End If
                End If
            End If
        Next inx

		
	End Sub
	
    Private Sub lsAuthorityCopy()
        Dim i As Integer
        Dim j As Integer

        Dim Domain As String
        Dim App_Program As String
        Dim Program As String
        Dim User_type As String
        Dim User_ID As String
        Dim Authority As String

        Dim Wstr As String
        Dim strWhere As String
        Dim CopyGB As String
        Dim DataCnt As Integer
        Dim DataCntGroup As Integer

        On Error GoTo CLEANUP

        User_ID = Trim(txtCode2.Text) 'Target User ID
        User_type = "U"
        Authority = "F"

        For i = 0 To sprSpread1.Sheets(0).RowCount - 1

            If gSpreadUnitDataFetch(sprSpread1, i, 0) = "1" Then
                Domain = gSpreadUnitDataFetch(sprSpread1, i, 3)
                App_Program = gSpreadUnitDataFetch(sprSpread1, i, 4)
                Program = gSpreadUnitDataFetch(sprSpread1, i, 5)

                strWhere = ""
                strWhere = strWhere & " where group_id = '" & VB.Left(App_Program, 8) & "'"
                strWhere = strWhere & "   and user_id = '" & User_ID & "'"

                DataCntGroup = llCheckGroupingDataCnt(strWhere)

                If DataCntGroup <> 1 Then
                    MsgBox("�ش� Application Group�� ���� ����Ͻʽÿ�.( " & App_Program & ")")
                    Exit Sub
                End If

                Wstr = ""
                Wstr = Wstr & " WHERE domain = '" & Domain & "'"
                Wstr = Wstr & "   AND app_program = '" & App_Program & "'"
                Wstr = Wstr & "   AND program = '" & Program & "'"
                Wstr = Wstr & "   AND user_type = '" & User_type & "'"
                Wstr = Wstr & "   AND user_id = '" & User_ID & "'"

                DataCnt = llCheckDataCnt(Wstr)

                If DataCnt = 0 Then
                    Gsql = "exec sp_prog_security_add '"
                    Gsql = Gsql & gUSERID & "','"
                    Gsql = Gsql & Domain & "','"
                    Gsql = Gsql & App_Program & "','"
                    Gsql = Gsql & Program & "','"
                    Gsql = Gsql & User_type & "','"
                    Gsql = Gsql & User_ID & "','"
                    Gsql = Gsql & Authority & "','"
                    Gsql = Gsql & gRequestNo & "'"
                    g = New GRSClass(Gsql)
                End If
            End If
        Next i

        Exit Sub
CLEANUP:
        Call gSetErrorDescription()
        Exit Sub
    End Sub
	Private Function llCheckDataCnt(ByRef Wstr As String) As Integer

		Gsql = "SELECT user_id FROM prog_security "
		Gsql = Gsql & Wstr
		
        g = New GRSClass(Gsql)
        llCheckDataCnt = g.RowCount
		
	End Function
	
	Private Function llCheckGroupingDataCnt(ByRef Wstr As String) As Integer

		Gsql = "SELECT user_id FROM grouping_info "
		Gsql = Gsql & Wstr
		
		Dim g As GRSClass = New GRSClass(Gsql)
        llCheckGroupingDataCnt = g.RowCount
		
	End Function
	
	
	Private Function lbQryCheck() As Boolean
		lbQryCheck = True

		'Source User ID �� ���ų� �߸��Ȱ��
		If txtCode1.Text = "" Or txtName1.Text = "" Then
			lbQryCheck = False
			MsgBox("Source User ID �� �߸��Ǿ����ϴ�.�ٽ� �Է��� �ּ���.",  , "Ȯ��")
			txtCode1.Focus()
			Exit Function
		End If

		'Target User ID �� ���ų� �߸��Ȱ��
		If txtCode2.Text = "" Or txtName2.Text = "" Then
			lbQryCheck = False
			MsgBox("Target User ID �� �߸��Ǿ����ϴ�.�ٽ� �Է��� �ּ���.",  , "Ȯ��")
			txtCode2.Focus()
			Exit Function
		End If

	End Function
	
	Private Function lsSourceUserQry(ByRef GB As String) As Boolean
		'GB "1"�� ��������1 , "2"�� ��������2
		
		Dim AppCode As String
		Dim userID As String
		Dim SQL1 As String
		Dim SQL2 As String
		
		On Error GoTo ErrHandler
		lsSourceUserQry = True
		
		AppCode = Trim(VB.Right(cboApplication.Text, 50))
		
		If GB = "1" Then
			userID = Trim(txtCode1.Text)
		Else
			userID = Trim(txtCode2.Text)
		End If
		
		SQL1 = ""
		SQL1 = SQL1 & " select a.group_id, b.group_name"
		SQL1 = SQL1 & "   from grouping_info a,"
		SQL1 = SQL1 & "        group_info b"
		SQL1 = SQL1 & "  where a.group_id = b.group_id"
		SQL1 = SQL1 & "    and a.user_id = '" & userID & "'"
		
		SQL2 = "EXEC sp_authority_list_user '" & userID & "','" & AppCode & "'"
		
		If GB = "1" Then
			
			'�׷�
            If Not gFillSpread(spdSpreadGroup1, SQL1) Then GoTo ErrHandler
			
            Call gSpreadAddColumn(spdSpreadGroup1, 0)
            Call gSpreadMakeCheckCell(spdSpreadGroup1, -1, 0, 0)

            spdSpreadGroup1.Sheets(0).ColumnHeader.Columns(0).Label = "copy"
            spdSpreadGroup1.Sheets(0).ColumnHeader.Columns(0).Width = 25

			'���α׷�
            If Not gFillSpread(sprSpread1, SQL2) Then GoTo ErrHandler
			
			'�������� ����
            With sprSpread1.Sheets(0).ColumnHeader
                .Columns(0).Width = 0
                .Columns(1).Width = 0
                .Columns(2).Width = 0
            End With
			
            Call gSpreadAddColumn(sprSpread1, 0)
            Call gSpreadMakeCheckCell(sprSpread1, -1, 0, 0)

            sprSpread1.Sheets(0).ColumnHeader.Columns(0).Label = "copy"
            sprSpread1.Sheets(0).ColumnHeader.Columns(0).Width = 25

		Else
            If Not gFillSpread(spdSpreadGroup2, SQL1) Then GoTo ErrHandler
            If Not gFillSpread(sprSpread2, SQL2) Then GoTo ErrHandler
			
            '�������� ����
            With sprSpread2.Sheets(0).ColumnHeader
                .Columns(0).Width = 0
                .Columns(1).Width = 0
                .Columns(2).Width = 0
            End With

		End If
		
		Exit Function
ErrHandler: 
		Err.Clear()
		Call gDisplayCemMessage()
		lsSourceUserQry = False
	End Function
	
	
	Private Sub cmdQry1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdQry1.Click
		gs_listCode = "3"
		frmProgramList.ShowDialog()
	End Sub
	
	Private Sub CmdQry2_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdQry2.Click
		gs_listCode = "4"
		frmProgramList.ShowDialog()
	End Sub
	
	Private Sub CmdReset_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdReset.Click
		cboApplication.SelectedIndex = 0
		txtCode1.Text = "" : txtName1.Text = ""
		txtCode2.Text = "" : txtName2.Text = ""
		Call gClearAllSpread(sprSpread1)
		Call gClearAllSpread(sprSpread2)
		Call gClearAllSpread(spdSpreadGroup1)
		Call gClearAllSpread(spdSpreadGroup2)
		txtCode1.Focus()
	End Sub
	
	
	
	
	Private Function lfCheckID(ByRef User_ID As String) As String

		Gsql = ""
		Gsql = Gsql & " SELECT user_name_k FROM user_info "
		Gsql = Gsql & " WHERE user_id='" & User_ID & "'"
        Dim g As GRSClass = New GRSClass(Gsql)

        If g.RowCount = 1 Then
            lfCheckID = g.gRS(0)
        Else
            lfCheckID = ""
        End If

	End Function
	
	
	Private Sub txtCode1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCode1.Click
		txtCode1.Text = "" : txtName1.Text = ""
	End Sub
	Private Sub txtCode1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles txtCode1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		If KeyCode = 13 Then
            Call CmdAuthorityQry_Click(CmdAuthorityQry, New System.EventArgs())
		End If
	End Sub
	
	
	Private Sub txtCode1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCode1.Leave
		If txtCode1.Text <> "" Then
			If txtName1.Text = "" Then
				txtName1.Text = lfCheckID(Trim(txtCode1.Text))
			End If
		End If
	End Sub
	Private Sub txtName1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtName1.Click
		txtCode1.Text = "" : txtName1.Text = ""
	End Sub
	
	Private Sub txtCode2_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCode2.Click
		txtCode2.Text = "" : txtName2.Text = ""
	End Sub
	
	Private Sub txtCode2_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles txtCode2.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		If KeyCode = 13 Then
            Call CmdTargetAuthorityQry_Click(CmdTargetAuthorityQry, New System.EventArgs())
		End If
	End Sub
	
	Private Sub txtCode2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCode2.Leave
		If txtCode2.Text <> "" Then
			If txtName2.Text = "" Then
				txtName2.Text = lfCheckID(Trim(txtCode2.Text))
			End If
		End If
	End Sub
	Private Sub txtName2_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtName2.Click
		txtCode2.Text = "" : txtName2.Text = ""
	End Sub
	 

    Private Sub CmdAuthorityCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdAuthorityCopy.Click
        Dim Cond As String

        If lbQryCheck() = False Then
            Exit Sub
        Else

            Cond = "< " & txtCode1.Text & " > ������� ������ < " & txtCode2.Text & " > ������� ���Ѱ� �����ϰ� �����մϴ�. "
            Cond = Cond & Chr(13) & Chr(13) & " ������ ��Ȯ�ϸ� ���� �Ͻʽÿ�."
            Cond = Cond & Chr(13) & " ����('Yes'), ���('No') "
            If MsgBox(Cond, MsgBoxStyle.YesNo, "Ȯ��") = MsgBoxResult.No Then
                Exit Sub
            Else
                If Not CheckRequestNo() Then
                    Exit Sub
                End If
                If gRequestNo = "" Then
                    Exit Sub
                End If
                Call IsGroupCopy()
                Call lsAuthorityCopy()
                Call lsSourceUserQry("2")
            End If
        End If
    End Sub

    Private Sub CmdTargetAuthorityQry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdTargetAuthorityQry.Click
        If txtCode2.Text = "" Then
            MsgBox("(Target User ID) ������ ��ȸ�� ����ڸ� ������ �ּ���.", , "Ȯ��")
            gs_listCode = "4"
            frmProgramList.ShowDialog()
        Else
            Call lsSourceUserQry("2")
        End If
    End Sub

    Private Sub CmdAuthorityQry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdAuthorityQry.Click
        If txtCode1.Text = "" Then
            MsgBox("(Source User ID) ������ ��ȸ�� ����ڸ� ������ �ּ���.", , "Ȯ��")
            gs_listCode = "3"
            frmProgramList.ShowDialog()
        Else
            sprSpread1.Sheets(0).RowCount = 0
            Call lsSourceUserQry("1")
        End If
    End Sub


    Private Sub spdSpreadGroup1_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSpreadGroup1.CellClick
        If e.ColumnHeader Then
            If e.Column = 0 Then
                With spdSpreadGroup1.Sheets(0)
                    For i As Integer = 0 To .RowCount - 1
                        .Cells(i, e.Column).Value = Not .Cells(i, e.Column).Value
                    Next
                End With
            End If
        End If
    End Sub

    Private Sub sprSpread1_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles sprSpread1.CellClick
        If e.ColumnHeader Then
            If e.Column = 0 Then
                With sprSpread1.Sheets(0)
                    For i As Integer = 0 To .RowCount - 1
                        .Cells(i, e.Column).Value = Not .Cells(i, e.Column).Value
                    Next
                End With
            End If
        End If
    End Sub
End Class