Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmPopupManage
	Inherits System.Windows.Forms.Form
    
	
	Private Sub Data_clear()
		Code_Txt.Text = ""
		apply_Txt.Text = ""
		txtFromDate.Text = ""
		txtToDate.Text = ""
		remark_Txt.Text = ""
	End Sub
    
	
	Private Sub frmPopupManage_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call Data_clear()
	End Sub
	
    
	
    Public Sub gSpread_CellSet(ByVal sprSpread As FarPoint.Win.Spread.FpSpread, ByRef logRow As Integer, ByRef logCol As Integer, ByRef varValue As String)
        On Error Resume Next ' null
        sprSpread.Sheets(0).Cells(logRow, logCol).Text = varValue
        On Error GoTo 0 '�������
    End Sub
	

	Function g_Date_Check(ByRef sstr As String) As Boolean
		
		If Len(sstr) = 8 Then
			g_Date_Check = IsDate(g_Date_format(sstr))
		Else
			g_Date_Check = IsDate(sstr)
		End If
		
	End Function
	Function g_Date_format(ByRef sstr As String) As String
		g_Date_format = VB.Left(sstr, 4) & "-" & Mid(sstr, 5, 2) & "-" & VB.Right(sstr, 2)
	End Function
	
    Public Function gSpread_CellValue1(ByVal sprSpread As FarPoint.Win.Spread.FpSpread, ByRef logRow As Integer, ByRef logCol As Integer) As Object

        Dim sValue As Object
        sValue = sprSpread.Sheets(0).Cells(logRow, logCol).Text

        gSpread_CellValue1 = sValue
    End Function

    Private Sub sear_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sear_button.Click
        Dim SQL As String
        Dim lRow As Integer
        Dim i As Short
        Dim gubun As String
        Dim code As String
        Dim g As GRSClass

        gubun = "1"

        On Error Resume Next
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Call gSpreadClear(sp_pop, sp_pop.Sheets(0).RowCount)

        If Code_Txt.Text = "" Then
            code = ""
        Else
            code = Code_Txt.Text
        End If

        SQL = " exec s_frmPopupManage " & " '" & gubun & "','" & code & "','','','',''"

        g = New GRSClass(SQL)

        If g.RowCount = 0 Then
            Call MsgBox("�����ϴ� �����Ͱ� �����ϴ�.", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            Call Data_clear()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If

        For inx As Integer = 0 To g.RowCount - 1
            sp_pop.Sheets(0).Cells(inx, 0).Text = g.gRS(0)
            sp_pop.Sheets(0).Cells(inx, 1).Text = g.gRS(1)
            sp_pop.Sheets(0).Cells(inx, 2).Text = g.gRS(2)
            sp_pop.Sheets(0).Cells(inx, 3).Text = g.gRS(3)
            g.MoveNext()
        Next
        Cursor.Current = Cursors.Default
        On Error GoTo 0
    End Sub

    Private Sub sub_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sub_button.Click
        Dim SQL As String
        Dim lRow As Integer
        Dim i As Short
        Dim strtmp As String
        Dim gubun As String

        gubun = "2"

        On Error Resume Next
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor


        If apply_Txt.Text = "" Then
            Call MsgBox("����� ���뿩�θ� �Է��ϼ���", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            apply_Txt.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If

        '��¥ üũ
        If g_Date_Check(txtFromDate.Text) = False Then
            MsgBox("��¥�Է��� �߸��Ǿ����ϴ�", 64, "Error Message")
            txtFromDate.Text = ""
            Exit Sub
        ElseIf g_Date_Check(txtToDate.Text) = False Then
            MsgBox("��¥�Է��� �߸��Ǿ����ϴ�", 64, "Error Message")
            txtToDate.Text = ""
            Exit Sub
        ElseIf txtFromDate.Text > txtToDate.Text Then
            MsgBox("�Ⱓ �Է��� �߸��Ǿ����ϴ�", 64, "Error Message")
            Exit Sub
        End If

        If remark_Txt.Text = "" Then
            Call MsgBox("����� �˾������� �Է��ϼ���", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            remark_Txt.Focus()
            Exit Sub
        End If

        Code_Txt.Text = ""

        SQL = " exec s_frmPopupManage " & " '" & gubun & "'," & " '" & Trim(Code_Txt.Text) & "'," & " '" & Trim(txtFromDate.Text) & "'," & " '" & Trim(txtToDate.Text) & "'," & " '" & Trim(apply_Txt.Text) & "'," & " '" & Trim(remark_Txt.Text) & "'"
        Dim g As GRSClass = New GRSClass(SQL)

        If g.gRS(0) = "1" Then
            Call MsgBox("���� �˾��� �����մϴ�.", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
        Else
            Call MsgBox("����Ͽ����ϴ�.", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
        End If

        Call Data_clear()
        Call sear_button_Click(sear_button, New System.EventArgs())
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        On Error GoTo 0
    End Sub

    Private Sub mod_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mod_button.Click
        Dim SQL As String
        'Dim msk_ToPlan As Object
        'Dim msk_FromPlan As Object
        Dim lRow As Integer
        Dim i As Short
        Dim gubun As String

        gubun = "3"

        On Error Resume Next
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        If Code_Txt.Text = "" Then
            Call MsgBox("������ �ڵ带 �Է��ϼ���", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            Code_Txt.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If

        If apply_Txt.Text = "" Then
            Call MsgBox("������ ���뿩�θ� �Է��ϼ���", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            apply_Txt.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If

        '��¥ üũ
        If g_Date_Check(txtFromDate.Text) = False Then
            MsgBox("��¥�Է��� �߸��Ǿ����ϴ�", 64, "Error Message")
            txtFromDate.Text = ""
            Exit Sub
        ElseIf g_Date_Check(txtToDate.Text) = False Then
            MsgBox("��¥�Է��� �߸��Ǿ����ϴ�", 64, "Error Message")
            txtToDate.Text = ""
            Exit Sub
        ElseIf txtFromDate.Text > txtToDate.Text Then
            MsgBox("�Ⱓ �Է��� �߸��Ǿ����ϴ�", 64, "Error Message")
            Exit Sub
        End If

        If remark_Txt.Text = "" Then
            Call MsgBox("������ �˾������� �Է��ϼ���", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            remark_Txt.Focus()
            Exit Sub
        End If


        SQL = " exec s_frmPopupManage " & " '" & gubun & "'," & " '" & Trim(Code_Txt.Text) & "'," & " '" & Trim(txtFromDate.Text) & "'," & " '" & Trim(txtToDate.Text) & "'," & " '" & Trim(apply_Txt.Text) & "'," & " '" & Trim(remark_Txt.Text) & "'"
        Dim g As GRSClass = New GRSClass(SQL)

        Call MsgBox("�����Ͽ����ϴ�..", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)

        Call Data_clear()
        Call sear_button_Click(sear_button, New System.EventArgs())
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        On Error GoTo 0
    End Sub

    Private Sub del_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles del_button.Click
        Dim SQL As String
        Dim lRow As Integer
        Dim i As Short
        Dim gubun As String

        gubun = "4"

        On Error Resume Next
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        If Code_Txt.Text = "" Then
            Call MsgBox("������ CODE�� �Է��ϼ���", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Code_Txt.Focus()
            Exit Sub
        End If


        SQL = " exec s_frmPopupManage " & " '" & gubun & "'," & " '" & Trim(Code_Txt.Text) & "','','','',''"
        g = New GRSClass(SQL)

        Call MsgBox("�����Ͽ����ϴ�..", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)


        Call Data_clear()
        Call sear_button_Click(sear_button, New System.EventArgs())
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

        On Error GoTo 0
    End Sub

    Private Sub beg_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles beg_button.Click
        Call Data_clear()
        Code_Txt.Focus()
    End Sub

    Private Sub see_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles see_button.Click

        Dim ggg As String
        Dim Buff As String
        Dim before_string As String
        Dim after_string As String

        If apply_Txt.Text = "Y" Or apply_Txt.Text = "y" Then

            before_string = "<HTML><HEAD><TITLE>��������</TITLE> " & "</HEAD>" & "<BODY background=NOTICE.jpg>" & "<FORM><table width=400 height = 300>" & "<TABLE BORDER=0>" & "<TR>" & "<TD width = 2 height = 200> &nbsp; </TD>" & "<TD height = 200>"
            after_string = "</TD> " & "</TR> <TR>" & "<TD width = 2 height = 100> &nbsp; </TD> " & "<TD height = 100> " & "<FONT face='����' size = 3>����ó:��Ƽ�� â�� ����� (�� 055-269-4342) </font><BR> " & "<FONT face=arial color=red size=3><B><U>cwadmin@otis.co.kr</U></B></FONT><BR><BR> " & "<font face='����' size =2><INPUT onclick=checkCount(); type=checkbox name=popup>������ �Ϸ絿�� ��â�� ���� �ʽ��ϴ�. </FONT> " & "</TD></TR></TABLE></FORM>      </BODY></HTML>"


            Buff = before_string & remark_Txt.Text & after_string

            FileOpen(2, My.Application.Info.DirectoryPath & "\view_popup.html", OpenMode.Output)
            PrintLine(2, Buff)
            FileClose(2)

            ggg = My.Application.Info.DirectoryPath & "\review_popup.html"

            WebBrowser1.Navigate(New System.Uri((ggg)))

        ElseIf apply_Txt.Text = "F" Or apply_Txt.Text = "f" Then
            before_string = "<META http-equiv=Content-Type content='text/html; charset=ks_c_5601-1987'><LINK href='style.css' type=text/css rel=stylesheet>" _
                            & "<TABLE height='100%' cellSpacing=0 cellPadding=0 width='100%' border=0><TBODY><TR><TD align=middle><TABLE cellSpacing=0 cellPadding=0 width=474 border=0>" _
                                & "<TBODY><TR><TD><IMG height=14 src='card_box_top.gif' width=474></TD></TR><TR><TD align=middle background='card_box_middle.gif'>" _
                                & "<TABLE class=st_lead130 cellSpacing=0 cellPadding=0 width=390 border=0><TBODY><TR><TD><IMG height=35 src='' width=5></TD></TR><TR><TD align=middle>" _
                                & "<IMG height=23 src='card_box_testingtitle.gif' width=281></TD></TR><TR><TD><IMG height=30 src='' width=5></TD></TR><TR><TD vAlign=top>"
            after_string = "<P align=center></P></TD></TR><TR><TD><IMG height=25 src='' width=5></TD></TR><TR><TD align=middle><DIV align=right></DIV></TD></TR><TR><TD height=14><IMG height=14 src='' width=5>" _
                            & "</TD></TR></TBODY></TABLE></TD></TR><TR><TD><IMG height=27 src='card_box_bottom.gif' width=474></TD></TR><TR><TD height=50>&nbsp;</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>"


            Buff = before_string & remark_Txt.Text & after_string

            FileOpen(2, My.Application.Info.DirectoryPath & "\front_view_popup.html", OpenMode.Output)
            PrintLine(2, Buff)
            FileClose(2)

            ggg = My.Application.Info.DirectoryPath + "\front_review_popup.html"

            WebBrowser1.Navigate(ggg)
        Else
            Call MsgBox("���뿩�ΰ� N�̸� �̸����Ⱑ �ȵ˴ϴ�.", (vbOKOnly + vbInformation))
        End If

    End Sub

    Private Sub see_button_1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles see_button_1.Click
        Dim ggg As Object
        Dim Buff As String
        Dim after_string As String
        Dim before_string As String

        before_string = "<META http-equiv=Content-Type content='text/html; charset=ks_c_5601-1987'><LINK href='style.css' type=text/css rel=stylesheet>" & "<TABLE height='100%' cellSpacing=0 cellPadding=0 width='100%' border=0><TBODY><TR><TD align=middle><TABLE cellSpacing=0 cellPadding=0 width=474 border=0>" & "<TBODY><TR><TD><IMG height=14 src='card_box_top.gif' width=474></TD></TR><TR><TD align=middle background='card_box_middle.gif'>" & "<TABLE class=st_lead130 cellSpacing=0 cellPadding=0 width=390 border=0><TBODY><TR><TD><IMG height=35 src='' width=5></TD></TR><TR><TD align=middle>" & "<IMG height=23 src='card_box_testingtitle.gif' width=281></TD></TR><TR><TD><IMG height=30 src='' width=5></TD></TR><TR><TD vAlign=top>"
        after_string = "<P align=center></P></TD></TR><TR><TD><IMG height=25 src='' width=5></TD></TR><TR><TD align=middle><DIV align=right></DIV></TD></TR><TR><TD height=14><IMG height=14 src='' width=5>" & "</TD></TR></TBODY></TABLE></TD></TR><TR><TD><IMG height=27 src='card_box_bottom.gif' width=474></TD></TR><TR><TD height=50>&nbsp;</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>"

        Buff = before_string & remark_Txt.Text & after_string

        FileOpen(2, My.Application.Info.DirectoryPath & "\front_view_popup.html", OpenMode.Output)
        PrintLine(2, Buff)
        FileClose(2)

        ggg = My.Application.Info.DirectoryPath & "\front_review_popup.html"

        WebBrowser1.Navigate(New System.Uri((ggg)))
    End Sub

    Private Sub can_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles can_button.Click
        Me.Close()
    End Sub
 

    Private Sub sp_pop_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles sp_pop.CellClick
        Dim SQL As String
        Dim code As String
        Dim g As GRSClass
        Dim row As Integer
        row = e.Row

        Code_Txt.Text = gSpread_CellValue1(sp_pop, row, 0)
        code = Code_Txt.Text
        txtFromDate.Text = gSpread_CellValue1(sp_pop, row, 1)
        txtToDate.Text = gSpread_CellValue1(sp_pop, row, 2)
        apply_Txt.Text = gSpread_CellValue1(sp_pop, row, 3)


        SQL = " exec s_frmPopupManage " & " '1','" & code & "','','','',''"
        g = New GRSClass(SQL)

        If g.RowCount = 0 Then
            Call MsgBox("�����ϴ� �����Ͱ� �����ϴ�.", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            Call Data_clear()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
            Exit Sub
        End If

        For inx As Integer = 0 To g.RowCount - 1
            remark_Txt.Text = Trim(g.gRS(4))
            g.MoveNext()
        Next
    End Sub
End Class