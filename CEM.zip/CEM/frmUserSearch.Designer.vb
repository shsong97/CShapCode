<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmUserSearch
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents txtFromDate As System.Windows.Forms.TextBox
	Public WithEvents txtToDate As System.Windows.Forms.TextBox
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Frame3 As System.Windows.Forms.GroupBox
	Public WithEvents txtValue As System.Windows.Forms.TextBox
	Public WithEvents txtUserName As System.Windows.Forms.TextBox
	Public WithEvents txtUserID As System.Windows.Forms.TextBox
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents CmdSave As System.Windows.Forms.Button
	Public WithEvents _Check1_3 As System.Windows.Forms.CheckBox
	Public WithEvents _Check1_2 As System.Windows.Forms.CheckBox
	Public WithEvents _Check1_1 As System.Windows.Forms.CheckBox
	Public WithEvents _Check1_0 As System.Windows.Forms.CheckBox
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents CmdClose As System.Windows.Forms.Button
	Public WithEvents CmdQuery As System.Windows.Forms.Button
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.Frame3 = New System.Windows.Forms.GroupBox
        Me.txtFromDate = New System.Windows.Forms.TextBox
        Me.txtToDate = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtValue = New System.Windows.Forms.TextBox
        Me.Frame2 = New System.Windows.Forms.GroupBox
        Me.txtUserName = New System.Windows.Forms.TextBox
        Me.txtUserID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.CmdSave = New System.Windows.Forms.Button
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me._Check1_3 = New System.Windows.Forms.CheckBox
        Me._Check1_2 = New System.Windows.Forms.CheckBox
        Me._Check1_1 = New System.Windows.Forms.CheckBox
        Me._Check1_0 = New System.Windows.Forms.CheckBox
        Me.CmdClose = New System.Windows.Forms.Button
        Me.CmdQuery = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.sprSearch = New FarPoint.Win.Spread.FpSpread
        Me.sprSearch_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.frmButton.SuspendLayout()
        Me.Frame3.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.Frame1.SuspendLayout()
        CType(Me.sprSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSearch_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.Frame3)
        Me.frmButton.Controls.Add(Me.txtValue)
        Me.frmButton.Controls.Add(Me.Frame2)
        Me.frmButton.Controls.Add(Me.CmdSave)
        Me.frmButton.Controls.Add(Me.Frame1)
        Me.frmButton.Controls.Add(Me.CmdClose)
        Me.frmButton.Controls.Add(Me.CmdQuery)
        Me.frmButton.Controls.Add(Me.Label5)
        Me.frmButton.Controls.Add(Me.Label4)
        Me.frmButton.Controls.Add(Me.Label3)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(865, 89)
        Me.frmButton.TabIndex = 1
        Me.frmButton.TabStop = False
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.SystemColors.Control
        Me.Frame3.Controls.Add(Me.txtFromDate)
        Me.Frame3.Controls.Add(Me.txtToDate)
        Me.Frame3.Controls.Add(Me.Label7)
        Me.Frame3.Controls.Add(Me.Label6)
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(416, 16)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(185, 65)
        Me.Frame3.TabIndex = 18
        Me.Frame3.TabStop = False
        Me.Frame3.Text = "����ó������"
        '
        'txtFromDate
        '
        Me.txtFromDate.AcceptsReturn = True
        Me.txtFromDate.BackColor = System.Drawing.SystemColors.Window
        Me.txtFromDate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFromDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFromDate.Location = New System.Drawing.Point(56, 16)
        Me.txtFromDate.MaxLength = 0
        Me.txtFromDate.Name = "txtFromDate"
        Me.txtFromDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFromDate.Size = New System.Drawing.Size(119, 20)
        Me.txtFromDate.TabIndex = 20
        '
        'txtToDate
        '
        Me.txtToDate.AcceptsReturn = True
        Me.txtToDate.BackColor = System.Drawing.SystemColors.Window
        Me.txtToDate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtToDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtToDate.Location = New System.Drawing.Point(56, 38)
        Me.txtToDate.MaxLength = 0
        Me.txtToDate.Name = "txtToDate"
        Me.txtToDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtToDate.Size = New System.Drawing.Size(119, 20)
        Me.txtToDate.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(8, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(36, 13)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "From :"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(24, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(26, 13)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "To :"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtValue
        '
        Me.txtValue.AcceptsReturn = True
        Me.txtValue.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtValue.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtValue.Enabled = False
        Me.txtValue.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtValue.Location = New System.Drawing.Point(794, 66)
        Me.txtValue.MaxLength = 0
        Me.txtValue.Name = "txtValue"
        Me.txtValue.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtValue.Size = New System.Drawing.Size(45, 20)
        Me.txtValue.TabIndex = 15
        Me.txtValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.txtUserName)
        Me.Frame2.Controls.Add(Me.txtUserID)
        Me.Frame2.Controls.Add(Me.Label2)
        Me.Frame2.Controls.Add(Me.Label1)
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(8, 16)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(225, 65)
        Me.Frame2.TabIndex = 10
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "����ڰ˻�"
        '
        'txtUserName
        '
        Me.txtUserName.AcceptsReturn = True
        Me.txtUserName.BackColor = System.Drawing.SystemColors.Window
        Me.txtUserName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUserName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUserName.Location = New System.Drawing.Point(78, 38)
        Me.txtUserName.MaxLength = 0
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUserName.Size = New System.Drawing.Size(119, 20)
        Me.txtUserName.TabIndex = 14
        '
        'txtUserID
        '
        Me.txtUserID.AcceptsReturn = True
        Me.txtUserID.BackColor = System.Drawing.SystemColors.Window
        Me.txtUserID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUserID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUserID.Location = New System.Drawing.Point(78, 16)
        Me.txtUserID.MaxLength = 0
        Me.txtUserID.Name = "txtUserID"
        Me.txtUserID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUserID.Size = New System.Drawing.Size(119, 20)
        Me.txtUserID.TabIndex = 13
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(14, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "����� �� :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(14, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "����� ID :"
        '
        'CmdSave
        '
        Me.CmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.CmdSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdSave.Location = New System.Drawing.Point(696, 16)
        Me.CmdSave.Name = "CmdSave"
        Me.CmdSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdSave.Size = New System.Drawing.Size(73, 25)
        Me.CmdSave.TabIndex = 9
        Me.CmdSave.Text = "����"
        Me.CmdSave.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me._Check1_3)
        Me.Frame1.Controls.Add(Me._Check1_2)
        Me.Frame1.Controls.Add(Me._Check1_1)
        Me.Frame1.Controls.Add(Me._Check1_0)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(240, 16)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(169, 65)
        Me.Frame1.TabIndex = 4
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "�ٹ�����"
        '
        '_Check1_3
        '
        Me._Check1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Check1_3.Checked = True
        Me._Check1_3.CheckState = System.Windows.Forms.CheckState.Checked
        Me._Check1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Check1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Check1_3.Location = New System.Drawing.Point(98, 40)
        Me._Check1_3.Name = "_Check1_3"
        Me._Check1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Check1_3.Size = New System.Drawing.Size(56, 17)
        Me._Check1_3.TabIndex = 8
        Me._Check1_3.Text = "����"
        Me._Check1_3.UseVisualStyleBackColor = False
        '
        '_Check1_2
        '
        Me._Check1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Check1_2.Checked = True
        Me._Check1_2.CheckState = System.Windows.Forms.CheckState.Checked
        Me._Check1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Check1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Check1_2.Location = New System.Drawing.Point(98, 20)
        Me._Check1_2.Name = "_Check1_2"
        Me._Check1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Check1_2.Size = New System.Drawing.Size(68, 17)
        Me._Check1_2.TabIndex = 7
        Me._Check1_2.Text = "���� "
        Me._Check1_2.UseVisualStyleBackColor = False
        '
        '_Check1_1
        '
        Me._Check1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Check1_1.Checked = True
        Me._Check1_1.CheckState = System.Windows.Forms.CheckState.Checked
        Me._Check1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Check1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Check1_1.Location = New System.Drawing.Point(20, 40)
        Me._Check1_1.Name = "_Check1_1"
        Me._Check1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Check1_1.Size = New System.Drawing.Size(53, 16)
        Me._Check1_1.TabIndex = 6
        Me._Check1_1.Text = "����"
        Me._Check1_1.UseVisualStyleBackColor = False
        '
        '_Check1_0
        '
        Me._Check1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Check1_0.Checked = True
        Me._Check1_0.CheckState = System.Windows.Forms.CheckState.Checked
        Me._Check1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Check1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Check1_0.Location = New System.Drawing.Point(20, 20)
        Me._Check1_0.Name = "_Check1_0"
        Me._Check1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Check1_0.Size = New System.Drawing.Size(53, 17)
        Me._Check1_0.TabIndex = 5
        Me._Check1_0.Text = "����"
        Me._Check1_0.UseVisualStyleBackColor = False
        '
        'CmdClose
        '
        Me.CmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.CmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdClose.Location = New System.Drawing.Point(776, 16)
        Me.CmdClose.Name = "CmdClose"
        Me.CmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdClose.Size = New System.Drawing.Size(73, 25)
        Me.CmdClose.TabIndex = 3
        Me.CmdClose.Text = "����"
        Me.CmdClose.UseVisualStyleBackColor = False
        '
        'CmdQuery
        '
        Me.CmdQuery.BackColor = System.Drawing.SystemColors.Control
        Me.CmdQuery.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdQuery.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdQuery.Location = New System.Drawing.Point(616, 16)
        Me.CmdQuery.Name = "CmdQuery"
        Me.CmdQuery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdQuery.Size = New System.Drawing.Size(73, 25)
        Me.CmdQuery.TabIndex = 2
        Me.CmdQuery.Text = "��ȸ"
        Me.CmdQuery.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(624, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(175, 13)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "( ����,���� �� -> ���� ���氡�� )"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(732, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "��ȸ�Ǽ� :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(840, 70)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(19, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "��"
        '
        'sprSearch
        '
        Me.sprSearch.AccessibleDescription = ""
        Me.sprSearch.Location = New System.Drawing.Point(0, 95)
        Me.sprSearch.Name = "sprSearch"
        Me.sprSearch.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSearch_Sheet1})
        Me.sprSearch.Size = New System.Drawing.Size(865, 422)
        Me.sprSearch.TabIndex = 2
        '
        'sprSearch_Sheet1
        '
        Me.sprSearch_Sheet1.Reset()
        Me.sprSearch_Sheet1.SheetName = "Sheet1"
        '
        'frmUserSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(872, 529)
        Me.Controls.Add(Me.sprSearch)
        Me.Controls.Add(Me.frmButton)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(17, 116)
        Me.Name = "frmUserSearch"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "����� ���� ���� ( frmUserSearch )"
        Me.frmButton.ResumeLayout(False)
        Me.frmButton.PerformLayout()
        Me.Frame3.ResumeLayout(False)
        Me.Frame3.PerformLayout()
        Me.Frame2.ResumeLayout(False)
        Me.Frame2.PerformLayout()
        Me.Frame1.ResumeLayout(False)
        CType(Me.sprSearch, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSearch_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents sprSearch As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSearch_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class