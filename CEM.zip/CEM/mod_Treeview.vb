Option Strict Off
Option Explicit On
Module mod_Treeview
    Public gtrvX As TreeView '���� ���ǰ� �ִ� Ʈ����
    Public gnodX As TreeNode '���� ���ǰ� �ִ� ���
    Public gParentNodX As TreeNode '���� ���ǰ� �ִ� �θ� ���
    Public gs_CurMgmt As String '���� ���ǰ� �ִ� �����׸� --- ROOT KEY�� �պκ�
    Public gi_NodeLevel As Short '��巹�� 0;root
    Public gs_ActiveFlag As String 'gs_ActiveFlag ����
    Private isLeafNode As Boolean
    Private isAlreadyExpanded As Boolean
    Private i_Cnt As Short
    Private i_Pos As Short
    Private is_Temp As String

    '��带 Ȯ���Ѵ�.
    Public Sub g_ExpandNode(Optional ByVal expand As Boolean = True)

        On Error GoTo Err_Handler

        Dim nodT As TreeNode '�ӽ�
        Dim g As GRSClass = Nothing

        '�̹� Ȯ��� ���
        isAlreadyExpanded = False
        isLeafNode = False
        If gnodX.FirstNode IsNot Nothing Then
            isAlreadyExpanded = True
        End If

        Call gSetCurMgmt()

        Select Case gs_CurMgmt

            ' ---------------------------------------------------------------------------------------------------
            Case "U" '����� ����

                Select Case gnodX.Tag

                    Case "M_U" '����� ���� ROOT

                        glivX.Items.Clear()
                        glivX.Columns.Clear()
                        Call g_DisplayListviewHeader()

                        If isAlreadyExpanded = False Then
                            nodT = gnodX.Nodes.Add("�׷�", "�׷�", UserIcon.Close, UserIcon.Open)
                            nodT.Tag = "C_G"
                            nodT = gnodX.Nodes.Add("�����", "�����", UserIcon.Close, UserIcon.Open)
                            nodT.Tag = "C_U"
                        End If
                        gitmX = glivX.Items.Add("�׷�", "�׷�", UserIcon.Close)
                        gitmX.SubItems.Add("�׷���� ���������Դϴ�.")
                        gitmX.Tag = "C_G"
                        gitmX = glivX.Items.Add("�����", "�����", UserIcon.Close)
                        gitmX.SubItems.Add("����ڵ��� ���������Դϴ�.")
                        gitmX.Tag = "C_U"
                        If Not isAlreadyExpanded And expand Then
                            gnodX.Expand()
                        End If

                        Exit Sub

                    Case "C_G" '�׷� ����Ʈ ��ȸ

                        Gsql = "SELECT GROUP_ID,GROUP_NAME,GROUP_SEC_LEVEL,CHNG_DATE,CHNG_ID  FROM GROUP_INFO"
                        Gsql = Gsql & " order by group_id "
                        g = New GRSClass(Gsql)

                        'Ʈ���� ����
                        If isAlreadyExpanded = False Then
                            For inx As Integer = 0 To g.RowCount - 1
                                nodT = gnodX.Nodes.Add(g.gRS(0), g.gRS(1), UserIcon.Group, UserIcon.Group)
                                nodT.Tag = "G_X"
                                g.MoveNext()
                            Next
                        End If

                    Case "G_X" '�׷� ���� ����� ��ȸ

                        Gsql = "SELECT user_id, username = ( CASE user_type WHEN 'G' THEN"
                        Gsql = Gsql & "             ( SELECT group_name FROM group_info WHERE group_id = N.user_id)"
                        Gsql = Gsql & "          ELSE "
                        Gsql = Gsql & "               (SELECT user_name_k FROM user_info WHERE user_id = N.user_id)"
                        Gsql = Gsql & "          END ), "
                        Gsql = Gsql & " authority, chng_date, chng_id, user_type "
                        Gsql = Gsql & " FROM grouping_info N" & " WHERE N.group_id = '" & gnodX.Name & "'"
                        Gsql = Gsql & " order by user_id    "
                        g = New GRSClass(Gsql)
                        If isAlreadyExpanded = False And expand Then
                            For inx As Integer = 0 To g.RowCount - 1
                                nodT = gnodX.Nodes.Add(g.gRS("User_ID"), g.gRS("UserName"), UserIcon.User)
                                If g.gRS("User_type") = "G" Then
                                    nodT.Tag = "G_X"
                                    nodT.ImageIndex = UserIcon.Group
                                Else
                                    nodT.Tag = "U_X"
                                    nodT.ImageIndex = UserIcon.User
                                    isLeafNode = True
                                End If

                                g.MoveNext()
                            Next
                        End If

                    Case "C_U" '����ڰ��� ( ����������κ��� ����Ÿ�� ���ڰ���)

                        Gsql = " SELECT USER_ID,USER_NAME_K,SECURITY_LEVEL,"
                        Gsql = Gsql & " CHNG_DATE,CHNG_ID "
                        Gsql = Gsql & " FROM USER_INFO"
                        Gsql = Gsql & " WHERE ACTIVE_FLAG <> 'T' AND ACTIVE_FLAG <> 'D' "
                        Gsql = Gsql & " order by user_id "

                        g = New GRSClass(Gsql)

                        If isAlreadyExpanded = False And expand Then
                            For inx As Integer = 0 To g.RowCount - 1
                                nodT = gnodX.Nodes.Add(g.gRS(0), g.gRS(1), UserIcon.User)
                                nodT.Tag = "U_X"
                                g.MoveNext()
                            Next
                        End If
                        isLeafNode = True
                    Case "U_X" '�����
                        isLeafNode = True
                        glivX.Tag = gnodX.Parent.FullPath
                        Call gFindListItem()
                        Exit Sub
                    Case Else
                        Exit Sub
                End Select
                If Not isAlreadyExpanded And isLeafNode = False Then
                    gnodX.Expand()
                End If
                Call g_gRStoglivX(g)
                ' --------------------------------------------------------------------------------------------------
            Case "A" '�������α׷� ����

                Select Case gnodX.Tag

                    Case "M_A" '�����ΰ��� ROOT,�����ε��� SELECT
                        Gsql = "SELECT DISTINCT domain  FROM app_prog_info "
                        Gsql = Gsql & " order by domain "
                        g = New GRSClass(Gsql)
                        'Ʈ���� ����
                        If isAlreadyExpanded = False Then
                            For inx As Integer = 0 To g.RowCount - 1
                                nodT = gnodX.Nodes.Add(g.gRS("Domain"), g.gRS("Domain"), UserIcon.Close, UserIcon.Open)
                                nodT.Tag = "DMX"
                                g.MoveNext()
                            Next
                        End If

                    Case "DMX" '������ ���� ���� ���α׷�
                        Gsql = "SELECT app_program, app_program_desc, chng_date, chng_id "
                        Gsql = Gsql & " FROM app_prog_info WHERE domain = '" & gnodX.Text & "'"
                        Gsql = Gsql & " order by app_program "
                        g = New GRSClass(Gsql)

                        'Ʈ���� ����
                        If isAlreadyExpanded = False Then
                            For inx As Integer = 0 To g.RowCount - 1
                                nodT = gnodX.Nodes.Add(g.gRS("App_Program"), g.gRS("app_program_desc"), UserIcon.App, UserIcon.App)
                                nodT.Tag = "APX"
                                g.MoveNext()
                            Next
                        End If

                    Case "APX" '�������α׷�

                        Gsql = "SELECT program, program_name = ( "
                        Gsql = Gsql & "           select program_name from program_info where program = A.program ), "
                        Gsql = Gsql & "       chng_date, chng_id "
                        Gsql = Gsql & "  FROM app_prog_mem_info A "
                        Gsql = Gsql & "  WHERE domain = '"
                        Gsql = Gsql & gnodX.Parent.Name
                        Gsql = Gsql & "'" & "    AND app_program = '" & gnodX.Name & "'"
                        Gsql = Gsql & " order by program "

                        g = New GRSClass(Gsql)

                        'Ʈ���� ����
                        If isAlreadyExpanded = False And expand Then
                            For inx As Integer = 0 To g.RowCount - 1
                                nodT = gnodX.Nodes.Add(g.gRS("Program"), g.gRS("program_name"), UserIcon.Program, UserIcon.Program)
                                nodT.Tag = "P_X"
                                g.MoveNext()
                            Next
                        End If

                    Case "P_X" '���α׷� ���ý� �����ִ� ����� ��ȸ

                        Gsql = "SELECT user_id, "
                        Gsql = Gsql & "        username = ( CASE user_type" & "          WHEN 'G' THEN"
                        Gsql = Gsql & "             ( SELECT group_name FROM group_info WHERE group_id = N.user_id)"
                        Gsql = Gsql & "          ELSE "
                        Gsql = Gsql & "               (SELECT user_name_k FROM user_info WHERE user_id = N.user_id)"
                        Gsql = Gsql & "          END ), "
                        Gsql = Gsql & " authority, chng_date, chng_id, user_type "
                        Gsql = Gsql & "  FROM prog_security N "
                        Gsql = Gsql & "  WHERE domain = '"
                        Gsql = Gsql & gnodX.Parent.Parent.Name
                        Gsql = Gsql & "'    AND app_program = '"
                        Gsql = Gsql & gnodX.Parent.Name
                        Gsql = Gsql & "'    AND program = '" & gnodX.Name & "'"
                        Gsql = Gsql & " order by user_id      "
                        g = New GRSClass(Gsql)

                        'Ʈ���� ����
                        If isAlreadyExpanded = False And expand Then
                            For inx As Integer = 0 To g.RowCount - 1
                                nodT = gnodX.Nodes.Add(g.gRS("User_ID"), g.gRS("UserName"), UserIcon.User, UserIcon.User)
                                If g.gRS("User_type") = "G" Then
                                    nodT.Tag = "G_X"
                                    nodT.ImageIndex = UserIcon.Group
                                    nodT.SelectedImageIndex = UserIcon.Group
                                Else
                                    nodT.Tag = "U_X"

                                End If
                                g.MoveNext()
                            Next
                        End If

                    Case "U_X" '���α׷� ��������
                        isLeafNode = True
                        Call gFindListItem()
                        Exit Sub
                    Case "G_X" '���α׷��� �׷� ��������
                        isLeafNode = True
                        'Call gFindListItem()
                        Exit Sub

                End Select
                If Not isAlreadyExpanded And isLeafNode = False And expand Then
                    gnodX.Expand()
                End If

                Call g_gRStoglivX(g)
                ' --------------------------------------------------------------------------------------------------
            Case "P" '���α׷�����

                Select Case gnodX.Tag

                    Case "M_P" '���α׷����� ROOT
                        Gsql = "SELECT program, program_name, version, chng_date, chng_id "
                        Gsql = Gsql & " FROM program_info "
                        Gsql = Gsql & " order by program"
                        g = New GRSClass(Gsql)

                        'Ʈ���� ����
                        If isAlreadyExpanded = False Then
                            For inx As Integer = 0 To g.RowCount - 1
                                nodT = gnodX.Nodes.Add(g.gRS("Program"), g.gRS("program_name"), UserIcon.Program, UserIcon.Program)
                                nodT.Tag = "P_X"
                                g.MoveNext()
                            Next
                        End If

                    Case "P_X" '���α׷�
                        isLeafNode = True
                        Call gFindListItem()
                        Exit Sub

                End Select
                If Not isAlreadyExpanded And isLeafNode = False And expand Then
                    gnodX.Expand()
                End If
                Call g_gRStoglivX(g)


            Case Else
                Exit Sub
        End Select 'Select Case gs_CurMgmt�� ��


        Exit Sub

Err_Handler:

        Select Case gF_Error_Handler()
            Case "X" : Exit Sub
            Case "N" : Resume Next
            Case "R" : Resume
            Case Else
        End Select

        Exit Sub
        MsgBox(ErrorToString())
        Resume

    End Sub

    Sub g_gRStoglivX(ByRef g As GRSClass)

        glivX.Items.Clear()
        glivX.Columns.Clear()
        g_DisplayListviewHeader()
        g.MoveFirst()
        Call g_DisplayListview(g)

    End Sub

    '������ ��з�
    Sub gSetCurMgmt()

        Dim nodT As TreeNode '�ӽ�
        nodT = gnodX
        gi_NodeLevel = gnodX.Level
        i_Pos = InStr(gnodX.FullPath, "\")

        If i_Pos > 0 Then      'node�� root�� �ƴϴ�.
            i_Cnt = 0
            Do Until i_Cnt = gi_NodeLevel
                nodT = nodT.Parent
                i_Cnt = i_Cnt + 1
            Loop

        End If
        gs_CurMgmt = Mid(nodT.Tag, 3, 1)

    End Sub

    '�ش����� �ڽĵ��� ��� �����Ѵ�.
    Public Sub gRemoveChildNode(ByRef nodX As TreeNode)

        'Dim i_Cnt As Short
        Dim iMaxCnt As Short
        iMaxCnt = nodX.Nodes.Count
        nodX.Nodes.Clear()

        'For i_Cnt = 0 To iMaxCnt - 1
        '    nodX.Nodes.RemoveAt(i_Cnt)
        'Next

    End Sub

    '����Ʈ���� �������� Ŭ���Ǿ��� �� �ش��ϴ� Ʈ������ ��带 ã�´�.
    Public Sub g_FindAndSelectNode()

        Dim nodT As TreeNode 'nodes�� child�� ���

        If gitmX Is Nothing Then Exit Sub

        Dim ar_Tag As String = gitmX.Tag
        Dim ar_Text As String = gitmX.Text

        'vb������ ��ü ��尡 ������
        '��ݿ����� �ش� ������ ��常 ���´�.
        For Each nodT In gParentNodX.Nodes
            If nodT.Tag = ar_Tag Then
                If gParentNodX.FullPath = glivX.Tag Then
                    If nodT.Name = ar_Text Then
                        gnodX = nodT
                        Exit For
                    End If
                End If
            End If
        Next nodT

        If gnodX Is Nothing Then
            MsgBox("������带 ������ �� �ٽú��� ��ư�� Ŭ���Ͻÿ�")
        End If

    End Sub

End Module