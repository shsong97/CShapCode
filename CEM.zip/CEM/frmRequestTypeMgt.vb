Option Strict Off
Option Explicit On
Friend Class frmRequestTypeMgt
	Inherits System.Windows.Forms.Form
	
	Private Sub cmdADD_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdADD.Click
        With sprList.Sheets(0)
            .RowCount = .RowCount + 1
            Call gSpreadMakeCheckCell(sprList, .RowCount - 1, 1, 1)
            .Cells(.RowCount - 1, .ColumnCount - 1).Text = "I"
        End With
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	Private Sub cmdInquery_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInquery.Click
		Call InqueryRequestType()
	End Sub
	
	Private Sub cmdSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSave.Click
		SaveRequestType()
		InqueryRequestType()
	End Sub
	
	Private Sub frmRequestTypeMgt_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		InqueryRequestType()
	End Sub
	
	Private Sub InqueryRequestType()
		On Error GoTo ErrHandler
		
        Gsql = " SELECT request_type, apply_flag, create_date, create_id, update_date, update_id,update_flag=''"
        Gsql = Gsql & "   FROM request_type "

        If Not gFillSpread(sprList, Gsql) Then GoTo ErrHandler
		Call gSpreadMakeCheckColumn(sprList, 1, 0)
		
		Exit Sub
ErrHandler: 
		Err.Clear()
	End Sub
	
	Private Sub SaveRequestType()
		On Error GoTo ErrHandler
        Dim i As Integer
        Dim g As GRSClass

        For i = 0 To sprList.Sheets(0).RowCount - 1
            With sprList.Sheets(0)

                If .Cells(i, 1).Text <> "1" Then GoTo next_loop
                If .Cells(i, .ColumnCount - 1).Text = "I" Then
                    Gsql = ""
                    Gsql = Gsql & " INSERT INTO request_type ( request_type, apply_flag, create_date, create_id, update_date, update_id )"
                    Gsql = Gsql & " VALUES ( '"
                    Gsql = Gsql & .Cells(i, 0).Text & "','"
                    Gsql = Gsql & .Cells(i, 1).Value & "',"

                    Gsql = Gsql & " getdate(),'"
                    Gsql = Gsql & gUSERID & "',"
                    Gsql = Gsql & " getdate(),'"
                    Gsql = Gsql & gUSERID & "' )"
                ElseIf .Cells(i, .ColumnCount - 1).Text = "U" Then
                    Gsql = ""
                    Gsql = Gsql & " UPDATE request_type"
                    Gsql = Gsql & " SET apply_flag = '" & .Cells(i, 1).Value & "',"
                    Gsql = Gsql & "     update_date = getdate(), "
                    Gsql = Gsql & "     update_id = '" & gUSERID & "'"
                    Gsql = Gsql & " WHERE request_type = '" & Trim(.Cells(i, 0).Text) & "'"
                Else
                    GoTo next_loop
                End If
            End With
            g = New GRSClass(Gsql)
next_loop:
        Next
		
		Exit Sub
ErrHandler: 
		Call gSetErrorMessage("", False)
		Err.Clear()
		Call gDisplayCemMessage()
	End Sub
	
	
	Private Sub frmRequestTypeMgt_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
        sprList.Width = Me.Width - 20
    End Sub
	
    'Private Sub sprList_Change(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ChangeEvent)
    '    'With sprList
    '    '	.eventArgs.Row = eventArgs.Row
    '    '	.eventArgs.Col = 1
    '    '	.Value = CStr(1)

    '    '	.eventArgs.Col = .MaxCols
    '    '	If .Text = "" Then .Text = "U"
    '    'End With
    'End Sub
End Class