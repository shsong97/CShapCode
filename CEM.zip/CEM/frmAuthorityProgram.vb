Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmAuthorityProgram
	Inherits System.Windows.Forms.Form
	
	Private Sub cboApplication_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboApplication.SelectedIndexChanged
        initialComboDate()
    End Sub
	
	Private Sub initialComboDate()
		Dim SQL As String
        Dim g As GRSClass
		Dim inx As Short
		
		TxtCode.Text = ""
		txtName.Text = ""
		
		SQL = ""
		SQL = SQL & " SELECT DISTINCT work_date "
		SQL = SQL & "   FROM app_prog_auth_hist "
		SQL = SQL & "  WHERE app_program = '" & Trim(VB.Right(cboApplication.Text, 50)) & "'"
		SQL = SQL & "  ORDER BY work_date DESC"
		
        g = New GRSClass(SQL)

		
		cboFromDate.Items.Clear()
		cboToDate.Items.Clear()
		
        For inx = 0 To g.RowCount - 1
            cboFromDate.Items.Add(g.gRS(0))
            cboToDate.Items.Add(g.gRS(0))
            g.MoveNext()
        Next inx
		
		If cboFromDate.Items.Count >= 2 Then
			cboFromDate.SelectedIndex = 1
			cboToDate.SelectedIndex = 0
		ElseIf cboFromDate.Items.Count = 1 Then 
			cboFromDate.SelectedIndex = 0
			cboToDate.SelectedIndex = 0
		End If
	End Sub
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	
	Private Sub cmdInqueryHistory_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInqueryHistory.Click
		InqueryHistory()
	End Sub
	
	Private Sub CmdList_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdList.Click
		If frmProgramList.lsQueryRun = True Then
			frmProgramList.ShowDialog()
		Else
			'MsgBox "���α׷��� ��ϵǾ� ���� �ʽ��ϴ�.", , "Ȯ��"
		End If
	End Sub
	

	Private Sub frmAuthorityProgram_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		gs_listCode = "1"
	End Sub
	
	Private Sub frmAuthorityProgram_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		gs_listCode = "1"
		Call lsAddComboBox()
		ShowForm(Me)
		
		
	End Sub
	Private Sub lsAddComboBox()
        Dim g As GRSClass
		Dim i As Integer
		'���ø����̼�
		Gsql = "SELECT app_program_desc,app_program "
		Gsql = Gsql & " FROM app_prog_info "
		Gsql = Gsql & " ORDER BY domain, app_program_desc"
		
        g = New GRSClass(Gsql)

		cboApplication.Items.Clear()
        For i = 0 To g.RowCount
            cboApplication.Items.Add(g.gRS(0) & Space(50) & g.gRS(1))
            g.MoveNext()
        Next i
		
		'VAN �ý��� �߰�
		cboApplication.Items.Add("VAN ������" & Space(50) & "VAN-I")
		cboApplication.Items.Add("VAN ����" & Space(50) & "VAN-A")
		cboApplication.Items.Add("VAN ����" & Space(50) & "VAN-M")
		cboApplication.Items.Add("VAN ����" & Space(50) & "VAN-P")
		cboApplication.Items.Add("VAN EL" & Space(50) & "VAN-E")
		
		cboApplication.SelectedIndex = 0
		
		TxtCode.Text = ""
		txtName.Text = ""
		
	End Sub
	
	Private Sub cmdInquery_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInquery.Click
		InqueryAllData()
	End Sub
	
	Private Sub InqueryAllData()
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		
		InqueryAppUserList()
		InqueryAppAuthority()
		InqueryCommonAppAuthority()
		initialComboDate()
		
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
	End Sub
	
	Private Function InqueryAppUserList() As Boolean
		
		Dim AppGroupCode As String
		
		On Error GoTo ErrHandler
		InqueryAppUserList = True
		
		AppGroupCode = Trim(VB.Right(cboApplication.Text, 50))
		
		If Mid(AppGroupCode, 1, 3) = "VAN" Then
			Exit Function
		Else
			Gsql = " EXEC s_getUserList '" & AppGroupCode & "'"
			
            If Not gFillSpread(spdUser, Gsql) Then GoTo ErrHandler
			
            'With spdUser
            '	.Row = -1
            '	.Col = 1
            '	.Action = SS_ACTION_DELETE_COL
            'End With
		End If
		Exit Function
ErrHandler: 
		Err.Clear()
		Call gDisplayCemMessage()
		InqueryAppUserList = False
	End Function
	
	Private Function InqueryAppAuthority() As Boolean
		Dim AppCode As String
		Dim ProgCode As String
		On Error GoTo ErrHandler
		InqueryAppAuthority = True
		
		AppCode = Trim(VB.Right(cboApplication.Text, 50))
		ProgCode = Trim(TxtCode.Text)
		Gsql = ""
		Gsql = Gsql & " EXEC sp_audit_authority_app "
		Gsql = Gsql & "'" & AppCode & "',"
		Gsql = Gsql & "'" & ProgCode & "',"
		Gsql = Gsql & "'" & CStr(chkSave.CheckState) & "'"
        If Not gFillSpread(spdProgram, Gsql) Then GoTo ErrHandler
		
		Exit Function
ErrHandler: 
		Err.Clear()
		Call gDisplayCemMessage()
		InqueryAppAuthority = False
	End Function
	
	Private Function InqueryCommonAppAuthority() As Boolean
		Dim AppCode As String
		Dim ProgCode As String
		On Error GoTo ErrHandler
		
		
		AppCode = Trim(VB.Right(cboApplication.Text, 50))
		ProgCode = Trim(TxtCode.Text)
		Gsql = ""
		Gsql = Gsql & " EXEC sp_audit_authority_common_app "
		Gsql = Gsql & "'" & AppCode & "'"
		
        If Not gFillSpread(spdCommonProgram, Gsql) Then GoTo ErrHandler
		
		Exit Function
ErrHandler: 
		Err.Clear()
		Call gDisplayCemMessage()
		
	End Function
	
	Private Function InqueryHistory() As Boolean
		
		Dim AppGroupCode As String
		
		On Error GoTo ErrHandler
		InqueryHistory = True
		
		AppGroupCode = Trim(VB.Right(cboApplication.Text, 50))
		
		Gsql = ""
		Gsql = Gsql & " EXEC sp_audit_authority_hist '"
		Gsql = Gsql & AppGroupCode & "','"
		Gsql = Gsql & cboFromDate.Text & "','"
		Gsql = Gsql & cboToDate.Text & "'"
		
        If Not gFillSpread(spdHistory, Gsql) Then GoTo ErrHandler
		
		Exit Function
ErrHandler: 
		Err.Clear()
		Call gDisplayCemMessage()
		InqueryHistory = False
	End Function
	
	

	Private Sub TxtCode_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtCode.Click
		TxtCode.Text = ""
		txtName.Text = ""
	End Sub
	
	Private Sub txtName_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtName.Click
		TxtCode.Text = ""
		txtName.Text = ""
	End Sub
End Class