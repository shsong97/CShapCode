Option Strict Off
Option Explicit On
Friend Class frmRetireSearch
	Inherits System.Windows.Forms.Form
	
	Sub F_new1()
        Call g_Spread_Clear(vaSpread1, 100)
    End Sub
	
	Sub F_new2()
        Call g_Spread_Clear(vaSpread2, 100)
    End Sub
	
	Sub F_new3()
        Call g_Spread_Clear(vaSpread3, 100)
    End Sub
	
	Sub F_new4()
        Call g_Spread_Clear(vaSpread4, 500)
    End Sub

	Private Sub frmRetireSearch_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
        txtFromDate1.Focus()
    End Sub
	
	Sub F_CLOSE()
		Me.Close()
	End Sub
	
	Private Sub frmRetireSearch_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		'�������� Clear
		Call g_Spread_Clear(vaSpread1, 10000)
		Call g_Spread_Clear(vaSpread2, 10000)
		Call g_Spread_Clear(vaSpread3, 10000)
		Call g_Spread_Clear(vaSpread4, 500)
	End Sub
	
    Sub g_Spread_Clear(ByRef spread As FarPoint.Win.Spread.FpSpread, ByVal MaxRow As Integer)
        With spread.Sheets(0)
            .RowCount = 0
            .RowCount = MaxRow
        End With
    End Sub
	
    Sub g_Spread_SetCell(ByRef spread As FarPoint.Win.Spread.FpSpread, ByVal Col As Integer, ByVal Row As Integer)
        'ȣ���� cursor focus�� spread�� set�����ش�. (spread.setfocus)
        With spread

            '.Row = Row
            '.Col = Col
            '.Position = 7 'bottom
            '.Action = 1 'SS_ACTION_goto_CELL
            '.Action = 0 'SS_ACTION_ACTIVE_CELL

        End With
    End Sub

    Private Sub cmdInit1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInit1.Click
        Call F_new1()
        Call g_Spread_SetCell(vaSpread1, 1, 1)
    End Sub

    Private Sub cmdSearch1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearch1.Click
        Dim sSQL As String
        Dim i As Integer
        Dim no As String
        Dim request_date As String
        Dim g As GRSClass

        If txtFromDate1.Text = "" Then
            MsgBox("From ��ȸ�Ⱓ�� �Է��ϼ���")
            txtFromDate1.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
            Exit Sub
        End If

        If txtToDate1.Text = "" Then
            MsgBox("From ��ȸ�Ⱓ�� �Է��ϼ���")
            txtToDate1.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
            Exit Sub
        End If

        If vaSpread1.Sheets(0).Cells(0, 0).Text = "" Then
            MsgBox("�߷�ó�����ڿ� ����� �����ؼ� �ٿ��ּ���")
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
        End If


        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Call g_Spread_SetCell(vaSpread1, 1, 1)

        With vaSpread1.Sheets(0)
            For i = 0 To .RowCount
                request_date = Trim(.Cells(i, 0).Text)
                no = Trim(.Cells(i, 1).Text)

                If no = "" Then
                    System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
                    Exit Sub
                End If

                If request_date = "" Then
                    System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
                    Exit Sub
                End If

                sSQL = " EXEC S_frmRetireSearch " & "'" & no & "'," & "'" & Trim(txtFromDate1.Text) & "'," & "'" & Trim(txtToDate1.Text) & "'," & "'" & request_date & "'"

                g = New GRSClass(sSQL)
                .Cells(i, 2).Text = g.gRS(0)
                .Cells(i, 3).Text = g.gRS(1)
                .Cells(i, 4).Text = g.gRS(2)
            Next i
        End With
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
    End Sub

    Private Sub cmdInit2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInit2.Click
        Call F_new2()
        Call g_Spread_SetCell(vaSpread2, 1, 1)
    End Sub

    Private Sub cmdSearch2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearch2.Click
        On Error GoTo ErrHandler
        Dim sSQL As String
        Dim i As Short
        Dim no As String
        Dim g As GRSClass

        If txtFromDate2.Text = "" Then
            MsgBox("From ��ȸ�Ⱓ�� �Է��ϼ���")
            txtFromDate2.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
            Exit Sub
        End If

        If txtToDate2.Text = "" Then
            MsgBox("From ��ȸ�Ⱓ�� �Է��ϼ���")
            txtToDate2.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
            Exit Sub
        End If

        sSQL = " EXEC S_frmRetireSearch_1 " & "'" & Trim(txtFromDate2.Text) & "'," & "'" & Trim(txtToDate2.Text) & "'"

        g = New GRSClass(sSQL)

        If g.RowCount > 0 Then

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            With vaSpread2.Sheets(0)
                .RowCount = 0
                .RowCount = g.RowCount

                For i = 1 To .RowCount
                    .Cells(i, 0).Text = g.gRS("request_date")
                    .Cells(i, 1).Text = g.gRS("user_id")
                    .Cells(i, 2).Text = g.gRS("user_name")
                    .Cells(i, 3).Text = g.gRS("unit")
                    .Cells(i, 4).Text = g.gRS("chng_id")
                    .Cells(i, 5).Text = g.gRS("bigo")
                    g.MoveNext()
                Next i
            End With
        Else
            Call g_Spread_Clear(vaSpread2, 100)
            MsgBox("��ȸ �ڷᰡ �����ϴ�.", MsgBoxStyle.Exclamation, Me.Text)
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
        Exit Sub

ErrHandler:
        Err.Clear()
    End Sub

    Private Sub cmdInit3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInit3.Click
        Call F_new3()
        Call g_Spread_SetCell(vaSpread3, 1, 1)
    End Sub

    Private Sub cmdSearch3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearch3.Click
        On Error GoTo ErrHandler
        Dim sSQL As String
        Dim i As Short
        Dim no As String
        Dim g As GRSClass

        If txtFromDate3.Text = "" Then
            MsgBox("From ��ȸ�Ⱓ�� �Է��ϼ���")
            txtFromDate3.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
            Exit Sub
        End If

        If txtToDate3.Text = "" Then
            MsgBox("From ��ȸ�Ⱓ�� �Է��ϼ���")
            txtToDate3.Focus()
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
            Exit Sub
        End If

        sSQL = " EXEC S_INSA_DOWN_EMP " & "'" & Trim(txtFromDate3.Text) & "'," & "'" & Trim(txtToDate3.Text) & "'"

        g = New GRSClass(sSQL)

        If g.RowCount > 0 Then

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            With vaSpread3.Sheets(0)
                .RowCount = 0
                .RowCount = g.RowCount

                For i = 0 To .RowCount
                    .Cells(i, 0).Text = g.gRS("emp_num")
                    .Cells(i, 1).Text = g.gRS("emp_name")
                    .Cells(i, 2).Text = g.gRS("unit")
                    .Cells(i, 3).Text = g.gRS("gubun")
                    .Cells(i, 4).Text = g.gRS("update_date")

                    g.MoveNext()
                Next i
            End With
        Else
            Call g_Spread_Clear(vaSpread3, 100)
            MsgBox("��ȸ �ڷᰡ �����ϴ�.", MsgBoxStyle.Exclamation, Me.Text)
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
        Exit Sub

ErrHandler:
        Err.Clear()
    End Sub

    Private Sub b_Init_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b_Init.Click
        Call F_new4()
        Call g_Spread_SetCell(vaSpread4, 1, 1)
    End Sub

    Private Sub b_Search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b_Search.Click
        Dim emp_id As String
        Dim sSQL As String
        Dim i As Integer

        If vaSpread4.Sheets(0).Cells(0, 0).Text = "" Then
            MsgBox("����� �ٿ��ּ���")
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Call g_Spread_SetCell(vaSpread4, 1, 1)

        For i = 0 To vaSpread4.Sheets(0).RowCount
            emp_id = Trim(vaSpread4.Sheets(0).Cells(i, 0).Text)

            If emp_id = "" Then
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
                Exit Sub
            End If

            sSQL = " EXEC S_frmRetireSearch_2 " & "'" & emp_id & "'"
            g = New GRSClass(sSQL)

            vaSpread4.Sheets(0).Cells(i, 1).Text = g.gRS(0)
            vaSpread4.Sheets(0).Cells(i, 2).Text = g.gRS(1)
            vaSpread4.Sheets(0).Cells(i, 3).Text = g.gRS(2)
            vaSpread4.Sheets(0).Cells(i, 4).Text = g.gRS(3)
            vaSpread4.Sheets(0).Cells(i, 5).Text = g.gRS(4)

        Next i

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
    End Sub

End Class