Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmUserAppSearch
	Inherits System.Windows.Forms.Form
	
	

	Private Sub cboApp_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboApp.SelectedIndexChanged
		If cboApp.Text = "" Then
            sprSearch.Sheets(0).RowCount = 0
		Else
			lsQueryRun()
		End If
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	
	Private Sub cmdDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDelete.Click
		Call lsDeleteGroupUser()
	End Sub
	
	Private Sub CmdQuery_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdQuery.Click
		Call lsQueryRun()
	End Sub
	
	
	Private Sub frmUserAppSearch_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call lsSeting()
		Call lsQryCombo("1")
	End Sub
	
	Private Sub lsSeting()
		Me.Show()
		Me.sprSearch.Width = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - 350)
		Me.sprSearch.Height = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - 2000)
	End Sub
	
	Private Sub lsQueryRun()
		On Error GoTo ErrHandler
		Dim GroupID As String
		
		GroupID = Trim(VB.Right(cboApp.Text, 50))
		
		gSQL = " EXEC s_getUserList '" & GroupID & "'"
		

		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		
        If Not gFillSpread(sprSearch, Gsql) Then GoTo ErrHandler
		
		Call gSpreadMakeCheckColumn(sprSearch, 1, 0)
		
		Call gSpreadCellLock(sprSearch, -1, 2)
		

		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        txtValue.Text = CStr(sprSearch.Sheets(0).RowCount)
		Exit Sub
		
ErrHandler: 

		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		Call gDisplayCemMessage()
		Exit Sub
		Resume 
	End Sub
	
	

	Private Sub Option1_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Option1.CheckedChanged
		If eventSender.Checked Then
			Call lsQryCombo("1")
		End If
	End Sub
	Private Sub lsQryCombo(ByRef QryGB As String)
		'QryGB 1 : Application
		'QryGB 2 : Group
		
		Dim i As Integer
		Dim Wstr As String
		
		If QryGB = "1" Then
			'Application
			Label1.Text = "Application"
			Wstr = " WHERE group_name like 'sys%' "
		Else
			'Group
			Label1.Text = "Group"
			Wstr = " WHERE group_name not like 'sys%' "
		End If
		
        Gsql = " SELECT group_name, group_id "
        Gsql = Gsql & " FROM group_info "
        Gsql = Gsql & Wstr
        Gsql = Gsql & " ORDER BY group_name"

        g = New GRSClass(Gsql)
		cboApp.Items.Clear()
		cboApp.Items.Add("")
		
        For i = 1 To g.RowCount
            cboApp.Items.Add(g.gRS(0) & Space(50) & g.gRS(1))
            g.MoveNext()
        Next i
		
		cboApp.SelectedIndex = 0
	End Sub
	

	Private Sub Option2_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Option2.CheckedChanged
		If eventSender.Checked Then
			Call lsQryCombo("2")
		End If
	End Sub

	
	Private Sub lsDeleteGroupUser()
		On Error GoTo ErrHandler
		Dim inx As Short
		Dim cnt As Short
        Dim g As GRSClass
		'�۾����� ���� Ȯ��
		If MsgBoxResult.No = MsgBox("���õ� ����ڰ� �׷쿡�� �����˴ϴ�. �۾��Ͻðڽ��ϱ�?", MsgBoxStyle.YesNo + MsgBoxStyle.Critical) Then
			Exit Sub
		End If
		
		'��û��ȣ ����
		If Not CheckRequestNo Then
			Exit Sub
		End If
		
        For inx = 0 To sprSearch.Sheets(0).RowCount - 1
            If gSpreadUnitDataFetch(sprSearch, inx, 0) = "1" Then

                Gsql = ""
                Gsql = Gsql & "EXEC sp_grouping_info_del "
                Gsql = Gsql & "'A','" 'P'�϶� �׷��ο��� parent ,'C'�϶� child,'A'�϶� all
                Gsql = Gsql & Trim(VB.Right(cboApp.Text, 50)) & "','" '�׷�
                Gsql = Gsql & "U','" '����ڱ���('G','U')
                Gsql = Gsql & Trim(gSpreadUnitDataFetch(sprSearch, inx, 1)) & "','" '�����ID
                Gsql = Gsql & gRequestNo & "'" '��û��ȣ

                g = New GRSClass(Gsql)

                cnt = cnt + 1
            End If
        Next inx
		
		MsgBox(CStr(cnt) & "�� �����Ǿ����ϴ�.")
		
		lsQueryRun()
		
		Exit Sub
ErrHandler: 
		If cnt > 0 Then MsgBox(CStr(cnt) & "�� �����Ǿ����ϴ�.")
		
		MsgBox(gErrorMessage & vbCrLf & Err.Description)
		Err.Clear()
	End Sub
End Class