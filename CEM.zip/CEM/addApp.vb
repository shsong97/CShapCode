Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frm_AppAdd
	Inherits System.Windows.Forms.Form
	
	Dim ib_ChangePW As Boolean
	Dim is_PrePW As String
	
	'edit���
	Public Function F_DBRecordDisplay() As Boolean

        F_DBRecordDisplay = True

        Gsql = ""
        Gsql = Gsql & " SELECT * "
        Gsql = Gsql & "   FROM app_prog_info"
        Gsql = Gsql & "  WHERE app_program = '" & txt_ID.Text & "'"
        Gsql = Gsql & "    AND domain = '" & txt_Domain.Text & "'"

        Dim g As GRSClass = New GRSClass(Gsql)

        If g.RowCount = 1 Then
            txtApp_Program_Desc.Text = g.gRS("app_program_desc")
            txtSource_Path.Text = g.gRS("source_path")
            txtTarget_Path.Text = g.gRS("target_path")
            txtMain_Server.Text = g.gRS("main_server")
            txtLogon.Text = g.gRS("LogOn")
            is_PrePW = g.gRS("Password")
            txtPassword.Text = g.gRS("Password")
            txtExtra_Server.Text = g.gRS("extra_server")
            txtMain_Database.Text = g.gRS("main_database")
            txtExtra_Database.Text = g.gRS("extra_database")
            txtDevelop_Tool.Text = g.gRS("develop_tool")
            txtCompany.Text = g.gRS("company")
            g_FindSetCombotIndex(cboDevelop_ID, g.gRS("develop_id"))
            txtDevelop_date.Text = VB6.Format(g.gRS("develop_date"), "yyyy/mm/dd hh:mm")
            txtVersion.Text = g.gRS("Version")
            g_FindSetCombotIndex(cboStatus, g.gRS("Status"))
            txtMemo.Text = g.gRS("Memo")
        Else
            F_DBRecordDisplay = False
            Exit Function
        End If


    End Function
	
    Sub LF_ComboInit()
        'Application ����
        cboStatus.Items.Clear()
        cboStatus.Items.Add("����" & Space(50) & "S")
        cboStatus.Items.Add("����" & Space(50) & "T")
        cboStatus.Items.Add("��� ����" & Space(50) & "P")
        cboStatus.Items.Add("���" & Space(50) & "C")

        '������
        Gsql = ""
        Gsql = Gsql & " select user_id, user_name_k "
        Gsql = Gsql & "   from user_info "
        Gsql = Gsql & "  where active_flag <> 'T' AND active_flag <> 'D' and security_level=0"
        Gsql = Gsql & "  order by user_id desc"

        Dim g As GRSClass = New GRSClass(Gsql)

        cboDevelop_ID.Items.Clear()
        For i As Integer = 0 To g.RowCount - 1
            cboDevelop_ID.Items.Add(g.gRS(1) & Space(50) & g.gRS(0))
            g.MoveNext()
        Next
    End Sub

    Private Sub frm_AppAdd_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        g_CenterForm(Me)
        LF_ComboInit()
    End Sub

    Private Sub txtPASSWORD_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtPassword.TextChanged
        If is_PrePW <> txtPassword.Text Then
            ib_ChangePW = True
            is_PrePW = txtPassword.Text
        End If
    End Sub

    Private Sub txtPASSWORD_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtPassword.Enter
        is_PrePW = txtPassword.Text
    End Sub

    Private Sub txtPASSWORD_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtPassword.Leave
        Dim enc As Encrypt = New Encrypt
        If ib_ChangePW Then
            txtPassword.Text = enc.EncryptPassword(txtPassword.Text)
            ib_ChangePW = False
        End If
    End Sub


    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        On Error GoTo Err_Handler


        Dim Kkey As String
        Dim enc As Encrypt = New Encrypt
        If Len(Trim(txt_ID.Text)) > 0 And Len(Trim(txt_Domain.Text)) > 0 Then
            txt_ID.Text = Trim(txt_ID.Text)
            txt_Domain.Text = Trim(txt_Domain.Text)
        Else
            Exit Sub
        End If

        If cmdOK.Text = "����" Then
            Kkey = "U"
        Else
            Kkey = "I"
        End If

        If Kkey = "I" And Len(txtPassword.Text) = 0 Then
            txtPassword.Text = enc.EncryptPassword(txtPassword.Text)

        End If

        Gsql = "exec sp_app_prog_info '"
        Gsql = Gsql & Kkey & "','"
        Gsql = Gsql & gUSERID & "','"
        Gsql = Gsql & txt_Domain.Text & "','"
        Gsql = Gsql & txt_ID.Text & "','"
        Gsql = Gsql & txtApp_Program_Desc.Text & "','"
        Gsql = Gsql & txtSource_Path.Text & "','"
        Gsql = Gsql & txtTarget_Path.Text & "','"
        Gsql = Gsql & txtMain_Server.Text & "','"
        Gsql = Gsql & txtLogon.Text & "','"
        Gsql = Gsql & txtPassword.Text & "','"
        Gsql = Gsql & txtExtra_Server.Text & "','"

        Gsql = Gsql & txtMain_Database.Text & "','"
        Gsql = Gsql & txtExtra_Database.Text & "','"
        Gsql = Gsql & txtDevelop_Tool.Text & "','"
        Gsql = Gsql & txtCompany.Text & "','"

        Gsql = Gsql & Trim(VB.Right(cboDevelop_ID.Text, 50)) & "','"
        Gsql = Gsql & IIf(IsDate(txtDevelop_date.Text), txtDevelop_date.Text, Today) & "','"
        Gsql = Gsql & Trim(txtVersion.Text) & "','"
        Gsql = Gsql & VB.Right(cboStatus.Text, 1) & "','"
        Gsql = Gsql & txtMemo.Text & "'"

        g = New GRSClass(Gsql)


        If cmdOK.Text = "����" Then
            Me.Close()
        Else
            txt_ID.Text = ""
            If txt_Domain.Enabled = True Then txt_Domain.Text = ""
            txtApp_Program_Desc.Text = ""
            Me.Close()
        End If

        Exit Sub
Err_Handler:
        Select Case gF_Error_Handler()
            Case "X" : Exit Sub
            Case "R" : Resume
            Case "N" : Resume Next
            Case Else
                Exit Sub
        End Select
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub
End Class