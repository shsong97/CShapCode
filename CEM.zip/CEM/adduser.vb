Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frm_UserAdd
	Inherits System.Windows.Forms.Form
	
    Sub LF_ComboInit()
        cboActiveFlag.Items.Clear()

        cboActiveFlag.Items.Add("����" & Space(50) & "C")
        cboActiveFlag.Items.Add("����" & Space(50) & "H")
        cboActiveFlag.Items.Add("����" & Space(50) & "T")
        cboActiveFlag.Items.Add("����" & Space(50) & "D")

        cboSecurity_rule.Items.Clear()
        cboSecurity_rule.Items.Add("��   ��   ��" & Space(50) & "U")
        cboSecurity_rule.Items.Add("��        ��" & Space(50) & "L")
        cboSecurity_rule.Items.Add("Password����" & Space(50) & "P")
        cboSecurity_rule.Items.Add("3���� �̻��" & Space(50) & "M")

        txt_ID.Text = ""
        txt_ID.Enabled = True
        txtSecurity_num.Text = ""
        cboSecurity_rule.SelectedIndex = 0
        cboActiveFlag.SelectedIndex = 0
        txtSecurity_level.Text = ""
        txtMail_id.Text = ""
        txtMrpID.Text = ""
        txtUser_Name_K.Text = ""
        txtUser_Name_E.Text = ""
        txtCountry.Text = ""
        txtCity_name.Text = ""
        txtGu_name.Text = ""
        txtAddress.Text = ""
        txtZip_code.Text = ""
        txtCompany.Text = ""
        txtWork_area.Text = ""
        txtUnit.Text = ""
        cboPost.Text = ""
        cboPosition.Text = ""
        txtEmp_Num.Text = ""
        txtWork_phone_1.Text = ""
        txtWork_phone_2.Text = ""
        txtHome_phone_1.Text = ""
        txtHome_phone_2.Text = ""
        txtFax.Text = ""
        txtHand_phone.Text = ""
        txtE_mail.Text = ""
        txtMemo.Text = ""
        txtOutDate.Text = ""

    End Sub
	
	
    Private Sub cboActiveFlag_Click()
        If VB.Left(cboActiveFlag.Text, 2) = "����" Then
            _lbl_Xs_19.Enabled = True
            txtOutDate.Enabled = True
        Else
            _lbl_Xs_19.Enabled = False
            txtOutDate.Enabled = False
        End If
    End Sub

	
	Private Sub frm_UserAdd_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call LF_ComboInit()
		g_CenterForm(Me)
	End Sub
	
    '�־��� ID�� �󼼳����� �˻��Ͽ� ���÷����Ѵ�.
	Public Function F_DBRecordDisplay() As Boolean
		
		F_DBRecordDisplay = True
		
		If Len(txt_ID.Text) > 0 Then
			
			Gsql = ""
			Gsql = Gsql & " SELECT *"
			Gsql = Gsql & "   FROM user_info "
			Gsql = Gsql & "  where user_id = '" & UCase(Trim(txt_ID.Text)) & "'"
			Gsql = Gsql & "    AND ACTIVE_FLAG <> 'T' AND ACTIVE_FLAG <> 'D'"
            Dim g As GRSClass = New GRSClass(Gsql)

            If g.RowCount <> 1 Then
                F_DBRecordDisplay = False
                Exit Function
            End If
			
            txt_ID.Text = g.gRS("User_ID")
            txtSecurity_num.Text = g.gRS(1)
            g_FindSetCombotIndex(cboSecurity_rule, g.gRS("Security_rule"))
            g_FindSetCombotIndex(cboActiveFlag, g.gRS("active_flag"))
			
            txtSecurity_level.Text = g.gRS("security_level")
            txtMail_id.Text = g.gRS("Mail_id")
            txtMrpID.Text = g.gRS("mrp_user_id")
            txtUser_Name_K.Text = g.gRS("user_name_k")
            txtUser_Name_E.Text = g.gRS("User_Name_E")
            txtCountry.Text = g.gRS("Country")
            txtCity_name.Text = g.gRS("City_name")
            txtGu_name.Text = g.gRS("Gu_name")
            txtAddress.Text = g.gRS("Address")
            txtZip_code.Text = g.gRS("Zip_code")
            txtCompany.Text = g.gRS("company")
            txtWork_area.Text = g.gRS("Work_area")
            txtUnit.Text = g.gRS("Unit")
            cboPost.Text = g.gRS("Post")
            cboPosition.Text = g.gRS("Position")
            txtEmp_Num.Text = g.gRS("Emp_Num")
            txtWork_phone_1.Text = g.gRS("Work_phone_1")
            txtWork_phone_2.Text = g.gRS("Work_phone_1")
            txtHome_phone_1.Text = g.gRS("Home_phone_1")
            txtHome_phone_2.Text = g.gRS("Home_phone_1")
            txtFax.Text = g.gRS("Fax")
            txtHand_phone.Text = g.gRS("Hand_phone")
            txtE_mail.Text = g.gRS("E_mail")
            txtMemo.Text = g.gRS("Memo")
            txtOutDate.Text = g.gRS("out_date")
			
            '�׷������������� �˻��Ѵ�.
			Gsql = ""
			Gsql = Gsql & " select N.group_id, G.group_name "
			Gsql = Gsql & "   from grouping_info N,"
			Gsql = Gsql & "        group_info G "
			Gsql = Gsql & "  where N.group_id = G.group_id "
			Gsql = Gsql & "    and N.user_type = 'U' "
			Gsql = Gsql & "    and N.user_id = '" & UCase(Trim(txt_ID.Text)) & "'"
			
            g = New GRSClass(Gsql)

			
            For i As Integer = 0 To g.RowCount - 1
                cboUserGroup.Items.Add(g.gRS("group_name") & Space(50) & g.gRS("group_id"))
                g.MoveNext()
            Next

        End If
	End Function
	
	' ����� ���̺��� ����ڸ� ���Ѵ�.
	Function LF_User_Append() As Short
		On Error GoTo Err_Handler
		
        Dim g As GRSClass
        Dim enc As Encrypt = New Encrypt
        'Request TABLE ����ڿ�û�̷� insert or update

        LF_User_Append = 0


		If Not CheckRequestNo Then
			LF_User_Append = 2
			Exit Function
		End If
		
        If Len(txtSecurity_num.Text) = 0 Then
            txtSecurity_num.Text = enc.EncryptPassword(txtSecurity_num.Text)
        End If

        If gRequestNo = "" Then
            MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�." & vbCrLf & "frm_UserAdd - LF_User_Append")
            Exit Function
        End If


        Gsql = " exec sp_user_info_add '"
        Gsql = Gsql & gUSERID & "','"
        Gsql = Gsql & UCase(txt_ID.Text) & "','"
        Gsql = Gsql & txtSecurity_num.Text & "','"
        Gsql = Gsql & UCase(VB.Right(cboSecurity_rule.Text, 1)) & "','"
        Gsql = Gsql & txtSecurity_level.Text & "','"
        Gsql = Gsql & txtMail_id.Text & "','"
        Gsql = Gsql & txtUser_Name_K.Text & "','"

        Gsql = Gsql & txtUser_Name_E.Text & "','"
        Gsql = Gsql & txtCountry.Text & "','"
        Gsql = Gsql & txtCity_name.Text & "','"
        Gsql = Gsql & txtGu_name.Text & "','"
        Gsql = Gsql & txtAddress.Text & "','"
        Gsql = Gsql & txtZip_code.Text & "','"


        Gsql = Gsql & txtCompany.Text & "','"
        Gsql = Gsql & txtWork_area.Text & "','"
        Gsql = Gsql & txtUnit.Text & "','"
        Gsql = Gsql & cboPost.Text & "','"
        Gsql = Gsql & cboPosition.Text & "','"

        Gsql = Gsql & txtEmp_Num.Text & "','"
        Gsql = Gsql & txtWork_phone_1.Text & "','"
        Gsql = Gsql & txtWork_phone_2.Text & "','"
        Gsql = Gsql & txtHome_phone_1.Text & "','"
        Gsql = Gsql & txtHome_phone_2.Text & "','"

        Gsql = Gsql & txtFax.Text & "','"
        Gsql = Gsql & txtHand_phone.Text & "','"
        Gsql = Gsql & txtE_mail.Text & "','"
        Gsql = Gsql & txtMemo.Text & "','"
        Gsql = Gsql & gRequestNo & "','"

        Gsql = Gsql & txtMrpID.Text & "','"
        Gsql = Gsql & txtOutDate.Text & "'"

        g = New GRSClass(Gsql)

        If g.gRS(0) = "1" Then
            Call LF_UserGroup_Append()
            LF_User_Append = 1
        Else
            LF_User_Append = 0
        End If

        '����� P/W �ʱ�ȭ �� �ڵ����Ϲ߼�
        PasswordInitialize()

        Exit Function
Err_Handler:
        Select Case gF_Error_Handler()
            Case "X" : Exit Function
            Case "R" : Resume
            Case "N" : Resume Next
            Case Else : Exit Function
        End Select
    End Function
	
	' ����� ���̺��� ����ڸ� �����Ѵ�.
    Function LF_User_Edit() As Short

        If Not CheckRequestNo Then
            Exit Function
        End If
        gs_ActiveFlag = ""
        If gRequestNo = "" Then
            MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�." & vbCrLf & "frm_UserAdd - LF_User_Edit")

            Exit Function
        End If
        Gsql = "exec sp_user_info_edit  '"
        Gsql = Gsql & gUSERID & "','"
        Gsql = Gsql & (txt_ID.Text) & "','"
        Gsql = Gsql & (txtSecurity_num.Text) & "','"
        Gsql = Gsql & (VB.Right(cboSecurity_rule.Text, 1)) & "','"
        Gsql = Gsql & (txtSecurity_level.Text) & "','"
        Gsql = Gsql & (txtMail_id.Text) & "','"
        Gsql = Gsql & (txtUser_Name_K.Text) & "','"
        Gsql = Gsql & (txtUser_Name_E.Text) & "','"
        Gsql = Gsql & (txtCountry.Text) & "','"
        Gsql = Gsql & (txtCity_name.Text) & "','"
        Gsql = Gsql & (txtGu_name.Text) & "','"
        Gsql = Gsql & (txtAddress.Text) & "','"
        Gsql = Gsql & (txtZip_code.Text) & "','"
        Gsql = Gsql & (txtCompany.Text) & "','"
        Gsql = Gsql & (txtWork_area.Text) & "','"
        Gsql = Gsql & (txtUnit.Text) & "','"
        Gsql = Gsql & (cboPost.Text) & "','"
        Gsql = Gsql & (cboPosition.Text) & "','"
        Gsql = Gsql & (txtEmp_Num.Text) & "','"
        Gsql = Gsql & (txtWork_phone_1.Text) & "','"
        Gsql = Gsql & (txtWork_phone_2.Text) & "','"
        Gsql = Gsql & (txtHome_phone_1.Text) & "','"
        Gsql = Gsql & (txtHome_phone_2.Text) & "','"
        Gsql = Gsql & (txtFax.Text) & "','"
        Gsql = Gsql & (txtHand_phone.Text) & "','"
        Gsql = Gsql & (txtE_mail.Text) & "','"
        Gsql = Gsql & (txtMemo.Text) & "','"
        Gsql = Gsql & (VB.Right(cboActiveFlag.Text, 1)) & "','"
        Gsql = Gsql & gRequestNo & "','"
        Gsql = Gsql & (txtMrpID.Text) & "','"
        Gsql = Gsql & (txtOutDate.Text) & "'"

        g = New GRSClass(Gsql)
        gs_ActiveFlag = (VB.Right(cboActiveFlag.Text, 1))

    End Function

    Sub LF_UserGroup_Append()

        Dim iTemp As Short

        If Not CheckRequestNo Then Exit Sub

        If gRequestNo = "" Then
            MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�.")
            Exit Sub
        End If

        For iTemp = 0 To Me.cboUserGroup.Items.Count - 1
            Gsql = "exec sp_grouping_info_add '"
            Gsql = Gsql & gUSERID & "','"
            Gsql = Gsql & Trim(VB.Right(VB6.GetItemString(cboUserGroup, iTemp), 50)) & "','"
            Gsql = Gsql & "U" & "','"
            Gsql = Gsql & UCase(txt_ID.Text) & "','"
            Gsql = Gsql & "R" & "','"
            Gsql = Gsql & gRequestNo & "'"
            g = New GRSClass(Gsql)
        Next iTemp
    End Sub
	
	
	Private Sub PasswordInitialize()
		On Error GoTo ErrHandler

		Dim RandPWD As String
		Dim EncryptPWD As String
        Dim isCorrect As String
        Dim g As GRSClass
        Dim enc As Encrypt = New Encrypt
		If Not CheckRequestNo Then
			Call gSetErrorMessage("����� ��û������ ��� �ʱ�ȭ���� ���߽��ϴ�.", False)
			GoTo ErrHandler
		End If
		
		Randomize()
		' 6���� �̳� ����� �н������ ��� �Ұ�
		Do 
			RandPWD = init_pass
            EncryptPWD = enc.EncryptPassword(RandPWD)
			
			
			Gsql = ""
			Gsql = Gsql & "EXEC sp_user_password_edit '"
			Gsql = Gsql & gUSERID & "','"
			Gsql = Gsql & txt_ID.Text & "','"
			Gsql = Gsql & RandPWD & "','"
			Gsql = Gsql & EncryptPWD & "','"
			Gsql = Gsql & gRequestNo & "'"

            g = New GRSClass(Gsql)

            isCorrect = g.gRS(0)
		Loop While isCorrect <> "Y"

		
		MsgBox("���Ϲ߼� �Ϸ��Ͽ����ϴ�.")
		
		Exit Sub
ErrHandler: 
		Err.Clear()
		Call gDisplayCemMessage()
	End Sub
	
	
	Private Function init_pass() As String
		Randomize()
        Dim int_cnt, i, inx, char_cnt As Integer
		Dim spcl_cnt As Short
		Dim init_flag As Boolean
		Dim spcl(6) As String
        init_pass = ""
		spcl(1) = "&"
		spcl(2) = "!"
		spcl(3) = "@"
		spcl(4) = "#"
		spcl(5) = "$"
		spcl(6) = "%"

		
		init_flag = False
		
		While (Not init_flag)
			init_pass = VB.Right("00000000" & CStr(Int(Rnd() * 10000000)), 8)
			inx = System.Math.Abs(Int(Rnd() * 8 + 1))
			init_pass = VB.Left(init_pass, inx - 1) & Chr(Int(Rnd() * 26) + 65) & VB.Right(init_pass, 8 - inx)
			inx = System.Math.Abs(Int(Rnd() * 8 + 1))
			init_pass = VB.Left(init_pass, inx - 1) & Chr(Int(Rnd() * 26) + 97) & VB.Right(init_pass, 8 - inx)
			inx = System.Math.Abs(Int(Rnd() * 8 + 1))
			init_pass = VB.Left(init_pass, inx - 1) & Chr(Int(Rnd() * 26) + 65) & VB.Right(init_pass, 8 - inx)
			inx = System.Math.Abs(Int(Rnd() * 8 + 1))
			init_pass = VB.Left(init_pass, inx - 1) & Chr(Int(Rnd() * 26) + 97) & VB.Right(init_pass, 8 - inx)
			inx = System.Math.Abs(Int(Rnd() * 8 + 1))
			init_pass = VB.Left(init_pass, inx - 1) & spcl(Int(Rnd() * 6 + 1)) & VB.Right(init_pass, 8 - inx)
			inx = System.Math.Abs(Int(Rnd() * 8 + 1))
			init_pass = VB.Left(init_pass, inx - 1) & spcl(Int(Rnd() * 6 + 1)) & VB.Right(init_pass, 8 - inx)
			
			int_cnt = 0
			char_cnt = 0
			spcl_cnt = 0
			For i = 1 To Len(init_pass)
				If IsNumeric(Mid(init_pass, i, 1)) = True Then
                    int_cnt = int_cnt + 1
                ElseIf (Mid(init_pass, i, 1) >= "A" And Mid(init_pass, i, 1) <= "Z") Or (Mid(init_pass, i, 1) >= "a" And Mid(init_pass, i, 1) <= "z") Then
                    char_cnt = char_cnt + 1
                Else
                    spcl_cnt = spcl_cnt + 1
                End If
			Next 
			
			If int_cnt >= 2 And char_cnt >= 2 And spcl_cnt >= 2 Then
                init_flag = True
            End If
		End While
		
	End Function
	
	
	Private Sub txt_ID_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txt_ID.Leave
		Dim txtID As String
		
		On Error GoTo ErrHandler
		
		txtID = Trim(txt_ID.Text)
		
		If txtID <> "" Then
			Gsql = ""
			Gsql = " SELECT user_id FROM user_info "
			Gsql = Gsql & " WHERE user_id='" & txtID & "'"
            g = New GRSClass(Gsql)

            If g.RowCount <> 0 Then
                MsgBox("< �ߺ� > �Ǵ� ����� ID �� �����մϴ�. �ٸ� ����� ID�� �������ּ���.", , "Ȯ��")
                txt_ID.Focus()
            End If
		End If
		
		
		Exit Sub
ErrHandler: 
		Call gDisplayCemMessage()
		Exit Sub
		Resume 
	End Sub
	
	Private Sub txtOutDate_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtOutDate.Enter
		txtOutDate.SelectionStart = 0
		txtOutDate.SelectionLength = Len(txtOutDate.Text) + 2
	End Sub
	
	Private Sub txtOutDate_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtOutDate.Leave
		If txtOutDate.Text = "" Then Exit Sub
		If IsDate(VB.Left(txtOutDate.Text, 4) & "-" & Mid(txtOutDate.Text, 5, 2) & "-" & VB.Right(txtOutDate.Text, 2)) <> True Then
			MsgBox("�������ڸ� Ȯ�����ּ���",  , "Ȯ��")
			txtOutDate.Focus()
		End If
	End Sub


    Private Sub cmdSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        frm_UserPwd_History.Return_Value1 = txt_ID.Text
        frm_UserPwd_History.ShowDialog()
    End Sub

    Private Sub CmdPwdRand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPwdRand.Click
        PasswordInitialize()
        Me.Close()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        On Error GoTo Err_Handler
        Dim Index As Short
        Dim N As Short

        If txt_ID.Text = "" Then
            MsgBox("����� ID�� �ݵ�� �Է��ؾ� �մϴ�.", 16)
            txt_ID.Focus()
            Exit Sub
        End If

        If txtUser_Name_K.Text = "" Then
            MsgBox("����� ������ �ݵ�� �Է��ؾ� �մϴ�.", 16)
            txtUser_Name_K.Focus()
            Exit Sub
        End If

        If txtMail_id.Text = "" Then
            MsgBox("Mail ID�� �ݵ�� �Է��ؾ� �մϴ�.", 16)
            txtMail_id.Focus()
            Exit Sub
        End If

        If txtOutDate.Text <> "" Then
            If VB.Right(cboActiveFlag.Text, 1) <> "T" Then
                MsgBox("�������ڴ� �������ΰ� <����>�� ��쿡�� �Է°����մϴ�.", 16)
                txtOutDate.Focus()
                Exit Sub
            End If
        End If

        If Not IsNumeric(txtSecurity_level.Text) Then txtSecurity_level.Text = "1000"
        If txtMrpID.Text = "" Then txtMrpID.Text = "N"

        Dim nodT As TreeNode
        If cmdOK.Text = "���" Then
            N = LF_User_Append() '����� �� �׷���

            If N = 1 Then
                nodT = gtrvX.Nodes.Add(UCase(txt_ID.Text), txtUser_Name_K.Text)
                nodT.Tag = "U_X"
                MsgBox("����ڰ� ���������� ��ϵǾ����ϴ�")
                Me.Close()
            ElseIf N = 2 Then
                MsgBox("����� ��û ����� ��� ����ڸ� �߰����� ���߽��ϴ�.")
            Else
                MsgBox("�ߺ��� ID�Դϴ�.")
                txt_ID.Text = ""
                txt_ID.Focus()
            End If

        Else '������ ���
            Call LF_User_Edit()
            gnodX.Text = txtUser_Name_K.Text
            Me.Close()
        End If

        Exit Sub
Err_Handler:
        Select Case gF_Error_Handler()
            Case "X" : Exit Sub
            Case "N" : Resume Next
            Case "R" : Resume
            Case Else
        End Select
    End Sub

    Private Sub cmdGroup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGroup.Click
        Dim sW As Short
        Dim i As Short

        frm_UserAddGroup.lblUserIDP.Text = txt_ID.Text
        frm_UserAddGroup.lblNameKorP.Text = txtUser_Name_K.Text

        Gsql = ""
        Gsql = Gsql & " select * "
        Gsql = Gsql & "   from group_info"
        Dim g As GRSClass = New GRSClass(Gsql)

        For inx As Integer = 0 To g.RowCount - 1
            sW = 0
            For i = 0 To Me.cboUserGroup.Items.Count - 1
                If g.gRS("group_name") = Trim(VB.Right(VB6.GetItemString(Me.cboUserGroup, i), 50)) Then
                    sW = 1
                End If
            Next i

            If sW = 0 Then frm_UserAddGroup.lstGroup.Items.Add(VB6.Format(g.gRS(1)) & Space(50) & VB6.Format(g.gRS(0)))
            g.MoveNext()
        Next

        For i = 0 To Me.cboUserGroup.Items.Count - 1
            frm_UserAddGroup.lstSelectGroup.Items.Add(VB6.GetItemString(cboUserGroup, i))
        Next i

        If Me.cboUserGroup.Items.Count = 0 Then
            frm_UserAddGroup.cmdOk.Text = "���"
        Else
            frm_UserAddGroup.cmdOk.Text = "����"
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
        frm_UserAddGroup.ShowDialog()
    End Sub
End Class