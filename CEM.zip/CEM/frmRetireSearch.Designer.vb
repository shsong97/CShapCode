<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmRetireSearch
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
    Public WithEvents txtToDate1 As System.Windows.Forms.MaskedTextBox
	Public WithEvents txtFromDate1 As System.Windows.Forms.MaskedTextBox
    Public WithEvents _SSTab1_TabPage0 As System.Windows.Forms.TabPage
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents txtToDate2 As System.Windows.Forms.MaskedTextBox
	Public WithEvents txtFromDate2 As System.Windows.Forms.MaskedTextBox
    Public WithEvents _SSTab1_TabPage1 As System.Windows.Forms.TabPage
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
    Public WithEvents txtToDate3 As System.Windows.Forms.MaskedTextBox
	Public WithEvents txtFromDate3 As System.Windows.Forms.MaskedTextBox
    Public WithEvents _SSTab1_TabPage2 As System.Windows.Forms.TabPage
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Label14 As System.Windows.Forms.Label
    Public WithEvents _SSTab1_TabPage3 As System.Windows.Forms.TabPage
	Public WithEvents SSTab1 As System.Windows.Forms.TabControl
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SSTab1 = New System.Windows.Forms.TabControl
        Me._SSTab1_TabPage0 = New System.Windows.Forms.TabPage
        Me.vaSpread1 = New FarPoint.Win.Spread.FpSpread
        Me.vaSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtToDate1 = New System.Windows.Forms.MaskedTextBox
        Me.txtFromDate1 = New System.Windows.Forms.MaskedTextBox
        Me._SSTab1_TabPage1 = New System.Windows.Forms.TabPage
        Me.vaSpread2 = New FarPoint.Win.Spread.FpSpread
        Me.vaSpread2_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtToDate2 = New System.Windows.Forms.MaskedTextBox
        Me.txtFromDate2 = New System.Windows.Forms.MaskedTextBox
        Me._SSTab1_TabPage2 = New System.Windows.Forms.TabPage
        Me.vaSpread3 = New FarPoint.Win.Spread.FpSpread
        Me.vaSpread3_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtToDate3 = New System.Windows.Forms.MaskedTextBox
        Me.txtFromDate3 = New System.Windows.Forms.MaskedTextBox
        Me._SSTab1_TabPage3 = New System.Windows.Forms.TabPage
        Me.vaSpread4 = New FarPoint.Win.Spread.FpSpread
        Me.vaSpread4_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.cmdSearch1 = New System.Windows.Forms.Button
        Me.cmdInit1 = New System.Windows.Forms.Button
        Me.cmdInit2 = New System.Windows.Forms.Button
        Me.cmdSearch2 = New System.Windows.Forms.Button
        Me.cmdInit3 = New System.Windows.Forms.Button
        Me.cmdSearch3 = New System.Windows.Forms.Button
        Me.b_Init = New System.Windows.Forms.Button
        Me.b_Search = New System.Windows.Forms.Button
        Me.SSTab1.SuspendLayout()
        Me._SSTab1_TabPage0.SuspendLayout()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._SSTab1_TabPage1.SuspendLayout()
        CType(Me.vaSpread2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread2_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._SSTab1_TabPage2.SuspendLayout()
        CType(Me.vaSpread3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread3_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._SSTab1_TabPage3.SuspendLayout()
        CType(Me.vaSpread4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread4_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SSTab1
        '
        Me.SSTab1.Controls.Add(Me._SSTab1_TabPage0)
        Me.SSTab1.Controls.Add(Me._SSTab1_TabPage1)
        Me.SSTab1.Controls.Add(Me._SSTab1_TabPage2)
        Me.SSTab1.Controls.Add(Me._SSTab1_TabPage3)
        Me.SSTab1.ItemSize = New System.Drawing.Size(42, 18)
        Me.SSTab1.Location = New System.Drawing.Point(9, 8)
        Me.SSTab1.Name = "SSTab1"
        Me.SSTab1.SelectedIndex = 0
        Me.SSTab1.Size = New System.Drawing.Size(892, 697)
        Me.SSTab1.TabIndex = 0
        '
        '_SSTab1_TabPage0
        '
        Me._SSTab1_TabPage0.Controls.Add(Me.cmdInit1)
        Me._SSTab1_TabPage0.Controls.Add(Me.cmdSearch1)
        Me._SSTab1_TabPage0.Controls.Add(Me.vaSpread1)
        Me._SSTab1_TabPage0.Controls.Add(Me.Label2)
        Me._SSTab1_TabPage0.Controls.Add(Me.Label1)
        Me._SSTab1_TabPage0.Controls.Add(Me.Label7)
        Me._SSTab1_TabPage0.Controls.Add(Me.Label8)
        Me._SSTab1_TabPage0.Controls.Add(Me.Label9)
        Me._SSTab1_TabPage0.Controls.Add(Me.Label10)
        Me._SSTab1_TabPage0.Controls.Add(Me.Label11)
        Me._SSTab1_TabPage0.Controls.Add(Me.txtToDate1)
        Me._SSTab1_TabPage0.Controls.Add(Me.txtFromDate1)
        Me._SSTab1_TabPage0.Location = New System.Drawing.Point(4, 22)
        Me._SSTab1_TabPage0.Name = "_SSTab1_TabPage0"
        Me._SSTab1_TabPage0.Size = New System.Drawing.Size(884, 671)
        Me._SSTab1_TabPage0.TabIndex = 0
        Me._SSTab1_TabPage0.Text = "������������� ����Ʈ"
        '
        'vaSpread1
        '
        Me.vaSpread1.AccessibleDescription = ""
        Me.vaSpread1.Location = New System.Drawing.Point(18, 71)
        Me.vaSpread1.Name = "vaSpread1"
        Me.vaSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread1_Sheet1})
        Me.vaSpread1.Size = New System.Drawing.Size(478, 588)
        Me.vaSpread1.TabIndex = 27
        '
        'vaSpread1_Sheet1
        '
        Me.vaSpread1_Sheet1.Reset()
        Me.vaSpread1_Sheet1.SheetName = "Sheet1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(158, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(14, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "~"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(16, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "��ȸ����"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(513, 70)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(225, 21)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "* ������������ڸ���Ʈ �������"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(512, 117)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(225, 21)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "2.�߷�ó������(�λ���)�� ����, ���̱�"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(512, 140)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(218, 21)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "3.ID�κ��� ����ʵ忡 ����, ���̱�"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(512, 94)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(214, 21)
        Me.Label10.TabIndex = 25
        Me.Label10.Text = "1.��ȸ���ڸ� �Է�"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(512, 161)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(214, 21)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "4.��ȸ"
        '
        'txtToDate1
        '
        Me.txtToDate1.AllowPromptAsInput = False
        Me.txtToDate1.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtToDate1.Location = New System.Drawing.Point(174, 34)
        Me.txtToDate1.Mask = "####-##-##"
        Me.txtToDate1.Name = "txtToDate1"
        Me.txtToDate1.Size = New System.Drawing.Size(81, 20)
        Me.txtToDate1.TabIndex = 3
        Me.txtToDate1.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        'txtFromDate1
        '
        Me.txtFromDate1.AllowPromptAsInput = False
        Me.txtFromDate1.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtFromDate1.Location = New System.Drawing.Point(70, 34)
        Me.txtFromDate1.Mask = "####-##-##"
        Me.txtFromDate1.Name = "txtFromDate1"
        Me.txtFromDate1.Size = New System.Drawing.Size(81, 20)
        Me.txtFromDate1.TabIndex = 2
        Me.txtFromDate1.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        '_SSTab1_TabPage1
        '
        Me._SSTab1_TabPage1.Controls.Add(Me.cmdSearch2)
        Me._SSTab1_TabPage1.Controls.Add(Me.cmdInit2)
        Me._SSTab1_TabPage1.Controls.Add(Me.vaSpread2)
        Me._SSTab1_TabPage1.Controls.Add(Me.Label3)
        Me._SSTab1_TabPage1.Controls.Add(Me.Label4)
        Me._SSTab1_TabPage1.Controls.Add(Me.txtToDate2)
        Me._SSTab1_TabPage1.Controls.Add(Me.txtFromDate2)
        Me._SSTab1_TabPage1.Location = New System.Drawing.Point(4, 22)
        Me._SSTab1_TabPage1.Name = "_SSTab1_TabPage1"
        Me._SSTab1_TabPage1.Size = New System.Drawing.Size(884, 671)
        Me._SSTab1_TabPage1.TabIndex = 1
        Me._SSTab1_TabPage1.Text = "�Ⱓ�� ������������� ����Ʈ"
        '
        'vaSpread2
        '
        Me.vaSpread2.AccessibleDescription = ""
        Me.vaSpread2.Location = New System.Drawing.Point(16, 66)
        Me.vaSpread2.Name = "vaSpread2"
        Me.vaSpread2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread2_Sheet1})
        Me.vaSpread2.Size = New System.Drawing.Size(576, 591)
        Me.vaSpread2.TabIndex = 15
        '
        'vaSpread2_Sheet1
        '
        Me.vaSpread2_Sheet1.Reset()
        Me.vaSpread2_Sheet1.SheetName = "Sheet1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(158, 42)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(14, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "~"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(7, 37)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(55, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "��ȸ����"
        '
        'txtToDate2
        '
        Me.txtToDate2.AllowPromptAsInput = False
        Me.txtToDate2.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtToDate2.Location = New System.Drawing.Point(174, 34)
        Me.txtToDate2.Mask = "####-##-##"
        Me.txtToDate2.Name = "txtToDate2"
        Me.txtToDate2.Size = New System.Drawing.Size(81, 20)
        Me.txtToDate2.TabIndex = 10
        Me.txtToDate2.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        'txtFromDate2
        '
        Me.txtFromDate2.AllowPromptAsInput = False
        Me.txtFromDate2.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtFromDate2.Location = New System.Drawing.Point(68, 34)
        Me.txtFromDate2.Mask = "####-##-##"
        Me.txtFromDate2.Name = "txtFromDate2"
        Me.txtFromDate2.Size = New System.Drawing.Size(81, 20)
        Me.txtFromDate2.TabIndex = 9
        Me.txtFromDate2.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        '_SSTab1_TabPage2
        '
        Me._SSTab1_TabPage2.Controls.Add(Me.cmdSearch3)
        Me._SSTab1_TabPage2.Controls.Add(Me.cmdInit3)
        Me._SSTab1_TabPage2.Controls.Add(Me.vaSpread3)
        Me._SSTab1_TabPage2.Controls.Add(Me.Label5)
        Me._SSTab1_TabPage2.Controls.Add(Me.Label6)
        Me._SSTab1_TabPage2.Controls.Add(Me.txtToDate3)
        Me._SSTab1_TabPage2.Controls.Add(Me.txtFromDate3)
        Me._SSTab1_TabPage2.Location = New System.Drawing.Point(4, 22)
        Me._SSTab1_TabPage2.Name = "_SSTab1_TabPage2"
        Me._SSTab1_TabPage2.Size = New System.Drawing.Size(884, 671)
        Me._SSTab1_TabPage2.TabIndex = 2
        Me._SSTab1_TabPage2.Text = "������������� ����Ʈ From �λ�"
        '
        'vaSpread3
        '
        Me.vaSpread3.AccessibleDescription = ""
        Me.vaSpread3.Location = New System.Drawing.Point(19, 64)
        Me.vaSpread3.Name = "vaSpread3"
        Me.vaSpread3.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread3_Sheet1})
        Me.vaSpread3.Size = New System.Drawing.Size(691, 600)
        Me.vaSpread3.TabIndex = 22
        '
        'vaSpread3_Sheet1
        '
        Me.vaSpread3_Sheet1.Reset()
        Me.vaSpread3_Sheet1.SheetName = "Sheet1"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(158, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(14, 13)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "~"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(16, 37)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "��ȸ����"
        '
        'txtToDate3
        '
        Me.txtToDate3.AllowPromptAsInput = False
        Me.txtToDate3.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtToDate3.Location = New System.Drawing.Point(174, 34)
        Me.txtToDate3.Mask = "####-##-##"
        Me.txtToDate3.Name = "txtToDate3"
        Me.txtToDate3.Size = New System.Drawing.Size(81, 20)
        Me.txtToDate3.TabIndex = 17
        Me.txtToDate3.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        'txtFromDate3
        '
        Me.txtFromDate3.AllowPromptAsInput = False
        Me.txtFromDate3.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtFromDate3.Location = New System.Drawing.Point(70, 34)
        Me.txtFromDate3.Mask = "####-##-##"
        Me.txtFromDate3.Name = "txtFromDate3"
        Me.txtFromDate3.Size = New System.Drawing.Size(81, 20)
        Me.txtFromDate3.TabIndex = 16
        Me.txtFromDate3.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        '_SSTab1_TabPage3
        '
        Me._SSTab1_TabPage3.Controls.Add(Me.b_Search)
        Me._SSTab1_TabPage3.Controls.Add(Me.b_Init)
        Me._SSTab1_TabPage3.Controls.Add(Me.vaSpread4)
        Me._SSTab1_TabPage3.Controls.Add(Me.Label12)
        Me._SSTab1_TabPage3.Controls.Add(Me.Label13)
        Me._SSTab1_TabPage3.Controls.Add(Me.Label14)
        Me._SSTab1_TabPage3.Location = New System.Drawing.Point(4, 22)
        Me._SSTab1_TabPage3.Name = "_SSTab1_TabPage3"
        Me._SSTab1_TabPage3.Size = New System.Drawing.Size(884, 671)
        Me._SSTab1_TabPage3.TabIndex = 3
        Me._SSTab1_TabPage3.Text = "����� ID ���� Ȯ��"
        '
        'vaSpread4
        '
        Me.vaSpread4.AccessibleDescription = ""
        Me.vaSpread4.Location = New System.Drawing.Point(3, 65)
        Me.vaSpread4.Name = "vaSpread4"
        Me.vaSpread4.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread4_Sheet1})
        Me.vaSpread4.Size = New System.Drawing.Size(637, 603)
        Me.vaSpread4.TabIndex = 33
        '
        'vaSpread4_Sheet1
        '
        Me.vaSpread4_Sheet1.Reset()
        Me.vaSpread4_Sheet1.SheetName = "Sheet1"
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(646, 129)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(214, 21)
        Me.Label12.TabIndex = 30
        Me.Label12.Text = "2.��ȸ"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(646, 106)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(218, 21)
        Me.Label13.TabIndex = 31
        Me.Label13.Text = "1.����� ����ʵ忡 ����, ���̱�"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(647, 82)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(225, 21)
        Me.Label14.TabIndex = 32
        Me.Label14.Text = "* ����� ID ���� Ȯ�� ����"
        '
        'cmdSearch1
        '
        Me.cmdSearch1.Location = New System.Drawing.Point(337, 29)
        Me.cmdSearch1.Name = "cmdSearch1"
        Me.cmdSearch1.Size = New System.Drawing.Size(58, 29)
        Me.cmdSearch1.TabIndex = 28
        Me.cmdSearch1.Text = "��ȸ"
        Me.cmdSearch1.UseVisualStyleBackColor = True
        '
        'cmdInit1
        '
        Me.cmdInit1.Location = New System.Drawing.Point(273, 29)
        Me.cmdInit1.Name = "cmdInit1"
        Me.cmdInit1.Size = New System.Drawing.Size(58, 29)
        Me.cmdInit1.TabIndex = 29
        Me.cmdInit1.Text = "�ʱ�ȭ"
        Me.cmdInit1.UseVisualStyleBackColor = True
        '
        'cmdInit2
        '
        Me.cmdInit2.Location = New System.Drawing.Point(261, 29)
        Me.cmdInit2.Name = "cmdInit2"
        Me.cmdInit2.Size = New System.Drawing.Size(55, 28)
        Me.cmdInit2.TabIndex = 16
        Me.cmdInit2.Text = "�ʱ�ȭ"
        Me.cmdInit2.UseVisualStyleBackColor = True
        '
        'cmdSearch2
        '
        Me.cmdSearch2.Location = New System.Drawing.Point(322, 28)
        Me.cmdSearch2.Name = "cmdSearch2"
        Me.cmdSearch2.Size = New System.Drawing.Size(53, 29)
        Me.cmdSearch2.TabIndex = 17
        Me.cmdSearch2.Text = "��ȸ"
        Me.cmdSearch2.UseVisualStyleBackColor = True
        '
        'cmdInit3
        '
        Me.cmdInit3.Location = New System.Drawing.Point(261, 30)
        Me.cmdInit3.Name = "cmdInit3"
        Me.cmdInit3.Size = New System.Drawing.Size(73, 27)
        Me.cmdInit3.TabIndex = 23
        Me.cmdInit3.Text = "�ʱ�ȭ"
        Me.cmdInit3.UseVisualStyleBackColor = True
        '
        'cmdSearch3
        '
        Me.cmdSearch3.Location = New System.Drawing.Point(340, 30)
        Me.cmdSearch3.Name = "cmdSearch3"
        Me.cmdSearch3.Size = New System.Drawing.Size(70, 27)
        Me.cmdSearch3.TabIndex = 24
        Me.cmdSearch3.Text = "��ȸ"
        Me.cmdSearch3.UseVisualStyleBackColor = True
        '
        'b_Init
        '
        Me.b_Init.Location = New System.Drawing.Point(3, 32)
        Me.b_Init.Name = "b_Init"
        Me.b_Init.Size = New System.Drawing.Size(86, 29)
        Me.b_Init.TabIndex = 34
        Me.b_Init.Text = "�ʱ�ȭ"
        Me.b_Init.UseVisualStyleBackColor = True
        '
        'b_Search
        '
        Me.b_Search.Location = New System.Drawing.Point(95, 32)
        Me.b_Search.Name = "b_Search"
        Me.b_Search.Size = New System.Drawing.Size(79, 29)
        Me.b_Search.TabIndex = 35
        Me.b_Search.Text = "��ȸ"
        Me.b_Search.UseVisualStyleBackColor = True
        '
        'frmRetireSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1038, 727)
        Me.Controls.Add(Me.SSTab1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 30)
        Me.Name = "frmRetireSearch"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "������������ڸ���Ʈ(frmRetireSearch)"
        Me.SSTab1.ResumeLayout(False)
        Me._SSTab1_TabPage0.ResumeLayout(False)
        Me._SSTab1_TabPage0.PerformLayout()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._SSTab1_TabPage1.ResumeLayout(False)
        Me._SSTab1_TabPage1.PerformLayout()
        CType(Me.vaSpread2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread2_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._SSTab1_TabPage2.ResumeLayout(False)
        Me._SSTab1_TabPage2.PerformLayout()
        CType(Me.vaSpread3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread3_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._SSTab1_TabPage3.ResumeLayout(False)
        CType(Me.vaSpread4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread4_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents vaSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents vaSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents vaSpread2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents vaSpread2_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents vaSpread3 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents vaSpread3_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents vaSpread4 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents vaSpread4_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents cmdInit1 As System.Windows.Forms.Button
    Friend WithEvents cmdSearch1 As System.Windows.Forms.Button
    Friend WithEvents cmdSearch2 As System.Windows.Forms.Button
    Friend WithEvents cmdInit2 As System.Windows.Forms.Button
    Friend WithEvents cmdSearch3 As System.Windows.Forms.Button
    Friend WithEvents cmdInit3 As System.Windows.Forms.Button
    Friend WithEvents b_Search As System.Windows.Forms.Button
    Friend WithEvents b_Init As System.Windows.Forms.Button
#End Region 
End Class