<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_UserAdd
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents cboActiveFlag As System.Windows.Forms.ComboBox
	Public WithEvents txtMrpID As System.Windows.Forms.TextBox
	Public WithEvents txtSecurity_level As System.Windows.Forms.TextBox
	Public WithEvents txtHand_phone As System.Windows.Forms.TextBox
	Public WithEvents txtHome_phone_2 As System.Windows.Forms.TextBox
	Public WithEvents txtE_mail As System.Windows.Forms.TextBox
	Public WithEvents txtFax As System.Windows.Forms.TextBox
	Public WithEvents txtWork_phone_1 As System.Windows.Forms.TextBox
	Public WithEvents txtHome_phone_1 As System.Windows.Forms.TextBox
	Public WithEvents txtWork_phone_2 As System.Windows.Forms.TextBox
	Public WithEvents txtWork_area As System.Windows.Forms.TextBox
	Public WithEvents txtAddress As System.Windows.Forms.TextBox
	Public WithEvents txtUnit As System.Windows.Forms.TextBox
	Public WithEvents txtCompany As System.Windows.Forms.TextBox
	Public WithEvents txtMemo As System.Windows.Forms.TextBox
	Public WithEvents txtZip_code As System.Windows.Forms.TextBox
	Public WithEvents cboSecurity_rule As System.Windows.Forms.ComboBox
	Public WithEvents txtCity_name As System.Windows.Forms.TextBox
	Public WithEvents txtGu_name As System.Windows.Forms.TextBox
	Public WithEvents txtMail_id As System.Windows.Forms.TextBox
	Public WithEvents txtCountry As System.Windows.Forms.TextBox
	Public WithEvents cboPost As System.Windows.Forms.ComboBox
	Public WithEvents cboUserGroup As System.Windows.Forms.ComboBox
	Public WithEvents cboPosition As System.Windows.Forms.ComboBox
	Public WithEvents txtEmp_Num As System.Windows.Forms.TextBox
	Public WithEvents txtUser_Name_E As System.Windows.Forms.TextBox
	Public WithEvents txtUser_Name_K As System.Windows.Forms.TextBox
	Public WithEvents txtSecurity_num As System.Windows.Forms.TextBox
	Public WithEvents txt_ID As System.Windows.Forms.TextBox
    Public WithEvents txtOutDate As System.Windows.Forms.MaskedTextBox
	Public WithEvents _lbl_Xs_19 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_21 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_22 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_20 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_18 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_17 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_16 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_15 As System.Windows.Forms.Label
	Public WithEvents lblUserGroup As System.Windows.Forms.Label
	Public WithEvents lblDepartmentCode As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_14 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_13 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_12 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_11 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_10 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_9 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_8 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_7 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_6 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_5 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_4 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_3 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_2 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_1 As System.Windows.Forms.Label
	Public WithEvents _lbl_Xs_0 As System.Windows.Forms.Label
	Public WithEvents lblEmploeyNo As System.Windows.Forms.Label
	Public WithEvents lblNameEng As System.Windows.Forms.Label
	Public WithEvents lblNameKor As System.Windows.Forms.Label
	Public WithEvents lblPassword As System.Windows.Forms.Label
	Public WithEvents lblUserID As System.Windows.Forms.Label
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_UserAdd))
        Me.cboActiveFlag = New System.Windows.Forms.ComboBox
        Me.txtMrpID = New System.Windows.Forms.TextBox
        Me.txtSecurity_level = New System.Windows.Forms.TextBox
        Me.txtHand_phone = New System.Windows.Forms.TextBox
        Me.txtHome_phone_2 = New System.Windows.Forms.TextBox
        Me.txtE_mail = New System.Windows.Forms.TextBox
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.txtWork_phone_1 = New System.Windows.Forms.TextBox
        Me.txtHome_phone_1 = New System.Windows.Forms.TextBox
        Me.txtWork_phone_2 = New System.Windows.Forms.TextBox
        Me.txtWork_area = New System.Windows.Forms.TextBox
        Me.txtAddress = New System.Windows.Forms.TextBox
        Me.txtUnit = New System.Windows.Forms.TextBox
        Me.txtCompany = New System.Windows.Forms.TextBox
        Me.txtMemo = New System.Windows.Forms.TextBox
        Me.txtZip_code = New System.Windows.Forms.TextBox
        Me.cboSecurity_rule = New System.Windows.Forms.ComboBox
        Me.txtCity_name = New System.Windows.Forms.TextBox
        Me.txtGu_name = New System.Windows.Forms.TextBox
        Me.txtMail_id = New System.Windows.Forms.TextBox
        Me.txtCountry = New System.Windows.Forms.TextBox
        Me.cboPost = New System.Windows.Forms.ComboBox
        Me.cboUserGroup = New System.Windows.Forms.ComboBox
        Me.cboPosition = New System.Windows.Forms.ComboBox
        Me.txtEmp_Num = New System.Windows.Forms.TextBox
        Me.txtUser_Name_E = New System.Windows.Forms.TextBox
        Me.txtUser_Name_K = New System.Windows.Forms.TextBox
        Me.txtSecurity_num = New System.Windows.Forms.TextBox
        Me.txt_ID = New System.Windows.Forms.TextBox
        Me.txtOutDate = New System.Windows.Forms.MaskedTextBox
        Me._lbl_Xs_19 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me._lbl_Xs_21 = New System.Windows.Forms.Label
        Me._lbl_Xs_22 = New System.Windows.Forms.Label
        Me._lbl_Xs_20 = New System.Windows.Forms.Label
        Me._lbl_Xs_18 = New System.Windows.Forms.Label
        Me._lbl_Xs_17 = New System.Windows.Forms.Label
        Me._lbl_Xs_16 = New System.Windows.Forms.Label
        Me._lbl_Xs_15 = New System.Windows.Forms.Label
        Me.lblUserGroup = New System.Windows.Forms.Label
        Me.lblDepartmentCode = New System.Windows.Forms.Label
        Me._lbl_Xs_14 = New System.Windows.Forms.Label
        Me._lbl_Xs_13 = New System.Windows.Forms.Label
        Me._lbl_Xs_12 = New System.Windows.Forms.Label
        Me._lbl_Xs_11 = New System.Windows.Forms.Label
        Me._lbl_Xs_10 = New System.Windows.Forms.Label
        Me._lbl_Xs_9 = New System.Windows.Forms.Label
        Me._lbl_Xs_8 = New System.Windows.Forms.Label
        Me._lbl_Xs_7 = New System.Windows.Forms.Label
        Me._lbl_Xs_6 = New System.Windows.Forms.Label
        Me._lbl_Xs_5 = New System.Windows.Forms.Label
        Me._lbl_Xs_4 = New System.Windows.Forms.Label
        Me._lbl_Xs_3 = New System.Windows.Forms.Label
        Me._lbl_Xs_2 = New System.Windows.Forms.Label
        Me._lbl_Xs_1 = New System.Windows.Forms.Label
        Me._lbl_Xs_0 = New System.Windows.Forms.Label
        Me.lblEmploeyNo = New System.Windows.Forms.Label
        Me.lblNameEng = New System.Windows.Forms.Label
        Me.lblNameKor = New System.Windows.Forms.Label
        Me.lblPassword = New System.Windows.Forms.Label
        Me.lblUserID = New System.Windows.Forms.Label
        Me.cmdSearch = New System.Windows.Forms.Button
        Me.CmdPwdRand = New System.Windows.Forms.Button
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.cmdOK = New System.Windows.Forms.Button
        Me.cmdGroup = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cboActiveFlag
        '
        Me.cboActiveFlag.BackColor = System.Drawing.SystemColors.Window
        Me.cboActiveFlag.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboActiveFlag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboActiveFlag.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cboActiveFlag.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboActiveFlag.Location = New System.Drawing.Point(424, 112)
        Me.cboActiveFlag.Name = "cboActiveFlag"
        Me.cboActiveFlag.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboActiveFlag.Size = New System.Drawing.Size(137, 20)
        Me.cboActiveFlag.TabIndex = 8
        '
        'txtMrpID
        '
        Me.txtMrpID.AcceptsReturn = True
        Me.txtMrpID.BackColor = System.Drawing.SystemColors.Window
        Me.txtMrpID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMrpID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtMrpID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMrpID.Location = New System.Drawing.Point(152, 88)
        Me.txtMrpID.MaxLength = 30
        Me.txtMrpID.Name = "txtMrpID"
        Me.txtMrpID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMrpID.Size = New System.Drawing.Size(137, 21)
        Me.txtMrpID.TabIndex = 5
        '
        'txtSecurity_level
        '
        Me.txtSecurity_level.AcceptsReturn = True
        Me.txtSecurity_level.BackColor = System.Drawing.SystemColors.Window
        Me.txtSecurity_level.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSecurity_level.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtSecurity_level.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSecurity_level.Location = New System.Drawing.Point(424, 88)
        Me.txtSecurity_level.MaxLength = 10
        Me.txtSecurity_level.Name = "txtSecurity_level"
        Me.txtSecurity_level.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSecurity_level.Size = New System.Drawing.Size(137, 21)
        Me.txtSecurity_level.TabIndex = 6
        '
        'txtHand_phone
        '
        Me.txtHand_phone.AcceptsReturn = True
        Me.txtHand_phone.BackColor = System.Drawing.Color.White
        Me.txtHand_phone.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtHand_phone.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtHand_phone.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtHand_phone.Location = New System.Drawing.Point(592, 354)
        Me.txtHand_phone.MaxLength = 20
        Me.txtHand_phone.Name = "txtHand_phone"
        Me.txtHand_phone.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtHand_phone.Size = New System.Drawing.Size(137, 21)
        Me.txtHand_phone.TabIndex = 27
        '
        'txtHome_phone_2
        '
        Me.txtHome_phone_2.AcceptsReturn = True
        Me.txtHome_phone_2.BackColor = System.Drawing.SystemColors.Window
        Me.txtHome_phone_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtHome_phone_2.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtHome_phone_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtHome_phone_2.Location = New System.Drawing.Point(592, 306)
        Me.txtHome_phone_2.MaxLength = 20
        Me.txtHome_phone_2.Name = "txtHome_phone_2"
        Me.txtHome_phone_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtHome_phone_2.Size = New System.Drawing.Size(137, 21)
        Me.txtHome_phone_2.TabIndex = 25
        '
        'txtE_mail
        '
        Me.txtE_mail.AcceptsReturn = True
        Me.txtE_mail.BackColor = System.Drawing.SystemColors.Window
        Me.txtE_mail.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtE_mail.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtE_mail.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtE_mail.Location = New System.Drawing.Point(592, 378)
        Me.txtE_mail.MaxLength = 50
        Me.txtE_mail.Name = "txtE_mail"
        Me.txtE_mail.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtE_mail.Size = New System.Drawing.Size(137, 21)
        Me.txtE_mail.TabIndex = 28
        '
        'txtFax
        '
        Me.txtFax.AcceptsReturn = True
        Me.txtFax.BackColor = System.Drawing.Color.White
        Me.txtFax.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFax.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtFax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFax.Location = New System.Drawing.Point(592, 330)
        Me.txtFax.MaxLength = 20
        Me.txtFax.Name = "txtFax"
        Me.txtFax.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFax.Size = New System.Drawing.Size(137, 21)
        Me.txtFax.TabIndex = 26
        '
        'txtWork_phone_1
        '
        Me.txtWork_phone_1.AcceptsReturn = True
        Me.txtWork_phone_1.BackColor = System.Drawing.SystemColors.Window
        Me.txtWork_phone_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtWork_phone_1.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtWork_phone_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWork_phone_1.Location = New System.Drawing.Point(592, 234)
        Me.txtWork_phone_1.MaxLength = 20
        Me.txtWork_phone_1.Name = "txtWork_phone_1"
        Me.txtWork_phone_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtWork_phone_1.Size = New System.Drawing.Size(137, 21)
        Me.txtWork_phone_1.TabIndex = 22
        '
        'txtHome_phone_1
        '
        Me.txtHome_phone_1.AcceptsReturn = True
        Me.txtHome_phone_1.BackColor = System.Drawing.SystemColors.Window
        Me.txtHome_phone_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtHome_phone_1.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtHome_phone_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtHome_phone_1.Location = New System.Drawing.Point(592, 282)
        Me.txtHome_phone_1.MaxLength = 20
        Me.txtHome_phone_1.Name = "txtHome_phone_1"
        Me.txtHome_phone_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtHome_phone_1.Size = New System.Drawing.Size(137, 21)
        Me.txtHome_phone_1.TabIndex = 24
        '
        'txtWork_phone_2
        '
        Me.txtWork_phone_2.AcceptsReturn = True
        Me.txtWork_phone_2.BackColor = System.Drawing.Color.White
        Me.txtWork_phone_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtWork_phone_2.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtWork_phone_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWork_phone_2.Location = New System.Drawing.Point(592, 258)
        Me.txtWork_phone_2.MaxLength = 20
        Me.txtWork_phone_2.Name = "txtWork_phone_2"
        Me.txtWork_phone_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtWork_phone_2.Size = New System.Drawing.Size(137, 21)
        Me.txtWork_phone_2.TabIndex = 23
        '
        'txtWork_area
        '
        Me.txtWork_area.AcceptsReturn = True
        Me.txtWork_area.BackColor = System.Drawing.SystemColors.Window
        Me.txtWork_area.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtWork_area.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtWork_area.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWork_area.Location = New System.Drawing.Point(320, 234)
        Me.txtWork_area.MaxLength = 50
        Me.txtWork_area.Name = "txtWork_area"
        Me.txtWork_area.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtWork_area.Size = New System.Drawing.Size(137, 21)
        Me.txtWork_area.TabIndex = 18
        '
        'txtAddress
        '
        Me.txtAddress.AcceptsReturn = True
        Me.txtAddress.BackColor = System.Drawing.SystemColors.Window
        Me.txtAddress.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAddress.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtAddress.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAddress.Location = New System.Drawing.Point(104, 354)
        Me.txtAddress.MaxLength = 100
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtAddress.Size = New System.Drawing.Size(353, 21)
        Me.txtAddress.TabIndex = 29
        '
        'txtUnit
        '
        Me.txtUnit.AcceptsReturn = True
        Me.txtUnit.BackColor = System.Drawing.Color.White
        Me.txtUnit.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUnit.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtUnit.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUnit.Location = New System.Drawing.Point(320, 258)
        Me.txtUnit.MaxLength = 50
        Me.txtUnit.Name = "txtUnit"
        Me.txtUnit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUnit.Size = New System.Drawing.Size(137, 21)
        Me.txtUnit.TabIndex = 19
        '
        'txtCompany
        '
        Me.txtCompany.AcceptsReturn = True
        Me.txtCompany.BackColor = System.Drawing.SystemColors.Window
        Me.txtCompany.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCompany.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtCompany.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCompany.Location = New System.Drawing.Point(104, 306)
        Me.txtCompany.MaxLength = 50
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCompany.Size = New System.Drawing.Size(137, 21)
        Me.txtCompany.TabIndex = 16
        '
        'txtMemo
        '
        Me.txtMemo.AcceptsReturn = True
        Me.txtMemo.BackColor = System.Drawing.SystemColors.Window
        Me.txtMemo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMemo.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtMemo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMemo.Location = New System.Drawing.Point(104, 378)
        Me.txtMemo.MaxLength = 255
        Me.txtMemo.Name = "txtMemo"
        Me.txtMemo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMemo.Size = New System.Drawing.Size(353, 21)
        Me.txtMemo.TabIndex = 30
        '
        'txtZip_code
        '
        Me.txtZip_code.AcceptsReturn = True
        Me.txtZip_code.BackColor = System.Drawing.Color.White
        Me.txtZip_code.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtZip_code.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtZip_code.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtZip_code.Location = New System.Drawing.Point(104, 330)
        Me.txtZip_code.MaxLength = 20
        Me.txtZip_code.Name = "txtZip_code"
        Me.txtZip_code.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtZip_code.Size = New System.Drawing.Size(137, 21)
        Me.txtZip_code.TabIndex = 17
        '
        'cboSecurity_rule
        '
        Me.cboSecurity_rule.BackColor = System.Drawing.SystemColors.Window
        Me.cboSecurity_rule.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboSecurity_rule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSecurity_rule.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cboSecurity_rule.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboSecurity_rule.Location = New System.Drawing.Point(152, 112)
        Me.cboSecurity_rule.Name = "cboSecurity_rule"
        Me.cboSecurity_rule.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboSecurity_rule.Size = New System.Drawing.Size(137, 20)
        Me.cboSecurity_rule.TabIndex = 7
        '
        'txtCity_name
        '
        Me.txtCity_name.AcceptsReturn = True
        Me.txtCity_name.BackColor = System.Drawing.Color.White
        Me.txtCity_name.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCity_name.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtCity_name.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCity_name.Location = New System.Drawing.Point(104, 258)
        Me.txtCity_name.MaxLength = 100
        Me.txtCity_name.Name = "txtCity_name"
        Me.txtCity_name.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCity_name.Size = New System.Drawing.Size(137, 21)
        Me.txtCity_name.TabIndex = 14
        '
        'txtGu_name
        '
        Me.txtGu_name.AcceptsReturn = True
        Me.txtGu_name.BackColor = System.Drawing.SystemColors.Window
        Me.txtGu_name.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtGu_name.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtGu_name.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGu_name.Location = New System.Drawing.Point(104, 282)
        Me.txtGu_name.MaxLength = 100
        Me.txtGu_name.Name = "txtGu_name"
        Me.txtGu_name.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtGu_name.Size = New System.Drawing.Size(137, 21)
        Me.txtGu_name.TabIndex = 15
        '
        'txtMail_id
        '
        Me.txtMail_id.AcceptsReturn = True
        Me.txtMail_id.BackColor = System.Drawing.SystemColors.Window
        Me.txtMail_id.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMail_id.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtMail_id.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMail_id.Location = New System.Drawing.Point(424, 64)
        Me.txtMail_id.MaxLength = 30
        Me.txtMail_id.Name = "txtMail_id"
        Me.txtMail_id.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMail_id.Size = New System.Drawing.Size(137, 21)
        Me.txtMail_id.TabIndex = 4
        '
        'txtCountry
        '
        Me.txtCountry.AcceptsReturn = True
        Me.txtCountry.BackColor = System.Drawing.SystemColors.Window
        Me.txtCountry.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCountry.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtCountry.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCountry.Location = New System.Drawing.Point(104, 234)
        Me.txtCountry.MaxLength = 50
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCountry.Size = New System.Drawing.Size(137, 21)
        Me.txtCountry.TabIndex = 13
        '
        'cboPost
        '
        Me.cboPost.BackColor = System.Drawing.SystemColors.Window
        Me.cboPost.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboPost.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cboPost.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboPost.Location = New System.Drawing.Point(320, 282)
        Me.cboPost.Name = "cboPost"
        Me.cboPost.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboPost.Size = New System.Drawing.Size(137, 20)
        Me.cboPost.TabIndex = 20
        Me.cboPost.Text = "cboPost"
        '
        'cboUserGroup
        '
        Me.cboUserGroup.BackColor = System.Drawing.SystemColors.Window
        Me.cboUserGroup.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboUserGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboUserGroup.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cboUserGroup.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboUserGroup.Location = New System.Drawing.Point(248, 182)
        Me.cboUserGroup.Name = "cboUserGroup"
        Me.cboUserGroup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboUserGroup.Size = New System.Drawing.Size(137, 20)
        Me.cboUserGroup.TabIndex = 52
        '
        'cboPosition
        '
        Me.cboPosition.BackColor = System.Drawing.SystemColors.Window
        Me.cboPosition.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboPosition.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cboPosition.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboPosition.Location = New System.Drawing.Point(320, 306)
        Me.cboPosition.Name = "cboPosition"
        Me.cboPosition.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboPosition.Size = New System.Drawing.Size(137, 20)
        Me.cboPosition.TabIndex = 21
        Me.cboPosition.Text = "cboPosition"
        '
        'txtEmp_Num
        '
        Me.txtEmp_Num.AcceptsReturn = True
        Me.txtEmp_Num.BackColor = System.Drawing.SystemColors.Window
        Me.txtEmp_Num.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtEmp_Num.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtEmp_Num.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtEmp_Num.Location = New System.Drawing.Point(152, 64)
        Me.txtEmp_Num.MaxLength = 10
        Me.txtEmp_Num.Name = "txtEmp_Num"
        Me.txtEmp_Num.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtEmp_Num.Size = New System.Drawing.Size(137, 21)
        Me.txtEmp_Num.TabIndex = 3
        '
        'txtUser_Name_E
        '
        Me.txtUser_Name_E.AcceptsReturn = True
        Me.txtUser_Name_E.BackColor = System.Drawing.SystemColors.Window
        Me.txtUser_Name_E.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUser_Name_E.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtUser_Name_E.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUser_Name_E.Location = New System.Drawing.Point(424, 40)
        Me.txtUser_Name_E.MaxLength = 50
        Me.txtUser_Name_E.Name = "txtUser_Name_E"
        Me.txtUser_Name_E.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUser_Name_E.Size = New System.Drawing.Size(137, 21)
        Me.txtUser_Name_E.TabIndex = 2
        '
        'txtUser_Name_K
        '
        Me.txtUser_Name_K.AcceptsReturn = True
        Me.txtUser_Name_K.BackColor = System.Drawing.SystemColors.Window
        Me.txtUser_Name_K.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUser_Name_K.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtUser_Name_K.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUser_Name_K.Location = New System.Drawing.Point(152, 40)
        Me.txtUser_Name_K.MaxLength = 50
        Me.txtUser_Name_K.Name = "txtUser_Name_K"
        Me.txtUser_Name_K.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUser_Name_K.Size = New System.Drawing.Size(137, 21)
        Me.txtUser_Name_K.TabIndex = 1
        '
        'txtSecurity_num
        '
        Me.txtSecurity_num.AcceptsReturn = True
        Me.txtSecurity_num.BackColor = System.Drawing.SystemColors.Window
        Me.txtSecurity_num.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSecurity_num.Enabled = False
        Me.txtSecurity_num.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtSecurity_num.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSecurity_num.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtSecurity_num.Location = New System.Drawing.Point(424, 16)
        Me.txtSecurity_num.MaxLength = 50
        Me.txtSecurity_num.Name = "txtSecurity_num"
        Me.txtSecurity_num.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSecurity_num.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSecurity_num.Size = New System.Drawing.Size(137, 21)
        Me.txtSecurity_num.TabIndex = 12
        '
        'txt_ID
        '
        Me.txt_ID.AcceptsReturn = True
        Me.txt_ID.BackColor = System.Drawing.Color.White
        Me.txt_ID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_ID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txt_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt_ID.Location = New System.Drawing.Point(152, 16)
        Me.txt_ID.MaxLength = 50
        Me.txt_ID.Name = "txt_ID"
        Me.txt_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt_ID.Size = New System.Drawing.Size(137, 21)
        Me.txt_ID.TabIndex = 0
        '
        'txtOutDate
        '
        Me.txtOutDate.AllowPromptAsInput = False
        Me.txtOutDate.Location = New System.Drawing.Point(424, 136)
        Me.txtOutDate.Mask = "####-##-##"
        Me.txtOutDate.Name = "txtOutDate"
        Me.txtOutDate.Size = New System.Drawing.Size(81, 20)
        Me.txtOutDate.TabIndex = 9
        Me.txtOutDate.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        '_lbl_Xs_19
        '
        Me._lbl_Xs_19.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._lbl_Xs_19.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_19.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_19.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_19.Location = New System.Drawing.Point(312, 136)
        Me._lbl_Xs_19.Name = "_lbl_Xs_19"
        Me._lbl_Xs_19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_19.Size = New System.Drawing.Size(100, 20)
        Me._lbl_Xs_19.TabIndex = 67
        Me._lbl_Xs_19.Text = "��������"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("����", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(40, 410)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(689, 25)
        Me.Label1.TabIndex = 66
        Me.Label1.Text = "��� �����ʹ� ��� �����ž� �մϴ�. MRP ID�� ���� ��� N�� �־� �ּ���..."
        '
        '_lbl_Xs_21
        '
        Me._lbl_Xs_21.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._lbl_Xs_21.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_21.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_21.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_21.Location = New System.Drawing.Point(312, 112)
        Me._lbl_Xs_21.Name = "_lbl_Xs_21"
        Me._lbl_Xs_21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_21.Size = New System.Drawing.Size(100, 20)
        Me._lbl_Xs_21.TabIndex = 63
        Me._lbl_Xs_21.Text = "��������"
        '
        '_lbl_Xs_22
        '
        Me._lbl_Xs_22.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._lbl_Xs_22.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_22.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_22.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_22.Location = New System.Drawing.Point(40, 88)
        Me._lbl_Xs_22.Name = "_lbl_Xs_22"
        Me._lbl_Xs_22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_22.Size = New System.Drawing.Size(100, 20)
        Me._lbl_Xs_22.TabIndex = 62
        Me._lbl_Xs_22.Text = "MRP ID"
        '
        '_lbl_Xs_20
        '
        Me._lbl_Xs_20.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_20.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_20.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_20.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_20.Location = New System.Drawing.Point(496, 354)
        Me._lbl_Xs_20.Name = "_lbl_Xs_20"
        Me._lbl_Xs_20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_20.Size = New System.Drawing.Size(89, 20)
        Me._lbl_Xs_20.TabIndex = 59
        Me._lbl_Xs_20.Text = "�޴���ȭ"
        '
        '_lbl_Xs_18
        '
        Me._lbl_Xs_18.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_18.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_18.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_18.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_18.Location = New System.Drawing.Point(40, 378)
        Me._lbl_Xs_18.Name = "_lbl_Xs_18"
        Me._lbl_Xs_18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_18.Size = New System.Drawing.Size(73, 20)
        Me._lbl_Xs_18.TabIndex = 58
        Me._lbl_Xs_18.Text = "�޸�"
        '
        '_lbl_Xs_17
        '
        Me._lbl_Xs_17.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_17.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_17.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_17.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_17.Location = New System.Drawing.Point(496, 378)
        Me._lbl_Xs_17.Name = "_lbl_Xs_17"
        Me._lbl_Xs_17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_17.Size = New System.Drawing.Size(89, 20)
        Me._lbl_Xs_17.TabIndex = 57
        Me._lbl_Xs_17.Text = "Mail(internet)"
        '
        '_lbl_Xs_16
        '
        Me._lbl_Xs_16.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_16.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_16.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_16.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_16.Location = New System.Drawing.Point(496, 306)
        Me._lbl_Xs_16.Name = "_lbl_Xs_16"
        Me._lbl_Xs_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_16.Size = New System.Drawing.Size(89, 20)
        Me._lbl_Xs_16.TabIndex = 56
        Me._lbl_Xs_16.Text = "��ȭ(��2)"
        '
        '_lbl_Xs_15
        '
        Me._lbl_Xs_15.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_15.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_15.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_15.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_15.Location = New System.Drawing.Point(496, 258)
        Me._lbl_Xs_15.Name = "_lbl_Xs_15"
        Me._lbl_Xs_15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_15.Size = New System.Drawing.Size(89, 20)
        Me._lbl_Xs_15.TabIndex = 55
        Me._lbl_Xs_15.Text = "��ȭ(�ٹ���2)"
        '
        'lblUserGroup
        '
        Me.lblUserGroup.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblUserGroup.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUserGroup.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblUserGroup.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUserGroup.Location = New System.Drawing.Point(166, 186)
        Me.lblUserGroup.Name = "lblUserGroup"
        Me.lblUserGroup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUserGroup.Size = New System.Drawing.Size(105, 13)
        Me.lblUserGroup.TabIndex = 54
        Me.lblUserGroup.Text = "����� �׷�"
        '
        'lblDepartmentCode
        '
        Me.lblDepartmentCode.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.lblDepartmentCode.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDepartmentCode.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblDepartmentCode.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDepartmentCode.Location = New System.Drawing.Point(256, 282)
        Me.lblDepartmentCode.Name = "lblDepartmentCode"
        Me.lblDepartmentCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDepartmentCode.Size = New System.Drawing.Size(81, 20)
        Me.lblDepartmentCode.TabIndex = 53
        Me.lblDepartmentCode.Text = "�μ��ڵ�"
        '
        '_lbl_Xs_14
        '
        Me._lbl_Xs_14.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_14.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_14.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_14.Location = New System.Drawing.Point(256, 234)
        Me._lbl_Xs_14.Name = "_lbl_Xs_14"
        Me._lbl_Xs_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_14.Size = New System.Drawing.Size(81, 20)
        Me._lbl_Xs_14.TabIndex = 51
        Me._lbl_Xs_14.Text = "�ٹ�ó"
        '
        '_lbl_Xs_13
        '
        Me._lbl_Xs_13.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_13.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_13.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_13.Location = New System.Drawing.Point(256, 258)
        Me._lbl_Xs_13.Name = "_lbl_Xs_13"
        Me._lbl_Xs_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_13.Size = New System.Drawing.Size(81, 20)
        Me._lbl_Xs_13.TabIndex = 50
        Me._lbl_Xs_13.Text = "UNIT"
        '
        '_lbl_Xs_12
        '
        Me._lbl_Xs_12.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_12.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_12.Location = New System.Drawing.Point(256, 306)
        Me._lbl_Xs_12.Name = "_lbl_Xs_12"
        Me._lbl_Xs_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_12.Size = New System.Drawing.Size(81, 20)
        Me._lbl_Xs_12.TabIndex = 49
        Me._lbl_Xs_12.Text = "����"
        '
        '_lbl_Xs_11
        '
        Me._lbl_Xs_11.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_11.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_11.Location = New System.Drawing.Point(496, 234)
        Me._lbl_Xs_11.Name = "_lbl_Xs_11"
        Me._lbl_Xs_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_11.Size = New System.Drawing.Size(89, 20)
        Me._lbl_Xs_11.TabIndex = 48
        Me._lbl_Xs_11.Text = "��ȭ(�ٹ���1)"
        '
        '_lbl_Xs_10
        '
        Me._lbl_Xs_10.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_10.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_10.Location = New System.Drawing.Point(496, 282)
        Me._lbl_Xs_10.Name = "_lbl_Xs_10"
        Me._lbl_Xs_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_10.Size = New System.Drawing.Size(89, 20)
        Me._lbl_Xs_10.TabIndex = 47
        Me._lbl_Xs_10.Text = "��ȭ(��1)"
        '
        '_lbl_Xs_9
        '
        Me._lbl_Xs_9.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_9.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_9.Location = New System.Drawing.Point(496, 330)
        Me._lbl_Xs_9.Name = "_lbl_Xs_9"
        Me._lbl_Xs_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_9.Size = New System.Drawing.Size(89, 20)
        Me._lbl_Xs_9.TabIndex = 46
        Me._lbl_Xs_9.Text = "Fax"
        '
        '_lbl_Xs_8
        '
        Me._lbl_Xs_8.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_8.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_8.Location = New System.Drawing.Point(40, 234)
        Me._lbl_Xs_8.Name = "_lbl_Xs_8"
        Me._lbl_Xs_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_8.Size = New System.Drawing.Size(65, 20)
        Me._lbl_Xs_8.TabIndex = 45
        Me._lbl_Xs_8.Text = "����"
        '
        '_lbl_Xs_7
        '
        Me._lbl_Xs_7.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_7.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_7.Location = New System.Drawing.Point(40, 258)
        Me._lbl_Xs_7.Name = "_lbl_Xs_7"
        Me._lbl_Xs_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_7.Size = New System.Drawing.Size(73, 20)
        Me._lbl_Xs_7.TabIndex = 44
        Me._lbl_Xs_7.Text = "��/��"
        '
        '_lbl_Xs_6
        '
        Me._lbl_Xs_6.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_6.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_6.Location = New System.Drawing.Point(40, 282)
        Me._lbl_Xs_6.Name = "_lbl_Xs_6"
        Me._lbl_Xs_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_6.Size = New System.Drawing.Size(73, 20)
        Me._lbl_Xs_6.TabIndex = 43
        Me._lbl_Xs_6.Text = "��/��/��"
        '
        '_lbl_Xs_5
        '
        Me._lbl_Xs_5.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_5.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_5.Location = New System.Drawing.Point(40, 354)
        Me._lbl_Xs_5.Name = "_lbl_Xs_5"
        Me._lbl_Xs_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_5.Size = New System.Drawing.Size(81, 20)
        Me._lbl_Xs_5.TabIndex = 42
        Me._lbl_Xs_5.Text = "�ּ�"
        '
        '_lbl_Xs_4
        '
        Me._lbl_Xs_4.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_4.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_4.Location = New System.Drawing.Point(40, 330)
        Me._lbl_Xs_4.Name = "_lbl_Xs_4"
        Me._lbl_Xs_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_4.Size = New System.Drawing.Size(73, 20)
        Me._lbl_Xs_4.TabIndex = 41
        Me._lbl_Xs_4.Text = "������ȣ"
        '
        '_lbl_Xs_3
        '
        Me._lbl_Xs_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._lbl_Xs_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_3.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_3.Location = New System.Drawing.Point(312, 64)
        Me._lbl_Xs_3.Name = "_lbl_Xs_3"
        Me._lbl_Xs_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_3.Size = New System.Drawing.Size(100, 20)
        Me._lbl_Xs_3.TabIndex = 40
        Me._lbl_Xs_3.Text = "����ID(Exchage)"
        '
        '_lbl_Xs_2
        '
        Me._lbl_Xs_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._lbl_Xs_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_2.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_2.Location = New System.Drawing.Point(40, 112)
        Me._lbl_Xs_2.Name = "_lbl_Xs_2"
        Me._lbl_Xs_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_2.Size = New System.Drawing.Size(100, 20)
        Me._lbl_Xs_2.TabIndex = 39
        Me._lbl_Xs_2.Text = "��� Flag"
        '
        '_lbl_Xs_1
        '
        Me._lbl_Xs_1.BackColor = System.Drawing.SystemColors.Control
        Me._lbl_Xs_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_1.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_1.Location = New System.Drawing.Point(40, 306)
        Me._lbl_Xs_1.Name = "_lbl_Xs_1"
        Me._lbl_Xs_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_1.Size = New System.Drawing.Size(73, 20)
        Me._lbl_Xs_1.TabIndex = 38
        Me._lbl_Xs_1.Text = "ȸ��"
        '
        '_lbl_Xs_0
        '
        Me._lbl_Xs_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._lbl_Xs_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_Xs_0.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me._lbl_Xs_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lbl_Xs_0.Location = New System.Drawing.Point(312, 88)
        Me._lbl_Xs_0.Name = "_lbl_Xs_0"
        Me._lbl_Xs_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_Xs_0.Size = New System.Drawing.Size(100, 20)
        Me._lbl_Xs_0.TabIndex = 37
        Me._lbl_Xs_0.Text = "���ȷ���"
        '
        'lblEmploeyNo
        '
        Me.lblEmploeyNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblEmploeyNo.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblEmploeyNo.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblEmploeyNo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEmploeyNo.Location = New System.Drawing.Point(40, 64)
        Me.lblEmploeyNo.Name = "lblEmploeyNo"
        Me.lblEmploeyNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblEmploeyNo.Size = New System.Drawing.Size(100, 20)
        Me.lblEmploeyNo.TabIndex = 36
        Me.lblEmploeyNo.Text = "���"
        '
        'lblNameEng
        '
        Me.lblNameEng.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblNameEng.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblNameEng.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblNameEng.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblNameEng.Location = New System.Drawing.Point(312, 40)
        Me.lblNameEng.Name = "lblNameEng"
        Me.lblNameEng.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblNameEng.Size = New System.Drawing.Size(100, 20)
        Me.lblNameEng.TabIndex = 35
        Me.lblNameEng.Text = "����(����)"
        '
        'lblNameKor
        '
        Me.lblNameKor.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblNameKor.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblNameKor.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblNameKor.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblNameKor.Location = New System.Drawing.Point(40, 40)
        Me.lblNameKor.Name = "lblNameKor"
        Me.lblNameKor.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblNameKor.Size = New System.Drawing.Size(100, 20)
        Me.lblNameKor.TabIndex = 34
        Me.lblNameKor.Text = "����(�ѱ�)"
        '
        'lblPassword
        '
        Me.lblPassword.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblPassword.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPassword.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblPassword.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPassword.Location = New System.Drawing.Point(312, 16)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPassword.Size = New System.Drawing.Size(100, 20)
        Me.lblPassword.TabIndex = 33
        Me.lblPassword.Text = "Password"
        '
        'lblUserID
        '
        Me.lblUserID.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblUserID.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUserID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblUserID.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUserID.Location = New System.Drawing.Point(40, 16)
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUserID.Size = New System.Drawing.Size(100, 20)
        Me.lblUserID.TabIndex = 32
        Me.lblUserID.Text = "����� ID"
        '
        'cmdSearch
        '
        Me.cmdSearch.Location = New System.Drawing.Point(664, 16)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.Size = New System.Drawing.Size(65, 34)
        Me.cmdSearch.TabIndex = 68
        Me.cmdSearch.Text = "�̷���ȸ"
        Me.cmdSearch.UseVisualStyleBackColor = True
        '
        'CmdPwdRand
        '
        Me.CmdPwdRand.Location = New System.Drawing.Point(608, 16)
        Me.CmdPwdRand.Name = "CmdPwdRand"
        Me.CmdPwdRand.Size = New System.Drawing.Size(57, 34)
        Me.CmdPwdRand.TabIndex = 69
        Me.CmdPwdRand.Text = "�ʱ�ȭ"
        Me.CmdPwdRand.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(608, 99)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(121, 33)
        Me.cmdCancel.TabIndex = 70
        Me.cmdCancel.Text = "���"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(608, 56)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(121, 33)
        Me.cmdOK.TabIndex = 71
        Me.cmdOK.Text = "���"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'cmdGroup
        '
        Me.cmdGroup.Location = New System.Drawing.Point(401, 180)
        Me.cmdGroup.Name = "cmdGroup"
        Me.cmdGroup.Size = New System.Drawing.Size(86, 23)
        Me.cmdGroup.TabIndex = 72
        Me.cmdGroup.Text = "�׷��Ҵ�"
        Me.cmdGroup.UseVisualStyleBackColor = True
        '
        'frm_UserAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(779, 454)
        Me.Controls.Add(Me.cmdGroup)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.CmdPwdRand)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.cboActiveFlag)
        Me.Controls.Add(Me.txtMrpID)
        Me.Controls.Add(Me.txtSecurity_level)
        Me.Controls.Add(Me.txtHand_phone)
        Me.Controls.Add(Me.txtHome_phone_2)
        Me.Controls.Add(Me.txtE_mail)
        Me.Controls.Add(Me.txtFax)
        Me.Controls.Add(Me.txtWork_phone_1)
        Me.Controls.Add(Me.txtHome_phone_1)
        Me.Controls.Add(Me.txtWork_phone_2)
        Me.Controls.Add(Me.txtWork_area)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtUnit)
        Me.Controls.Add(Me.txtCompany)
        Me.Controls.Add(Me.txtMemo)
        Me.Controls.Add(Me.txtZip_code)
        Me.Controls.Add(Me.cboSecurity_rule)
        Me.Controls.Add(Me.txtCity_name)
        Me.Controls.Add(Me.txtGu_name)
        Me.Controls.Add(Me.txtMail_id)
        Me.Controls.Add(Me.txtCountry)
        Me.Controls.Add(Me.cboPost)
        Me.Controls.Add(Me.cboUserGroup)
        Me.Controls.Add(Me.cboPosition)
        Me.Controls.Add(Me.txtEmp_Num)
        Me.Controls.Add(Me.txtUser_Name_E)
        Me.Controls.Add(Me.txtUser_Name_K)
        Me.Controls.Add(Me.txtSecurity_num)
        Me.Controls.Add(Me.txt_ID)
        Me.Controls.Add(Me.txtOutDate)
        Me.Controls.Add(Me._lbl_Xs_19)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me._lbl_Xs_21)
        Me.Controls.Add(Me._lbl_Xs_22)
        Me.Controls.Add(Me._lbl_Xs_20)
        Me.Controls.Add(Me._lbl_Xs_18)
        Me.Controls.Add(Me._lbl_Xs_17)
        Me.Controls.Add(Me._lbl_Xs_16)
        Me.Controls.Add(Me._lbl_Xs_15)
        Me.Controls.Add(Me.lblUserGroup)
        Me.Controls.Add(Me.lblDepartmentCode)
        Me.Controls.Add(Me._lbl_Xs_14)
        Me.Controls.Add(Me._lbl_Xs_13)
        Me.Controls.Add(Me._lbl_Xs_12)
        Me.Controls.Add(Me._lbl_Xs_11)
        Me.Controls.Add(Me._lbl_Xs_10)
        Me.Controls.Add(Me._lbl_Xs_9)
        Me.Controls.Add(Me._lbl_Xs_8)
        Me.Controls.Add(Me._lbl_Xs_7)
        Me.Controls.Add(Me._lbl_Xs_6)
        Me.Controls.Add(Me._lbl_Xs_5)
        Me.Controls.Add(Me._lbl_Xs_4)
        Me.Controls.Add(Me._lbl_Xs_3)
        Me.Controls.Add(Me._lbl_Xs_2)
        Me.Controls.Add(Me._lbl_Xs_1)
        Me.Controls.Add(Me._lbl_Xs_0)
        Me.Controls.Add(Me.lblEmploeyNo)
        Me.Controls.Add(Me.lblNameEng)
        Me.Controls.Add(Me.lblNameKor)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblUserID)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(48, 43)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_UserAdd"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "����� �߰� ( frm_UserAdd )"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdSearch As System.Windows.Forms.Button
    Friend WithEvents CmdPwdRand As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents cmdGroup As System.Windows.Forms.Button
#End Region 
End Class