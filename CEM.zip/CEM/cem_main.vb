Option Strict Off
Option Explicit On
Friend Enum UserIcon
    User
    Group
    Close
    Open
    App
    Program
End Enum

Friend Class frm_CEM_Main
	Inherits System.Windows.Forms.Form
	Private ib_Drag As Boolean
	Private ib_Resize As Boolean
	Private ib_TreeClick As Boolean

    Sub LF_Init()
        glivX = liv_Detail
        gtrvX = trv_Explorer

        ' image key
        gnodX = gtrvX.Nodes.Add("��������", "��������", UserIcon.Close, UserIcon.Open)
        gnodX.Tag = "M_U"
        gnodX = gtrvX.Nodes.Add("���α׷� ����", "���α׷� ����", UserIcon.Close, UserIcon.Open)
        gnodX.Tag = "M_P"
        gnodX = gtrvX.Nodes.Add("�������α׷� ����", "�������α׷� ����", UserIcon.Close, UserIcon.Open)
        gnodX.Tag = "M_A"

        gnodX = trv_Explorer.Nodes("��������")
        Call trv_Explorer_NodeClick(gnodX, False)
        gnodX = trv_Explorer.Nodes("���α׷� ����")
        Call trv_Explorer_NodeClick(gnodX, False)
    End Sub
	Private Sub CmdQry_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdQry.Click

        ib_TreeClick = True

        gnodX = trv_Explorer.Nodes("��������")
        Call trv_Explorer_NodeClick(gnodX)
        gnodX = gnodX.Nodes("�����")
        Call trv_Explorer_NodeClick(gnodX)

        If gitmX Is Nothing Then gitmX = New ListViewItem
        gitmX.Tag = "U_X"

        Gsql = " SELECT USER_ID,USER_NAME_K,SECURITY_LEVEL," & " CHNG_DATE,CHNG_ID " & " FROM USER_INFO" & " WHERE ACTIVE_FLAG <> 'T' AND ACTIVE_FLAG <> 'D' "
        Gsql = Gsql & " order by user_id "

        g = New GRSClass(Gsql)

        Call g_gRStoglivX(g)

        ib_TreeClick = False
    End Sub
	Private Sub CmdQry2_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdQry2.Click

        ib_TreeClick = True

        gnodX = trv_Explorer.Nodes("��������")
        Call trv_Explorer_NodeClick(gnodX)
        gnodX = gnodX.Nodes("�׷�")
        Call trv_Explorer_NodeClick(gnodX)

        If gitmX Is Nothing Then gitmX = New ListViewItem
        gitmX.Tag = "G_X"

        Gsql = "SELECT GROUP_ID,GROUP_NAME,GROUP_SEC_LEVEL,CHNG_DATE,CHNG_ID  FROM GROUP_INFO"
        Gsql = Gsql & " order by group_id "
        g = New GRSClass(Gsql)

        Call g_gRStoglivX(g)

		ib_TreeClick = False
	End Sub
	Private Sub CmdQry3_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdQry3.Click
        ib_TreeClick = True

        gnodX = trv_Explorer.Nodes("���α׷� ����")
        Call trv_Explorer_NodeClick(gnodX)
        If gitmX Is Nothing Then gitmX = New ListViewItem
        gitmX.Tag = "P_X"

        Gsql = "SELECT program, program_name, version, chng_date, chng_id " & " FROM program_info "
        Gsql = Gsql & " order by program"
        g = New GRSClass(Gsql)

        Call g_gRStoglivX(g)
        ib_TreeClick = False
    End Sub
	
    Private Sub frm_CEM_Main_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        LF_Init()
        frm_CEM_MDI.LayoutMdi(System.Windows.Forms.MdiLayout.TileVertical)

        '�ʱ⿡ ������� ���
        glivX.View = View.List
        frm_CEM_MDI._mnu_View_icon_0.Checked = False
        frm_CEM_MDI._mnu_View_icon_1.Checked = False
        frm_CEM_MDI._mnu_View_icon_2.Checked = True
        frm_CEM_MDI._mnu_View_icon_3.Checked = False
        frm_CEM_MDI._mnu_View_icon_4.Checked = False
    End Sub
	Private Sub frm_CEM_Main_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = 0 Then
			Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
			Cancel = True
		End If
		eventArgs.Cancel = Cancel
	End Sub
	Private Sub frm_CEM_Main_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize

        Dim sL As Object
        Dim St As Single 'left,top
        Dim sW As Object
        Dim sH As Single 'width,height

        If WindowState = System.Windows.Forms.FormWindowState.Minimized Then Exit Sub

        On Error Resume Next
        
        'tree view/list view resize
        trv_Explorer.Height = Me.Height - 116
        liv_Detail.Height = Me.Height - 116
        liv_Detail.Width = Me.Width - 350

    End Sub

    Public Sub mnu_add_Click()

        On Error Resume Next
        Dim ConX As System.Windows.Forms.Control
        Dim ls_Return As String
        ConX = Me.ActiveControl
        ls_Return = gF_AddData(ConX)

        If ls_Return = "X" Then Exit Sub
        If gnodX.Tag = ls_Return Then gnodX = gnodX.Parent
        If gnodX.Tag = "M_P" Or gnodX.Tag = "C_U" Then
        Else
            Call gRemoveChildNode(gnodX)
        End If
        Call trv_Explorer_NodeClick(gnodX)


    End Sub
	Public Sub mnu_delete_Click()
		
		On Error Resume Next
		
		Dim ConX As System.Windows.Forms.Control
		If gnodX Is Nothing Then Exit Sub
		
		
		
		ConX = Me.ActiveControl
		If gnodX.Parent.Tag = "C_U" Or gnodX.Parent.Tag = "M_P" Then
			g_DeleteData(ConX)
        Else
            If Not gnodX Is Nothing And gnodX.Tag Like "??X" Then
                g_DeleteData(ConX)
                gnodX = gnodX.Parent
                gb_NotMSG = True
                If gnodX.Tag <> "C_U" Then Call gRemoveChildNode(gnodX)
                Call trv_Explorer_NodeClick(gnodX)
                gb_NotMSG = False
            End If
		End If
		
		ConX.Focus()
		
	End Sub
	Public Sub mnu_edit_Click()
        On Error Resume Next
        Dim ConX As System.Windows.Forms.Control
        ConX = Me.ActiveControl
        g_EditData(ConX)
    End Sub
	Private Sub mnu_exit_Click()
		frm_CEM_MDI.mnu_File_exit_Click()
	End Sub
	Public Sub mnu_refresh_Click()
		Call g_Refresh()
	End Sub
	Public Sub mnu_history_Click()
		
		Dim sAddItem As String

		Dim ConX As System.Windows.Forms.Control
		
		ConX = Me.ActiveControl
		
		If ConX Is glivX Then
            sAddItem = gitmX.Tag
		Else
            sAddItem = gnodX.Tag
		End If
		
		Select Case sAddItem
			Case "U_X"
                frmHistoryUser.SetUserID((gnodX.Name))
			Case "G_X"
                frmHistoryGroup.SetGroupID((gnodX.Name))
			Case "P_X"
                frmHistoryProgram.SetProgramID((gnodX.Name))
			Case Else
		End Select
		
	End Sub
    Public Sub g_Refresh(Optional ByRef nodX As TreeNode = Nothing)
        On Error GoTo Line_Error

        If nodX Is Nothing Then nodX = gnodX

        gRemoveChildNode(nodX)
        lbl_Detail.Text = gnodX.FullPath
        Call g_ExpandNode()
        Exit Sub
Line_Error:
        Resume Next
    End Sub
    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click
        mnu_add_Click()
    End Sub

    Private Sub EditButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditButton.Click
        mnu_edit_Click()
    End Sub

    Private Sub DeleteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteButton.Click
        mnu_delete_Click()
    End Sub
    Private Sub exitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitButton.Click
        mnu_exit_Click()
    End Sub
    Private Sub RefreshButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshButton.Click
        mnu_refresh_Click()
    End Sub
    Private Sub �߰�ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles �߰�ToolStripMenuItem.Click
        mnu_add_Click()
    End Sub

    Private Sub ����ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ����ToolStripMenuItem.Click
        mnu_edit_Click()
    End Sub
    Private Sub ����ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ����ToolStripMenuItem.Click
        mnu_delete_Click()
    End Sub
    Private Sub �̷º���ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles �̷º���ToolStripMenuItem.Click
        mnu_history_Click()
    End Sub

    Private Sub lsExplorer_DragDrop(ByRef dragNode As TreeNode)
        '���콺������ hittest�� ����ִ� ���� ���� ���(gnodx) ��

        If gnodX.Tag = dragNode.Tag Then
            If gnodX.Tag <> "G_X" Then
                MsgBox("������ �������� ������� �ʽ��ϴ�.")
                Exit Sub
            End If
        End If

        '��ӵǾ����� ����
        gs_nodTag = dragNode.Tag

        gnodDrag = dragNode
        gnodParentX = gnodDrag.Parent
        gs_itmTag = gitmX.Tag

        If gF_isMatchingDragItemDropNode() Then
            Call g_SetRelatonDragDrop()
        End If
        '���ʱ�ȭ
        ib_Drag = False

    End Sub
    Private Sub trv_Explorer_NodeClick(ByVal eventArgs As TreeNode, Optional ByVal expand As Boolean = True)

        If eventArgs Is Nothing Then Exit Sub

        Dim lb_isLeafNode As Boolean

        If gnodX Is Nothing Then gnodX = eventArgs

        '��带 Ȯ���Ѵ�.
        '���� ���ϴܳ���̸� �θ��带 ���� �ѹ� Ȯ���Ѵ�.
        lb_isLeafNode = False

        If eventArgs.Tag Like "N??" Then
            lb_isLeafNode = True
        Else
            Select Case eventArgs.Tag
                Case "U_X"
                    lb_isLeafNode = True
                Case "G_X"
                    If eventArgs.Parent.Tag = "P_X" Then
                        lb_isLeafNode = True
                    End If
            End Select
        End If

        If lb_isLeafNode = True Then
            gnodX = eventArgs.Parent
            If glivX.Tag <> gnodX.FullPath Then
                Call g_ExpandNode()
            End If
            glivX.Tag = gnodX.FullPath
        Else
            glivX.Tag = eventArgs.FullPath
        End If

        lbl_Detail.Text = glivX.Tag
        Call g_ExpandNode(expand)
    End Sub
    Private Sub trv_Explorer_NodeMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles trv_Explorer.NodeMouseClick
        gnodX = e.Node
        lbl_Detail.Text = gnodX.FullPath
        glivX.Tag = gnodX.FullPath
        Call g_ExpandNode()
    End Sub
    Private Sub trv_Explorer_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles trv_Explorer.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            If gtrvX.HitTest(e.X, e.Y) IsNot Nothing Then
                Call trv_Explorer_NodeClick(gtrvX.HitTest(e.X, e.Y).Node)
                ContextMenuStrip1.Show(trv_Explorer, New Point(e.X, e.Y), ToolStripDropDownDirection.Right)
            End If
        End If
    End Sub
    Private Sub trv_Explorer_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles trv_Explorer.DragDrop
        Dim dragNode As TreeNode
        dragNode = trv_Explorer.HitTest(trv_Explorer.PointToClient(New Point(e.X, e.Y))).Node
        If dragNode IsNot Nothing Then
            Call lsExplorer_DragDrop(dragNode)
        End If

    End Sub
    Private Sub trv_Explorer_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles trv_Explorer.DragEnter
        e.Effect = e.AllowedEffect
    End Sub
    Private Sub trv_Explorer_ItemDrag(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ItemDragEventArgs) Handles trv_Explorer.ItemDrag
        trv_Explorer.DoDragDrop(e.Item, DragDropEffects.Copy)
    End Sub

    Private Sub liv_Detail_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles liv_Detail.KeyDown
        If e.KeyCode = Keys.Return Then
            Call liv_Detail_DoubleClick(liv_Detail, New System.EventArgs())
        End If
    End Sub
    Private Sub liv_Detail_ItemSelectionChanged(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles liv_Detail.ItemSelectionChanged
        gitmX = e.Item
        gParentNodX = gnodX
        Call g_FindAndSelectNode()
    End Sub
    Private Sub liv_Detail_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles liv_Detail.MouseDown
        If glivX.HitTest(e.X, e.Y) Is Nothing Then
            gitmX = Nothing
            Exit Sub
        Else
            gitmX = glivX.HitTest(e.X, e.Y).Item
            'Call g_FindAndSelectNode()
        End If
        Select Case e.Button
            Case Windows.Forms.MouseButtons.Right '������ ��ư���� ���콺�ٿ��� �Ͼ �� �˾� ȣ��
                'ContextMenuStrip1.Show(liv_Detail, New Point(e.X, e.Y), ToolStripDropDownDirection.Right)
        End Select

    End Sub
    Private Sub liv_Detail_ItemDrag(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ItemDragEventArgs) Handles liv_Detail.ItemDrag
        gitmX = e.Item
        liv_Detail.DoDragDrop(e.Item, DragDropEffects.Move)
    End Sub
    Private Sub liv_Detail_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles liv_Detail.MouseMove
        ib_Drag = False
        If e.Button = Windows.Forms.MouseButtons.Left And Not gitmX Is Nothing Then
            If gF_isDragabledItem() Then
                ib_Drag = True
            End If
        End If
    End Sub
    Private Sub liv_Detail_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles liv_Detail.DragEnter
        e.Effect = e.AllowedEffect
    End Sub
    Private Sub liv_Detail_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles liv_Detail.DoubleClick
        If Not gitmX Is Nothing Then
            If gitmX.ImageIndex = UserIcon.Close Then
                Call g_FindAndSelectNode()
                trv_Explorer_NodeClick(gnodX)
            Else
                Call g_FindAndSelectNode()
                Call mnu_edit_Click()
            End If
        End If
    End Sub




End Class