Option Strict Off
Option Explicit On
Friend Class frm_GroupAddUser
	Inherits System.Windows.Forms.Form
	

	Private Sub frm_GroupAddUser_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
    End Sub
	
	Private Sub frm_GroupAddUser_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		g_CenterForm(Me)
	End Sub
	
	
	Private Sub lstSelectUser_DblClick()
        Call cmdDelete_Click(cmdDelete, New System.EventArgs())
	End Sub
	
	
	Private Sub lstUser_DblClick()
        Call cmdAppend_Click(cmdAppend, New System.EventArgs())
	End Sub
	
	
    Private Sub cmdOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOk.Click
        Dim i As Short
        frm_GroupAdd.cboGroupUser.Items.Clear()
        For i = 1 To livSelectUser.Items.Count
            frm_GroupAdd.cboGroupUser.Items.Add(livSelectUser.Items(i).Text)
        Next i
        Me.Close()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdAppend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAppend.Click
        If livUser.Items.Count = 0 Then Exit Sub
        Dim sSS As String
        sSS = Trim(livUser.Items(livUser.SelectedIndices(0)).Text)
        If livUser.Items(livUser.SelectedIndices(0)).Text = "USER" Then
            gitmX = livSelectUser.Items.Add("USER", sSS, UserIcon.User)
        Else
            gitmX = livSelectUser.Items.Add("GROUP", sSS, UserIcon.Group)
        End If
        livUser.Items.Remove(livUser.SelectedItems(0))
    End Sub

    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        Dim sSS As String
        sSS = Trim(livUser.Items(livSelectUser.SelectedIndices(0)).Text)
        If livSelectUser.Items(livUser.SelectedIndices(0)).Text = "USER" Then
            gitmX = livUser.Items.Add("USER", sSS, UserIcon.User)
        Else
            gitmX = livUser.Items.Add("GROUP", sSS, UserIcon.Group)
        End If
        livSelectUser.Items.Remove(livSelectUser.SelectedItems(0))
    End Sub
End Class