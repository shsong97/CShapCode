Option Strict Off
Option Explicit On
Friend Class frmRequestDetails
	Inherits System.Windows.Forms.Form
	
	Dim fRequestNo As String
	
	Public Sub setRequestNo(ByRef RequestNo As String)
		fRequestNo = RequestNo
	End Sub
	
	Private Sub TabCaption()
		tabDetails.TabPages.Item(0).Text = "User"
		tabDetails.TabPages.Item(1).Text = "Group"
		tabDetails.TabPages.Item(2).Text = "Grouping"
		tabDetails.TabPages.Item(3).Text = "Program"
		tabDetails.TabPages.Item(4).Text = "Program Security"
	End Sub
	


	Private Sub cboRequestNo_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboRequestNo.TextChanged
		fRequestNo = cboRequestNo.Text
	End Sub
	

	Private Sub cboRequestNo_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboRequestNo.SelectedIndexChanged
		fRequestNo = cboRequestNo.Text
		InqueryAllData()
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	Private Sub cmdInquery_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInquery.Click
		InqueryAllData()
	End Sub
	
	
	
	Private Sub frmRequestDetails_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		ShowForm(Me, 12000, 7500)
		FillComboBox()
	End Sub
	
	Private Sub FillComboBox()
		Dim lSQL As String
		
		lSQL = "SELECT request_no FROM request"
		Call sprComboBox(cboRequestNo, lSQL, fRequestNo)
	End Sub
	
	Private Sub InqueryAllData()
		On Error GoTo ErrHandler

		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		
		TabCaption()
		
		If Not InqueryRequest Then GoTo ErrHandler
		
		If Not InqueryUser And InqueryGroup And InqueryGrouping And InqueryProgram And InqueryProgSecurity Then GoTo ErrHandler
		

		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
		Exit Sub
ErrHandler: 

		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow
		Call gDisplayCemMessage()
	End Sub
	
	
	Private Function InqueryRequest() As Boolean
		On Error GoTo ErrHandler
		InqueryRequest = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT request_id,request_date,request_type,"
		gSQL = gSQL & "        request_desc = isnull(request_desc,''),"
		gSQL = gSQL & "        remark1 = isnull(remark1,''),"
		gSQL = gSQL & "        remark2 = isnull(remark2,''),"
		gSQL = gSQL & "        attach_file = isnull(attach_file,''),"
		gSQL = gSQL & "        change_id,"
		gSQL = gSQL & "        change_date = convert( varchar(10), change_date, 121 ) "
		gSQL = gSQL & "   FROM request"
		gSQL = gSQL & "  WHERE request_no = " & fRequestNo
		
        Dim g As GRSClass = New GRSClass(Gsql)

        If g.RowCount <> 1 Then Call gSetErrorMessage("���� �̻��մϴ�. 1���� ���� ���� ���߽��ϴ�.", True) : GoTo ErrHandler
		
        txtRequestID.Text = g.gRS("request_id")
        txtRequestDate.Text = g.gRS("request_date")
        txtRequestType.Text = g.gRS("request_type")
        txtRequestDesc.Text = g.gRS("request_desc")
        txtRemark1.Text = g.gRS("remark1")
        txtRemark2.Text = g.gRS("remark2")
        txtFile.Text = g.gRS("attach_file")
        txtChangeID.Text = g.gRS("change_id")
        txtChangeDate.Text = g.gRS("change_date")
		
		Exit Function
ErrHandler: 
		Call gSetErrorMessage("", False)
		Err.Clear()
		InqueryRequest = False
	End Function
	
	Private Function InqueryUser() As Boolean
		On Error GoTo ErrHandler
		InqueryUser = True
		
		gSQL = ""
		gSQL = " EXEC sp_request_details_user '" & fRequestNo & "'"
		
        If Not gFillSpread(sprSpread_0, Gsql) Then GoTo ErrHandler
		
        tabDetails.TabPages.Item(0).Text = tabDetails.TabPages.Item(0).Text & "(" & sprSpread_0.Sheets(0).RowCount & ")"
		Exit Function
ErrHandler: 
		Call gSetErrorMessage("", False)
		Err.Clear()
		InqueryUser = False
	End Function
	Private Function InqueryGroup() As Boolean
		On Error GoTo ErrHandler
		InqueryGroup = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT *"
		gSQL = gSQL & "   FROM group_info_audit"
		gSQL = gSQL & "  WHERE request_no = " & fRequestNo
		gSQL = gSQL & "  ORDER BY audit_log_id"
		
        If Not gFillSpread(sprSpread_1, Gsql) Then GoTo ErrHandler
		
        tabDetails.TabPages.Item(1).Text = tabDetails.TabPages.Item(1).Text & "(" & sprSpread_1.Sheets(0).RowCount & ")"
		Exit Function
ErrHandler: 
		Call gSetErrorMessage("", False)
		Err.Clear()
		InqueryGroup = False
	End Function
	Private Function InqueryGrouping() As Boolean
		On Error GoTo ErrHandler
		InqueryGrouping = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT *"
		gSQL = gSQL & "   FROM grouping_info_audit"
		gSQL = gSQL & "  WHERE request_no = " & fRequestNo
		gSQL = gSQL & "  ORDER BY audit_log_id"
		
        If Not gFillSpread(sprSpread_2, Gsql) Then GoTo ErrHandler
		
        tabDetails.TabPages.Item(2).Text = tabDetails.TabPages.Item(2).Text & "(" & sprSpread_2.Sheets(0).RowCount & ")"
		Exit Function
ErrHandler: 
		Call gSetErrorMessage("", False)
		Err.Clear()
		InqueryGrouping = False
	End Function
	Private Function InqueryProgram() As Boolean
		On Error GoTo ErrHandler
		InqueryProgram = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT *"
		gSQL = gSQL & "   FROM program_info_audit"
		gSQL = gSQL & "  WHERE request_no = " & fRequestNo
		gSQL = gSQL & "  ORDER BY audit_log_id"
		
        If Not gFillSpread(sprSpread_3, Gsql) Then GoTo ErrHandler
		
        tabDetails.TabPages.Item(3).Text = tabDetails.TabPages.Item(3).Text & "(" & sprSpread_3.Sheets(0).RowCount & ")"
		Exit Function
ErrHandler: 
		Call gSetErrorMessage("", False)
		Err.Clear()
		InqueryProgram = False
	End Function
	Private Function InqueryProgSecurity() As Boolean
		On Error GoTo ErrHandler
		InqueryProgSecurity = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT *"
		gSQL = gSQL & "   FROM prog_security_audit"
		gSQL = gSQL & "  WHERE request_no = " & fRequestNo
		gSQL = gSQL & "  ORDER BY audit_log_id"
		
        If Not gFillSpread(sprSpread_4, Gsql) Then GoTo ErrHandler
		
        tabDetails.TabPages.Item(4).Text = tabDetails.TabPages.Item(4).Text & "(" & sprSpread_4.Sheets(0).RowCount & ")"
		Exit Function
ErrHandler: 
		Call gSetErrorMessage("", False)
		Err.Clear()
		InqueryProgSecurity = False
	End Function
	
	Private Sub frmRequestDetails_FormClosed(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
		fRequestNo = ""
	End Sub
End Class