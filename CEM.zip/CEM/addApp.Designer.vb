<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_AppAdd
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents cboStatus As System.Windows.Forms.ComboBox
	Public WithEvents txtVersion As System.Windows.Forms.TextBox
	Public WithEvents _Label1_2 As System.Windows.Forms.Label
	Public WithEvents _Label1_3 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents txtMain_Server As System.Windows.Forms.TextBox
	Public WithEvents txtExtra_Server As System.Windows.Forms.TextBox
	Public WithEvents txtTarget_Path As System.Windows.Forms.TextBox
	Public WithEvents txtSource_Path As System.Windows.Forms.TextBox
	Public WithEvents txtLogon As System.Windows.Forms.TextBox
	Public WithEvents txtPassword As System.Windows.Forms.TextBox
	Public WithEvents txtCompany As System.Windows.Forms.TextBox
	Public WithEvents txt_Domain As System.Windows.Forms.TextBox
	Public WithEvents txtMemo As System.Windows.Forms.TextBox
	Public WithEvents txtDevelop_Tool As System.Windows.Forms.TextBox
	Public WithEvents txtExtra_Database As System.Windows.Forms.TextBox
	Public WithEvents txtMain_Database As System.Windows.Forms.TextBox
	Public WithEvents txtDevelop_date As System.Windows.Forms.TextBox
	Public WithEvents cboDevelop_ID As System.Windows.Forms.ComboBox
	Public WithEvents txt_ID As System.Windows.Forms.TextBox
	Public WithEvents txtApp_Program_Desc As System.Windows.Forms.TextBox
    Public WithEvents _Label1_5 As System.Windows.Forms.Label
	Public WithEvents _Label1_14 As System.Windows.Forms.Label
	Public WithEvents _Label1_15 As System.Windows.Forms.Label
	Public WithEvents _Label1_13 As System.Windows.Forms.Label
	Public WithEvents _Label1_17 As System.Windows.Forms.Label
	Public WithEvents _Label1_16 As System.Windows.Forms.Label
	Public WithEvents _Label1_10 As System.Windows.Forms.Label
	Public WithEvents _Label1_8 As System.Windows.Forms.Label
	Public WithEvents _Label1_4 As System.Windows.Forms.Label
	Public WithEvents _Label1_12 As System.Windows.Forms.Label
	Public WithEvents _Label1_11 As System.Windows.Forms.Label
	Public WithEvents _Label1_1 As System.Windows.Forms.Label
	Public WithEvents _Label1_9 As System.Windows.Forms.Label
	Public WithEvents _Label1_7 As System.Windows.Forms.Label
	Public WithEvents _Label1_6 As System.Windows.Forms.Label
	Public WithEvents _Label1_0 As System.Windows.Forms.Label
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.cboStatus = New System.Windows.Forms.ComboBox
        Me.txtVersion = New System.Windows.Forms.TextBox
        Me._Label1_2 = New System.Windows.Forms.Label
        Me._Label1_3 = New System.Windows.Forms.Label
        Me.txtMain_Server = New System.Windows.Forms.TextBox
        Me.txtExtra_Server = New System.Windows.Forms.TextBox
        Me.txtTarget_Path = New System.Windows.Forms.TextBox
        Me.txtSource_Path = New System.Windows.Forms.TextBox
        Me.txtLogon = New System.Windows.Forms.TextBox
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.txtCompany = New System.Windows.Forms.TextBox
        Me.txt_Domain = New System.Windows.Forms.TextBox
        Me.txtMemo = New System.Windows.Forms.TextBox
        Me.txtDevelop_Tool = New System.Windows.Forms.TextBox
        Me.txtExtra_Database = New System.Windows.Forms.TextBox
        Me.txtMain_Database = New System.Windows.Forms.TextBox
        Me.txtDevelop_date = New System.Windows.Forms.TextBox
        Me.cboDevelop_ID = New System.Windows.Forms.ComboBox
        Me.txt_ID = New System.Windows.Forms.TextBox
        Me.txtApp_Program_Desc = New System.Windows.Forms.TextBox
        Me._Label1_5 = New System.Windows.Forms.Label
        Me._Label1_14 = New System.Windows.Forms.Label
        Me._Label1_15 = New System.Windows.Forms.Label
        Me._Label1_13 = New System.Windows.Forms.Label
        Me._Label1_17 = New System.Windows.Forms.Label
        Me._Label1_16 = New System.Windows.Forms.Label
        Me._Label1_10 = New System.Windows.Forms.Label
        Me._Label1_8 = New System.Windows.Forms.Label
        Me._Label1_4 = New System.Windows.Forms.Label
        Me._Label1_12 = New System.Windows.Forms.Label
        Me._Label1_11 = New System.Windows.Forms.Label
        Me._Label1_1 = New System.Windows.Forms.Label
        Me._Label1_9 = New System.Windows.Forms.Label
        Me._Label1_7 = New System.Windows.Forms.Label
        Me._Label1_6 = New System.Windows.Forms.Label
        Me._Label1_0 = New System.Windows.Forms.Label
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.cmdOK = New System.Windows.Forms.Button
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cboStatus)
        Me.Frame1.Controls.Add(Me.txtVersion)
        Me.Frame1.Controls.Add(Me._Label1_2)
        Me.Frame1.Controls.Add(Me._Label1_3)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(360, 234)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(223, 78)
        Me.Frame1.TabIndex = 34
        Me.Frame1.TabStop = False
        '
        'cboStatus
        '
        Me.cboStatus.BackColor = System.Drawing.SystemColors.Window
        Me.cboStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboStatus.Location = New System.Drawing.Point(52, 43)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboStatus.Size = New System.Drawing.Size(159, 21)
        Me.cboStatus.TabIndex = 36
        '
        'txtVersion
        '
        Me.txtVersion.AcceptsReturn = True
        Me.txtVersion.BackColor = System.Drawing.SystemColors.Window
        Me.txtVersion.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtVersion.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtVersion.Location = New System.Drawing.Point(52, 18)
        Me.txtVersion.MaxLength = 20
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtVersion.Size = New System.Drawing.Size(159, 22)
        Me.txtVersion.TabIndex = 35
        '
        '_Label1_2
        '
        Me._Label1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_2.Location = New System.Drawing.Point(10, 22)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(36, 18)
        Me._Label1_2.TabIndex = 38
        Me._Label1_2.Text = "����"
        Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_3
        '
        Me._Label1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_3.Location = New System.Drawing.Point(10, 47)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(36, 18)
        Me._Label1_3.TabIndex = 37
        Me._Label1_3.Text = "����"
        Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMain_Server
        '
        Me.txtMain_Server.AcceptsReturn = True
        Me.txtMain_Server.BackColor = System.Drawing.SystemColors.Window
        Me.txtMain_Server.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMain_Server.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtMain_Server.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMain_Server.Location = New System.Drawing.Point(139, 121)
        Me.txtMain_Server.MaxLength = 15
        Me.txtMain_Server.Name = "txtMain_Server"
        Me.txtMain_Server.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMain_Server.Size = New System.Drawing.Size(162, 21)
        Me.txtMain_Server.TabIndex = 5
        '
        'txtExtra_Server
        '
        Me.txtExtra_Server.AcceptsReturn = True
        Me.txtExtra_Server.BackColor = System.Drawing.SystemColors.Window
        Me.txtExtra_Server.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtExtra_Server.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtExtra_Server.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtExtra_Server.Location = New System.Drawing.Point(367, 121)
        Me.txtExtra_Server.MaxLength = 15
        Me.txtExtra_Server.Name = "txtExtra_Server"
        Me.txtExtra_Server.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtExtra_Server.Size = New System.Drawing.Size(176, 21)
        Me.txtExtra_Server.TabIndex = 6
        '
        'txtTarget_Path
        '
        Me.txtTarget_Path.AcceptsReturn = True
        Me.txtTarget_Path.BackColor = System.Drawing.SystemColors.Window
        Me.txtTarget_Path.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTarget_Path.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtTarget_Path.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTarget_Path.Location = New System.Drawing.Point(785, 113)
        Me.txtTarget_Path.MaxLength = 255
        Me.txtTarget_Path.Name = "txtTarget_Path"
        Me.txtTarget_Path.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTarget_Path.Size = New System.Drawing.Size(208, 21)
        Me.txtTarget_Path.TabIndex = 4
        '
        'txtSource_Path
        '
        Me.txtSource_Path.AcceptsReturn = True
        Me.txtSource_Path.BackColor = System.Drawing.SystemColors.Window
        Me.txtSource_Path.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSource_Path.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtSource_Path.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSource_Path.Location = New System.Drawing.Point(139, 95)
        Me.txtSource_Path.MaxLength = 255
        Me.txtSource_Path.Name = "txtSource_Path"
        Me.txtSource_Path.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSource_Path.Size = New System.Drawing.Size(208, 21)
        Me.txtSource_Path.TabIndex = 3
        '
        'txtLogon
        '
        Me.txtLogon.AcceptsReturn = True
        Me.txtLogon.BackColor = System.Drawing.SystemColors.Window
        Me.txtLogon.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLogon.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtLogon.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLogon.Location = New System.Drawing.Point(139, 146)
        Me.txtLogon.MaxLength = 20
        Me.txtLogon.Name = "txtLogon"
        Me.txtLogon.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLogon.Size = New System.Drawing.Size(208, 21)
        Me.txtLogon.TabIndex = 7
        '
        'txtPassword
        '
        Me.txtPassword.AcceptsReturn = True
        Me.txtPassword.BackColor = System.Drawing.SystemColors.Window
        Me.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPassword.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtPassword.Location = New System.Drawing.Point(139, 172)
        Me.txtPassword.MaxLength = 30
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPassword.Size = New System.Drawing.Size(208, 21)
        Me.txtPassword.TabIndex = 8
        '
        'txtCompany
        '
        Me.txtCompany.AcceptsReturn = True
        Me.txtCompany.BackColor = System.Drawing.SystemColors.Window
        Me.txtCompany.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCompany.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtCompany.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCompany.Location = New System.Drawing.Point(139, 248)
        Me.txtCompany.MaxLength = 50
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCompany.Size = New System.Drawing.Size(208, 21)
        Me.txtCompany.TabIndex = 12
        '
        'txt_Domain
        '
        Me.txt_Domain.AcceptsReturn = True
        Me.txt_Domain.BackColor = System.Drawing.SystemColors.Window
        Me.txt_Domain.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Domain.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txt_Domain.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt_Domain.Location = New System.Drawing.Point(139, 18)
        Me.txt_Domain.MaxLength = 50
        Me.txt_Domain.Name = "txt_Domain"
        Me.txt_Domain.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt_Domain.Size = New System.Drawing.Size(208, 21)
        Me.txt_Domain.TabIndex = 0
        '
        'txtMemo
        '
        Me.txtMemo.AcceptsReturn = True
        Me.txtMemo.BackColor = System.Drawing.SystemColors.Window
        Me.txtMemo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMemo.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtMemo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMemo.Location = New System.Drawing.Point(138, 326)
        Me.txtMemo.MaxLength = 255
        Me.txtMemo.Name = "txtMemo"
        Me.txtMemo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMemo.Size = New System.Drawing.Size(445, 21)
        Me.txtMemo.TabIndex = 15
        '
        'txtDevelop_Tool
        '
        Me.txtDevelop_Tool.AcceptsReturn = True
        Me.txtDevelop_Tool.BackColor = System.Drawing.SystemColors.Window
        Me.txtDevelop_Tool.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDevelop_Tool.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtDevelop_Tool.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDevelop_Tool.Location = New System.Drawing.Point(139, 223)
        Me.txtDevelop_Tool.MaxLength = 50
        Me.txtDevelop_Tool.Name = "txtDevelop_Tool"
        Me.txtDevelop_Tool.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDevelop_Tool.Size = New System.Drawing.Size(208, 21)
        Me.txtDevelop_Tool.TabIndex = 11
        '
        'txtExtra_Database
        '
        Me.txtExtra_Database.AcceptsReturn = True
        Me.txtExtra_Database.BackColor = System.Drawing.SystemColors.Window
        Me.txtExtra_Database.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtExtra_Database.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtExtra_Database.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtExtra_Database.Location = New System.Drawing.Point(367, 197)
        Me.txtExtra_Database.MaxLength = 50
        Me.txtExtra_Database.Name = "txtExtra_Database"
        Me.txtExtra_Database.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtExtra_Database.Size = New System.Drawing.Size(176, 21)
        Me.txtExtra_Database.TabIndex = 10
        '
        'txtMain_Database
        '
        Me.txtMain_Database.AcceptsReturn = True
        Me.txtMain_Database.BackColor = System.Drawing.SystemColors.Window
        Me.txtMain_Database.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMain_Database.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtMain_Database.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMain_Database.Location = New System.Drawing.Point(139, 197)
        Me.txtMain_Database.MaxLength = 50
        Me.txtMain_Database.Name = "txtMain_Database"
        Me.txtMain_Database.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMain_Database.Size = New System.Drawing.Size(162, 21)
        Me.txtMain_Database.TabIndex = 9
        '
        'txtDevelop_date
        '
        Me.txtDevelop_date.AcceptsReturn = True
        Me.txtDevelop_date.BackColor = System.Drawing.SystemColors.Window
        Me.txtDevelop_date.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDevelop_date.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDevelop_date.Location = New System.Drawing.Point(139, 299)
        Me.txtDevelop_date.MaxLength = 20
        Me.txtDevelop_date.Name = "txtDevelop_date"
        Me.txtDevelop_date.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDevelop_date.Size = New System.Drawing.Size(208, 22)
        Me.txtDevelop_date.TabIndex = 14
        '
        'cboDevelop_ID
        '
        Me.cboDevelop_ID.BackColor = System.Drawing.SystemColors.Window
        Me.cboDevelop_ID.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboDevelop_ID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDevelop_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboDevelop_ID.Location = New System.Drawing.Point(139, 274)
        Me.cboDevelop_ID.Name = "cboDevelop_ID"
        Me.cboDevelop_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboDevelop_ID.Size = New System.Drawing.Size(208, 21)
        Me.cboDevelop_ID.TabIndex = 13
        '
        'txt_ID
        '
        Me.txt_ID.AcceptsReturn = True
        Me.txt_ID.BackColor = System.Drawing.SystemColors.Window
        Me.txt_ID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_ID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txt_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt_ID.Location = New System.Drawing.Point(139, 44)
        Me.txt_ID.MaxLength = 100
        Me.txt_ID.Name = "txt_ID"
        Me.txt_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt_ID.Size = New System.Drawing.Size(208, 21)
        Me.txt_ID.TabIndex = 1
        '
        'txtApp_Program_Desc
        '
        Me.txtApp_Program_Desc.AcceptsReturn = True
        Me.txtApp_Program_Desc.BackColor = System.Drawing.SystemColors.Window
        Me.txtApp_Program_Desc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtApp_Program_Desc.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtApp_Program_Desc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtApp_Program_Desc.Location = New System.Drawing.Point(139, 70)
        Me.txtApp_Program_Desc.MaxLength = 255
        Me.txtApp_Program_Desc.Name = "txtApp_Program_Desc"
        Me.txtApp_Program_Desc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtApp_Program_Desc.Size = New System.Drawing.Size(208, 21)
        Me.txtApp_Program_Desc.TabIndex = 2
        '
        '_Label1_5
        '
        Me._Label1_5.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_5.Location = New System.Drawing.Point(299, 125)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(62, 18)
        Me._Label1_5.TabIndex = 33
        Me._Label1_5.Text = "����"
        Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_14
        '
        Me._Label1_14.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_14.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_14.Location = New System.Drawing.Point(25, 125)
        Me._Label1_14.Name = "_Label1_14"
        Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_14.Size = New System.Drawing.Size(104, 18)
        Me._Label1_14.TabIndex = 32
        Me._Label1_14.Text = "�ּ���"
        Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_15
        '
        Me._Label1_15.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_15.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_15.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_15.Location = New System.Drawing.Point(25, 99)
        Me._Label1_15.Name = "_Label1_15"
        Me._Label1_15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_15.Size = New System.Drawing.Size(104, 18)
        Me._Label1_15.TabIndex = 31
        Me._Label1_15.Text = "Source Path"
        Me._Label1_15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_13
        '
        Me._Label1_13.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_13.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_13.Location = New System.Drawing.Point(671, 118)
        Me._Label1_13.Name = "_Label1_13"
        Me._Label1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_13.Size = New System.Drawing.Size(104, 18)
        Me._Label1_13.TabIndex = 30
        Me._Label1_13.Text = "Target Path"
        Me._Label1_13.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_17
        '
        Me._Label1_17.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_17.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_17.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_17.Location = New System.Drawing.Point(25, 151)
        Me._Label1_17.Name = "_Label1_17"
        Me._Label1_17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_17.Size = New System.Drawing.Size(104, 18)
        Me._Label1_17.TabIndex = 29
        Me._Label1_17.Text = "Logon"
        Me._Label1_17.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_16
        '
        Me._Label1_16.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_16.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_16.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_16.Location = New System.Drawing.Point(25, 177)
        Me._Label1_16.Name = "_Label1_16"
        Me._Label1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_16.Size = New System.Drawing.Size(104, 18)
        Me._Label1_16.TabIndex = 28
        Me._Label1_16.Text = "Password"
        Me._Label1_16.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_10
        '
        Me._Label1_10.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_10.Location = New System.Drawing.Point(25, 228)
        Me._Label1_10.Name = "_Label1_10"
        Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_10.Size = New System.Drawing.Size(104, 18)
        Me._Label1_10.TabIndex = 27
        Me._Label1_10.Text = "������"
        Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_8
        '
        Me._Label1_8.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_8.Location = New System.Drawing.Point(25, 202)
        Me._Label1_8.Name = "_Label1_8"
        Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_8.Size = New System.Drawing.Size(104, 18)
        Me._Label1_8.TabIndex = 26
        Me._Label1_8.Text = "�ֵ���Ÿ���̽�"
        Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_4
        '
        Me._Label1_4.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_4.Location = New System.Drawing.Point(299, 201)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(60, 18)
        Me._Label1_4.TabIndex = 25
        Me._Label1_4.Text = "����"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_12
        '
        Me._Label1_12.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_12.Location = New System.Drawing.Point(25, 254)
        Me._Label1_12.Name = "_Label1_12"
        Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_12.Size = New System.Drawing.Size(104, 18)
        Me._Label1_12.TabIndex = 24
        Me._Label1_12.Text = "ȸ��"
        Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_11
        '
        Me._Label1_11.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_11.Location = New System.Drawing.Point(24, 330)
        Me._Label1_11.Name = "_Label1_11"
        Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_11.Size = New System.Drawing.Size(104, 18)
        Me._Label1_11.TabIndex = 23
        Me._Label1_11.Text = "�޸�"
        Me._Label1_11.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_1
        '
        Me._Label1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_1.Location = New System.Drawing.Point(25, 22)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(104, 18)
        Me._Label1_1.TabIndex = 22
        Me._Label1_1.Text = "������"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_9
        '
        Me._Label1_9.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_9.Location = New System.Drawing.Point(25, 74)
        Me._Label1_9.Name = "_Label1_9"
        Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_9.Size = New System.Drawing.Size(104, 18)
        Me._Label1_9.TabIndex = 21
        Me._Label1_9.Text = "�������α׷���"
        Me._Label1_9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_7
        '
        Me._Label1_7.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_7.Location = New System.Drawing.Point(25, 279)
        Me._Label1_7.Name = "_Label1_7"
        Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_7.Size = New System.Drawing.Size(104, 18)
        Me._Label1_7.TabIndex = 20
        Me._Label1_7.Text = "������"
        Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_6.Location = New System.Drawing.Point(25, 304)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(104, 18)
        Me._Label1_6.TabIndex = 19
        Me._Label1_6.Text = "��������"
        Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_0.Location = New System.Drawing.Point(25, 48)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(104, 18)
        Me._Label1_0.TabIndex = 18
        Me._Label1_0.Text = "�������α׷�"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(407, 57)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(124, 33)
        Me.cmdCancel.TabIndex = 35
        Me.cmdCancel.Text = "���"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(407, 18)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(124, 33)
        Me.cmdOK.TabIndex = 36
        Me.cmdOK.Text = "���"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'frm_AppAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(609, 415)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.txtMain_Server)
        Me.Controls.Add(Me.txtExtra_Server)
        Me.Controls.Add(Me.txtTarget_Path)
        Me.Controls.Add(Me.txtSource_Path)
        Me.Controls.Add(Me.txtLogon)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtCompany)
        Me.Controls.Add(Me.txt_Domain)
        Me.Controls.Add(Me.txtMemo)
        Me.Controls.Add(Me.txtDevelop_Tool)
        Me.Controls.Add(Me.txtExtra_Database)
        Me.Controls.Add(Me.txtMain_Database)
        Me.Controls.Add(Me.txtDevelop_date)
        Me.Controls.Add(Me.cboDevelop_ID)
        Me.Controls.Add(Me.txt_ID)
        Me.Controls.Add(Me.txtApp_Program_Desc)
        Me.Controls.Add(Me._Label1_5)
        Me.Controls.Add(Me._Label1_14)
        Me.Controls.Add(Me._Label1_15)
        Me.Controls.Add(Me._Label1_13)
        Me.Controls.Add(Me._Label1_17)
        Me.Controls.Add(Me._Label1_16)
        Me.Controls.Add(Me._Label1_10)
        Me.Controls.Add(Me._Label1_8)
        Me.Controls.Add(Me._Label1_4)
        Me.Controls.Add(Me._Label1_12)
        Me.Controls.Add(Me._Label1_11)
        Me.Controls.Add(Me._Label1_1)
        Me.Controls.Add(Me._Label1_9)
        Me.Controls.Add(Me._Label1_7)
        Me.Controls.Add(Me._Label1_6)
        Me.Controls.Add(Me._Label1_0)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("����ü", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(195, 160)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_AppAdd"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�������α׷� ��� ( frm_AppAdd )"
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdOK As System.Windows.Forms.Button
#End Region 
End Class