<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_ProgAdd
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents txtSecurity_level As System.Windows.Forms.TextBox
	Public WithEvents txtVersion As System.Windows.Forms.TextBox
	Public WithEvents cboStatus As System.Windows.Forms.ComboBox
	Public WithEvents txtDevelop_date As System.Windows.Forms.TextBox
	Public WithEvents cboDevelop_ID As System.Windows.Forms.ComboBox
	Public WithEvents txtDevelop_chng_date As System.Windows.Forms.TextBox
	Public WithEvents cboDevelop_chng_ID As System.Windows.Forms.ComboBox
	Public WithEvents txt_ID As System.Windows.Forms.TextBox
	Public WithEvents txtProgram_Name As System.Windows.Forms.TextBox
    Public WithEvents _Label1_3 As System.Windows.Forms.Label
	Public WithEvents _Label1_9 As System.Windows.Forms.Label
	Public WithEvents _Label1_8 As System.Windows.Forms.Label
	Public WithEvents _Label1_7 As System.Windows.Forms.Label
	Public WithEvents _Label1_6 As System.Windows.Forms.Label
	Public WithEvents _Label1_5 As System.Windows.Forms.Label
	Public WithEvents _Label1_4 As System.Windows.Forms.Label
	Public WithEvents _Label1_2 As System.Windows.Forms.Label
	Public WithEvents _Label1_0 As System.Windows.Forms.Label
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtSecurity_level = New System.Windows.Forms.TextBox
        Me.txtVersion = New System.Windows.Forms.TextBox
        Me.cboStatus = New System.Windows.Forms.ComboBox
        Me.txtDevelop_date = New System.Windows.Forms.TextBox
        Me.cboDevelop_ID = New System.Windows.Forms.ComboBox
        Me.txtDevelop_chng_date = New System.Windows.Forms.TextBox
        Me.cboDevelop_chng_ID = New System.Windows.Forms.ComboBox
        Me.txt_ID = New System.Windows.Forms.TextBox
        Me.txtProgram_Name = New System.Windows.Forms.TextBox
        Me._Label1_3 = New System.Windows.Forms.Label
        Me._Label1_9 = New System.Windows.Forms.Label
        Me._Label1_8 = New System.Windows.Forms.Label
        Me._Label1_7 = New System.Windows.Forms.Label
        Me._Label1_6 = New System.Windows.Forms.Label
        Me._Label1_5 = New System.Windows.Forms.Label
        Me._Label1_4 = New System.Windows.Forms.Label
        Me._Label1_2 = New System.Windows.Forms.Label
        Me._Label1_0 = New System.Windows.Forms.Label
        Me.cmdOk = New System.Windows.Forms.Button
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'txtSecurity_level
        '
        Me.txtSecurity_level.AcceptsReturn = True
        Me.txtSecurity_level.BackColor = System.Drawing.SystemColors.Window
        Me.txtSecurity_level.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSecurity_level.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtSecurity_level.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSecurity_level.Location = New System.Drawing.Point(129, 82)
        Me.txtSecurity_level.MaxLength = 255
        Me.txtSecurity_level.Name = "txtSecurity_level"
        Me.txtSecurity_level.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSecurity_level.Size = New System.Drawing.Size(197, 21)
        Me.txtSecurity_level.TabIndex = 2
        '
        'txtVersion
        '
        Me.txtVersion.AcceptsReturn = True
        Me.txtVersion.BackColor = System.Drawing.SystemColors.Window
        Me.txtVersion.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtVersion.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtVersion.Location = New System.Drawing.Point(129, 255)
        Me.txtVersion.MaxLength = 20
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtVersion.Size = New System.Drawing.Size(197, 22)
        Me.txtVersion.TabIndex = 8
        '
        'cboStatus
        '
        Me.cboStatus.BackColor = System.Drawing.SystemColors.Window
        Me.cboStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboStatus.Location = New System.Drawing.Point(129, 225)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboStatus.Size = New System.Drawing.Size(197, 21)
        Me.cboStatus.TabIndex = 7
        '
        'txtDevelop_date
        '
        Me.txtDevelop_date.AcceptsReturn = True
        Me.txtDevelop_date.BackColor = System.Drawing.SystemColors.Window
        Me.txtDevelop_date.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDevelop_date.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDevelop_date.Location = New System.Drawing.Point(129, 140)
        Me.txtDevelop_date.MaxLength = 20
        Me.txtDevelop_date.Name = "txtDevelop_date"
        Me.txtDevelop_date.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDevelop_date.Size = New System.Drawing.Size(197, 22)
        Me.txtDevelop_date.TabIndex = 4
        '
        'cboDevelop_ID
        '
        Me.cboDevelop_ID.BackColor = System.Drawing.SystemColors.Window
        Me.cboDevelop_ID.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboDevelop_ID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDevelop_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboDevelop_ID.Location = New System.Drawing.Point(129, 111)
        Me.cboDevelop_ID.Name = "cboDevelop_ID"
        Me.cboDevelop_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboDevelop_ID.Size = New System.Drawing.Size(197, 21)
        Me.cboDevelop_ID.TabIndex = 3
        '
        'txtDevelop_chng_date
        '
        Me.txtDevelop_chng_date.AcceptsReturn = True
        Me.txtDevelop_chng_date.BackColor = System.Drawing.SystemColors.Window
        Me.txtDevelop_chng_date.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDevelop_chng_date.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDevelop_chng_date.Location = New System.Drawing.Point(129, 197)
        Me.txtDevelop_chng_date.MaxLength = 20
        Me.txtDevelop_chng_date.Name = "txtDevelop_chng_date"
        Me.txtDevelop_chng_date.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDevelop_chng_date.Size = New System.Drawing.Size(197, 22)
        Me.txtDevelop_chng_date.TabIndex = 6
        '
        'cboDevelop_chng_ID
        '
        Me.cboDevelop_chng_ID.BackColor = System.Drawing.SystemColors.Window
        Me.cboDevelop_chng_ID.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboDevelop_chng_ID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDevelop_chng_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboDevelop_chng_ID.Location = New System.Drawing.Point(129, 168)
        Me.cboDevelop_chng_ID.Name = "cboDevelop_chng_ID"
        Me.cboDevelop_chng_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboDevelop_chng_ID.Size = New System.Drawing.Size(197, 21)
        Me.cboDevelop_chng_ID.TabIndex = 5
        '
        'txt_ID
        '
        Me.txt_ID.AcceptsReturn = True
        Me.txt_ID.BackColor = System.Drawing.SystemColors.Window
        Me.txt_ID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_ID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txt_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt_ID.Location = New System.Drawing.Point(129, 24)
        Me.txt_ID.MaxLength = 100
        Me.txt_ID.Name = "txt_ID"
        Me.txt_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt_ID.Size = New System.Drawing.Size(197, 21)
        Me.txt_ID.TabIndex = 0
        '
        'txtProgram_Name
        '
        Me.txtProgram_Name.AcceptsReturn = True
        Me.txtProgram_Name.BackColor = System.Drawing.SystemColors.Window
        Me.txtProgram_Name.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProgram_Name.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtProgram_Name.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtProgram_Name.Location = New System.Drawing.Point(129, 53)
        Me.txtProgram_Name.MaxLength = 255
        Me.txtProgram_Name.Name = "txtProgram_Name"
        Me.txtProgram_Name.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtProgram_Name.Size = New System.Drawing.Size(197, 21)
        Me.txtProgram_Name.TabIndex = 1
        '
        '_Label1_3
        '
        Me._Label1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_3.Location = New System.Drawing.Point(8, 228)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(104, 18)
        Me._Label1_3.TabIndex = 19
        Me._Label1_3.Text = "����"
        Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_9
        '
        Me._Label1_9.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_9.Location = New System.Drawing.Point(9, 56)
        Me._Label1_9.Name = "_Label1_9"
        Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_9.Size = New System.Drawing.Size(104, 18)
        Me._Label1_9.TabIndex = 18
        Me._Label1_9.Text = "���α׷���"
        Me._Label1_9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_8
        '
        Me._Label1_8.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_8.Location = New System.Drawing.Point(9, 85)
        Me._Label1_8.Name = "_Label1_8"
        Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_8.Size = New System.Drawing.Size(104, 18)
        Me._Label1_8.TabIndex = 17
        Me._Label1_8.Text = "���ȷ���"
        Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_7
        '
        Me._Label1_7.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_7.Location = New System.Drawing.Point(9, 114)
        Me._Label1_7.Name = "_Label1_7"
        Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_7.Size = New System.Drawing.Size(104, 18)
        Me._Label1_7.TabIndex = 16
        Me._Label1_7.Text = "������"
        Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_6.Location = New System.Drawing.Point(9, 142)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(104, 18)
        Me._Label1_6.TabIndex = 15
        Me._Label1_6.Text = "��������"
        Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_5
        '
        Me._Label1_5.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_5.Location = New System.Drawing.Point(9, 171)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(104, 18)
        Me._Label1_5.TabIndex = 14
        Me._Label1_5.Text = "���ߺ�����"
        Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_4
        '
        Me._Label1_4.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_4.Location = New System.Drawing.Point(9, 200)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(104, 18)
        Me._Label1_4.TabIndex = 13
        Me._Label1_4.Text = "���ߺ�������"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_2
        '
        Me._Label1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_2.Location = New System.Drawing.Point(8, 258)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(104, 18)
        Me._Label1_2.TabIndex = 12
        Me._Label1_2.Text = "����"
        Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_0.Location = New System.Drawing.Point(9, 27)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(104, 18)
        Me._Label1_0.TabIndex = 11
        Me._Label1_0.Text = "���α׷�"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmdOk
        '
        Me.cmdOk.Location = New System.Drawing.Point(70, 312)
        Me.cmdOk.Name = "cmdOk"
        Me.cmdOk.Size = New System.Drawing.Size(104, 33)
        Me.cmdOk.TabIndex = 20
        Me.cmdOk.Text = "���"
        Me.cmdOk.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(211, 312)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(105, 33)
        Me.cmdCancel.TabIndex = 21
        Me.cmdCancel.Text = "���"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'frm_ProgAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(391, 377)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOk)
        Me.Controls.Add(Me.txtSecurity_level)
        Me.Controls.Add(Me.txtVersion)
        Me.Controls.Add(Me.cboStatus)
        Me.Controls.Add(Me.txtDevelop_date)
        Me.Controls.Add(Me.cboDevelop_ID)
        Me.Controls.Add(Me.txtDevelop_chng_date)
        Me.Controls.Add(Me.cboDevelop_chng_ID)
        Me.Controls.Add(Me.txt_ID)
        Me.Controls.Add(Me.txtProgram_Name)
        Me.Controls.Add(Me._Label1_3)
        Me.Controls.Add(Me._Label1_9)
        Me.Controls.Add(Me._Label1_8)
        Me.Controls.Add(Me._Label1_7)
        Me.Controls.Add(Me._Label1_6)
        Me.Controls.Add(Me._Label1_5)
        Me.Controls.Add(Me._Label1_4)
        Me.Controls.Add(Me._Label1_2)
        Me.Controls.Add(Me._Label1_0)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("����ü", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Location = New System.Drawing.Point(442, 76)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_ProgAdd"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "���α׷� ��� ( frm_ProgAdd )"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdOk As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
#End Region 
End Class