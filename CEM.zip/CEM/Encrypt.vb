﻿Imports System.Text
imports System.Security.Cryptography

Public Class Encrypt
    Public Function IsCorectPassword(ByVal original As String, ByVal encrypt As String) As Boolean
        Dim data As Byte() = Encoding.UTF8.GetBytes(original)
        Dim result As Byte()

        Dim shaM As SHA256 = New SHA256Managed()
        result = shaM.ComputeHash(data)

        Dim enc_original As String = Convert.ToBase64String(result)
        If enc_original.Equals(encrypt) Then
            Return True
        Else
            Return False
        End If

    End Function

    Public Function EncryptPassword(ByVal password As String) As String
        Dim data As Byte() = Encoding.UTF8.GetBytes(password)
        Dim result As Byte()

        Dim shaM As SHA256 = New SHA256Managed()
        result = shaM.ComputeHash(data)
        Return Convert.ToBase64String(result)
    End Function

End Class
