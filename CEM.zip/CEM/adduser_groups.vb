Option Strict Off
Option Explicit On
Friend Class frm_UserAddGroup
	Inherits System.Windows.Forms.Form
	
	Private Sub frm_UserAddGroup_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		g_CenterForm(Me)
	End Sub

	Private Sub lstSelectGroup_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstSelectGroup.DoubleClick
        Call cmdDelete_Click(cmdDelete, New System.EventArgs())
	End Sub
	
	Private Sub lstGroup_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstGroup.DoubleClick
        Call cmdDelete_Click(cmdDelete, New System.EventArgs())
	End Sub

    Private Sub cmdAppend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAppend.Click
        If lstGroup.SelectedIndex <> -1 Then
            lstSelectGroup.Items.Add(VB6.GetItemString(lstGroup, Me.lstGroup.SelectedIndex))
            lstGroup.Items.RemoveAt(lstGroup.SelectedIndex)
        End If
    End Sub

    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If lstSelectGroup.SelectedIndex <> -1 Then
            lstGroup.Items.Add(VB6.GetItemString(lstSelectGroup, lstSelectGroup.SelectedIndex))
            lstSelectGroup.Items.RemoveAt(lstSelectGroup.SelectedIndex)
        End If
    End Sub

    Private Sub cmdOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOk.Click
        Dim i As Short

        frm_UserAdd.cboUserGroup.Items.Clear()

        For i = 0 To lstSelectGroup.Items.Count - 1
            frm_UserAdd.cboUserGroup.Items.Add(VB6.GetItemString(lstSelectGroup, i))
        Next i

        Me.Close()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub
End Class