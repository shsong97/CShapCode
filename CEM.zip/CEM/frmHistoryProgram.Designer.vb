<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmHistoryProgram
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents cboProgram As System.Windows.Forms.ComboBox
	Public WithEvents cmdInquery As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.Frame2 = New System.Windows.Forms.GroupBox
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.cboProgram = New System.Windows.Forms.ComboBox
        Me.cmdInquery = New System.Windows.Forms.Button
        Me.cmdClose = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.sprProgram = New FarPoint.Win.Spread.FpSpread
        Me.sprProgram_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.sprProgSecurity = New FarPoint.Win.Spread.FpSpread
        Me.sprProgSecurity_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Frame1.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.frmButton.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me.sprProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprProgram_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprProgSecurity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprProgSecurity_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.sprProgram)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(0, 56)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(689, 225)
        Me.Frame1.TabIndex = 7
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Program"
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.sprProgSecurity)
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(0, 288)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(689, 217)
        Me.Frame2.TabIndex = 5
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "Program Security"
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.cboProgram)
        Me.frmButton.Controls.Add(Me.cmdInquery)
        Me.frmButton.Controls.Add(Me.cmdClose)
        Me.frmButton.Controls.Add(Me.Label8)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(689, 49)
        Me.frmButton.TabIndex = 0
        Me.frmButton.TabStop = False
        '
        'cboProgram
        '
        Me.cboProgram.BackColor = System.Drawing.SystemColors.Window
        Me.cboProgram.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboProgram.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProgram.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboProgram.Location = New System.Drawing.Point(64, 16)
        Me.cboProgram.Name = "cboProgram"
        Me.cboProgram.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboProgram.Size = New System.Drawing.Size(145, 21)
        Me.cboProgram.TabIndex = 3
        '
        'cmdInquery
        '
        Me.cmdInquery.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInquery.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInquery.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInquery.Location = New System.Drawing.Point(544, 16)
        Me.cmdInquery.Name = "cmdInquery"
        Me.cmdInquery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInquery.Size = New System.Drawing.Size(65, 25)
        Me.cmdInquery.TabIndex = 2
        Me.cmdInquery.Text = "��ȸ"
        Me.cmdInquery.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(616, 16)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(65, 25)
        Me.cmdClose.TabIndex = 1
        Me.cmdClose.Text = "����"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(8, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(73, 20)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Program"
        '
        'StatusBar1
        '
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 501)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(694, 22)
        Me.StatusBar1.TabIndex = 9
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = False
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(963, 17)
        Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'sprProgram
        '
        Me.sprProgram.AccessibleDescription = ""
        Me.sprProgram.Location = New System.Drawing.Point(3, 16)
        Me.sprProgram.Name = "sprProgram"
        Me.sprProgram.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprProgram_Sheet1})
        Me.sprProgram.Size = New System.Drawing.Size(679, 206)
        Me.sprProgram.TabIndex = 0
        '
        'sprProgram_Sheet1
        '
        Me.sprProgram_Sheet1.Reset()
        Me.sprProgram_Sheet1.SheetName = "Sheet1"
        '
        'sprProgSecurity
        '
        Me.sprProgSecurity.AccessibleDescription = ""
        Me.sprProgSecurity.Location = New System.Drawing.Point(3, 16)
        Me.sprProgSecurity.Name = "sprProgSecurity"
        Me.sprProgSecurity.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprProgSecurity_Sheet1})
        Me.sprProgSecurity.Size = New System.Drawing.Size(679, 194)
        Me.sprProgSecurity.TabIndex = 0
        '
        'sprProgSecurity_Sheet1
        '
        Me.sprProgSecurity_Sheet1.Reset()
        Me.sprProgSecurity_Sheet1.SheetName = "Sheet1"
        '
        'frmHistoryProgram
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(694, 523)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Frame2)
        Me.Controls.Add(Me.frmButton)
        Me.Controls.Add(Me.StatusBar1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 23)
        Me.Name = "frmHistoryProgram"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "���α׷� �̷� ��ȸ ( frmHistoryProgram )"
        Me.Frame1.ResumeLayout(False)
        Me.Frame2.ResumeLayout(False)
        Me.frmButton.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me.sprProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprProgram_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprProgSecurity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprProgSecurity_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents sprProgram As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprProgram_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents sprProgSecurity As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprProgSecurity_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class