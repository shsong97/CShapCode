Option Strict Off
Option Explicit On
Module basError
	Public gErrorMessage As String
	Public gErrWriteFlag As Boolean
	Public gErrorDescription As String
	Public gMessageDisplayFlag As Boolean
	
    Public Sub gDisplayMessage()
        If gMessageDisplayFlag Then MsgBox(gErrorMessage)
    End Sub

	Public Sub gSetErrorDescription()
		gErrorDescription = "Business Logic Error!!"
		If Err.Number <> 0 Then gErrorDescription = "Error��ȣ:" & Str(Err.Number) & "// ����:" & Err.Description
	End Sub
  
	Public Sub gSetErrorMessage(ByRef lMessage As String, ByRef initFlag As Boolean)
		If initFlag Then gErrorMessage = ""
		
		If Err.Number <> 0 Then
			gErrorMessage = lMessage & gGetNewLine & gErrorMessage & gGetNewLine & "Error Description : " & Err.Description
		Else
			gErrorMessage = lMessage & gGetNewLine & gErrorMessage
		End If
	End Sub
	Public Function gGetNewLine() As String
		gGetNewLine = (Chr(13) & Chr(10))
	End Function
	    
	 
End Module