Option Strict Off
Option Explicit On
Module mod_DBserv

    Public gs_Err As String
    Public g As GRSClass
	Public Gsql As String
    Public gUSERID As String
    Public gUserPW As String
    Public gUserLevel As Short
    Public gCo_Server As String

    Public gRequestNo As String

    Public Const DbLogonID As String = "AppCEM"
    Public Const DbLogonPwd As String = "app@.2012.04.CE"

	
	Public Sub g_CloseDB()
        DBManager.Close()
    End Sub
	
	
    Public Sub gDisplayCemMessage()
        MessageBox.Show(gErrorMessage)
    End Sub

    Public Sub gFillSpreadHead(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef g As GRSClass)
        On Error GoTo CLEANUP
        Dim dt As DataTable = g.GetDT()
        With sprSpread.Sheets(0)
            For iny As Integer = 0 To g.ColCount - 1
                .ColumnHeader.Columns(iny).HorizontalAlignment = CellHorizontalAlignment.Center
                .ColumnHeader.Columns(iny).Label = dt.Columns(iny).Caption
                .ColumnHeader.Columns(iny).Width = dt.Columns(iny).Caption.Length * 10
            Next
        End With

        Exit Sub
CLEANUP:
        Call gSetErrorMessage("Spread Head Display Error!!!", True)
        Err.Clear()
        Call gDisplayCemMessage()
    End Sub


    Public Function gFillSpread(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef Gsql As String) As Boolean
        On Error GoTo CLEANUP
        gFillSpread = True

        Dim lRow, lCol As Integer
        Dim lMaxRow As Integer
        Dim lMaxCol As Integer

        lRow = 0
        lMaxRow = 0
        lMaxCol = 0

        sprSpread.Sheets(0).RowCount = 0
        Dim g As GRSClass = New GRSClass(Gsql)

        If g.RowCount < 1 Then
            Call gSetErrorMessage("��ȸ�� ����� �����ϴ�.", True)
            GoTo CLEANUP
        End If

        With sprSpread.Sheets(0)

            If g.RowCount <> 0 Then
                lMaxRow = lMaxRow + g.RowCount
                .RowCount = lMaxRow
                If lMaxCol < g.ColCount Then lMaxCol = g.ColCount : .ColumnCount = lMaxCol
                Call gFillSpreadHead(sprSpread, g)
                lRow = lRow + 1
            End If

            For inx As Integer = 0 To g.RowCount - 1
                For iny As Integer = 0 To g.ColCount - 1
                    .Cells(inx, iny).Text = g.gRS(iny)
                Next
                g.MoveNext()
            Next

        End With
        Exit Function
CLEANUP:
        gFillSpread = False
    End Function


    Public Function sprComboBox(ByRef combo As ComboBox, ByVal SQL As String, ByRef txtTitle As String, Optional ByRef allflag As Boolean = False) As Boolean
        On Error GoTo CLEANUP
        Dim i As Short
        Dim save_index As Integer = 0

        sprComboBox = True
        Dim g As GRSClass = New GRSClass(SQL)
        combo.Items.Clear()

        For i = 0 To g.RowCount - 1
            combo.Items.Add(g.gRS(0))
            g.MoveNext()
        Next

        If allflag Then combo.Items.Add("All")

        For i = 0 To combo.Items.Count - 1

            If txtTitle = combo.Items(i).ToString() Then
                save_index = i
            End If
        Next
        combo.SelectedIndex = save_index


        Exit Function
CLEANUP:
        Err.Clear()
        sprComboBox = False
    End Function

    Public Function CheckRequestNo() As Boolean
        On Error GoTo ErrHandler
        Dim isFlag As Short

        CheckRequestNo = True

        If gRequestNo = "" Then
            isFlag = MsgBox("����� ��û�� ���� ������ �Է����� �����̽��ϴ�. " & vbCrLf & "���� �Է��Ͻðڽ��ϱ�?", MsgBoxStyle.YesNo + MsgBoxStyle.Information)

            If isFlag = MsgBoxResult.Yes Then
                frmRequestMgt.ShowDialog()
            Else
                GoTo ErrHandler
            End If
        End If

        Exit Function
ErrHandler:
        Err.Clear()
        CheckRequestNo = False
    End Function

    Public Sub ShowForm(ByRef Form As System.Windows.Forms.Form, Optional ByRef FormWidth As Integer = 10000, Optional ByRef FormHeight As Integer = 7500)
        Form.Width = VB6.TwipsToPixelsX(FormWidth)
        Form.Height = VB6.TwipsToPixelsY(FormHeight)

        Form.SetBounds(VB6.TwipsToPixelsX((VB6.PixelsToTwipsX(System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width) - VB6.PixelsToTwipsX(Form.Width)) \ 2), VB6.TwipsToPixelsY((VB6.PixelsToTwipsY(System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height) - VB6.PixelsToTwipsY(Form.Height)) \ 2), 0, 0, Windows.Forms.BoundsSpecified.X Or Windows.Forms.BoundsSpecified.Y)
    End Sub
    Function gF_GetFromString2TokenArray(ByRef target As String, Optional ByRef Sep As String = ";") As String

        Dim j As Short 'find string position
        Dim ls_Return As String

        j = InStr(1, target, Sep, 0)
        If j = 0 Then
            gF_GetFromString2TokenArray = Trim(target)
        Else
            ls_Return = Left(target, j - 1)
            target = Mid(target, j + 1)
            gF_GetFromString2TokenArray = Trim(ls_Return)
        End If

    End Function

    Sub g_CenterForm(ByRef frmX As System.Windows.Forms.Form)

        frmX.Enabled = False
        frmX.Top = VB6.TwipsToPixelsY((VB6.PixelsToTwipsY(System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height) * 0.95) \ 2 - VB6.PixelsToTwipsY(frmX.Height) \ 2)
        frmX.Left = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width) \ 2 - VB6.PixelsToTwipsX(frmX.Width) \ 2)
        frmX.Enabled = True

    End Sub

    '�޺��ڽ��� �ؽ�Ʈ�ڽ����� ������ �����Ѵ�.
    Sub g_ControlTextClear(ByRef frmX As System.Windows.Forms.Form)
        'Dim Control As System.Windows.Forms.Control

        'For	Each Control In frmX.Controls
        '	'UPGRADE_WARNING: TypeOf�� �� ������ �ֽ��ϴ�. �ڼ��� ������ ������ �����Ͻʽÿ�. 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
        '	If TypeOf Control Is System.Windows.Forms.TextBox Then
        '		Control.Text = ""
        '	End If
        '	'UPGRADE_WARNING: TypeOf�� �� ������ �ֽ��ϴ�. �ڼ��� ������ ������ �����Ͻʽÿ�. 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
        '	If TypeOf Control Is System.Windows.Forms.ComboBox Then
        '		Select Case Control.Name
        '			Case "cboUserGroup", "cboGroupUser"
        '				'UPGRADE_WARNING: Control.Clear ��ü�� �⺻ �Ӽ��� Ȯ���� �� �����ϴ�. �ڼ��� ������ ������ �����Ͻʽÿ�. 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '				Control.Clear()
        '			Case Else
        '				'UPGRADE_WARNING: Control.ListCount ��ü�� �⺻ �Ӽ��� Ȯ���� �� �����ϴ�. �ڼ��� ������ ������ �����Ͻʽÿ�. 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '				'UPGRADE_WARNING: Control.ListIndex ��ü�� �⺻ �Ӽ��� Ȯ���� �� �����ϴ�. �ڼ��� ������ ������ �����Ͻʽÿ�. 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '				If Control.ListCount > 0 Then Control.ListIndex = 0
        '		End Select
        '	End If
        'Next Control

    End Sub


    '�޺��ڽ��� �ش��ڵ带 ã�� LIstIndex�� �����Ѵ�.
    Sub g_FindSetCombotIndex(ByRef cboX As System.Windows.Forms.ComboBox, ByRef as_Find As String)

        Dim i As Short
        Dim iLen As Short

        iLen = Len(as_Find)
        If iLen > 0 Then
            If cboX.Items.Count > 0 Then
                '���
            Else
                Exit Sub
            End If
        Else
            If cboX.Items.Count > 0 Then
                ' cboX.ListIndex = -1
            End If
            Exit Sub
        End If

        For i = 0 To cboX.Items.Count - 1
            If as_Find = Right(VB6.GetItemString(cboX, i), iLen) Then
                cboX.SelectedIndex = i
                Exit Sub
            End If
        Next i

    End Sub


    Function gF_Error_Handler() As String

        Dim ls_Return As String

        gs_Err = gs_Err & "����" & vbCrLf
        gs_Err = gs_Err & "--------------------------------------------------" & vbCrLf
        gs_Err = gs_Err & "��ȣ     : " & Err.Number & vbCrLf
        gs_Err = gs_Err & "���λ��� : " & Err.Description & vbCrLf
        gs_Err = gs_Err & "�߻�ó   : " & Err.Source & vbCrLf & vbCrLf

        Select Case Err.Number

            Case 91 'settinge���� ���� ����
                gs_Err = gs_Err & "settinge���� ���� ���� ; �� ���ν����� �����ϴ�.."
                ls_Return = "X"
            Case 40002
                gs_Err = gs_Err & "�� ���ν����� �����ϴ�."
                ls_Return = "X"
            Case Else
                gs_Err = gs_Err & "�� ���ν����� �����ϴ�."
                ls_Return = "X"
        End Select

        Gsql = ""
        gs_Err = ""
        Err.Clear()

        gF_Error_Handler = ls_Return

    End Function
End Module