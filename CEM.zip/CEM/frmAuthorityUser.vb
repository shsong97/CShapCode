Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmAuthorityUser
	Inherits System.Windows.Forms.Form
	
	Private Sub cboDomain_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboDomain.SelectedIndexChanged
        Call lsApplicationCall()
    End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	
	Private Sub cmdInquery_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInquery.Click
		
		If txtUserID.Text = "" Then
			MsgBox("�˻��Ͻ� ����ڸ� ������ �ּ���.",  , "Ȯ��")
			frmProgramList.ShowDialog()
			Exit Sub
		End If
		
		InqueryAllData()
		
	End Sub
	
	
	
	Private Sub InqueryAllData()
		Call gSetErrorMessage("", True)
		InqueryUserAuthority()
	End Sub
	
	Private Function InqueryUserAuthority() As Boolean
		Dim AppCode As String
		On Error GoTo ErrHandler
		
		AppCode = Trim(VB.Right(cboApplication.Text, 50))
		InqueryUserAuthority = True
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		gSQL = ""
		gSQL = gSQL & " EXEC sp_audit_authority_user '"
		gSQL = gSQL & Trim(UCase(txtUserID.Text)) & "'"
		If AppCode <> "" Then
			gSQL = gSQL & ",'" & AppCode & "'"
		End If
		
        If Not gFillSpread(sprSpread, Gsql) Then GoTo ErrHandler
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		Exit Function
ErrHandler: 
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		Call gSetErrorMessage("", False)
		Err.Clear()
		Call gDisplayCemMessage()
		InqueryUserAuthority = False
	End Function
	
	
	Private Sub cmdSearchInfo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSearchInfo.Click
		frmProgramList.ShowDialog()
	End Sub
	
	Private Sub frmAuthorityUser_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
        gs_listCode = "2"
    End Sub
	
	Private Sub frmAuthorityUser_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		gs_listCode = "2"
		Call lsAddComboBox()
		ShowForm(Me)
	End Sub
	Private Sub lsApplicationCall()
        Dim g As GRSClass
		Dim i As Integer
		'���ø����̼�
		gSQL = "SELECT app_program_desc,app_program "
		gSQL = gSQL & " FROM app_prog_info "
		gSQL = gSQL & " WHERE domain='" & Trim(cboDomain.Text) & "'"
		gSQL = gSQL & " ORDER BY app_program_desc"
		
        g = New GRSClass(Gsql)

		cboApplication.Items.Clear()
		cboApplication.Items.Add("")
        For i = 1 To g.RowCount
            cboApplication.Items.Add(g.gRS(0) & Space(50) & g.gRS(1))
            g.MoveNext()
        Next i
		cboApplication.SelectedIndex = 0
	End Sub
	Private Sub lsAddComboBox()
		Dim i As Integer
        Dim g As GRSClass
		
		'������
		gSQL = "SELECT DISTINCT domain FROM app_prog_info ORDER BY domain"
        g = New GRSClass(Gsql)
	
        For i = 1 To g.RowCount
            cboDomain.Items.Add(g.gRS(0))
            g.MoveNext()
        Next i
		
		cboDomain.SelectedIndex = 0
    End Sub
	
	Private Sub frmAuthorityUser_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
        sprSpread.Width = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - 145)

        If VB6.PixelsToTwipsY(Me.Height) >= 7000 Then
            sprSpread.Height = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - 1305)
        Else
            sprSpread.Height = VB6.TwipsToPixelsY(5295)
        End If

    End Sub
	
	Private Sub txtUserId_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtUserId.Click
		txtUserID.Text = "" : txtUserName.Text = ""
	End Sub
	
	Private Sub txtUserName_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtUserName.Click
		txtUserID.Text = "" : txtUserName.Text = ""
	End Sub
End Class