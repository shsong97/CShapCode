Option Strict Off
Option Explicit On
Friend Class frmHistoryGroup
	Inherits System.Windows.Forms.Form
	
	Dim fGroupID As String
	
	Public Sub SetGroupID(ByRef lGroupID As String)
        Me.Show()
        fGroupID = Trim(lGroupID)
        Call Set_cboIndex(cboGroup, fGroupID, Len(fGroupID))
        InqueryAllData()
	End Sub
	
	Private Sub cboApplication_Click()
		InqueryAllData()
	End Sub
	

	Private Sub cboGroup_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboGroup.SelectedIndexChanged
		fGroupID = Trim(cboGroup.Text)
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	Private Sub frmHistoryGroup_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Gsql = "select group_id from group_info order by group_id"
        Call sprComboBox(cboGroup, Gsql, "", True)
        InqueryAllData()
	End Sub
	
	Private Sub cmdInquery_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInquery.Click
		InqueryAllData()
	End Sub
	
	Private Sub InqueryAllData()
		InqueryHistoryGroup()
		InqueryHistoryGrouping()
	End Sub
	
	Private Function InqueryHistoryGroup() As Boolean
		On Error GoTo ErrHandler
		InqueryHistoryGroup = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT group_id,group_name,group_sec_level,memo,chng_date,chng_id,request_no,modify_id,modify_host,modify_app,modify_date,modify_contents"
		gSQL = gSQL & "   FROM group_info_audit"
		If Trim(cboGroup.Text) <> "All" Then
			gSQL = gSQL & "  WHERE group_id = '" & fGroupID & "'"
		End If
		gSQL = gSQL & "  ORDER BY group_id, audit_log_id "
		
        If Not gFillSpread(sprGroup, Gsql) Then GoTo ErrHandler
		
		Exit Function
ErrHandler: 
		Err.Clear()
		InqueryHistoryGroup = False
	End Function
	
	Private Function InqueryHistoryGrouping() As Boolean
		On Error GoTo ErrHandler
		InqueryHistoryGrouping = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT *"
		gSQL = gSQL & "   FROM grouping_info_audit"
		If Trim(cboGroup.Text) <> "All" Then
			gSQL = gSQL & "  WHERE group_id = '" & fGroupID & "'"
		End If
		gSQL = gSQL & "  ORDER BY group_id, audit_log_id "
		Debug.Print(gSQL)
		
        If Not gFillSpread(sprGrouping, Gsql) Then GoTo ErrHandler
		
		Exit Function
ErrHandler: 
		Err.Clear()
		InqueryHistoryGrouping = False
	End Function
End Class