Option Strict Off
Option Explicit On
Module basFillCode
	
    Public Sub Fill_Combo(ByRef Combo As Object, ByRef CodeSelect As String, ByRef code As String, Optional ByRef sstable As String = "", Optional ByRef process_flag As String = "")
        Dim i As Integer = 0

        '** Combo   : Object (combo,spread)
        '** Codeselect    : List�������� / ����sp�� ������ �Ҷ� SQL
        '** Code    : Listindex�� �ڵ�
        '** process_flag ---  1st: ��ü���Կ���(A/ ),  2nd:�ڵ尡 Before/After(B/A)

        Dim Gsql As String
        Dim g As GRSClass
        Dim ttable As String
        Dim BA_flag As String
        Dim Total_Diplay_flag As String
        If code = "" Then
            code = " "
        End If

        Total_Diplay_flag = Left(process_flag, 1)
        BA_flag = IIf(Mid(process_flag, 2, 1) > "0", Mid(process_flag, 2, 1), "A")

        ttable = IIf(sstable > "0", sstable, "T_EX_000")

        If Len(CodeSelect) > 10 Then
            Gsql = CodeSelect
        Else
            Gsql = "EXEC el_cd.dbo.s_ex_code_1 '" & ttable & "','" & CodeSelect & "'"
        End If
        g = New GRSClass(Gsql)

        With Combo
            .Clear()

            If Total_Diplay_flag = "A" Then
                Combo.AddItem(IIf(BA_flag = "B", "        ��ü", "��ü                   "))
            End If

            For i = 1 To g.RowCount
                If BA_flag = "B" Then
                    .AddItem(Trim(g.gRS(0)) & "-" & g.gRS(1))
                Else
                    .AddItem(g.gRS(1) & Space(10) & Trim(g.gRS(0)))
                End If
                g.MoveNext()
            Next
            Call Set_cboIndex(Combo, code, Len(code))
        End With


    End Sub
    Public Sub Set_cboIndex(ByRef Combo As ComboBox, ByRef code As String, ByRef length As Short, Optional ByRef Direct_flag As String = "A")

        Dim i_code As Object
        '** Direct_flag : B:Befor,A:After
        'Dim save_index As Object
        Dim k As Short

        length = IIf(length < 1, 1, length)
        For k = 0 To Combo.Items.Count - 1
            i_code = IIf(Direct_flag = "B", Left(Combo.Items(k).ToString, length), Right(Combo.Items(k).ToString, length))
            If i_code = code Then
                Combo.SelectedIndex = k
                Exit Sub
            End If
        Next
        'index�� ������ ó����
        Combo.SelectedIndex = 0

    End Sub
End Module