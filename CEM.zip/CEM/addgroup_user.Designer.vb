<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_GroupAddUser
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents lblUser As System.Windows.Forms.Label
	Public WithEvents lblSelectUser As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents lblGroupID As System.Windows.Forms.Label
	Public WithEvents lblGroupName As System.Windows.Forms.Label
	Public WithEvents lblGroupIDP As System.Windows.Forms.Label
	Public WithEvents lblGroupNameP As System.Windows.Forms.Label
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_GroupAddUser))
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.cmdDelete = New System.Windows.Forms.Button
        Me.cmdAppend = New System.Windows.Forms.Button
        Me.livSelectUser = New System.Windows.Forms.ListView
        Me.livUser = New System.Windows.Forms.ListView
        Me.lblUser = New System.Windows.Forms.Label
        Me.lblSelectUser = New System.Windows.Forms.Label
        Me.lblGroupID = New System.Windows.Forms.Label
        Me.lblGroupName = New System.Windows.Forms.Label
        Me.lblGroupIDP = New System.Windows.Forms.Label
        Me.lblGroupNameP = New System.Windows.Forms.Label
        Me.cmdOk = New System.Windows.Forms.Button
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cmdDelete)
        Me.Frame1.Controls.Add(Me.cmdAppend)
        Me.Frame1.Controls.Add(Me.livSelectUser)
        Me.Frame1.Controls.Add(Me.livUser)
        Me.Frame1.Controls.Add(Me.lblUser)
        Me.Frame1.Controls.Add(Me.lblSelectUser)
        Me.Frame1.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(12, 91)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(421, 299)
        Me.Frame1.TabIndex = 8
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "����� ����"
        '
        'cmdDelete
        '
        Me.cmdDelete.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cmdDelete.Location = New System.Drawing.Point(182, 139)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(57, 34)
        Me.cmdDelete.TabIndex = 16
        Me.cmdDelete.Text = "����"
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'cmdAppend
        '
        Me.cmdAppend.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cmdAppend.Location = New System.Drawing.Point(182, 99)
        Me.cmdAppend.Name = "cmdAppend"
        Me.cmdAppend.Size = New System.Drawing.Size(57, 34)
        Me.cmdAppend.TabIndex = 15
        Me.cmdAppend.Text = "�߰�"
        Me.cmdAppend.UseVisualStyleBackColor = True
        '
        'livSelectUser
        '
        Me.livSelectUser.LargeImageList = Me.ImageList1
        Me.livSelectUser.Location = New System.Drawing.Point(248, 41)
        Me.livSelectUser.Name = "livSelectUser"
        Me.livSelectUser.Size = New System.Drawing.Size(161, 245)
        Me.livSelectUser.SmallImageList = Me.ImageList1
        Me.livSelectUser.TabIndex = 14
        Me.livSelectUser.UseCompatibleStateImageBehavior = False
        '
        'livUser
        '
        Me.livUser.LargeImageList = Me.ImageList1
        Me.livUser.Location = New System.Drawing.Point(14, 41)
        Me.livUser.Name = "livUser"
        Me.livUser.Size = New System.Drawing.Size(161, 245)
        Me.livUser.SmallImageList = Me.ImageList1
        Me.livUser.TabIndex = 13
        Me.livUser.UseCompatibleStateImageBehavior = False
        '
        'lblUser
        '
        Me.lblUser.BackColor = System.Drawing.SystemColors.Control
        Me.lblUser.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUser.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblUser.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUser.Location = New System.Drawing.Point(12, 24)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUser.Size = New System.Drawing.Size(153, 17)
        Me.lblUser.TabIndex = 10
        Me.lblUser.Text = "�����,�׷�"
        '
        'lblSelectUser
        '
        Me.lblSelectUser.BackColor = System.Drawing.SystemColors.Control
        Me.lblSelectUser.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblSelectUser.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblSelectUser.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblSelectUser.Location = New System.Drawing.Point(256, 24)
        Me.lblSelectUser.Name = "lblSelectUser"
        Me.lblSelectUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblSelectUser.Size = New System.Drawing.Size(153, 17)
        Me.lblSelectUser.TabIndex = 9
        Me.lblSelectUser.Text = "���õ� �����,�׷�"
        '
        'lblGroupID
        '
        Me.lblGroupID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblGroupID.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroupID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblGroupID.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroupID.Location = New System.Drawing.Point(16, 16)
        Me.lblGroupID.Name = "lblGroupID"
        Me.lblGroupID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroupID.Size = New System.Drawing.Size(81, 25)
        Me.lblGroupID.TabIndex = 7
        Me.lblGroupID.Text = "�� �� ID"
        '
        'lblGroupName
        '
        Me.lblGroupName.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblGroupName.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroupName.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblGroupName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroupName.Location = New System.Drawing.Point(16, 52)
        Me.lblGroupName.Name = "lblGroupName"
        Me.lblGroupName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroupName.Size = New System.Drawing.Size(81, 25)
        Me.lblGroupName.TabIndex = 6
        Me.lblGroupName.Text = "�� �� ��"
        '
        'lblGroupIDP
        '
        Me.lblGroupIDP.BackColor = System.Drawing.Color.White
        Me.lblGroupIDP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGroupIDP.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroupIDP.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblGroupIDP.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroupIDP.Location = New System.Drawing.Point(104, 16)
        Me.lblGroupIDP.Name = "lblGroupIDP"
        Me.lblGroupIDP.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroupIDP.Size = New System.Drawing.Size(149, 25)
        Me.lblGroupIDP.TabIndex = 5
        '
        'lblGroupNameP
        '
        Me.lblGroupNameP.BackColor = System.Drawing.Color.White
        Me.lblGroupNameP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGroupNameP.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroupNameP.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblGroupNameP.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroupNameP.Location = New System.Drawing.Point(104, 48)
        Me.lblGroupNameP.Name = "lblGroupNameP"
        Me.lblGroupNameP.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroupNameP.Size = New System.Drawing.Size(149, 25)
        Me.lblGroupNameP.TabIndex = 4
        '
        'cmdOk
        '
        Me.cmdOk.Location = New System.Drawing.Point(308, 12)
        Me.cmdOk.Name = "cmdOk"
        Me.cmdOk.Size = New System.Drawing.Size(117, 29)
        Me.cmdOk.TabIndex = 10
        Me.cmdOk.Text = "���"
        Me.cmdOk.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(308, 48)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(117, 29)
        Me.cmdCancel.TabIndex = 11
        Me.cmdCancel.Text = "���"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "user16.bmp")
        Me.ImageList1.Images.SetKeyName(1, "group16.bmp")
        '
        'frm_GroupAddUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(442, 402)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOk)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.lblGroupID)
        Me.Controls.Add(Me.lblGroupName)
        Me.Controls.Add(Me.lblGroupIDP)
        Me.Controls.Add(Me.lblGroupNameP)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(138, 138)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_GroupAddUser"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�׷� ����� ���� ( frm_GroupAddUser )"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdOk As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents livSelectUser As System.Windows.Forms.ListView
    Friend WithEvents livUser As System.Windows.Forms.ListView
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents cmdAppend As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
#End Region 
End Class