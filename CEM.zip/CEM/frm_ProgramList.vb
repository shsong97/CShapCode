Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmProgramList
	Inherits System.Windows.Forms.Form
    Private Sub lsProgramCall()
        Dim code As String = ""
        Dim Name_Renamed As String = ""

        code = Trim(sprSpread1.Sheets(0).Cells(sprSpread1.Sheets(0).ActiveRowIndex, 0).Text)
        Name_Renamed = Trim(sprSpread1.Sheets(0).Cells(sprSpread1.Sheets(0).ActiveRowIndex, 1).Text)

        If gs_listCode = "1" Then
            If code <> "" Then
                frmAuthorityProgram.TxtCode.Text = code
                frmAuthorityProgram.txtName.Text = Name_Renamed
                Me.Close()
            End If

        ElseIf gs_listCode = "2" Then
            If code <> "" Then
                frmAuthorityUser.txtUserId.Text = code
                frmAuthorityUser.txtUserName.Text = Name_Renamed
                Me.Close()
            End If
        ElseIf gs_listCode = "3" Then
            If code <> "" Then
                frmAuthorityUserAdd.txtCode1.Text = code
                frmAuthorityUserAdd.txtName1.Text = Name_Renamed
                Me.Close()
            End If
        ElseIf gs_listCode = "4" Then
            If code <> "" Then
                frmAuthorityUserAdd.txtCode2.Text = code
                frmAuthorityUserAdd.txtName2.Text = Name_Renamed
                Me.Close()
            End If
        Else
        End If
    End Sub
	
	Private Sub frmProgramList_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		If gs_listCode = "1" Then
			Call lsQueryRun()
		ElseIf gs_listCode = "2" Or gs_listCode = "3" Or gs_listCode = "4" Then 
			Call lsQueryRun2()
		Else
		End If
		
	End Sub
	
	Public Function lsQueryRun() As Boolean
		'���α׷� ����Ʈ �˻�
		Dim AppCode As String
		Dim CodeQry As String
		Dim NameQry As String
		Dim Wstr As String
		
		On Error GoTo ErrHandler
		Check1.Visible = False
		lblCode.Text = "���α׷� ID"
		lblName.Text = "���α׷� ��"
		AppCode = Trim(VB.Right(frmAuthorityProgram.cboApplication.Text, 50))
		CodeQry = Trim(Me.CodeQry.Text)
		NameQry = Trim(Me.NameQry.Text)
		Wstr = ""
		
		If CodeQry <> "" Then
			Wstr = Wstr & " AND program like '%" & CodeQry & "%'"
		End If
		If NameQry <> "" Then
			Wstr = Wstr & " AND program in (select program from program_info where program_name like '%" & NameQry & "%')"
			
		End If
		If AppCode <> "" Then
			Wstr = Wstr & " AND app_program = '" & AppCode & "'"
		End If
		
		lsQueryRun = True
		AppCode = Trim(VB.Right(frmAuthorityProgram.cboApplication.Text, 50))
		
		Gsql = "SELECT program, "
		Gsql = Gsql & " program_name = (select program_name from program_info where program = A.program )"
		Gsql = Gsql & " FROM app_prog_mem_info A"
		Gsql = Gsql & " WHERE 1=1"
		Gsql = Gsql & Wstr
		Gsql = Gsql & " ORDER BY program_name"
		
        If Not gFillSpread(sprSpread1, Gsql) Then GoTo ErrHandler
        sprSpread1.Sheets(0).ColumnHeader.Columns(1).Width = 25
		
		Exit Function
ErrHandler: 
		lsQueryRun = False
		Err.Clear()
		Call gDisplayCemMessage()
	End Function
	Public Function lsQueryRun2() As Boolean
		'����� ����Ʈ �˻�
		'Dim DomainCode  As String
		'Dim AppCode     As String
		Dim CodeQry As String
		Dim NameQry As String
		Dim Wstr As String
		
		On Error GoTo ErrHandler
		
		lsQueryRun2 = True
		Check1.Visible = True
		
		lblCode.Text = "�����ID"
		lblName.Text = "����ڸ�"
		
		
		CodeQry = Trim(Me.CodeQry.Text)
		NameQry = Trim(Me.NameQry.Text)
		Wstr = ""
		If CodeQry <> "" Then
			Wstr = Wstr & " AND user_id like '%" & CodeQry & "%'"
		End If
		If NameQry <> "" Then
			Wstr = Wstr & " AND user_name_k like '%" & NameQry & "%'"
		End If
		If Check1.CheckState <> 1 Then
			Wstr = Wstr & " AND active_flag NOT in('T','D') "
		End If
		
		Gsql = "SELECT user_id,user_name_k FROM user_info "
		Gsql = Gsql & " WHERE 1=1 "
		Gsql = Gsql & Wstr
		Gsql = Gsql & " ORDER BY user_id DESC"
		
		
        If Not gFillSpread(sprSpread1, Gsql) Then GoTo ErrHandler
		
		Exit Function
ErrHandler: 
		lsQueryRun2 = False
		Err.Clear()
		Call gDisplayCemMessage()
		'Unload Me
	End Function
	
	
	
    'Private Sub sprSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent)
    '    Call lsProgramCall()
    'End Sub

    Private Sub CmdQryCall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdQryCall.Click
        If gs_listCode = "1" Then
            Call lsQueryRun()
        ElseIf gs_listCode = "2" Or gs_listCode = "3" Or gs_listCode = "4" Then
            Call lsQueryRun2()
        Else
        End If
    End Sub

    Private Sub CmdYes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdYes.Click
        Call lsProgramCall()
    End Sub

    Private Sub CmdNo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdNo.Click
        Me.Close()
    End Sub
End Class