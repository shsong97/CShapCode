<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmRequestTypeMgt
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents cmdADD As System.Windows.Forms.Button
	Public WithEvents cmdInquery As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdSave As System.Windows.Forms.Button
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.cmdADD = New System.Windows.Forms.Button
        Me.cmdInquery = New System.Windows.Forms.Button
        Me.cmdClose = New System.Windows.Forms.Button
        Me.cmdSave = New System.Windows.Forms.Button
        Me.sprList = New FarPoint.Win.Spread.FpSpread
        Me.sprList_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.frmButton.SuspendLayout()
        CType(Me.sprList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprList_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.cmdADD)
        Me.frmButton.Controls.Add(Me.cmdInquery)
        Me.frmButton.Controls.Add(Me.cmdClose)
        Me.frmButton.Controls.Add(Me.cmdSave)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(766, 45)
        Me.frmButton.TabIndex = 2
        Me.frmButton.TabStop = False
        '
        'cmdADD
        '
        Me.cmdADD.BackColor = System.Drawing.SystemColors.Control
        Me.cmdADD.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdADD.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdADD.Location = New System.Drawing.Point(93, 15)
        Me.cmdADD.Name = "cmdADD"
        Me.cmdADD.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdADD.Size = New System.Drawing.Size(76, 23)
        Me.cmdADD.TabIndex = 6
        Me.cmdADD.Text = "�߰�"
        Me.cmdADD.UseVisualStyleBackColor = False
        '
        'cmdInquery
        '
        Me.cmdInquery.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInquery.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInquery.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInquery.Location = New System.Drawing.Point(9, 15)
        Me.cmdInquery.Name = "cmdInquery"
        Me.cmdInquery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInquery.Size = New System.Drawing.Size(76, 23)
        Me.cmdInquery.TabIndex = 5
        Me.cmdInquery.Text = "��ȸ"
        Me.cmdInquery.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(259, 15)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(76, 23)
        Me.cmdClose.TabIndex = 4
        Me.cmdClose.Text = "����"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSave.Location = New System.Drawing.Point(177, 15)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSave.Size = New System.Drawing.Size(76, 23)
        Me.cmdSave.TabIndex = 3
        Me.cmdSave.Text = "����"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'sprList
        '
        Me.sprList.AccessibleDescription = ""
        Me.sprList.Location = New System.Drawing.Point(9, 51)
        Me.sprList.Name = "sprList"
        Me.sprList.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprList_Sheet1})
        Me.sprList.Size = New System.Drawing.Size(747, 375)
        Me.sprList.TabIndex = 3
        '
        'sprList_Sheet1
        '
        Me.sprList_Sheet1.Reset()
        Me.sprList_Sheet1.SheetName = "Sheet1"
        '
        'frmRequestTypeMgt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(769, 437)
        Me.Controls.Add(Me.sprList)
        Me.Controls.Add(Me.frmButton)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 23)
        Me.Name = "frmRequestTypeMgt"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "����� ��û ���� ���� ( frmRequestTypeMgt )"
        Me.frmButton.ResumeLayout(False)
        CType(Me.sprList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprList_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents sprList As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprList_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class