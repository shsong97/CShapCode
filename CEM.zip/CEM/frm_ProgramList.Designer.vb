<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmProgramList
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents Check1 As System.Windows.Forms.CheckBox
	Public WithEvents NameQry As System.Windows.Forms.TextBox
	Public WithEvents CodeQry As System.Windows.Forms.TextBox
    Public WithEvents lblName As System.Windows.Forms.Label
	Public WithEvents lblCode As System.Windows.Forms.Label
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Check1 = New System.Windows.Forms.CheckBox
        Me.NameQry = New System.Windows.Forms.TextBox
        Me.CodeQry = New System.Windows.Forms.TextBox
        Me.lblName = New System.Windows.Forms.Label
        Me.lblCode = New System.Windows.Forms.Label
        Me.CmdQryCall = New System.Windows.Forms.Button
        Me.CmdYes = New System.Windows.Forms.Button
        Me.CmdNo = New System.Windows.Forms.Button
        Me.sprSpread1 = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView
        CType(Me.sprSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Check1
        '
        Me.Check1.BackColor = System.Drawing.SystemColors.Control
        Me.Check1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Check1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Check1.Location = New System.Drawing.Point(145, 55)
        Me.Check1.Name = "Check1"
        Me.Check1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Check1.Size = New System.Drawing.Size(141, 16)
        Me.Check1.TabIndex = 9
        Me.Check1.Text = "�����,������ ����"
        Me.Check1.UseVisualStyleBackColor = False
        Me.Check1.Visible = False
        '
        'NameQry
        '
        Me.NameQry.AcceptsReturn = True
        Me.NameQry.BackColor = System.Drawing.SystemColors.Window
        Me.NameQry.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.NameQry.ForeColor = System.Drawing.SystemColors.WindowText
        Me.NameQry.Location = New System.Drawing.Point(145, 29)
        Me.NameQry.MaxLength = 0
        Me.NameQry.Name = "NameQry"
        Me.NameQry.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NameQry.Size = New System.Drawing.Size(171, 20)
        Me.NameQry.TabIndex = 6
        '
        'CodeQry
        '
        Me.CodeQry.AcceptsReturn = True
        Me.CodeQry.BackColor = System.Drawing.SystemColors.Window
        Me.CodeQry.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.CodeQry.ForeColor = System.Drawing.SystemColors.WindowText
        Me.CodeQry.Location = New System.Drawing.Point(15, 29)
        Me.CodeQry.MaxLength = 0
        Me.CodeQry.Name = "CodeQry"
        Me.CodeQry.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CodeQry.Size = New System.Drawing.Size(119, 20)
        Me.CodeQry.TabIndex = 5
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.BackColor = System.Drawing.SystemColors.Control
        Me.lblName.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblName.Location = New System.Drawing.Point(145, 9)
        Me.lblName.Name = "lblName"
        Me.lblName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblName.Size = New System.Drawing.Size(45, 13)
        Me.lblName.TabIndex = 8
        Me.lblName.Text = "lblName"
        '
        'lblCode
        '
        Me.lblCode.AutoSize = True
        Me.lblCode.BackColor = System.Drawing.SystemColors.Control
        Me.lblCode.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblCode.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblCode.Location = New System.Drawing.Point(12, 9)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblCode.Size = New System.Drawing.Size(42, 13)
        Me.lblCode.TabIndex = 7
        Me.lblCode.Text = "lblCode"
        '
        'CmdQryCall
        '
        Me.CmdQryCall.Location = New System.Drawing.Point(322, 22)
        Me.CmdQryCall.Name = "CmdQryCall"
        Me.CmdQryCall.Size = New System.Drawing.Size(57, 32)
        Me.CmdQryCall.TabIndex = 3
        Me.CmdQryCall.Text = "�˻�"
        Me.CmdQryCall.UseVisualStyleBackColor = True
        '
        'CmdYes
        '
        Me.CmdYes.Location = New System.Drawing.Point(148, 466)
        Me.CmdYes.Name = "CmdYes"
        Me.CmdYes.Size = New System.Drawing.Size(103, 29)
        Me.CmdYes.TabIndex = 4
        Me.CmdYes.Text = "�� ��"
        Me.CmdYes.UseVisualStyleBackColor = True
        '
        'CmdNo
        '
        Me.CmdNo.Location = New System.Drawing.Point(257, 466)
        Me.CmdNo.Name = "CmdNo"
        Me.CmdNo.Size = New System.Drawing.Size(103, 29)
        Me.CmdNo.TabIndex = 5
        Me.CmdNo.Text = "�� ��"
        Me.CmdNo.UseVisualStyleBackColor = True
        '
        'sprSpread1
        '
        Me.sprSpread1.Location = New System.Drawing.Point(15, 77)
        Me.sprSpread1.Name = "sprSpread1"
        Me.sprSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread1_Sheet1})
        Me.sprSpread1.Size = New System.Drawing.Size(341, 383)
        Me.sprSpread1.TabIndex = 10
        '
        'sprSpread1_Sheet1
        '
        Me.sprSpread1_Sheet1.Reset()
        Me.sprSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.sprSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.sprSpread1_Sheet1.ColumnCount = 2
        Me.sprSpread1_Sheet1.RowCount = 100
        Me.sprSpread1_Sheet1.Columns.Get(0).Width = 104.0!
        Me.sprSpread1_Sheet1.Columns.Get(1).Width = 180.0!
        Me.sprSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode
        Me.sprSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.sprSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmProgramList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(391, 519)
        Me.Controls.Add(Me.sprSpread1)
        Me.Controls.Add(Me.Check1)
        Me.Controls.Add(Me.CmdNo)
        Me.Controls.Add(Me.NameQry)
        Me.Controls.Add(Me.CmdYes)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.CodeQry)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.CmdQryCall)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Location = New System.Drawing.Point(627, 71)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmProgramList"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "����Ʈ �˻� ( frmProgramList )"
        CType(Me.sprSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CmdQryCall As System.Windows.Forms.Button
    Friend WithEvents CmdYes As System.Windows.Forms.Button
    Friend WithEvents CmdNo As System.Windows.Forms.Button
    Friend WithEvents sprSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class