Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmRequestMgt
	Inherits System.Windows.Forms.Form
	
	Dim fFileName As String

	Private Sub cmdSearchFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSearchFile.Click
		cdgFileOpenOpen.ShowDialog()
		
		txtFile.Text = cdgFileOpenOpen.FileName
		fFileName = cdgFileOpenOpen.FileName
	End Sub
	
	Private Sub frmRequestMgt_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		lFormInitialize()
		lFillRequestType()
		
	End Sub
	
	Private Sub cmdInitial_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInitial.Click
		lFormInitialize()
	End Sub
	
	Private Sub cmdSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSave.Click
		On Error GoTo ErrHandler
		
		If Not lValidateSave Then GoTo ErrHandler
		
		Gsql = ""
		Gsql = "EXEC sp_request_mgt '"
		Gsql = Gsql & Trim(txtReqName.Text) & "','"
		Gsql = Gsql & Trim(txtRequestDate.Text) & "','"
		Gsql = Gsql & Trim(cboRequestType.Text) & "','"
		Gsql = Gsql & Trim(txtRequestDesc.Text) & "','"
		Gsql = Gsql & Trim(txtRemark1.Text) & "','"
		Gsql = Gsql & Trim(txtRemark2.Text) & "','"
		Gsql = Gsql & fFileName & "','"
		Gsql = Gsql & gUSERID & "'"

        Dim g As GRSClass = New GRSClass(Gsql)

        If g.RowCount = 0 Then Call gSetErrorMessage(Gsql & "������ ���� �߻�.", False) : GoTo ErrHandler
		
        gRequestNo = g.gRS(0)
		
        MsgBox("��û��ȣ " & gRequestNo & "�� ����Ǿ����ϴ�. " & vbCrLf & "���� �۾��� �� ��û���� ��ϵ˴ϴ�.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
		
		Me.Close()
		Exit Sub
ErrHandler: 
		Call gSetErrorMessage("", False)
		Err.Clear()
		Call gDisplayCemMessage()
		
		Exit Sub
		Resume 
		
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
        Me.Close()
	End Sub
	
	Private Sub lFormInitialize()
		On Error GoTo ErrHandler
		gRequestNo = ""
		
		txtReqName.Text = ""
		txtRequestDate.Text = VB6.Format(System.Date.FromOADate(Today.ToOADate + TimeOfDay.ToOADate), "YYYY-MM-DD hh:mm")
		
		txtRequestDesc.Text = ""
		txtRemark1.Text = ""
		txtRemark2.Text = ""
		txtFile.Text = ""

		txtHour.Text = "0"
		txtMin.Text = ""
		
		Exit Sub
ErrHandler: 
		Call gSetErrorMessage("�ʱ�ȭ ����", True)
		Err.Clear()
		Call gDisplayCemMessage()
	End Sub
	
	Private Sub lFillRequestType()
		On Error GoTo ErrHandler
		
		Gsql = "select request_type from request_type where apply_flag = '1'"
		Call sprComboBox(cboRequestType, Gsql, "")
		
		cboRequestType.SelectedIndex = 0
		
		Exit Sub
ErrHandler: 
		Err.Clear()
	End Sub
	
	Private Function lValidateSave() As Boolean
		On Error GoTo ErrHandler
		lValidateSave = True
		
		If Trim(txtReqName.Text) = "" Then Call gSetErrorMessage("��û�ڸ� Ȯ���� �ּ���...", True) : GoTo ErrHandler
		If Not IsDate(txtRequestDate.Text) Then Call gSetErrorMessage("��û���ڸ� Ȯ���� �ּ���...", True) : GoTo ErrHandler
		If Trim(txtRequestDesc.Text) = "" Then Call gSetErrorMessage("��û������ �����ϴ�...", True) : GoTo ErrHandler

		If txtHour.Text = "" Or Len(txtHour.Text) = 0 Or txtMin.Text = "" Or Len(txtMin.Text) = 0 Then
			Call gSetErrorMessage("�۾��ð��� �Է��� �ּ���...", True) : GoTo ErrHandler
		End If
		
		Exit Function
ErrHandler: 
		Err.Clear()
		lValidateSave = False
	End Function
	
	
End Class