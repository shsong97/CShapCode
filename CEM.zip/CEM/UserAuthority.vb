﻿Module UserAuthority

    Public Function UserLevel(ByVal lUserId As String) As String
        Dim sql As String = " exec common.dbo.sp_get_security_level '" + lUserId + "','',''"

        Dim g As GRSClass = New GRSClass(sql)

        If g.RowCount = 0 Then
            UserLevel = -1
        End If

        UserLevel = g.gRSInt("min_securith_level")
    End Function
End Module
