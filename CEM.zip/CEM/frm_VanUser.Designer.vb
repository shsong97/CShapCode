<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_VanUser
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents Command1 As System.Windows.Forms.Button
	Public WithEvents txtUserId As System.Windows.Forms.TextBox
	Public WithEvents txtBicsId As System.Windows.Forms.TextBox
	Public WithEvents cboStatus As System.Windows.Forms.ComboBox
	Public WithEvents cboGubun As System.Windows.Forms.ComboBox
	Public WithEvents cboManage As System.Windows.Forms.ComboBox
	Public WithEvents chkAdmin As System.Windows.Forms.CheckBox
	Public WithEvents txtMailId As System.Windows.Forms.TextBox
	Public WithEvents txtVendorName As System.Windows.Forms.TextBox
    Public WithEvents cmdHistory As System.Windows.Forms.Button
	Public WithEvents cmdPassword As System.Windows.Forms.Button
	Public WithEvents cmdInactive As System.Windows.Forms.Button
	Public WithEvents cmdDelete As System.Windows.Forms.Button
	Public WithEvents cmdRegister As System.Windows.Forms.Button
	Public WithEvents cmdSave As System.Windows.Forms.Button
	Public WithEvents cmdSearch As System.Windows.Forms.Button
	Public WithEvents Text1 As System.Windows.Forms.TextBox
	Public WithEvents lblCount As System.Windows.Forms.Label
	Public WithEvents lblLastDate As System.Windows.Forms.Label
	Public WithEvents lblCreateDate As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim TextCellType15 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType16 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType17 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType18 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType19 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType20 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType21 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Me.Command1 = New System.Windows.Forms.Button
        Me.txtUserId = New System.Windows.Forms.TextBox
        Me.txtBicsId = New System.Windows.Forms.TextBox
        Me.cboStatus = New System.Windows.Forms.ComboBox
        Me.cboGubun = New System.Windows.Forms.ComboBox
        Me.cboManage = New System.Windows.Forms.ComboBox
        Me.chkAdmin = New System.Windows.Forms.CheckBox
        Me.txtMailId = New System.Windows.Forms.TextBox
        Me.txtVendorName = New System.Windows.Forms.TextBox
        Me.cmdHistory = New System.Windows.Forms.Button
        Me.cmdPassword = New System.Windows.Forms.Button
        Me.cmdInactive = New System.Windows.Forms.Button
        Me.cmdDelete = New System.Windows.Forms.Button
        Me.cmdRegister = New System.Windows.Forms.Button
        Me.cmdSave = New System.Windows.Forms.Button
        Me.cmdSearch = New System.Windows.Forms.Button
        Me.Text1 = New System.Windows.Forms.TextBox
        Me.lblCount = New System.Windows.Forms.Label
        Me.lblLastDate = New System.Windows.Forms.Label
        Me.lblCreateDate = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.vaSpread1 = New FarPoint.Win.Spread.FpSpread
        Me.vaSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.FpSpread1 = New FarPoint.Win.Spread.FpSpread
        Me.FpSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtTradeName = New System.Windows.Forms.TextBox
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.SystemColors.Control
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(523, 44)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(90, 23)
        Me.Command1.TabIndex = 32
        Me.Command1.Text = "ȭ���ʱ�ȭ"
        Me.Command1.UseVisualStyleBackColor = False
        '
        'txtUserId
        '
        Me.txtUserId.AcceptsReturn = True
        Me.txtUserId.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtUserId.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUserId.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUserId.Location = New System.Drawing.Point(84, 44)
        Me.txtUserId.MaxLength = 7
        Me.txtUserId.Name = "txtUserId"
        Me.txtUserId.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUserId.Size = New System.Drawing.Size(164, 21)
        Me.txtUserId.TabIndex = 31
        '
        'txtBicsId
        '
        Me.txtBicsId.AcceptsReturn = True
        Me.txtBicsId.BackColor = System.Drawing.SystemColors.Window
        Me.txtBicsId.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBicsId.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBicsId.Location = New System.Drawing.Point(345, 177)
        Me.txtBicsId.MaxLength = 0
        Me.txtBicsId.Name = "txtBicsId"
        Me.txtBicsId.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBicsId.Size = New System.Drawing.Size(159, 21)
        Me.txtBicsId.TabIndex = 30
        '
        'cboStatus
        '
        Me.cboStatus.BackColor = System.Drawing.SystemColors.Window
        Me.cboStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboStatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboStatus.Location = New System.Drawing.Point(345, 148)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboStatus.Size = New System.Drawing.Size(150, 20)
        Me.cboStatus.TabIndex = 29
        Me.cboStatus.Text = "Combo3"
        '
        'cboGubun
        '
        Me.cboGubun.BackColor = System.Drawing.SystemColors.Window
        Me.cboGubun.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboGubun.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboGubun.Location = New System.Drawing.Point(84, 177)
        Me.cboGubun.Name = "cboGubun"
        Me.cboGubun.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboGubun.Size = New System.Drawing.Size(159, 20)
        Me.cboGubun.TabIndex = 26
        Me.cboGubun.Text = "Combo2"
        '
        'cboManage
        '
        Me.cboManage.BackColor = System.Drawing.SystemColors.Window
        Me.cboManage.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboManage.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboManage.Location = New System.Drawing.Point(84, 148)
        Me.cboManage.Name = "cboManage"
        Me.cboManage.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboManage.Size = New System.Drawing.Size(159, 20)
        Me.cboManage.TabIndex = 25
        Me.cboManage.Text = "Combo1"
        '
        'chkAdmin
        '
        Me.chkAdmin.BackColor = System.Drawing.SystemColors.Control
        Me.chkAdmin.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkAdmin.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkAdmin.Location = New System.Drawing.Point(84, 210)
        Me.chkAdmin.Name = "chkAdmin"
        Me.chkAdmin.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkAdmin.Size = New System.Drawing.Size(85, 16)
        Me.chkAdmin.TabIndex = 24
        Me.chkAdmin.Text = "Admin"
        Me.chkAdmin.UseVisualStyleBackColor = False
        '
        'txtMailId
        '
        Me.txtMailId.AcceptsReturn = True
        Me.txtMailId.BackColor = System.Drawing.SystemColors.Window
        Me.txtMailId.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMailId.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMailId.Location = New System.Drawing.Point(84, 114)
        Me.txtMailId.MaxLength = 0
        Me.txtMailId.Name = "txtMailId"
        Me.txtMailId.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMailId.Size = New System.Drawing.Size(164, 21)
        Me.txtMailId.TabIndex = 23
        '
        'txtVendorName
        '
        Me.txtVendorName.AcceptsReturn = True
        Me.txtVendorName.BackColor = System.Drawing.SystemColors.Window
        Me.txtVendorName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtVendorName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtVendorName.Location = New System.Drawing.Point(84, 81)
        Me.txtVendorName.MaxLength = 0
        Me.txtVendorName.Name = "txtVendorName"
        Me.txtVendorName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtVendorName.Size = New System.Drawing.Size(164, 21)
        Me.txtVendorName.TabIndex = 22
        '
        'cmdHistory
        '
        Me.cmdHistory.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHistory.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHistory.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHistory.Location = New System.Drawing.Point(635, 7)
        Me.cmdHistory.Name = "cmdHistory"
        Me.cmdHistory.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHistory.Size = New System.Drawing.Size(118, 23)
        Me.cmdHistory.TabIndex = 8
        Me.cmdHistory.Text = "�ʱ�ȭ �̷���ȸ"
        Me.cmdHistory.UseVisualStyleBackColor = False
        '
        'cmdPassword
        '
        Me.cmdPassword.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPassword.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPassword.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPassword.Location = New System.Drawing.Point(504, 7)
        Me.cmdPassword.Name = "cmdPassword"
        Me.cmdPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPassword.Size = New System.Drawing.Size(127, 23)
        Me.cmdPassword.TabIndex = 7
        Me.cmdPassword.Text = "Password�ʱ�ȭ"
        Me.cmdPassword.UseVisualStyleBackColor = False
        '
        'cmdInactive
        '
        Me.cmdInactive.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInactive.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInactive.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInactive.Location = New System.Drawing.Point(406, 7)
        Me.cmdInactive.Name = "cmdInactive"
        Me.cmdInactive.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInactive.Size = New System.Drawing.Size(90, 23)
        Me.cmdInactive.TabIndex = 6
        Me.cmdInactive.Text = "ID��Ȱ��ȭ"
        Me.cmdInactive.UseVisualStyleBackColor = False
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDelete.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDelete.Location = New System.Drawing.Point(341, 7)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDelete.Size = New System.Drawing.Size(57, 23)
        Me.cmdDelete.TabIndex = 5
        Me.cmdDelete.Text = "����"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdRegister
        '
        Me.cmdRegister.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRegister.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRegister.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRegister.Location = New System.Drawing.Point(616, 44)
        Me.cmdRegister.Name = "cmdRegister"
        Me.cmdRegister.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRegister.Size = New System.Drawing.Size(90, 23)
        Me.cmdRegister.TabIndex = 4
        Me.cmdRegister.Text = "�űԵ��"
        Me.cmdRegister.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSave.Location = New System.Drawing.Point(280, 7)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSave.Size = New System.Drawing.Size(57, 23)
        Me.cmdSave.TabIndex = 3
        Me.cmdSave.Text = "����"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdSearch
        '
        Me.cmdSearch.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSearch.Location = New System.Drawing.Point(215, 7)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSearch.Size = New System.Drawing.Size(57, 23)
        Me.cmdSearch.TabIndex = 2
        Me.cmdSearch.Text = "�˻�"
        Me.cmdSearch.UseVisualStyleBackColor = False
        '
        'Text1
        '
        Me.Text1.AcceptsReturn = True
        Me.Text1.BackColor = System.Drawing.SystemColors.Window
        Me.Text1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text1.Location = New System.Drawing.Point(70, 7)
        Me.Text1.MaxLength = 0
        Me.Text1.Name = "Text1"
        Me.Text1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text1.Size = New System.Drawing.Size(136, 21)
        Me.Text1.TabIndex = 0
        '
        'lblCount
        '
        Me.lblCount.BackColor = System.Drawing.SystemColors.Control
        Me.lblCount.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblCount.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblCount.Location = New System.Drawing.Point(350, 122)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblCount.Size = New System.Drawing.Size(155, 16)
        Me.lblCount.TabIndex = 28
        '
        'lblLastDate
        '
        Me.lblLastDate.BackColor = System.Drawing.SystemColors.Control
        Me.lblLastDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblLastDate.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblLastDate.Location = New System.Drawing.Point(350, 85)
        Me.lblLastDate.Name = "lblLastDate"
        Me.lblLastDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblLastDate.Size = New System.Drawing.Size(155, 19)
        Me.lblLastDate.TabIndex = 27
        '
        'lblCreateDate
        '
        Me.lblCreateDate.BackColor = System.Drawing.SystemColors.Control
        Me.lblCreateDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblCreateDate.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblCreateDate.Location = New System.Drawing.Point(350, 48)
        Me.lblCreateDate.Name = "lblCreateDate"
        Me.lblCreateDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblCreateDate.Size = New System.Drawing.Size(159, 18)
        Me.lblCreateDate.TabIndex = 21
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(271, 181)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(45, 12)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Bics ID"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(271, 151)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(29, 12)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "����"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(271, 122)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(53, 12)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "�湮Ƚ��"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(271, 85)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(65, 12)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "�ֱ�������"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(271, 48)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(53, 12)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "�������"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(19, 214)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(47, 12)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Admin?"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(19, 185)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(53, 12)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "�����ڵ�"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(19, 151)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "��������"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(19, 122)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(44, 12)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Mail ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(19, 85)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "��ü��"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(19, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(46, 12)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "User ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(19, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(42, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "UserID"
        '
        'vaSpread1
        '
        Me.vaSpread1.AccessibleDescription = "vaSpread1, Sheet1, Row 0, Column 0, "
        Me.vaSpread1.Location = New System.Drawing.Point(10, 234)
        Me.vaSpread1.Name = "vaSpread1"
        Me.vaSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread1_Sheet1})
        Me.vaSpread1.Size = New System.Drawing.Size(663, 190)
        Me.vaSpread1.TabIndex = 33
        Me.vaSpread1.SetViewportTopRow(0, 0, 24)
        '
        'vaSpread1_Sheet1
        '
        Me.vaSpread1_Sheet1.Reset()
        Me.vaSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.vaSpread1_Sheet1.ColumnCount = 5
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "���̵�"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "��ü��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "������"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "������"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "����"
        Me.vaSpread1_Sheet1.Columns.Get(0).CellType = TextCellType15
        Me.vaSpread1_Sheet1.Columns.Get(0).Label = "���̵�"
        Me.vaSpread1_Sheet1.Columns.Get(0).Width = 70.0!
        Me.vaSpread1_Sheet1.Columns.Get(1).CellType = TextCellType16
        Me.vaSpread1_Sheet1.Columns.Get(1).Label = "��ü��"
        Me.vaSpread1_Sheet1.Columns.Get(1).Width = 133.0!
        Me.vaSpread1_Sheet1.Columns.Get(2).CellType = TextCellType17
        Me.vaSpread1_Sheet1.Columns.Get(2).Label = "������"
        Me.vaSpread1_Sheet1.Columns.Get(2).Width = 88.0!
        Me.vaSpread1_Sheet1.Columns.Get(3).CellType = TextCellType18
        Me.vaSpread1_Sheet1.Columns.Get(3).Label = "������"
        Me.vaSpread1_Sheet1.Columns.Get(3).Width = 97.0!
        Me.vaSpread1_Sheet1.Columns.Get(4).CellType = TextCellType19
        Me.vaSpread1_Sheet1.Columns.Get(4).Label = "����"
        Me.vaSpread1_Sheet1.Columns.Get(4).Width = 211.0!
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'FpSpread1
        '
        Me.FpSpread1.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.FpSpread1.Location = New System.Drawing.Point(534, 104)
        Me.FpSpread1.Name = "FpSpread1"
        Me.FpSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpread1_Sheet1})
        Me.FpSpread1.Size = New System.Drawing.Size(268, 122)
        Me.FpSpread1.TabIndex = 34
        '
        'FpSpread1_Sheet1
        '
        Me.FpSpread1_Sheet1.Reset()
        Me.FpSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.FpSpread1_Sheet1.ColumnCount = 2
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "���̵�"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "��ü��"
        Me.FpSpread1_Sheet1.Columns.Get(0).CellType = TextCellType20
        Me.FpSpread1_Sheet1.Columns.Get(0).Label = "���̵�"
        Me.FpSpread1_Sheet1.Columns.Get(0).Width = 82.0!
        Me.FpSpread1_Sheet1.Columns.Get(1).CellType = TextCellType21
        Me.FpSpread1_Sheet1.Columns.Get(1).Label = "��ü��"
        Me.FpSpread1_Sheet1.Columns.Get(1).Width = 127.0!
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(534, 85)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(41, 12)
        Me.Label13.TabIndex = 35
        Me.Label13.Text = "��ü��"
        '
        'txtTradeName
        '
        Me.txtTradeName.Location = New System.Drawing.Point(584, 77)
        Me.txtTradeName.Name = "txtTradeName"
        Me.txtTradeName.Size = New System.Drawing.Size(122, 21)
        Me.txtTradeName.TabIndex = 36
        '
        'frm_VanUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(845, 435)
        Me.Controls.Add(Me.txtTradeName)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.FpSpread1)
        Me.Controls.Add(Me.vaSpread1)
        Me.Controls.Add(Me.Command1)
        Me.Controls.Add(Me.txtUserId)
        Me.Controls.Add(Me.txtBicsId)
        Me.Controls.Add(Me.cboStatus)
        Me.Controls.Add(Me.cboGubun)
        Me.Controls.Add(Me.cboManage)
        Me.Controls.Add(Me.chkAdmin)
        Me.Controls.Add(Me.txtMailId)
        Me.Controls.Add(Me.txtVendorName)
        Me.Controls.Add(Me.cmdHistory)
        Me.Controls.Add(Me.cmdPassword)
        Me.Controls.Add(Me.cmdInactive)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdRegister)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.lblLastDate)
        Me.Controls.Add(Me.lblCreateDate)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 30)
        Me.Name = "frm_VanUser"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Van User ���� (frm_VanUser)"
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents vaSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents vaSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents FpSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtTradeName As System.Windows.Forms.TextBox
#End Region 
End Class