<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmRequestMgt
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents txtChangeID As System.Windows.Forms.TextBox
	Public WithEvents txtChangeDate As System.Windows.Forms.MaskedTextBox
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Frame3 As System.Windows.Forms.GroupBox
    Public WithEvents cmdSave As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdInitial As System.Windows.Forms.Button
	Public cdgFileOpenOpen As System.Windows.Forms.OpenFileDialog
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
	Public WithEvents txtRequestDesc As System.Windows.Forms.TextBox
	Public WithEvents txtHour As System.Windows.Forms.TextBox
	Public WithEvents txtMin As System.Windows.Forms.TextBox
	Public WithEvents txtTeamname As System.Windows.Forms.TextBox
	Public WithEvents txtTel As System.Windows.Forms.TextBox
	Public WithEvents txtReqName As System.Windows.Forms.TextBox
	Public WithEvents cmdSearchFile As System.Windows.Forms.Button
	Public WithEvents txtFile As System.Windows.Forms.TextBox
	Public WithEvents cboRequestType As System.Windows.Forms.ComboBox
	Public WithEvents txtRequestDate As System.Windows.Forms.MaskedTextBox
	Public WithEvents txtRemark2 As System.Windows.Forms.TextBox
	Public WithEvents txtRemark1 As System.Windows.Forms.TextBox
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label19 As System.Windows.Forms.Label
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRequestMgt))
        Me.Frame3 = New System.Windows.Forms.GroupBox
        Me.txtChangeID = New System.Windows.Forms.TextBox
        Me.txtChangeDate = New System.Windows.Forms.MaskedTextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.cmdSave = New System.Windows.Forms.Button
        Me.cmdClose = New System.Windows.Forms.Button
        Me.cmdInitial = New System.Windows.Forms.Button
        Me.cdgFileOpenOpen = New System.Windows.Forms.OpenFileDialog
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.txtRequestDesc = New System.Windows.Forms.TextBox
        Me.txtHour = New System.Windows.Forms.TextBox
        Me.txtMin = New System.Windows.Forms.TextBox
        Me.txtTeamname = New System.Windows.Forms.TextBox
        Me.txtTel = New System.Windows.Forms.TextBox
        Me.txtReqName = New System.Windows.Forms.TextBox
        Me.cmdSearchFile = New System.Windows.Forms.Button
        Me.txtFile = New System.Windows.Forms.TextBox
        Me.cboRequestType = New System.Windows.Forms.ComboBox
        Me.txtRequestDate = New System.Windows.Forms.MaskedTextBox
        Me.txtRemark2 = New System.Windows.Forms.TextBox
        Me.txtRemark1 = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Frame3.SuspendLayout()
        Me.frmButton.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.SystemColors.Control
        Me.Frame3.Controls.Add(Me.txtChangeID)
        Me.Frame3.Controls.Add(Me.txtChangeDate)
        Me.Frame3.Controls.Add(Me.Label2)
        Me.Frame3.Controls.Add(Me.Label1)
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(0, 414)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(589, 45)
        Me.Frame3.TabIndex = 30
        Me.Frame3.TabStop = False
        '
        'txtChangeID
        '
        Me.txtChangeID.AcceptsReturn = True
        Me.txtChangeID.BackColor = System.Drawing.SystemColors.Window
        Me.txtChangeID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtChangeID.Enabled = False
        Me.txtChangeID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtChangeID.Location = New System.Drawing.Point(84, 15)
        Me.txtChangeID.MaxLength = 0
        Me.txtChangeID.Name = "txtChangeID"
        Me.txtChangeID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtChangeID.Size = New System.Drawing.Size(168, 21)
        Me.txtChangeID.TabIndex = 31
        '
        'txtChangeDate
        '
        Me.txtChangeDate.AllowPromptAsInput = False
        Me.txtChangeDate.Enabled = False
        Me.txtChangeDate.Location = New System.Drawing.Point(373, 15)
        Me.txtChangeDate.Mask = "####-##-##"
        Me.txtChangeDate.Name = "txtChangeDate"
        Me.txtChangeDate.Size = New System.Drawing.Size(168, 21)
        Me.txtChangeDate.TabIndex = 32
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(308, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(57, 18)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "������"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(19, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(57, 18)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "������"
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.cmdSave)
        Me.frmButton.Controls.Add(Me.cmdClose)
        Me.frmButton.Controls.Add(Me.cmdInitial)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(766, 45)
        Me.frmButton.TabIndex = 2
        Me.frmButton.TabStop = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSave.Location = New System.Drawing.Point(103, 15)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSave.Size = New System.Drawing.Size(76, 23)
        Me.cmdSave.TabIndex = 0
        Me.cmdSave.Text = "����"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(681, 15)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(76, 23)
        Me.cmdClose.TabIndex = 4
        Me.cmdClose.Text = "����"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdInitial
        '
        Me.cmdInitial.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInitial.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInitial.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInitial.Location = New System.Drawing.Point(19, 15)
        Me.cmdInitial.Name = "cmdInitial"
        Me.cmdInitial.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInitial.Size = New System.Drawing.Size(76, 23)
        Me.cmdInitial.TabIndex = 1
        Me.cmdInitial.Text = "�ʱ�ȭ"
        Me.cmdInitial.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.txtRequestDesc)
        Me.Frame1.Controls.Add(Me.txtHour)
        Me.Frame1.Controls.Add(Me.txtMin)
        Me.Frame1.Controls.Add(Me.txtTeamname)
        Me.Frame1.Controls.Add(Me.txtTel)
        Me.Frame1.Controls.Add(Me.txtReqName)
        Me.Frame1.Controls.Add(Me.cmdSearchFile)
        Me.Frame1.Controls.Add(Me.txtFile)
        Me.Frame1.Controls.Add(Me.cboRequestType)
        Me.Frame1.Controls.Add(Me.txtRequestDate)
        Me.Frame1.Controls.Add(Me.txtRemark2)
        Me.Frame1.Controls.Add(Me.txtRemark1)
        Me.Frame1.Controls.Add(Me.Label13)
        Me.Frame1.Controls.Add(Me.Label12)
        Me.Frame1.Controls.Add(Me.Label3)
        Me.Frame1.Controls.Add(Me.Label11)
        Me.Frame1.Controls.Add(Me.Label19)
        Me.Frame1.Controls.Add(Me.Label10)
        Me.Frame1.Controls.Add(Me.Label9)
        Me.Frame1.Controls.Add(Me.Label8)
        Me.Frame1.Controls.Add(Me.Label7)
        Me.Frame1.Controls.Add(Me.Label6)
        Me.Frame1.Controls.Add(Me.Label5)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(0, 46)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(766, 255)
        Me.Frame1.TabIndex = 0
        Me.Frame1.TabStop = False
        '
        'txtRequestDesc
        '
        Me.txtRequestDesc.AcceptsReturn = True
        Me.txtRequestDesc.BackColor = System.Drawing.SystemColors.Window
        Me.txtRequestDesc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRequestDesc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRequestDesc.Location = New System.Drawing.Point(103, 103)
        Me.txtRequestDesc.MaxLength = 0
        Me.txtRequestDesc.Multiline = True
        Me.txtRequestDesc.Name = "txtRequestDesc"
        Me.txtRequestDesc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRequestDesc.Size = New System.Drawing.Size(654, 82)
        Me.txtRequestDesc.TabIndex = 2
        '
        'txtHour
        '
        Me.txtHour.AcceptsReturn = True
        Me.txtHour.BackColor = System.Drawing.SystemColors.Window
        Me.txtHour.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtHour.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtHour.Location = New System.Drawing.Point(383, 15)
        Me.txtHour.MaxLength = 0
        Me.txtHour.Name = "txtHour"
        Me.txtHour.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtHour.Size = New System.Drawing.Size(31, 21)
        Me.txtHour.TabIndex = 23
        Me.txtHour.Text = "0"
        '
        'txtMin
        '
        Me.txtMin.AcceptsReturn = True
        Me.txtMin.BackColor = System.Drawing.SystemColors.Window
        Me.txtMin.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMin.Location = New System.Drawing.Point(457, 15)
        Me.txtMin.MaxLength = 0
        Me.txtMin.Name = "txtMin"
        Me.txtMin.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMin.Size = New System.Drawing.Size(31, 21)
        Me.txtMin.TabIndex = 22
        Me.txtMin.Text = "0"
        '
        'txtTeamname
        '
        Me.txtTeamname.AcceptsReturn = True
        Me.txtTeamname.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtTeamname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTeamname.Enabled = False
        Me.txtTeamname.ForeColor = System.Drawing.Color.Black
        Me.txtTeamname.Location = New System.Drawing.Point(317, 44)
        Me.txtTeamname.MaxLength = 0
        Me.txtTeamname.Name = "txtTeamname"
        Me.txtTeamname.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTeamname.Size = New System.Drawing.Size(206, 21)
        Me.txtTeamname.TabIndex = 18
        Me.txtTeamname.Visible = False
        '
        'txtTel
        '
        Me.txtTel.AcceptsReturn = True
        Me.txtTel.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtTel.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTel.Enabled = False
        Me.txtTel.ForeColor = System.Drawing.Color.Black
        Me.txtTel.Location = New System.Drawing.Point(607, 44)
        Me.txtTel.MaxLength = 0
        Me.txtTel.Name = "txtTel"
        Me.txtTel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTel.Size = New System.Drawing.Size(150, 21)
        Me.txtTel.TabIndex = 17
        Me.txtTel.Visible = False
        '
        'txtReqName
        '
        Me.txtReqName.AcceptsReturn = True
        Me.txtReqName.BackColor = System.Drawing.Color.White
        Me.txtReqName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtReqName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtReqName.Location = New System.Drawing.Point(103, 44)
        Me.txtReqName.MaxLength = 0
        Me.txtReqName.Name = "txtReqName"
        Me.txtReqName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtReqName.Size = New System.Drawing.Size(103, 21)
        Me.txtReqName.TabIndex = 0
        '
        'cmdSearchFile
        '
        Me.cmdSearchFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearchFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSearchFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSearchFile.Image = CType(resources.GetObject("cmdSearchFile.Image"), System.Drawing.Image)
        Me.cmdSearchFile.Location = New System.Drawing.Point(728, 229)
        Me.cmdSearchFile.Name = "cmdSearchFile"
        Me.cmdSearchFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSearchFile.Size = New System.Drawing.Size(27, 18)
        Me.cmdSearchFile.TabIndex = 15
        Me.cmdSearchFile.Text = "?"
        Me.cmdSearchFile.UseVisualStyleBackColor = False
        Me.cmdSearchFile.Visible = False
        '
        'txtFile
        '
        Me.txtFile.AcceptsReturn = True
        Me.txtFile.BackColor = System.Drawing.SystemColors.Window
        Me.txtFile.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFile.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFile.Location = New System.Drawing.Point(103, 229)
        Me.txtFile.MaxLength = 0
        Me.txtFile.Name = "txtFile"
        Me.txtFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFile.Size = New System.Drawing.Size(616, 21)
        Me.txtFile.TabIndex = 13
        Me.txtFile.Visible = False
        '
        'cboRequestType
        '
        Me.cboRequestType.BackColor = System.Drawing.SystemColors.Window
        Me.cboRequestType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboRequestType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRequestType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboRequestType.Location = New System.Drawing.Point(103, 74)
        Me.cboRequestType.Name = "cboRequestType"
        Me.cboRequestType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboRequestType.Size = New System.Drawing.Size(168, 20)
        Me.cboRequestType.TabIndex = 4
        '
        'txtRequestDate
        '
        Me.txtRequestDate.AllowPromptAsInput = False
        Me.txtRequestDate.Location = New System.Drawing.Point(103, 15)
        Me.txtRequestDate.Mask = "####-##-## ##:##"
        Me.txtRequestDate.Name = "txtRequestDate"
        Me.txtRequestDate.Size = New System.Drawing.Size(114, 21)
        Me.txtRequestDate.TabIndex = 9
        '
        'txtRemark2
        '
        Me.txtRemark2.AcceptsReturn = True
        Me.txtRemark2.BackColor = System.Drawing.SystemColors.Window
        Me.txtRemark2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRemark2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRemark2.Location = New System.Drawing.Point(103, 199)
        Me.txtRemark2.MaxLength = 0
        Me.txtRemark2.Name = "txtRemark2"
        Me.txtRemark2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRemark2.Size = New System.Drawing.Size(654, 21)
        Me.txtRemark2.TabIndex = 3
        '
        'txtRemark1
        '
        Me.txtRemark1.AcceptsReturn = True
        Me.txtRemark1.BackColor = System.Drawing.SystemColors.Window
        Me.txtRemark1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRemark1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRemark1.Location = New System.Drawing.Point(383, 74)
        Me.txtRemark1.MaxLength = 0
        Me.txtRemark1.Name = "txtRemark1"
        Me.txtRemark1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRemark1.Size = New System.Drawing.Size(262, 21)
        Me.txtRemark1.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(19, 111)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(66, 23)
        Me.Label13.TabIndex = 29
        Me.Label13.Text = "��û����"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(299, 74)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(66, 23)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "BICS No"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(299, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(66, 23)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "�۾��ð�"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(500, 15)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(20, 11)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "��"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label19.Location = New System.Drawing.Point(421, 15)
        Me.Label19.Name = "Label19"
        Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label19.Size = New System.Drawing.Size(28, 11)
        Me.Label19.TabIndex = 24
        Me.Label19.Text = "�ð�"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(243, 44)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(66, 23)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "�μ�"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label10.Visible = False
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(532, 44)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(66, 23)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "TEL."
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label9.Visible = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(19, 44)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(66, 23)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "��û��"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(19, 229)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(66, 23)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "÷��ȭ��"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label7.Visible = False
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(19, 74)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(66, 23)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "��û����"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(19, 199)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(66, 23)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Remark"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(19, 15)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(66, 23)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "��û��"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'frmRequestMgt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(772, 310)
        Me.Controls.Add(Me.Frame3)
        Me.Controls.Add(Me.frmButton)
        Me.Controls.Add(Me.Frame1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(145, 158)
        Me.Name = "frmRequestMgt"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "����� ��û ���� ( frmRequestMgt )"
        Me.Frame3.ResumeLayout(False)
        Me.Frame3.PerformLayout()
        Me.frmButton.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
#End Region 
End Class