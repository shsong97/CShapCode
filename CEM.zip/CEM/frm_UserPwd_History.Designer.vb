<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_UserPwd_History
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents cmdExit As System.Windows.Forms.Button
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_UserPwd_History))
        Me.cmdExit = New System.Windows.Forms.Button
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.vaSpread = New FarPoint.Win.Spread.FpSpread
        Me.vaSpread_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.frmButton.SuspendLayout()
        CType(Me.vaSpread, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExit.Image = CType(resources.GetObject("cmdExit.Image"), System.Drawing.Image)
        Me.cmdExit.Location = New System.Drawing.Point(498, 16)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(64, 27)
        Me.cmdExit.TabIndex = 2
        Me.cmdExit.Text = "�ݱ�"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.cmdExit)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(569, 49)
        Me.frmButton.TabIndex = 1
        Me.frmButton.TabStop = False
        '
        'vaSpread
        '
        Me.vaSpread.AccessibleDescription = ""
        Me.vaSpread.Location = New System.Drawing.Point(5, 59)
        Me.vaSpread.Name = "vaSpread"
        Me.vaSpread.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread_Sheet1})
        Me.vaSpread.Size = New System.Drawing.Size(563, 341)
        Me.vaSpread.TabIndex = 2
        '
        'vaSpread_Sheet1
        '
        Me.vaSpread_Sheet1.Reset()
        Me.vaSpread_Sheet1.SheetName = "Sheet1"
        '
        'frm_UserPwd_History
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(574, 406)
        Me.Controls.Add(Me.vaSpread)
        Me.Controls.Add(Me.frmButton)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 23)
        Me.Name = "frm_UserPwd_History"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "�н����� �ʱ�ȭ �̷���ȸ ( frm_UserPwd_History )"
        Me.frmButton.ResumeLayout(False)
        CType(Me.vaSpread, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents vaSpread As FarPoint.Win.Spread.FpSpread
    Friend WithEvents vaSpread_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class