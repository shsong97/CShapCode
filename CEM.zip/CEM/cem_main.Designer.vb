<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_CEM_Main
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents CmdQry3 As System.Windows.Forms.Button
	Public WithEvents CmdQry2 As System.Windows.Forms.Button
	Public WithEvents CmdQry As System.Windows.Forms.Button
    Public WithEvents lbl_Detail As System.Windows.Forms.Label
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_CEM_Main))
        Me.CmdQry3 = New System.Windows.Forms.Button
        Me.CmdQry2 = New System.Windows.Forms.Button
        Me.CmdQry = New System.Windows.Forms.Button
        Me.lbl_Detail = New System.Windows.Forms.Label
        Me.trv_Explorer = New System.Windows.Forms.TreeView
        Me.ImageListTreeViewIcon = New System.Windows.Forms.ImageList(Me.components)
        Me.ImageListToolBar = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.exitButton = New System.Windows.Forms.ToolStripButton
        Me.AddButton = New System.Windows.Forms.ToolStripButton
        Me.EditButton = New System.Windows.Forms.ToolStripButton
        Me.DeleteButton = New System.Windows.Forms.ToolStripButton
        Me.RefreshButton = New System.Windows.Forms.ToolStripButton
        Me.liv_Detail = New System.Windows.Forms.ListView
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.�߰�ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.����ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.����ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.�̷º���ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CmdQry3
        '
        Me.CmdQry3.BackColor = System.Drawing.SystemColors.Control
        Me.CmdQry3.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdQry3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdQry3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdQry3.Location = New System.Drawing.Point(300, 143)
        Me.CmdQry3.Name = "CmdQry3"
        Me.CmdQry3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdQry3.Size = New System.Drawing.Size(32, 33)
        Me.CmdQry3.TabIndex = 9
        Me.CmdQry3.Text = "P"
        Me.CmdQry3.UseVisualStyleBackColor = False
        '
        'CmdQry2
        '
        Me.CmdQry2.BackColor = System.Drawing.SystemColors.Control
        Me.CmdQry2.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdQry2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdQry2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdQry2.Location = New System.Drawing.Point(300, 107)
        Me.CmdQry2.Name = "CmdQry2"
        Me.CmdQry2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdQry2.Size = New System.Drawing.Size(32, 30)
        Me.CmdQry2.TabIndex = 8
        Me.CmdQry2.Text = "G"
        Me.CmdQry2.UseVisualStyleBackColor = False
        '
        'CmdQry
        '
        Me.CmdQry.BackColor = System.Drawing.SystemColors.Control
        Me.CmdQry.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdQry.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdQry.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdQry.Location = New System.Drawing.Point(300, 68)
        Me.CmdQry.Name = "CmdQry"
        Me.CmdQry.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdQry.Size = New System.Drawing.Size(32, 33)
        Me.CmdQry.TabIndex = 7
        Me.CmdQry.Text = "U"
        Me.CmdQry.UseVisualStyleBackColor = False
        '
        'lbl_Detail
        '
        Me.lbl_Detail.BackColor = System.Drawing.SystemColors.Control
        Me.lbl_Detail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Detail.Cursor = System.Windows.Forms.Cursors.Default
        Me.lbl_Detail.Font = New System.Drawing.Font("����", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lbl_Detail.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_Detail.Location = New System.Drawing.Point(3, 42)
        Me.lbl_Detail.Name = "lbl_Detail"
        Me.lbl_Detail.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_Detail.Size = New System.Drawing.Size(602, 23)
        Me.lbl_Detail.TabIndex = 5
        '
        'trv_Explorer
        '
        Me.trv_Explorer.AllowDrop = True
        Me.trv_Explorer.Font = New System.Drawing.Font("����", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.trv_Explorer.ImageKey = "user16.bmp"
        Me.trv_Explorer.ImageList = Me.ImageListTreeViewIcon
        Me.trv_Explorer.Location = New System.Drawing.Point(3, 68)
        Me.trv_Explorer.Name = "trv_Explorer"
        Me.trv_Explorer.SelectedImageKey = "user16.bmp"
        Me.trv_Explorer.Size = New System.Drawing.Size(291, 323)
        Me.trv_Explorer.TabIndex = 11
        '
        'ImageListTreeViewIcon
        '
        Me.ImageListTreeViewIcon.ImageStream = CType(resources.GetObject("ImageListTreeViewIcon.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageListTreeViewIcon.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageListTreeViewIcon.Images.SetKeyName(0, "user16.bmp")
        Me.ImageListTreeViewIcon.Images.SetKeyName(1, "group16.bmp")
        Me.ImageListTreeViewIcon.Images.SetKeyName(2, "closefolder16.bmp")
        Me.ImageListTreeViewIcon.Images.SetKeyName(3, "openfolder16.bmp")
        Me.ImageListTreeViewIcon.Images.SetKeyName(4, "app16.bmp")
        Me.ImageListTreeViewIcon.Images.SetKeyName(5, "program16.bmp")
        '
        'ImageListToolBar
        '
        Me.ImageListToolBar.ImageStream = CType(resources.GetObject("ImageListToolBar.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageListToolBar.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageListToolBar.Images.SetKeyName(0, "exit.bmp")
        Me.ImageListToolBar.Images.SetKeyName(1, "edit.bmp")
        Me.ImageListToolBar.Images.SetKeyName(2, "search.bmp")
        Me.ImageListToolBar.Images.SetKeyName(3, "delete.bmp")
        Me.ImageListToolBar.Images.SetKeyName(4, "refresh.bmp")
        '
        'ToolStrip1
        '
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.exitButton, Me.AddButton, Me.EditButton, Me.DeleteButton, Me.RefreshButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(773, 39)
        Me.ToolStrip1.TabIndex = 12
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'exitButton
        '
        Me.exitButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.exitButton.Image = CType(resources.GetObject("exitButton.Image"), System.Drawing.Image)
        Me.exitButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(36, 36)
        Me.exitButton.Text = "����"
        '
        'AddButton
        '
        Me.AddButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AddButton.Image = CType(resources.GetObject("AddButton.Image"), System.Drawing.Image)
        Me.AddButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(36, 36)
        Me.AddButton.Text = "�߰�"
        '
        'EditButton
        '
        Me.EditButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.EditButton.Image = CType(resources.GetObject("EditButton.Image"), System.Drawing.Image)
        Me.EditButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.EditButton.Name = "EditButton"
        Me.EditButton.Size = New System.Drawing.Size(36, 36)
        Me.EditButton.Text = "����"
        '
        'DeleteButton
        '
        Me.DeleteButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteButton.Image = CType(resources.GetObject("DeleteButton.Image"), System.Drawing.Image)
        Me.DeleteButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteButton.Name = "DeleteButton"
        Me.DeleteButton.Size = New System.Drawing.Size(36, 36)
        Me.DeleteButton.Text = "����"
        '
        'RefreshButton
        '
        Me.RefreshButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RefreshButton.Image = CType(resources.GetObject("RefreshButton.Image"), System.Drawing.Image)
        Me.RefreshButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RefreshButton.Name = "RefreshButton"
        Me.RefreshButton.Size = New System.Drawing.Size(36, 36)
        Me.RefreshButton.Text = "����ȸ"
        '
        'liv_Detail
        '
        Me.liv_Detail.AllowColumnReorder = True
        Me.liv_Detail.AllowDrop = True
        Me.liv_Detail.ContextMenuStrip = Me.ContextMenuStrip1
        Me.liv_Detail.GridLines = True
        Me.liv_Detail.LargeImageList = Me.ImageListTreeViewIcon
        Me.liv_Detail.Location = New System.Drawing.Point(338, 68)
        Me.liv_Detail.Name = "liv_Detail"
        Me.liv_Detail.Size = New System.Drawing.Size(423, 320)
        Me.liv_Detail.SmallImageList = Me.ImageListTreeViewIcon
        Me.liv_Detail.TabIndex = 13
        Me.liv_Detail.UseCompatibleStateImageBehavior = False
        Me.liv_Detail.View = System.Windows.Forms.View.List
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.�߰�ToolStripMenuItem, Me.����ToolStripMenuItem, Me.����ToolStripMenuItem, Me.�̷º���ToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(153, 114)
        '
        '�߰�ToolStripMenuItem
        '
        Me.�߰�ToolStripMenuItem.Name = "�߰�ToolStripMenuItem"
        Me.�߰�ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.�߰�ToolStripMenuItem.Text = "�߰�"
        '
        '����ToolStripMenuItem
        '
        Me.����ToolStripMenuItem.Name = "����ToolStripMenuItem"
        Me.����ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.����ToolStripMenuItem.Text = "����"
        '
        '����ToolStripMenuItem
        '
        Me.����ToolStripMenuItem.Name = "����ToolStripMenuItem"
        Me.����ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.����ToolStripMenuItem.Text = "����"
        '
        '�̷º���ToolStripMenuItem
        '
        Me.�̷º���ToolStripMenuItem.Name = "�̷º���ToolStripMenuItem"
        Me.�̷º���ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.�̷º���ToolStripMenuItem.Text = "�̷º���"
        '
        'frm_CEM_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(773, 402)
        Me.Controls.Add(Me.liv_Detail)
        Me.Controls.Add(Me.CmdQry3)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.CmdQry2)
        Me.Controls.Add(Me.trv_Explorer)
        Me.Controls.Add(Me.CmdQry)
        Me.Controls.Add(Me.lbl_Detail)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(261, 210)
        Me.Name = "frm_CEM_Main"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Common Enterprise Manager"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents trv_Explorer As System.Windows.Forms.TreeView
    Friend WithEvents ImageListToolBar As System.Windows.Forms.ImageList
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents exitButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents AddButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents EditButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents DeleteButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents RefreshButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ImageListTreeViewIcon As System.Windows.Forms.ImageList
    Friend WithEvents liv_Detail As System.Windows.Forms.ListView
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents �߰�ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ����ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ����ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents �̷º���ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
#End Region 
End Class