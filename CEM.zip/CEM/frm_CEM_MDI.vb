Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic

Friend Class frm_CEM_MDI
	Inherits System.Windows.Forms.Form
	
	Public Sub mnu_AppAuthoiryInquiry_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_AppAuthoiryInquiry.Click
		g_FormShow(frmAuthorityProgram)
	End Sub
	
    Public Sub mnu_AuditReport_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
    End Sub
	
	
	Public Sub mnu_editer_add_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_editer_add.Click
		frm_CEM_Main.mnu_add_Click()
	End Sub
	
	Public Sub mnu_editer_delete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_editer_delete.Click
		frm_CEM_Main.mnu_delete_Click()
	End Sub
	
	Public Sub mnu_editer_edit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_editer_edit.Click
		frm_CEM_Main.mnu_edit_Click()
	End Sub
	
	Public Sub mnu_editer_history_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_editer_history.Click
		frm_CEM_Main.mnu_history_Click()
	End Sub
	
	Public Sub mnu_editer_refresh_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_editer_refresh.Click
		frm_CEM_Main.mnu_refresh_Click()
	End Sub
	
	Public Sub mnu_File_exit_Click()
		frm_CEM_Main.Close()
		End
	End Sub
	
	Public Sub mnu_GroupHistory_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_GroupHistory.Click
		g_FormShow(frmHistoryGroup)
	End Sub

	Public Sub mnu_popup_manage_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_popup_manage.Click
		g_FormShow(frmPopupManage)
	End Sub
	
	Public Sub mnu_ProgramHistory_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_ProgramHistory.Click
		g_FormShow(frmHistoryProgram)
	End Sub

	
	Public Sub mnu_RequestDetails_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_RequestDetails.Click
		g_FormShow(frmRequestDetails)
	End Sub

	
	Public Sub mnu_RequestMgt_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_RequestMgt.Click
		g_FormShow(frmRequestMgt)
	End Sub
	
	Public Sub mnu_RequestType_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_RequestType.Click
		g_FormShow(frmRequestTypeMgt)
	End Sub
	
	Public Sub mnu_retire_list_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_retire_list.Click
		g_FormShow(frmRetireSearch)
	End Sub
	
	Public Sub mnu_searchuser_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_searchuser.Click
		g_FormShow(frmUserSearch)
	End Sub
	
	
	Public Sub mnu_UserAuthority_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_UserAuthority.Click
		g_FormShow(frmAuthorityUser)
	End Sub
	
	Public Sub mnu_UserAuthorityCopy_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_UserAuthorityCopy.Click
		g_FormShow(frmAuthorityUserAdd)
	End Sub
	
	Public Sub mnu_UserHistory_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_UserHistory.Click
		g_FormShow(frmHistoryUser)
	End Sub
	
	Public Sub mnu_van_user_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_van_user.Click
		g_FormShow(frm_VanUser)
	End Sub
	
	Public Sub mnu_Window_cascade_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_Window_cascade.Click
		LayoutMDI(System.Windows.Forms.MDILayout.Cascade)
	End Sub
	
	Public Sub mnu_Window_ho_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_Window_ho.Click
		LayoutMDI(System.Windows.Forms.MDILayout.TileHorizontal)
	End Sub
	
	Public Sub mnu_Window_ve_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnu_Window_ve.Click
		LayoutMDI(System.Windows.Forms.MDILayout.TileVertical)
	End Sub
	
	Private Sub tmr_Delay_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmr_Delay.Tick
		tmr_Delay.Enabled = False
    End Sub

    Private Sub frm_CEM_MDI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Main���� �ϴ� �۾��� �����ؾ���
        Dim lCommandLine As String

        If VB.Command() = "" Then
            MsgBox("CWIS_CO�� ���ؼ� �����Ͻʽÿ�. ���α׷��� �����մϴ�..............")
            End
        End If

        lCommandLine = Command()
        Dim param As String() = lCommandLine.Split(New Char() {","})
        gUserLevel = 0
        gCo_Server = param(0)
        gUSERID = param(1)
        gUserPW = param(2)

        DBManager.SetConnectionString("ODBC", gCo_Server, "COMMON", DbLogonID, DbLogonPwd)
        If Not DBManager.Open() Then
            MessageBox.Show(DBManager.ErrorMessage)
            End
        End If

        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        frm_CEM_Main.Show()
        frm_CEM_Main.WindowState = FormWindowState.Maximized
    End Sub

 
    Private Sub mnu_UserManage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_UserManage.Click
        g_FormShow(frm_CEM_Main)
        g_MenuControl(1)
    End Sub

    Private Sub _mnu_View_icon_1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _mnu_View_icon_1.Click
        glivX.View = View.SmallIcon
        _mnu_View_icon_0.Checked = False
        _mnu_View_icon_1.Checked = True
        _mnu_View_icon_2.Checked = False
        _mnu_View_icon_3.Checked = False
        _mnu_View_icon_4.Checked = False
    End Sub

    Private Sub _mnu_View_icon_2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _mnu_View_icon_2.Click
        glivX.View = View.List
        _mnu_View_icon_0.Checked = False
        _mnu_View_icon_1.Checked = False
        _mnu_View_icon_2.Checked = True
        _mnu_View_icon_3.Checked = False
        _mnu_View_icon_4.Checked = False
    End Sub

    Private Sub _mnu_View_icon_3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _mnu_View_icon_3.Click
        glivX.View = View.Details
        _mnu_View_icon_0.Checked = False
        _mnu_View_icon_1.Checked = False
        _mnu_View_icon_2.Checked = False
        _mnu_View_icon_3.Checked = True
        _mnu_View_icon_4.Checked = False
    End Sub

    Private Sub _mnu_View_icon_0_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _mnu_View_icon_0.Click
        glivX.View = View.LargeIcon
        _mnu_View_icon_0.Checked = True
        _mnu_View_icon_1.Checked = False
        _mnu_View_icon_2.Checked = False
        _mnu_View_icon_3.Checked = False
        _mnu_View_icon_4.Checked = False
    End Sub

    Private Sub _mnu_View_icon_4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _mnu_View_icon_4.Click
        glivX.View = View.Tile
        _mnu_View_icon_0.Checked = False
        _mnu_View_icon_1.Checked = False
        _mnu_View_icon_2.Checked = False
        _mnu_View_icon_3.Checked = False
        _mnu_View_icon_4.Checked = True
    End Sub
End Class