<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmAuthorityUserAdd
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents CmdReset As System.Windows.Forms.Button
	Public WithEvents cboApplication As System.Windows.Forms.ComboBox
    Public WithEvents Frame7 As System.Windows.Forms.GroupBox
    Public WithEvents Frame6 As System.Windows.Forms.GroupBox
	Public WithEvents txtCode2 As System.Windows.Forms.TextBox
	Public WithEvents txtName2 As System.Windows.Forms.TextBox
	Public WithEvents CmdQry2 As System.Windows.Forms.Button
    Public WithEvents Frame5 As System.Windows.Forms.GroupBox
	Public WithEvents txtCode1 As System.Windows.Forms.TextBox
	Public WithEvents txtName1 As System.Windows.Forms.TextBox
	Public WithEvents cmdQry1 As System.Windows.Forms.Button
    Public WithEvents Frame3 As System.Windows.Forms.GroupBox
    Public WithEvents Frame2 As System.Windows.Forms.GroupBox
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents Label8 As System.Windows.Forms.Label
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.CmdReset = New System.Windows.Forms.Button
        Me.cboApplication = New System.Windows.Forms.ComboBox
        Me.Frame5 = New System.Windows.Forms.GroupBox
        Me.CmdAuthorityCopy = New System.Windows.Forms.Button
        Me.CmdTargetAuthorityQry = New System.Windows.Forms.Button
        Me.Frame7 = New System.Windows.Forms.GroupBox
        Me.sprSpread2 = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread2_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Frame6 = New System.Windows.Forms.GroupBox
        Me.spdSpreadGroup2 = New FarPoint.Win.Spread.FpSpread
        Me.spdSpreadGroup2_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.txtCode2 = New System.Windows.Forms.TextBox
        Me.txtName2 = New System.Windows.Forms.TextBox
        Me.CmdQry2 = New System.Windows.Forms.Button
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.CmdAuthorityQry = New System.Windows.Forms.Button
        Me.txtCode1 = New System.Windows.Forms.TextBox
        Me.txtName1 = New System.Windows.Forms.TextBox
        Me.cmdQry1 = New System.Windows.Forms.Button
        Me.Frame3 = New System.Windows.Forms.GroupBox
        Me.sprSpread1 = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Frame2 = New System.Windows.Forms.GroupBox
        Me.spdSpreadGroup1 = New FarPoint.Win.Spread.FpSpread
        Me.spdSpreadGroup1_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Label8 = New System.Windows.Forms.Label
        Me.Frame5.SuspendLayout()
        Me.Frame7.SuspendLayout()
        CType(Me.sprSpread2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread2_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Frame6.SuspendLayout()
        CType(Me.spdSpreadGroup2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSpreadGroup2_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Frame1.SuspendLayout()
        Me.Frame3.SuspendLayout()
        CType(Me.sprSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Frame2.SuspendLayout()
        CType(Me.spdSpreadGroup1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSpreadGroup1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CmdReset
        '
        Me.CmdReset.BackColor = System.Drawing.SystemColors.Control
        Me.CmdReset.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdReset.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdReset.Location = New System.Drawing.Point(1083, 7)
        Me.CmdReset.Name = "CmdReset"
        Me.CmdReset.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdReset.Size = New System.Drawing.Size(66, 23)
        Me.CmdReset.TabIndex = 21
        Me.CmdReset.Text = "Reset"
        Me.CmdReset.UseVisualStyleBackColor = False
        '
        'cboApplication
        '
        Me.cboApplication.BackColor = System.Drawing.SystemColors.Window
        Me.cboApplication.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboApplication.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboApplication.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboApplication.Location = New System.Drawing.Point(112, 7)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboApplication.Size = New System.Drawing.Size(206, 20)
        Me.cboApplication.TabIndex = 18
        '
        'Frame5
        '
        Me.Frame5.BackColor = System.Drawing.SystemColors.Control
        Me.Frame5.Controls.Add(Me.CmdAuthorityCopy)
        Me.Frame5.Controls.Add(Me.CmdTargetAuthorityQry)
        Me.Frame5.Controls.Add(Me.Frame7)
        Me.Frame5.Controls.Add(Me.Frame6)
        Me.Frame5.Controls.Add(Me.txtCode2)
        Me.Frame5.Controls.Add(Me.txtName2)
        Me.Frame5.Controls.Add(Me.CmdQry2)
        Me.Frame5.Font = New System.Drawing.Font("����", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Frame5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame5.Location = New System.Drawing.Point(0, 354)
        Me.Frame5.Name = "Frame5"
        Me.Frame5.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame5.Size = New System.Drawing.Size(1158, 245)
        Me.Frame5.TabIndex = 9
        Me.Frame5.TabStop = False
        Me.Frame5.Text = "Target User"
        '
        'CmdAuthorityCopy
        '
        Me.CmdAuthorityCopy.Location = New System.Drawing.Point(269, 11)
        Me.CmdAuthorityCopy.Name = "CmdAuthorityCopy"
        Me.CmdAuthorityCopy.Size = New System.Drawing.Size(100, 23)
        Me.CmdAuthorityCopy.TabIndex = 22
        Me.CmdAuthorityCopy.Text = "���Ѻ���"
        Me.CmdAuthorityCopy.UseVisualStyleBackColor = True
        '
        'CmdTargetAuthorityQry
        '
        Me.CmdTargetAuthorityQry.Location = New System.Drawing.Point(377, 12)
        Me.CmdTargetAuthorityQry.Name = "CmdTargetAuthorityQry"
        Me.CmdTargetAuthorityQry.Size = New System.Drawing.Size(103, 23)
        Me.CmdTargetAuthorityQry.TabIndex = 21
        Me.CmdTargetAuthorityQry.Text = "������ȸ"
        Me.CmdTargetAuthorityQry.UseVisualStyleBackColor = True
        '
        'Frame7
        '
        Me.Frame7.BackColor = System.Drawing.SystemColors.Control
        Me.Frame7.Controls.Add(Me.sprSpread2)
        Me.Frame7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame7.Location = New System.Drawing.Point(429, 37)
        Me.Frame7.Name = "Frame7"
        Me.Frame7.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame7.Size = New System.Drawing.Size(720, 200)
        Me.Frame7.TabIndex = 16
        Me.Frame7.TabStop = False
        Me.Frame7.Text = "Program"
        '
        'sprSpread2
        '
        Me.sprSpread2.AccessibleDescription = ""
        Me.sprSpread2.Location = New System.Drawing.Point(3, 16)
        Me.sprSpread2.Name = "sprSpread2"
        Me.sprSpread2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread2_Sheet1})
        Me.sprSpread2.Size = New System.Drawing.Size(712, 182)
        Me.sprSpread2.TabIndex = 0
        '
        'sprSpread2_Sheet1
        '
        Me.sprSpread2_Sheet1.Reset()
        Me.sprSpread2_Sheet1.SheetName = "Sheet1"
        '
        'Frame6
        '
        Me.Frame6.BackColor = System.Drawing.SystemColors.Control
        Me.Frame6.Controls.Add(Me.spdSpreadGroup2)
        Me.Frame6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame6.Location = New System.Drawing.Point(9, 37)
        Me.Frame6.Name = "Frame6"
        Me.Frame6.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame6.Size = New System.Drawing.Size(412, 200)
        Me.Frame6.TabIndex = 14
        Me.Frame6.TabStop = False
        Me.Frame6.Text = "Group"
        '
        'spdSpreadGroup2
        '
        Me.spdSpreadGroup2.AccessibleDescription = ""
        Me.spdSpreadGroup2.Location = New System.Drawing.Point(9, 16)
        Me.spdSpreadGroup2.Name = "spdSpreadGroup2"
        Me.spdSpreadGroup2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSpreadGroup2_Sheet1})
        Me.spdSpreadGroup2.Size = New System.Drawing.Size(398, 182)
        Me.spdSpreadGroup2.TabIndex = 0
        '
        'spdSpreadGroup2_Sheet1
        '
        Me.spdSpreadGroup2_Sheet1.Reset()
        Me.spdSpreadGroup2_Sheet1.SheetName = "Sheet1"
        '
        'txtCode2
        '
        Me.txtCode2.AcceptsReturn = True
        Me.txtCode2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtCode2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCode2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCode2.Location = New System.Drawing.Point(19, 15)
        Me.txtCode2.MaxLength = 0
        Me.txtCode2.Name = "txtCode2"
        Me.txtCode2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCode2.Size = New System.Drawing.Size(103, 21)
        Me.txtCode2.TabIndex = 13
        '
        'txtName2
        '
        Me.txtName2.AcceptsReturn = True
        Me.txtName2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtName2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtName2.Enabled = False
        Me.txtName2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtName2.Location = New System.Drawing.Point(121, 15)
        Me.txtName2.MaxLength = 0
        Me.txtName2.Name = "txtName2"
        Me.txtName2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtName2.Size = New System.Drawing.Size(103, 21)
        Me.txtName2.TabIndex = 12
        '
        'CmdQry2
        '
        Me.CmdQry2.BackColor = System.Drawing.SystemColors.Control
        Me.CmdQry2.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdQry2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdQry2.Location = New System.Drawing.Point(233, 15)
        Me.CmdQry2.Name = "CmdQry2"
        Me.CmdQry2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdQry2.Size = New System.Drawing.Size(29, 17)
        Me.CmdQry2.TabIndex = 11
        Me.CmdQry2.Text = "?"
        Me.CmdQry2.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.CmdAuthorityQry)
        Me.Frame1.Controls.Add(Me.txtCode1)
        Me.Frame1.Controls.Add(Me.txtName1)
        Me.Frame1.Controls.Add(Me.cmdQry1)
        Me.Frame1.Controls.Add(Me.Frame3)
        Me.Frame1.Controls.Add(Me.Frame2)
        Me.Frame1.Font = New System.Drawing.Font("����", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(0, 30)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(1158, 318)
        Me.Frame1.TabIndex = 0
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Source User"
        '
        'CmdAuthorityQry
        '
        Me.CmdAuthorityQry.Location = New System.Drawing.Point(260, 15)
        Me.CmdAuthorityQry.Name = "CmdAuthorityQry"
        Me.CmdAuthorityQry.Size = New System.Drawing.Size(110, 22)
        Me.CmdAuthorityQry.TabIndex = 8
        Me.CmdAuthorityQry.Text = "������ȸ"
        Me.CmdAuthorityQry.UseVisualStyleBackColor = True
        '
        'txtCode1
        '
        Me.txtCode1.AcceptsReturn = True
        Me.txtCode1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtCode1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCode1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCode1.Location = New System.Drawing.Point(9, 15)
        Me.txtCode1.MaxLength = 0
        Me.txtCode1.Name = "txtCode1"
        Me.txtCode1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCode1.Size = New System.Drawing.Size(103, 21)
        Me.txtCode1.TabIndex = 7
        '
        'txtName1
        '
        Me.txtName1.AcceptsReturn = True
        Me.txtName1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtName1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtName1.Enabled = False
        Me.txtName1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtName1.Location = New System.Drawing.Point(112, 15)
        Me.txtName1.MaxLength = 0
        Me.txtName1.Name = "txtName1"
        Me.txtName1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtName1.Size = New System.Drawing.Size(103, 21)
        Me.txtName1.TabIndex = 6
        '
        'cmdQry1
        '
        Me.cmdQry1.BackColor = System.Drawing.SystemColors.Control
        Me.cmdQry1.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdQry1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdQry1.Location = New System.Drawing.Point(224, 15)
        Me.cmdQry1.Name = "cmdQry1"
        Me.cmdQry1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdQry1.Size = New System.Drawing.Size(29, 17)
        Me.cmdQry1.TabIndex = 5
        Me.cmdQry1.Text = "?"
        Me.cmdQry1.UseVisualStyleBackColor = False
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.SystemColors.Control
        Me.Frame3.Controls.Add(Me.sprSpread1)
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(429, 37)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(720, 274)
        Me.Frame3.TabIndex = 2
        Me.Frame3.TabStop = False
        Me.Frame3.Text = "Program"
        '
        'sprSpread1
        '
        Me.sprSpread1.AccessibleDescription = ""
        Me.sprSpread1.Location = New System.Drawing.Point(3, 16)
        Me.sprSpread1.Name = "sprSpread1"
        Me.sprSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread1_Sheet1})
        Me.sprSpread1.Size = New System.Drawing.Size(712, 256)
        Me.sprSpread1.TabIndex = 0
        '
        'sprSpread1_Sheet1
        '
        Me.sprSpread1_Sheet1.Reset()
        Me.sprSpread1_Sheet1.SheetName = "Sheet1"
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.spdSpreadGroup1)
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(9, 37)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(412, 274)
        Me.Frame2.TabIndex = 1
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "Group"
        '
        'spdSpreadGroup1
        '
        Me.spdSpreadGroup1.AccessibleDescription = ""
        Me.spdSpreadGroup1.Location = New System.Drawing.Point(5, 16)
        Me.spdSpreadGroup1.Name = "spdSpreadGroup1"
        Me.spdSpreadGroup1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSpreadGroup1_Sheet1})
        Me.spdSpreadGroup1.Size = New System.Drawing.Size(403, 256)
        Me.spdSpreadGroup1.TabIndex = 0
        '
        'spdSpreadGroup1_Sheet1
        '
        Me.spdSpreadGroup1_Sheet1.Reset()
        Me.spdSpreadGroup1_Sheet1.SheetName = "Sheet1"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(19, 7)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(67, 12)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Application"
        '
        'frmAuthorityUserAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1161, 624)
        Me.Controls.Add(Me.CmdReset)
        Me.Controls.Add(Me.cboApplication)
        Me.Controls.Add(Me.Frame5)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Label8)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(29, 306)
        Me.Name = "frmAuthorityUserAdd"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "����� ���� ���� ( frmAuthorityUserAdd )"
        Me.Frame5.ResumeLayout(False)
        Me.Frame5.PerformLayout()
        Me.Frame7.ResumeLayout(False)
        CType(Me.sprSpread2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread2_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame6.ResumeLayout(False)
        CType(Me.spdSpreadGroup2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSpreadGroup2_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.Frame3.ResumeLayout(False)
        CType(Me.sprSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame2.ResumeLayout(False)
        CType(Me.spdSpreadGroup1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSpreadGroup1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents sprSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdSpreadGroup1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSpreadGroup1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents sprSpread2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread2_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdSpreadGroup2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSpreadGroup2_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents CmdAuthorityCopy As System.Windows.Forms.Button
    Friend WithEvents CmdTargetAuthorityQry As System.Windows.Forms.Button
    Friend WithEvents CmdAuthorityQry As System.Windows.Forms.Button
#End Region 
End Class