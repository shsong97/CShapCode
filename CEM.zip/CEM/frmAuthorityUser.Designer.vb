<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmAuthorityUser
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents txtUserName As System.Windows.Forms.TextBox
	Public WithEvents cboDomain As System.Windows.Forms.ComboBox
	Public WithEvents cboApplication As System.Windows.Forms.ComboBox
	Public WithEvents cmdSearchInfo As System.Windows.Forms.Button
	Public WithEvents txtUserId As System.Windows.Forms.TextBox
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdInquery As System.Windows.Forms.Button
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAuthorityUser))
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.txtUserName = New System.Windows.Forms.TextBox
        Me.cboDomain = New System.Windows.Forms.ComboBox
        Me.cboApplication = New System.Windows.Forms.ComboBox
        Me.cmdSearchInfo = New System.Windows.Forms.Button
        Me.txtUserId = New System.Windows.Forms.TextBox
        Me.cmdClose = New System.Windows.Forms.Button
        Me.cmdInquery = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.sprSpread = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.frmButton.SuspendLayout()
        CType(Me.sprSpread, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.txtUserName)
        Me.frmButton.Controls.Add(Me.cboDomain)
        Me.frmButton.Controls.Add(Me.cboApplication)
        Me.frmButton.Controls.Add(Me.cmdSearchInfo)
        Me.frmButton.Controls.Add(Me.txtUserId)
        Me.frmButton.Controls.Add(Me.cmdClose)
        Me.frmButton.Controls.Add(Me.cmdInquery)
        Me.frmButton.Controls.Add(Me.Label3)
        Me.frmButton.Controls.Add(Me.Label2)
        Me.frmButton.Controls.Add(Me.Label1)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(975, 49)
        Me.frmButton.TabIndex = 0
        Me.frmButton.TabStop = False
        '
        'txtUserName
        '
        Me.txtUserName.AcceptsReturn = True
        Me.txtUserName.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtUserName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUserName.Enabled = False
        Me.txtUserName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUserName.Location = New System.Drawing.Point(622, 18)
        Me.txtUserName.MaxLength = 0
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUserName.Size = New System.Drawing.Size(89, 20)
        Me.txtUserName.TabIndex = 11
        '
        'cboDomain
        '
        Me.cboDomain.BackColor = System.Drawing.SystemColors.Window
        Me.cboDomain.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboDomain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDomain.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboDomain.Location = New System.Drawing.Point(60, 18)
        Me.cboDomain.Name = "cboDomain"
        Me.cboDomain.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboDomain.Size = New System.Drawing.Size(151, 21)
        Me.cboDomain.TabIndex = 10
        '
        'cboApplication
        '
        Me.cboApplication.BackColor = System.Drawing.SystemColors.Window
        Me.cboApplication.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboApplication.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboApplication.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboApplication.Location = New System.Drawing.Point(282, 16)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboApplication.Size = New System.Drawing.Size(171, 21)
        Me.cboApplication.TabIndex = 9
        '
        'cmdSearchInfo
        '
        Me.cmdSearchInfo.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearchInfo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSearchInfo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSearchInfo.Image = CType(resources.GetObject("cmdSearchInfo.Image"), System.Drawing.Image)
        Me.cmdSearchInfo.Location = New System.Drawing.Point(714, 18)
        Me.cmdSearchInfo.Name = "cmdSearchInfo"
        Me.cmdSearchInfo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSearchInfo.Size = New System.Drawing.Size(23, 20)
        Me.cmdSearchInfo.TabIndex = 6
        Me.cmdSearchInfo.Text = "?"
        Me.cmdSearchInfo.UseVisualStyleBackColor = False
        '
        'txtUserId
        '
        Me.txtUserId.AcceptsReturn = True
        Me.txtUserId.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtUserId.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUserId.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUserId.Location = New System.Drawing.Point(532, 18)
        Me.txtUserId.MaxLength = 0
        Me.txtUserId.Name = "txtUserId"
        Me.txtUserId.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUserId.Size = New System.Drawing.Size(89, 20)
        Me.txtUserId.TabIndex = 3
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(833, 16)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(65, 25)
        Me.cmdClose.TabIndex = 2
        Me.cmdClose.Text = "����"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdInquery
        '
        Me.cmdInquery.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInquery.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInquery.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInquery.Location = New System.Drawing.Point(762, 16)
        Me.cmdInquery.Name = "cmdInquery"
        Me.cmdInquery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInquery.Size = New System.Drawing.Size(65, 25)
        Me.cmdInquery.TabIndex = 1
        Me.cmdInquery.Text = "��ȸ"
        Me.cmdInquery.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(10, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Domain"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(216, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(59, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Application"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("����", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(478, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(51, 17)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "User ID"
        '
        'sprSpread
        '
        Me.sprSpread.Location = New System.Drawing.Point(0, 55)
        Me.sprSpread.Name = "sprSpread"
        Me.sprSpread.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread_Sheet1})
        Me.sprSpread.Size = New System.Drawing.Size(985, 355)
        Me.sprSpread.TabIndex = 1
        '
        'sprSpread_Sheet1
        '
        Me.sprSpread_Sheet1.Reset()
        Me.sprSpread_Sheet1.SheetName = "Sheet1"
        '
        'frmAuthorityUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(997, 413)
        Me.Controls.Add(Me.sprSpread)
        Me.Controls.Add(Me.frmButton)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(17, 323)
        Me.Name = "frmAuthorityUser"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "����� ���� ��ȸ ( frmAuthorityUser )"
        Me.frmButton.ResumeLayout(False)
        Me.frmButton.PerformLayout()
        CType(Me.sprSpread, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents sprSpread As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class