Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frm_GroupAdd
	Inherits System.Windows.Forms.Form
	
	Public Function F_DBRecordDisplay() As Boolean
		F_DBRecordDisplay = True
		
		If Len(txt_ID.Text) > 0 Then
			
			Gsql = ""
			Gsql = Gsql & " select * "
			Gsql = Gsql & "   from group_info "
			Gsql = Gsql & "  where group_id = '" & UCase(Trim(txt_ID.Text)) & "'"

            Dim g As GRSClass = New GRSClass(Gsql)
			
            If g.RowCount = 1 Then
                txtGroup_Name.Text = g.gRS("group_name")
                txtGroup_Sec_Level.Text = g.gRS("Group_Sec_Level")
                txtMemo.Text = g.gRS("Memo")
            Else
                F_DBRecordDisplay = False
                Exit Function
            End If
			
			'�׷��� ����
			Gsql = ""
			Gsql = Gsql & " SELECT USER_ID, "
			Gsql = Gsql & "        USERNAME = ( CASE USER_TYPE"
			Gsql = Gsql & "          WHEN 'G' THEN"
			Gsql = Gsql & "             ( SELECT GROUP_NAME FROM GROUP_INFO WHERE GROUP_ID = N.USER_ID)"
			Gsql = Gsql & "          ELSE "
			Gsql = Gsql & "               (SELECT USER_NAME_K FROM USER_INFO WHERE USER_ID = N.USER_ID)"
			Gsql = Gsql & "          END ),"
			Gsql = Gsql & "        USER_TYPE "
			Gsql = Gsql & "   FROM GROUPING_INFO N"
			Gsql = Gsql & "  WHERE N.GROUP_ID = '" & UCase(Trim(txt_ID.Text)) & "'"
            Gsql = Gsql & "  ORDER BY USER_ID "

            g = New GRSClass(Gsql)

            cboGroupUser.Items.Clear()
            For i As Integer = 0 To g.RowCount - 1
                cboGroupUser.Items.Add(g.gRS("UserName") & Space(50) & g.gRS("User_ID") & g.gRS("User_type"))
                g.MoveNext()
            Next


		End If
	End Function
	
	'�׷��� ����Ѵ�.
    Function LF_Group_Append() As Short

        Dim pP As Short
        Dim i As Short
        LF_Group_Append = 0

        If Not CheckRequestNo Then
            LF_Group_Append = 2
            Exit Function
        End If
        If gRequestNo = "" Then
            MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�." & vbCrLf & "frm_GroupAdd - LF_Group_Append")
            Exit Function
        End If
        '�׷������� ���
        Gsql = "exec sp_group_info_add '"
        Gsql = Gsql & gUSERID & "','"
        Gsql = Gsql & txt_ID.Text & "','"
        Gsql = Gsql & txtGroup_Name.Text & "','"
        Gsql = Gsql & txtGroup_Sec_Level.Text & "','"
        Gsql = Gsql & txtMemo.Text & "','"
        Gsql = Gsql & gRequestNo & "'"

        g = New GRSClass(Gsql)
        pP = g.gRS(0)


        If pP = 1 Then
            '����ڱ׷� �������
            For i = 0 To cboGroupUser.Items.Count - 1
                Gsql = "exec sp_grouping_info_add '"
                Gsql = Gsql & gUSERID & "','"
                Gsql = Gsql & txt_ID.Text & "','"
                Gsql = Gsql & VB.Right(VB6.GetItemString(cboGroupUser, i), 1) & "','"
                Gsql = Gsql & Trim(VB.Left(VB.Right(VB6.GetItemString(cboGroupUser, i), 51), 50)) & "','"
                Gsql = Gsql & "R" & "','"
                Gsql = Gsql & gRequestNo & "'"

            Next i
            LF_Group_Append = 0
        Else
            LF_Group_Append = 1
        End If

    End Function

    '�׷��� �����Ѵ�.
    Private Function LF_Group_Edit() As Boolean
        LF_Group_Edit = True

        If Not CheckRequestNo Then
            LF_Group_Edit = False
            Exit Function
        End If

        If gRequestNo = "" Then
            MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�." & vbCrLf & "frm_GroupAdd - LF_Group_Edit")
            LF_Group_Edit = False
            Exit Function
        End If

        '�׷������� �����Ѵ�.
        Gsql = "exec sp_group_info_edit '"
        Gsql = Gsql & gUSERID & "','"
        Gsql = Gsql & txt_ID.Text & "','"
        Gsql = Gsql & txtGroup_Name.Text & "','"
        Gsql = Gsql & txtGroup_Sec_Level.Text & "','"
        Gsql = Gsql & Trim(txtMemo.Text) & "','"
        Gsql = Gsql & gRequestNo & "'"
        g = New GRSClass(Gsql)

    End Function

	Private Sub frm_GroupAdd_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
        If cboGroupUser.Items.Count <> 0 Then
            cboGroupUser.SelectedIndex = 0
        End If
    End Sub
	
	Private Sub frm_GroupAdd_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        txtGroup_Name.Text = ""
        txtGroup_Sec_Level.Text = ""
        txtMemo.Text = ""
        g_CenterForm(Me)
	End Sub
	
    Private Sub cmdUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUser.Click
        Dim i As Short
        Dim j As Short

        If cmdOK.Text <> "���" Then
            MsgBox("�׷����� ������ < ��ϸ�� > ������ �����մϴ�.", , "Ȯ��")
            Exit Sub
        End If
        '����� Select
        Gsql = ""
        Gsql = Gsql & " select user_id, user_name_k "
        Gsql = Gsql & "   from user_info"
        Gsql = Gsql & "  where active_flag <> 'T' AND active_flag <> 'D'"
        Gsql = Gsql & "  order by user_name_k"

        Dim g As GRSClass = New GRSClass(Gsql)

        For inx As Integer = 0 To g.RowCount - 1
            gitmX = frm_GroupAddUser.livUser.Items.Add("USER", g.gRS("user_name_k") & Space(50) & VB6.Format(g.gRS("User_ID")) & "U", 0)
            g.MoveNext()
        Next


        '�׷� Select
        Gsql = ""
        Gsql = Gsql & " select group_id, group_name "
        Gsql = Gsql & "   from group_info"

        g = New GRSClass(Gsql)

        For inx As Integer = 0 To g.RowCount - 1
            If g.gRS("group_id") <> txt_ID.Text Then
                gitmX = frm_GroupAddUser.livUser.Items.Add("GROUP", g.gRS("group_name") & Space(50) & g.gRS("group_id") & "G", 0)
            End If
            g.MoveNext()
        Next

        '���� ��ϵ� ����ڿ� �׷��
        For i = 0 To cboGroupUser.Items.Count - 1
            If VB.Right(VB6.GetItemString(cboGroupUser, i), 1) = "U" Then
                gitmX = frm_GroupAddUser.livSelectUser.Items.Add("USER", VB6.GetItemString(cboGroupUser, i), 0)
            Else
                gitmX = frm_GroupAddUser.livSelectUser.Items.Add("GROUP", VB6.GetItemString(cboGroupUser, i), 0)
            End If
        Next i

        '������ �� �ִ� ����ڿ� �׷�鿡�� ���� ��ϵ� ����ڿ� �׷���� remove
        For i = 1 To frm_GroupAddUser.livSelectUser.Items.Count
            For j = 1 To frm_GroupAddUser.livUser.Items.Count
                If frm_GroupAddUser.livSelectUser.Items(i).Text = frm_GroupAddUser.livUser.Items(j).Text Then
                    frm_GroupAddUser.livUser.Items.RemoveAt(j)
                    Exit For
                End If
            Next j
        Next i


        If cboGroupUser.Items.Count = 0 Then
            frm_GroupAddUser.cmdOk.Text = "���"
        Else
            frm_GroupAddUser.cmdOk.Text = "����"
        End If

        frm_GroupAddUser.lblGroupIDP.Text = txt_ID.Text
        frm_GroupAddUser.lblGroupNameP.Text = txtGroup_Name.Text

        frm_GroupAddUser.ShowDialog()
    End Sub

    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Dim N As Short

        If Not IsNumeric(txtGroup_Sec_Level.Text) Then txtGroup_Sec_Level.Text = "999"

        If txt_ID.Text <> "" Then
            If cmdOK.Text = "���" Then
                N = LF_Group_Append()

                If N = 1 Then
                    N = MsgBox("���� �׷� ID�� �ֽ��ϴ�. �ٸ� �׷� ID�� ����ϼ���", 16)
                    txt_ID.Text = ""
                ElseIf N = 2 Then
                    N = MsgBox("����� ��û ������ �ۼ��� �ּ���.", 16)
                Else
                    N = MsgBox("�׷��� ��� �Ǿ����ϴ�.", , "Ȯ��")
                    txt_ID.Text = ""
                    txtGroup_Name.Text = ""
                    cboGroupUser.Items.Clear()
                    Me.Close()
                End If
                'txt_ID.SetFocus
            Else
                If Not LF_Group_Edit() Then
                    N = MsgBox("�������� �ʾҽ��ϴ�. ����� ��û �Է� �ȵ�", 16)
                Else
                    'frm_GroupAddUser.livGroup.ListItems.Remove frm_GroupAddUser.livGroup.SelectedItem.INDEX
                    '           Set gitmX = frm_GroupAddUser.livGroup.ListItems.Add(, , txt_ID.Text, 1, "�׷�")
                    '               gitmX.SubItems(1) = txtGroup_Name.Text
                    '               gitmX.SubItems(2) = cboGroup_Sec_Level.Text
                    '
                    Me.Close()
                End If
            End If
        Else
            N = MsgBox("�׷� ID�� �ݵ�� �Է��ؾ� �մϴ�.", 16)
            txt_ID.Focus()
        End If
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub
End Class