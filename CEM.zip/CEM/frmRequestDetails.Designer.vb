<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmRequestDetails
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents _tabDetails_TabPage0 As System.Windows.Forms.TabPage
    Public WithEvents _tabDetails_TabPage1 As System.Windows.Forms.TabPage
    Public WithEvents _tabDetails_TabPage2 As System.Windows.Forms.TabPage
    Public WithEvents _tabDetails_TabPage3 As System.Windows.Forms.TabPage
    Public WithEvents _tabDetails_TabPage4 As System.Windows.Forms.TabPage
	Public WithEvents tabDetails As System.Windows.Forms.TabControl
	Public WithEvents cboRequestNo As System.Windows.Forms.ComboBox
	Public WithEvents cmdInquery As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
	Public WithEvents txtChangeID As System.Windows.Forms.TextBox
	Public WithEvents txtRequestType As System.Windows.Forms.TextBox
	Public WithEvents txtRequestDesc As System.Windows.Forms.TextBox
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents txtRequestID As System.Windows.Forms.TextBox
	Public WithEvents txtRemark1 As System.Windows.Forms.TextBox
	Public WithEvents txtRemark2 As System.Windows.Forms.TextBox
	Public WithEvents txtFile As System.Windows.Forms.TextBox
	Public WithEvents txtRequestDate As System.Windows.Forms.MaskedTextBox
	Public WithEvents txtChangeDate As System.Windows.Forms.MaskedTextBox
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtRequestType = New System.Windows.Forms.TextBox
        Me.txtRequestID = New System.Windows.Forms.TextBox
        Me.tabDetails = New System.Windows.Forms.TabControl
        Me._tabDetails_TabPage0 = New System.Windows.Forms.TabPage
        Me.sprSpread_0 = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread_0_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me._tabDetails_TabPage1 = New System.Windows.Forms.TabPage
        Me.sprSpread_1 = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread_1_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me._tabDetails_TabPage2 = New System.Windows.Forms.TabPage
        Me.sprSpread_2 = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread_2_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me._tabDetails_TabPage3 = New System.Windows.Forms.TabPage
        Me.sprSpread_3 = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread_3_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me._tabDetails_TabPage4 = New System.Windows.Forms.TabPage
        Me.sprSpread_4 = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread_4_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.cboRequestNo = New System.Windows.Forms.ComboBox
        Me.cmdInquery = New System.Windows.Forms.Button
        Me.cmdClose = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.txtChangeID = New System.Windows.Forms.TextBox
        Me.Frame2 = New System.Windows.Forms.GroupBox
        Me.txtRequestDesc = New System.Windows.Forms.TextBox
        Me.txtRemark1 = New System.Windows.Forms.TextBox
        Me.txtRemark2 = New System.Windows.Forms.TextBox
        Me.txtFile = New System.Windows.Forms.TextBox
        Me.txtRequestDate = New System.Windows.Forms.MaskedTextBox
        Me.txtChangeDate = New System.Windows.Forms.MaskedTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.tabDetails.SuspendLayout()
        Me._tabDetails_TabPage0.SuspendLayout()
        CType(Me.sprSpread_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread_0_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._tabDetails_TabPage1.SuspendLayout()
        CType(Me.sprSpread_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread_1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._tabDetails_TabPage2.SuspendLayout()
        CType(Me.sprSpread_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread_2_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._tabDetails_TabPage3.SuspendLayout()
        CType(Me.sprSpread_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread_3_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._tabDetails_TabPage4.SuspendLayout()
        CType(Me.sprSpread_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread_4_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.frmButton.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtRequestType
        '
        Me.txtRequestType.AcceptsReturn = True
        Me.txtRequestType.BackColor = System.Drawing.SystemColors.Window
        Me.txtRequestType.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRequestType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRequestType.Location = New System.Drawing.Point(607, 15)
        Me.txtRequestType.MaxLength = 0
        Me.txtRequestType.Name = "txtRequestType"
        Me.txtRequestType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRequestType.Size = New System.Drawing.Size(187, 21)
        Me.txtRequestType.TabIndex = 18
        '
        'txtRequestID
        '
        Me.txtRequestID.AcceptsReturn = True
        Me.txtRequestID.BackColor = System.Drawing.SystemColors.Window
        Me.txtRequestID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRequestID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRequestID.Location = New System.Drawing.Point(84, 15)
        Me.txtRequestID.MaxLength = 0
        Me.txtRequestID.Name = "txtRequestID"
        Me.txtRequestID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRequestID.Size = New System.Drawing.Size(168, 21)
        Me.txtRequestID.TabIndex = 5
        '
        'tabDetails
        '
        Me.tabDetails.Controls.Add(Me._tabDetails_TabPage0)
        Me.tabDetails.Controls.Add(Me._tabDetails_TabPage1)
        Me.tabDetails.Controls.Add(Me._tabDetails_TabPage2)
        Me.tabDetails.Controls.Add(Me._tabDetails_TabPage3)
        Me.tabDetails.Controls.Add(Me._tabDetails_TabPage4)
        Me.tabDetails.ItemSize = New System.Drawing.Size(42, 18)
        Me.tabDetails.Location = New System.Drawing.Point(0, 273)
        Me.tabDetails.Name = "tabDetails"
        Me.tabDetails.SelectedIndex = 0
        Me.tabDetails.Size = New System.Drawing.Size(859, 138)
        Me.tabDetails.TabIndex = 19
        '
        '_tabDetails_TabPage0
        '
        Me._tabDetails_TabPage0.Controls.Add(Me.sprSpread_0)
        Me._tabDetails_TabPage0.Location = New System.Drawing.Point(4, 22)
        Me._tabDetails_TabPage0.Name = "_tabDetails_TabPage0"
        Me._tabDetails_TabPage0.Size = New System.Drawing.Size(851, 112)
        Me._tabDetails_TabPage0.TabIndex = 0
        Me._tabDetails_TabPage0.Text = "User"
        '
        'sprSpread_0
        '
        Me.sprSpread_0.AccessibleDescription = ""
        Me.sprSpread_0.Location = New System.Drawing.Point(9, 3)
        Me.sprSpread_0.Name = "sprSpread_0"
        Me.sprSpread_0.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread_0_Sheet1})
        Me.sprSpread_0.Size = New System.Drawing.Size(837, 108)
        Me.sprSpread_0.TabIndex = 0
        '
        'sprSpread_0_Sheet1
        '
        Me.sprSpread_0_Sheet1.Reset()
        Me.sprSpread_0_Sheet1.SheetName = "Sheet1"
        '
        '_tabDetails_TabPage1
        '
        Me._tabDetails_TabPage1.Controls.Add(Me.sprSpread_1)
        Me._tabDetails_TabPage1.Location = New System.Drawing.Point(4, 22)
        Me._tabDetails_TabPage1.Name = "_tabDetails_TabPage1"
        Me._tabDetails_TabPage1.Size = New System.Drawing.Size(851, 112)
        Me._tabDetails_TabPage1.TabIndex = 1
        Me._tabDetails_TabPage1.Text = "Group"
        '
        'sprSpread_1
        '
        Me.sprSpread_1.AccessibleDescription = ""
        Me.sprSpread_1.Location = New System.Drawing.Point(5, 3)
        Me.sprSpread_1.Name = "sprSpread_1"
        Me.sprSpread_1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread_1_Sheet1})
        Me.sprSpread_1.Size = New System.Drawing.Size(841, 108)
        Me.sprSpread_1.TabIndex = 0
        '
        'sprSpread_1_Sheet1
        '
        Me.sprSpread_1_Sheet1.Reset()
        Me.sprSpread_1_Sheet1.SheetName = "Sheet1"
        '
        '_tabDetails_TabPage2
        '
        Me._tabDetails_TabPage2.Controls.Add(Me.sprSpread_2)
        Me._tabDetails_TabPage2.Location = New System.Drawing.Point(4, 22)
        Me._tabDetails_TabPage2.Name = "_tabDetails_TabPage2"
        Me._tabDetails_TabPage2.Size = New System.Drawing.Size(851, 112)
        Me._tabDetails_TabPage2.TabIndex = 2
        Me._tabDetails_TabPage2.Text = "Grouping"
        '
        'sprSpread_2
        '
        Me.sprSpread_2.AccessibleDescription = ""
        Me.sprSpread_2.Location = New System.Drawing.Point(5, 3)
        Me.sprSpread_2.Name = "sprSpread_2"
        Me.sprSpread_2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread_2_Sheet1})
        Me.sprSpread_2.Size = New System.Drawing.Size(841, 108)
        Me.sprSpread_2.TabIndex = 0
        '
        'sprSpread_2_Sheet1
        '
        Me.sprSpread_2_Sheet1.Reset()
        Me.sprSpread_2_Sheet1.SheetName = "Sheet1"
        '
        '_tabDetails_TabPage3
        '
        Me._tabDetails_TabPage3.Controls.Add(Me.sprSpread_3)
        Me._tabDetails_TabPage3.Location = New System.Drawing.Point(4, 22)
        Me._tabDetails_TabPage3.Name = "_tabDetails_TabPage3"
        Me._tabDetails_TabPage3.Size = New System.Drawing.Size(851, 112)
        Me._tabDetails_TabPage3.TabIndex = 3
        Me._tabDetails_TabPage3.Text = "Program"
        '
        'sprSpread_3
        '
        Me.sprSpread_3.AccessibleDescription = ""
        Me.sprSpread_3.Location = New System.Drawing.Point(5, 3)
        Me.sprSpread_3.Name = "sprSpread_3"
        Me.sprSpread_3.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread_3_Sheet1})
        Me.sprSpread_3.Size = New System.Drawing.Size(841, 108)
        Me.sprSpread_3.TabIndex = 0
        '
        'sprSpread_3_Sheet1
        '
        Me.sprSpread_3_Sheet1.Reset()
        Me.sprSpread_3_Sheet1.SheetName = "Sheet1"
        '
        '_tabDetails_TabPage4
        '
        Me._tabDetails_TabPage4.Controls.Add(Me.sprSpread_4)
        Me._tabDetails_TabPage4.Location = New System.Drawing.Point(4, 22)
        Me._tabDetails_TabPage4.Name = "_tabDetails_TabPage4"
        Me._tabDetails_TabPage4.Size = New System.Drawing.Size(851, 112)
        Me._tabDetails_TabPage4.TabIndex = 4
        Me._tabDetails_TabPage4.Text = "Program Security"
        '
        'sprSpread_4
        '
        Me.sprSpread_4.AccessibleDescription = ""
        Me.sprSpread_4.Location = New System.Drawing.Point(5, 3)
        Me.sprSpread_4.Name = "sprSpread_4"
        Me.sprSpread_4.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread_4_Sheet1})
        Me.sprSpread_4.Size = New System.Drawing.Size(841, 108)
        Me.sprSpread_4.TabIndex = 0
        '
        'sprSpread_4_Sheet1
        '
        Me.sprSpread_4_Sheet1.Reset()
        Me.sprSpread_4_Sheet1.SheetName = "Sheet1"
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.cboRequestNo)
        Me.frmButton.Controls.Add(Me.cmdInquery)
        Me.frmButton.Controls.Add(Me.cmdClose)
        Me.frmButton.Controls.Add(Me.Label8)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(859, 45)
        Me.frmButton.TabIndex = 13
        Me.frmButton.TabStop = False
        '
        'cboRequestNo
        '
        Me.cboRequestNo.BackColor = System.Drawing.SystemColors.Window
        Me.cboRequestNo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboRequestNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboRequestNo.Location = New System.Drawing.Point(84, 15)
        Me.cboRequestNo.Name = "cboRequestNo"
        Me.cboRequestNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboRequestNo.Size = New System.Drawing.Size(168, 20)
        Me.cboRequestNo.TabIndex = 17
        Me.cboRequestNo.Text = "cboRequestNo"
        '
        'cmdInquery
        '
        Me.cmdInquery.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInquery.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInquery.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInquery.Location = New System.Drawing.Point(258, 13)
        Me.cmdInquery.Name = "cmdInquery"
        Me.cmdInquery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInquery.Size = New System.Drawing.Size(76, 23)
        Me.cmdInquery.TabIndex = 15
        Me.cmdInquery.Text = "��ȸ"
        Me.cmdInquery.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(340, 13)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(76, 23)
        Me.cmdClose.TabIndex = 14
        Me.cmdClose.Text = "����"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(19, 15)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(57, 18)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "��û��ȣ"
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.txtChangeID)
        Me.Frame1.Controls.Add(Me.txtRequestType)
        Me.Frame1.Controls.Add(Me.Frame2)
        Me.Frame1.Controls.Add(Me.txtRequestID)
        Me.Frame1.Controls.Add(Me.txtRemark1)
        Me.Frame1.Controls.Add(Me.txtRemark2)
        Me.Frame1.Controls.Add(Me.txtFile)
        Me.Frame1.Controls.Add(Me.txtRequestDate)
        Me.Frame1.Controls.Add(Me.txtChangeDate)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.Controls.Add(Me.Label2)
        Me.Frame1.Controls.Add(Me.Label3)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.Controls.Add(Me.Label5)
        Me.Frame1.Controls.Add(Me.Label6)
        Me.Frame1.Controls.Add(Me.Label7)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(0, 52)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(859, 215)
        Me.Frame1.TabIndex = 0
        Me.Frame1.TabStop = False
        '
        'txtChangeID
        '
        Me.txtChangeID.AcceptsReturn = True
        Me.txtChangeID.BackColor = System.Drawing.SystemColors.Window
        Me.txtChangeID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtChangeID.Enabled = False
        Me.txtChangeID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtChangeID.Location = New System.Drawing.Point(84, 193)
        Me.txtChangeID.MaxLength = 0
        Me.txtChangeID.Name = "txtChangeID"
        Me.txtChangeID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtChangeID.Size = New System.Drawing.Size(168, 21)
        Me.txtChangeID.TabIndex = 22
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.txtRequestDesc)
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(9, 37)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(798, 75)
        Me.Frame2.TabIndex = 6
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "��û����"
        '
        'txtRequestDesc
        '
        Me.txtRequestDesc.AcceptsReturn = True
        Me.txtRequestDesc.BackColor = System.Drawing.SystemColors.Window
        Me.txtRequestDesc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRequestDesc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRequestDesc.Location = New System.Drawing.Point(9, 15)
        Me.txtRequestDesc.MaxLength = 0
        Me.txtRequestDesc.Multiline = True
        Me.txtRequestDesc.Name = "txtRequestDesc"
        Me.txtRequestDesc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRequestDesc.Size = New System.Drawing.Size(776, 53)
        Me.txtRequestDesc.TabIndex = 7
        '
        'txtRemark1
        '
        Me.txtRemark1.AcceptsReturn = True
        Me.txtRemark1.BackColor = System.Drawing.SystemColors.Window
        Me.txtRemark1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRemark1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRemark1.Location = New System.Drawing.Point(84, 118)
        Me.txtRemark1.MaxLength = 0
        Me.txtRemark1.Name = "txtRemark1"
        Me.txtRemark1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRemark1.Size = New System.Drawing.Size(766, 21)
        Me.txtRemark1.TabIndex = 4
        '
        'txtRemark2
        '
        Me.txtRemark2.AcceptsReturn = True
        Me.txtRemark2.BackColor = System.Drawing.SystemColors.Window
        Me.txtRemark2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRemark2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRemark2.Location = New System.Drawing.Point(84, 140)
        Me.txtRemark2.MaxLength = 0
        Me.txtRemark2.Name = "txtRemark2"
        Me.txtRemark2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRemark2.Size = New System.Drawing.Size(766, 21)
        Me.txtRemark2.TabIndex = 3
        '
        'txtFile
        '
        Me.txtFile.AcceptsReturn = True
        Me.txtFile.BackColor = System.Drawing.SystemColors.Window
        Me.txtFile.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFile.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFile.Location = New System.Drawing.Point(84, 162)
        Me.txtFile.MaxLength = 0
        Me.txtFile.Name = "txtFile"
        Me.txtFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFile.Size = New System.Drawing.Size(766, 21)
        Me.txtFile.TabIndex = 1
        Me.txtFile.Visible = False
        '
        'txtRequestDate
        '
        Me.txtRequestDate.AllowPromptAsInput = False
        Me.txtRequestDate.Location = New System.Drawing.Point(345, 15)
        Me.txtRequestDate.Mask = "####-##-##"
        Me.txtRequestDate.Name = "txtRequestDate"
        Me.txtRequestDate.Size = New System.Drawing.Size(168, 21)
        Me.txtRequestDate.TabIndex = 2
        '
        'txtChangeDate
        '
        Me.txtChangeDate.AllowPromptAsInput = False
        Me.txtChangeDate.Enabled = False
        Me.txtChangeDate.Location = New System.Drawing.Point(355, 192)
        Me.txtChangeDate.Mask = "####-##-##"
        Me.txtChangeDate.Name = "txtChangeDate"
        Me.txtChangeDate.Size = New System.Drawing.Size(168, 21)
        Me.txtChangeDate.TabIndex = 23
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(19, 192)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(57, 18)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "������"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(289, 192)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(57, 18)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "������"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(19, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(57, 18)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "��û��"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(280, 15)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(57, 18)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "��û��"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(19, 118)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(57, 18)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Remark"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(541, 15)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(57, 18)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "��û����"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(19, 162)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(57, 18)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "÷��ȭ��"
        Me.Label7.Visible = False
        '
        'frmRequestDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(870, 415)
        Me.Controls.Add(Me.tabDetails)
        Me.Controls.Add(Me.frmButton)
        Me.Controls.Add(Me.Frame1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 23)
        Me.Name = "frmRequestDetails"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "����� ��û�� ���� ���� ���� ( frmRequestDetails )"
        Me.tabDetails.ResumeLayout(False)
        Me._tabDetails_TabPage0.ResumeLayout(False)
        CType(Me.sprSpread_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread_0_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._tabDetails_TabPage1.ResumeLayout(False)
        CType(Me.sprSpread_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread_1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._tabDetails_TabPage2.ResumeLayout(False)
        CType(Me.sprSpread_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread_2_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._tabDetails_TabPage3.ResumeLayout(False)
        CType(Me.sprSpread_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread_3_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._tabDetails_TabPage4.ResumeLayout(False)
        CType(Me.sprSpread_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread_4_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.frmButton.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.Frame2.ResumeLayout(False)
        Me.Frame2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents sprSpread_0 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread_0_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents sprSpread_1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread_1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents sprSpread_2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread_2_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents sprSpread_3 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread_3_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents sprSpread_4 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread_4_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class