Option Strict Off
Option Explicit On
Friend Class frm_UserPwd_History
	Inherits System.Windows.Forms.Form
	
	Dim User_ID As String
	
	Private Sub cmdExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExit.Click
		Me.Close()
	End Sub
	
	WriteOnly Property Return_Value1() As String
		Set(ByVal Value As String)
			User_ID = Value
		End Set
	End Property
	
	Private Sub frm_UserPwd_History_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Dim i As Short
		Dim SQL As String
        Dim g As GRSClass
		SQL = "EXEC sp_user_pwd_history '" & User_ID & "'"
        g = New GRSClass(SQL)

		
        If g.RowCount > 0 Then
            With vaSpread.Sheets(0)
                .RowCount = 0
                .RowCount = g.RowCount
                For i = 0 To g.RowCount - 1
                    .Cells(i, 0).Text = g.gRS(0)
                    .Cells(i, 1).Text = g.gRS(1)
                    .Cells(i, 2).Text = g.gRS(2)
                    .Cells(i, 3).Text = g.gRS(3)
                    .Cells(i, 4).Text = g.gRS(4)
                    g.MoveNext()
                Next
            End With
        Else
            MsgBox("��ȸ����� �����ϴ�")
        End If
	End Sub
End Class