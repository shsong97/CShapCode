Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmUserSearch
	Inherits System.Windows.Forms.Form
	
	
    Private Sub lsSaveRun()

        Dim i As Integer
        Dim cnt As Integer
        Dim tmpStr As String
        Dim TmpStr2 As String

        On Error GoTo Line_Error

        If Not CheckRequestNo() Then
            Exit Sub
        End If

        cnt = 0

        For i = 0 To sprSearch.Sheets(0).RowCount - 1
            tmpStr = VB.Right(Trim(sprSearch.Sheets(0).Cells(i, 9).Text), 6)

            If tmpStr = "update" Then

                Call lsUserUpdate(i)
                TmpStr2 = Replace(sprSearch.Sheets(0).Cells(i, 5).Text, "update", "")
                sprSearch.Sheets(0).Cells(i, 9).Text = TmpStr2
                '���������� �ʵ����
                Call gSpreadRowLock(sprSearch, i)
                cnt = cnt + 1
            End If
        Next i

        MsgBox(cnt & " ���� ����Ÿ�� ������Ʈ �Ǿ����ϴ�.", , "Ȯ��")

        Exit Sub
Line_Error:
        MsgBox(ErrorToString())
        Exit Sub
    End Sub
	Private Sub lsUserUpdate(ByRef ActRow As Integer)
		
		Dim ActFlag As String
		Dim userID As String
        Dim g As GRSClass
        ActFlag = VB.Right(sprSearch.Sheets(0).Cells(ActRow, 5).Text, 1)
        userID = Trim(sprSearch.Sheets(0).Cells(ActRow, 0).Text)


        Gsql = "UPDATE user_info SET "
        Gsql = Gsql & " chng_id = '" & gUSERID & "',"
        Gsql = Gsql & " chng_date = getdate(),"
        Gsql = Gsql & " request_no = '" & gRequestNo & "',"
        Gsql = Gsql & " active_flag = '" & ActFlag & "'"
        Gsql = Gsql & " WHERE user_id = '" & userID & "'"

        g = New GRSClass(Gsql)

        'Gsql = "UPDATE EL_CD..T_EF_010 SET "
        'Gsql = Gsql & " UPDATE_DATE = getdate(),"
        'Gsql = Gsql & " USER_STATUS = '" & ActFlag & "'"
        'Gsql = Gsql & " WHERE user_id = '" & userID & "'"

        'g = New GRSClass(Gsql)

        ManageUserInfo(userID)
		
	End Sub
	
	Private Sub ManageUserInfo(ByRef userID As String)
		
        frm_UserAdd.Text = "����� ����"
        frm_UserAdd.cmdOK.Text = "����"

        frm_UserAdd.txt_ID.Text = userID
        frm_UserAdd.txt_ID.Enabled = False

        If frm_UserAdd.F_DBRecordDisplay Then
            frm_UserAdd.ShowDialog()
        Else
            frm_UserAdd.Close()
        End If
		
	End Sub
	
	Private Sub frmUserSearch_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call lsSeting()
	End Sub
	Private Sub lsSeting()
		Me.Show()
		Me.sprSearch.Width = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - 350)
		Me.sprSearch.Height = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - 2000)
	End Sub
	Private Function lsWhereStr() As String
        Dim Wstr As String = ""
		
		'����� ID
		If txtUserID.Text <> "" Then
			Wstr = Wstr & " AND user_id like '%" & Trim(txtUserID.Text) & "%' "
		End If
		'����� ��
		If txtUserName.Text <> "" Then
			Wstr = Wstr & " AND user_name_k like '%" & Trim(txtUserName.Text) & "%' "
		End If
		
        If _Check1_2.CheckState = 1 And txtFromDate.Text > "" And txtToDate.Text > "" Then
            Wstr = Wstr & " AND out_date between '" & txtFromDate.Text & "' and '" & txtToDate.Text & "'"
        End If
		
		lsWhereStr = Wstr
	End Function
	Private Function lsORStr() As String
        Dim ORStr As String = ""
		'����
        If _Check1_0.CheckState = 1 Then
            If ORStr = "" Then
                ORStr = ORStr & " active_flag = 'C' "
            Else
                ORStr = ORStr & " OR active_flag = 'C' "
            End If
        End If
		'����
        If _Check1_1.CheckState = 1 Then
            If ORStr = "" Then
                ORStr = ORStr & " active_flag = 'H' "
            Else
                ORStr = ORStr & " OR active_flag = 'H' "
            End If
        End If
		'����
        If _Check1_2.CheckState = 1 Then
            If ORStr = "" Then
                ORStr = ORStr & " active_flag = 'T' "
            Else
                ORStr = ORStr & " OR active_flag = 'T' "
            End If
        End If
		'����
        If _Check1_3.CheckState = 1 Then
            If ORStr = "" Then
                ORStr = ORStr & " active_flag = 'D' "
            Else
                ORStr = ORStr & " OR active_flag = 'D' "
            End If
        End If
		If ORStr <> "" Then
			ORStr = " AND (" & ORStr & ")"
		End If
		
		lsORStr = ORStr
	End Function
	Private Sub lsQueryRun()
		Dim Wstr As String
		Dim ORStr As String
		
		On Error GoTo ErrHandler
		
		Wstr = "" : ORStr = "" : txtValue.Text = ""
		'�˻����Ǽ���
		Wstr = lsWhereStr
		ORStr = lsORStr
		
		Gsql = ""
		Gsql = "SELECT user_id,"
		Gsql = Gsql & " user_name_k,"
		Gsql = Gsql & " security_level,"
		Gsql = Gsql & " emp_num,"
		Gsql = Gsql & " unit,"
		Gsql = Gsql & " active_flag,"
		Gsql = Gsql & " request_no,"
		Gsql = Gsql & " chng_id,"
		Gsql = Gsql & " out_date, "
		Gsql = Gsql & " security_rule " 'U(�����), M(3�����̻��), P(�н�����Ʋ��)
		Gsql = Gsql & " FROM user_info WHERE 1=1 "
		Gsql = Gsql & Wstr & ORStr
		Gsql = Gsql & " ORDER BY user_id "
		
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If Not FillSpread(sprSearch, Gsql, True) Then GoTo ErrHandler

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        txtValue.Text = CStr(sprSearch.Sheets(0).RowCount)
		Exit Sub
		
ErrHandler: 
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		Call gDisplayCemMessage()
		Exit Sub
		Resume 
	End Sub
	


	Private Sub lsReDisp(ByVal Col As Integer, ByVal Row As Integer)
        Dim tmpStr As String
        Dim tmpStatus As String
		
        With sprSearch.Sheets(0)
            tmpStr = .Cells(Row, 5).Text
            .Columns(5).Width = 70
            Dim combo As CellType.ComboBoxCellType = New CellType.ComboBoxCellType()
            Dim comboItem As String() = New String() {"���� C", "���� H", "���� T", "���� D"}
            Dim comboItemData As String() = New String() {"C", "H", "T", "D"}
            combo.Items = comboItem
            combo.ItemData = comboItemData

            .Cells(Row, 5).CellType = combo

            Select Case tmpStr
                Case "C"
                    If gSpreadUnitDataFetch(sprSearch, Row, 9) < " " Then
                        Call gSpreadCellLock(sprSearch, Row, 5)
                    Else
                        Call gSpreadCellunLock(sprSearch, Row, 5)
                    End If
                Case "H"
                    Call gSpreadCellunLock(sprSearch, Row, 5)
                Case "T"
                    If gSpreadUnitDataFetch(sprSearch, Row, 8) < " " Then
                        Call gSpreadCellunLock(sprSearch, Row, 5)
                    Else
                        Call gSpreadCellLock(sprSearch, Row, 5)
                    End If
                Case "D"
                    Call gSpreadCellunLock(sprSearch, Row, 5)
                Case Else
                    Call gSpreadCellunLock(sprSearch, Row, 5)
            End Select


            If gSpreadUnitDataFetch(sprSearch, Row, 9) = "" Then
                tmpStatus = gSpreadUnitDataFetch(sprSearch, Row, 5)
                If tmpStatus = "" Then
                    tmpStatus = gSpreadUnitDataFetch(sprSearch, Row, 9)
                End If
                .Cells(Row, 9).Text = tmpStatus
            End If


        End With

	End Sub
	
    Private Sub txtUserID_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles txtUserID.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        If KeyCode = 13 Then
            Call lsQueryRun()
        End If
    End Sub

    Private Sub txtUserName_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles txtUserName.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        If KeyCode = 13 Then
            Call lsQueryRun()
        End If
    End Sub

    Private Sub CmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSave.Click
        Call lsSaveRun()
    End Sub

    Private Sub CmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdClose.Click
        Me.Close()
    End Sub

    Private Sub CmdQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdQuery.Click
        Call lsQueryRun()
    End Sub

    Private Sub sprSearch_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles sprSearch.CellClick
        If e.Column = 5 Then
            lsReDisp(e.Column, e.Row)
        End If
    End Sub

    Private Sub sprSearch_SelectionChanged(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.SelectionChangedEventArgs) Handles sprSearch.SelectionChanged
        Dim tmpStr As String

        With sprSearch.Sheets(0)
            Dim combo As CellType.ComboBoxCellType = .Cells(.ActiveRow.Index, 5).CellType


            If VB.Right(.Cells(.ActiveRow.Index, 5).Text, 1) = "C" Then
                .Cells(.ActiveRow.Index, 9).Text = .Cells(.ActiveRow.Index, 9).Text & "update"
            Else
                '������� �ٲ۴�
                MsgBox("< ���� > ó���θ� ���氡���մϴ�.", , "Ȯ��")
                .Cells(.ActiveRow.Index, 9).Text = Replace(.Cells(.ActiveRow.Index, 9).Text, "update", "")
                tmpStr = .Cells(.ActiveRow.Index, 9).Text
                .Cells(.ActiveRow.Index, 5).Text = tmpStr
                Exit Sub
            End If
        End With
    End Sub
End Class