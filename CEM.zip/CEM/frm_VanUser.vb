Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frm_VanUser
	Inherits System.Windows.Forms.Form
	
	
	Private Sub cmdDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDelete.Click
		Call UserProcess("5")
	End Sub
	
	Private Sub cmdHistory_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdHistory.Click
		Dim i As Object
        Dim SQL As String
        SQL = "exec el_cd..s_cx_260_5 '" & txtUserId.Text & "'"
        g = New GRSClass(SQL)

        vaSpread1.Sheets(0).RowCount = 0
        If g.RowCount > 0 Then
            With vaSpread1.Sheets(0)
                .RowCount = g.RowCount

                For i = 0 To g.RowCount - 1
                    .Cells(i, 0).Text = g.gRS("user_id")
                    .Cells(i, 1).Text = g.gRS("name")
                    .Cells(i, 2).Text = g.gRS("chng_id")
                    .Cells(i, 3).Text = g.gRS("chng_date")
                    .Cells(i, 4).Text = g.gRS("description")
                    g.MoveNext()
                Next i
            End With
        End If
	End Sub
	
	Private Sub cmdInactive_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInactive.Click
		Call UserProcess("7")
	End Sub
	
	Private Sub cmdPassword_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPassword.Click
		Call UserProcess("6")
	End Sub
	
	Private Sub cmdRegister_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRegister.Click
		If Len(txtUserId.Text) >= 6 Then
			Call UserProcess("3")
		Else
			MsgBox("ID�� �������� �ʾҽ��ϴ�.")
		End If
	End Sub
	
	Private Sub cmdSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSave.Click
		If Len(Text1.Text) <= 5 Then
			MsgBox("��ü�ڵ带 Ȯ���ϼ���!")
			Exit Sub
		End If
		Call UserProcess("1")
	End Sub
	
	Private Sub UserProcess(ByRef act_flag As String)
        Dim SQL As String
		
        SQL = "exec el_cd..S_CX_260_3 '" & txtUserId.Text & "','" & txtMailId.Text & "','" & txtVendorName.Text & "','"
		SQL = SQL & VB.Right(cboManage.Text, 1) & "','" & VB.Right(cboStatus.Text, 1) & "','" & act_flag & " ','"
		SQL = SQL & gUSERID & "','" & VB.Right(cboGubun.Text, 1) & "',"
		SQL = SQL & "'" & "" & "' , "
		SQL = SQL & "'" & "" & "' , "
		SQL = SQL & "'" & txtMailId.Text & "' , "
		SQL = SQL & "'" & txtBicsId.Text & "' , "
		SQL = SQL & "'" & chkAdmin.CheckState & "'"

        g = New GRSClass(SQL)
        If g.gRS(0) = "000" Then
            MsgBox("ó���Ǿ����ϴ�.")
        Else
            MsgBox("�۾������� ������ �߻��Ͽ����ϴ�.")
        End If

	End Sub
	
	Private Sub cmdSearch_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSearch.Click
        Dim SQL As String
		
		If Len(Text1.Text) <= 5 And Len(txtVendorName.Text) = 0 Then
			MsgBox("��ü�ڵ� Ȥ�� ��ü���� Ȯ���ϼ���")
			Exit Sub
		End If
		
		SQL = "exec el_cd..s_cx_260_4 '" & Text1.Text & "','" & txtVendorName.Text & "'"
        g = New GRSClass(SQL)

        If g.RowCount > 0 Then
            txtUserId.Text = g.gRS("user_id")
            txtUserId.ReadOnly = True
            txtVendorName.Text = g.gRS("name")
            txtMailId.Text = g.gRS("mail_id")
            Call Set_cboIndex(cboManage, g.gRS("user_flag"), 1)
            Call Set_cboIndex(cboGubun, g.gRS("dept_code"), 1)
            chkAdmin.CheckState = IIf(g.gRS("admin") = "Y", 1, 0)
            lblCreateDate.Text = g.gRS("insert_date")
            lblLastDate.Text = g.gRS("last_use_date")
            lblCount.Text = g.gRS("visit_count")
            Call Set_cboIndex(cboStatus, g.gRS("active_flag"), 1)
            txtBicsId.Text = g.gRS("bics_id")

            Call cmdHistory_Click(cmdHistory, New System.EventArgs())
        End If
		
	End Sub
	
	Private Sub Command1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command1.Click
		txtUserId.Text = ""
		txtUserId.ReadOnly = False
		txtVendorName.Text = ""
		txtMailId.Text = ""
		cboManage.SelectedIndex = 0
		cboGubun.SelectedIndex = 0
		chkAdmin.CheckState = CShort("0")
		lblCreateDate.Text = ""
		lblLastDate.Text = ""
		lblCount.Text = ""
		cboStatus.SelectedIndex = 0
		txtBicsId.Text = ""
		txtUserId.BackColor = System.Drawing.ColorTranslator.FromOle(&H80000005)
	End Sub
	
	Private Sub frm_VanUser_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		cboStatus.Items.Add("����� A")
		cboStatus.Items.Add("�н����� ���� L")
		cboStatus.Items.Add("��� I")
		cboStatus.Items.Add("���� D")
		cboStatus.SelectedIndex = 0
		
		cboGubun.Items.Add("EL E")
		cboGubun.Items.Add("���� P")
		cboGubun.Items.Add("��Ÿ M")
		cboGubun.Items.Add("���� A")
		cboGubun.Items.Add("������ I")
		cboGubun.SelectedIndex = 0
		
		cboManage.Items.Add("���¾�ü 1")
		cboManage.Items.Add("OTIS 2")
		cboManage.SelectedIndex = 0
		
	End Sub

    Private Sub txtTradeName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtTradeName.TextChanged

    End Sub

    Private Sub txtTradeName_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtTradeName.KeyDown
        Dim sql As String
        Dim i As Integer
        If e.KeyCode = 13 Then
            sql = "select user_id,name from el_cd.dbo.t_cx_260 where name like  '%" & txtTradeName.Text & "%'"
            g = New GRSClass(Sql)
            If g.RowCount > 0 Then
                With FpSpread1.Sheets(0)
                    .RowCount = g.RowCount

                    For i = 0 To g.RowCount - 1
                        .Cells(i, 0).Value = g.gRS("user_id")
                        .Cells(i, 1).Value = g.gRS("name")
                        g.MoveNext()
                    Next
                End With
            End If
        End If
    End Sub
End Class