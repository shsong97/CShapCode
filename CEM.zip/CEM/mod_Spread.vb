Option Strict Off
Option Explicit On
Module mod_Spread
	
    Public Sub gClearAllSpread(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, Optional ByRef MaxRow As Short = 50, Optional ByRef MaxCol As Short = 30)
        On Error GoTo CLEANUP

        sprSpread.Sheets(0).RowCount = 0
        sprSpread.Sheets(0).ColumnCount = 0

        sprSpread.Sheets(0).RowCount = MaxRow
        sprSpread.Sheets(0).ColumnCount = MaxCol

        Exit Sub
CLEANUP:
        Call gSetErrorMessage("", True)
        Err.Clear()
        Call gDisplayCemMessage()
    End Sub
	

    Public Sub gSpreadClear(ByRef spread As FarPoint.Win.Spread.FpSpread, ByVal MaxRow As Integer)
        '------------------------------------------------------------------------------------------------------------------------
        ' Description     : spread Clear
        ' Prameters       : spread Object Name, MaxRow)
        '------------------------------------------------------------------------------------------------------------------------
        With spread.Sheets(0)
            'If .VirtualMode = True Then
            '    .VirtualMode = False
            'End If

            '.Row = .StartingRowNumber
            '.Col = .StartingColNumber
            '.Row2 = .MaxRows
            '.Col2 = .MaxCols
            '.BlockMode = True
            '.Action = SS_ACTION_CLEAR_TEXT 'SS_ACTION_CLEAR
            '.BlockMode = False
            '.MaxRows = MaxRow
        End With
    End Sub
	
    Public Sub gSpreadAddColumn(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByVal iniCol As Integer)
        With sprSpread.Sheets(0)
            .ColumnCount = .ColumnCount + iniCol
            .Columns(iniCol).Add()
        End With

    End Sub
    Public Sub gSpreadAddRow(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByVal iniRow As Integer)
        With sprSpread.Sheets(0)
            .RowCount = .RowCount + iniRow
        End With
    End Sub
	
    Public Sub gSpreadMakeCheckColumn(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef Col As Integer, ByRef DefaultValue As Short)
        On Error GoTo CLEANUP
        Dim ckbxcell As New FarPoint.Win.Spread.CellType.CheckBoxCellType()
        With sprSpread.Sheets(0)
            ckbxcell.ThreeState = False
            ckbxcell.TextTrue = ""
            ckbxcell.TextFalse = ""
            .Columns.Item(Col).CellType = ckbxcell
        End With
        Exit Sub
CLEANUP:
        MsgBox(Err.Number + CDbl(Err.Description))
        Err.Clear()
    End Sub
	
    Public Sub gSpreadMakeCheckCell(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef Row As Integer, ByRef Col As Integer, ByRef DefaultValue As Short)
        On Error GoTo CLEANUP
        Dim ckbxcell As New FarPoint.Win.Spread.CellType.CheckBoxCellType()
        With sprSpread.Sheets(0)
            ckbxcell.ThreeState = False
            ckbxcell.TextTrue = ""
            ckbxcell.TextFalse = ""
            If Row = -1 Then
                For i As Integer = 0 To .RowCount - 1
                    .Cells(i, Col).CellType = ckbxcell
                    If DefaultValue = 1 Then
                        .Cells(i, Col).Value = True
                    End If
                Next
            Else
                .Cells(Row, Col).CellType = ckbxcell
                If DefaultValue = 1 Then
                    .Cells(Row, Col).Value = True
                End If
            End If
        End With
        Exit Sub
CLEANUP:
        MsgBox(Err.Description)
        Err.Clear()
    End Sub
	
    Public Sub gSpreadSort(ByRef spread As FarPoint.Win.Spread.FpSpread, ByRef fCol As Integer)
        With spread.Sheets(0)
            '.Row = .StartingRowNumber
            '.Col = .StartingColNumber
            '.Row2 = .DataRowCnt
            '.Col2 = .DataColCnt

            '.SortBy = SS_SORT_BY_ROW '0
            '.set_SortKey(1, fCol)

            'If .get_SortKeyOrder(1) = SS_SORT_ORDER_ASCENDING Then
            '    .set_SortKeyOrder(1, SS_SORT_ORDER_DESCENDING) '2
            'Else
            '    .set_SortKeyOrder(1, SS_SORT_ORDER_ASCENDING) '1
            'End If

            '.Action = SS_ACTION_SORT '25
        End With
    End Sub

    'Cell Lock/Unlock
    Public Sub gSpreadCellLock(ByRef sprSpread As FarPoint.Win.Spread.SheetView, ByRef lRow As Integer, ByRef lCol As Integer)
        sprSpread.Cells(lRow, lCol).Locked = True
    End Sub
    Public Sub gSpreadCellunLock(ByRef sprSpread As FarPoint.Win.Spread.SheetView, ByRef lRow As Integer, ByRef lCol As Integer)
        sprSpread.Cells(lRow, lCol).Locked = False
    End Sub
    Public Sub gSpreadCellLock(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef lRow As Integer, ByRef lCol As Integer)
        sprSpread.Sheets(0).Cells(lRow, lCol).Locked = True
    End Sub
    Public Sub gSpreadCellunLock(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef lRow As Integer, ByRef lCol As Integer)
        sprSpread.Sheets(0).Cells(lRow, lCol).Locked = False
    End Sub
    'Row Lock/Unlock
    Public Sub gSpreadRowLock(ByRef sprSpread As FarPoint.Win.Spread.SheetView, ByRef lRow As Integer)
        sprSpread.Rows(lRow).Locked = True
    End Sub
    Public Sub gSpreadRowunLock(ByRef sprSpread As FarPoint.Win.Spread.SheetView, ByRef lRow As Integer)
        sprSpread.Rows(lRow).Locked = False
    End Sub
    Public Sub gSpreadRowLock(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef lRow As Integer)
        sprSpread.Sheets(0).Rows(lRow).Locked = True
    End Sub
    Public Sub gSpreadRowunLock(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef lRow As Integer)
        sprSpread.Sheets(0).Rows(lRow).Locked = False
    End Sub

    Public Function gSpreadUnitDataFetch(ByRef sprSpread As FarPoint.Win.Spread.SheetView, ByRef lRow As Integer, ByRef lCol As Integer) As String
        gSpreadUnitDataFetch = sprSpread.Cells(lRow, lCol).Text
    End Function
    Public Function gSpreadUnitDataFetch(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef lRow As Integer, ByRef lCol As Integer) As String
        gSpreadUnitDataFetch = sprSpread.Sheets(0).Cells(lRow, lCol).Text
    End Function


    Public Function FillSpread(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef Gsql As String, Optional ByRef colsizeflag As Boolean = False) As Boolean
        On Error GoTo CLEANUP
        FillSpread = True

        Dim lRow, lCol As Integer
        Dim sv As SheetView = sprSpread.Sheets(0)
        Dim g As GRSClass = New GRSClass(Gsql)

        sv.RowCount = 0
        If g.RowCount < 1 Then
            Call gSetErrorMessage("��ȸ�� ����� �����ϴ�.", True)
            GoTo CLEANUP
        End If

        With sv

            If g.RowCount > 0 Then
                .RowCount = g.RowCount
                .ColumnCount = g.ColCount
                Call FillSpreadHead(sprSpread, g, True)
            End If

            For lRow = 0 To g.RowCount - 1
                For lCol = 0 To g.ColCount - 1
                    .Cells(lRow, lCol).Text = g.gRS(lCol)
                    If g.gRS(lCol).Length <= 5 Then
                        .Cells(lRow, lCol).HorizontalAlignment = CellHorizontalAlignment.Center
                    Else
                        .Cells(lRow, lCol).HorizontalAlignment = CellHorizontalAlignment.Left
                    End If
                Next
                g.MoveNext()
            Next
        End With
        Exit Function
CLEANUP:

        FillSpread = False
    End Function
    Public Sub FillSpreadHead(ByRef sprSpread As FarPoint.Win.Spread.FpSpread, ByRef g As GRSClass, Optional ByRef colsizeflag As Boolean = True)
        On Error GoTo CLEANUP

        Dim sv As SheetView = sprSpread.Sheets(0)
        Dim dt As DataTable = g.GetDS.Tables(0)
        With sv
            For col As Integer = 0 To g.ColCount - 1
                .ColumnHeader.Columns(col).HorizontalAlignment = CellHorizontalAlignment.Center
                .ColumnHeader.Columns(col).Label = dt.Columns(col).ToString
                If colsizeflag Then
                    .ColumnHeader.Columns(col).Width = dt.Columns(col).ToString.Length * 8
                End If
            Next
        End With
        Exit Sub
CLEANUP:
        Call gSetErrorMessage("Spread Head Display Error!!!", True)
        Err.Clear()
        Call gDisplayCemMessage()
    End Sub
End Module