Option Strict Off
Option Explicit On
Friend Class frmHistoryProgram
	Inherits System.Windows.Forms.Form
	Dim fProgramID As String
	
	Public Sub SetProgramID(ByRef lProgramID As String)
		fProgramID = Trim(lProgramID)
		Me.Show()
		InqueryAllData()
	End Sub
	
	Private Sub cboApplication_Click()
		InqueryAllData()
	End Sub
	

	Private Sub cboProgram_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboProgram.SelectedIndexChanged
		fProgramID = Trim(cboProgram.Text)
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	Private Sub frmHistoryProgram_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		gSQL = "select program from program_info"
		Call sprComboBox(cboProgram, gSQL, "", True)
	End Sub
	
	Private Sub cmdInquery_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInquery.Click
		InqueryAllData()
	End Sub
	
	Private Sub InqueryAllData()
		InqueryHistoryProgram()
		InqueryHistoryProgSecurity()
	End Sub
	
	Private Function InqueryHistoryProgram() As Boolean
		On Error GoTo ErrHandler
		InqueryHistoryProgram = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT *"
		gSQL = gSQL & "   FROM program_info_audit"
		If Trim(cboProgram.Text) <> "All" Then
			gSQL = gSQL & "  WHERE program = '" & fProgramID & "'"
		End If
		gSQL = gSQL & "  ORDER BY program, audit_log_id "
		Debug.Print(gSQL)
		
        If Not gFillSpread(sprProgram, Gsql) Then GoTo ErrHandler
		
		Exit Function
ErrHandler: 
		Err.Clear()
		InqueryHistoryProgram = False
	End Function
	
	
	Private Function InqueryHistoryProgSecurity() As Boolean
		On Error GoTo ErrHandler
		InqueryHistoryProgSecurity = True
		
		gSQL = ""
		gSQL = gSQL & " SELECT *"
		gSQL = gSQL & "   FROM prog_security_audit"
		If Trim(cboProgram.Text) <> "All" Then
			gSQL = gSQL & "  WHERE program = '" & fProgramID & "'"
		End If
		gSQL = gSQL & "  ORDER BY domain, app_program, program, audit_log_id "
		Debug.Print(gSQL)
		
        If Not gFillSpread(sprProgSecurity, Gsql) Then GoTo ErrHandler
		
		Exit Function
ErrHandler: 
		Err.Clear()
		InqueryHistoryProgSecurity = False
	End Function
End Class