Option Strict Off
Option Explicit On
Friend Class frmHistoryUser
	Inherits System.Windows.Forms.Form
	
	Dim fUserID As String
	
	Public Sub SetUserID(ByRef lUserID As String)
		fUserID = lUserID
		txtUserID.Text = fUserID
		Me.Show()
		InqueryUserLog()
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	Private Sub cmdInquery_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInquery.Click
		InqueryAllData()
	End Sub
	
	Private Sub InqueryAllData()
		InqueryUserLog()
	End Sub
	
	Private Function InqueryUserLog() As Boolean
		On Error GoTo ErrHandler
		InqueryUserLog = True
		
		gSQL = ""
		gSQL = gSQL & " EXEC sp_log_user '"
		gSQL = gSQL & fUserID & "','"
		gSQL = gSQL & chkFlag.CheckState & "'"
		
        If Not gFillSpread(sprSpread, Gsql) Then GoTo ErrHandler
		Exit Function
ErrHandler: 
		Err.Clear()
		InqueryUserLog = False
	End Function
	
	Private Sub frmHistoryUser_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		ShowForm(Me)
	End Sub
	
	Private Sub frmHistoryUser_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
        sprSpread.Width = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - 145)
        If VB6.PixelsToTwipsY(sprSpread.Top) + 1000 < VB6.PixelsToTwipsY(Me.Height) Then
            sprSpread.Height = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - VB6.PixelsToTwipsY(sprSpread.Top) - 700)
        End If
    End Sub
	
	Private Sub cmdSearchInfo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSearchInfo.Click
		On Error GoTo CLEANUP
		Dim InputUserName As String
        Dim g As GRSClass

		Call gSetErrorMessage("", True)
		
		InputUserName = InputBox("����� �̸�����???", "����� ID ã��")
		
		gSQL = ""
		gSQL = gSQL & " SELECT user_id "
		gSQL = gSQL & "   FROM user_info "
		gSQL = gSQL & "  WHERE user_name_k like '%" & InputUserName & "%'"
        g = New GRSClass(Gsql)

		
        If g.RowCount < 1 Then
            Call gSetErrorMessage("�Է��� ����ڰ� �����ϴ�..", True)
            GoTo CLEANUP
        ElseIf g.RowCount > 1 Then
            Call gSetErrorMessage("����� �̸��� Ȯ���� �ּ���. (�������� ��ȸ�Ǿ����ϴ�.)", True)
            GoTo CLEANUP
        End If
		
        txtUserId.Text = g.gRS(0)
		InqueryAllData()
		
		Exit Sub
CLEANUP: 
		Err.Clear()
		gDisplayCemMessage()
	End Sub
	
	Private Sub txtUserId_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtUserId.TextChanged
        fUserID = txtUserId.Text
    End Sub
End Class