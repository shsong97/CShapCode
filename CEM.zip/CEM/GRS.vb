﻿Public Class GRSClass
    Dim tableCount As Integer = 0
    Dim bRowCount As Integer = 0
    Dim bColCount As Integer = 0
    Dim rowIndex As Integer = 0
    Dim tableIndex As Integer = 0
    Dim dr As DataRow
    Dim ds As DataSet

    Public Sub New()

    End Sub
    Public Sub New(ByVal query As String)
        SetDataset(DBManager.Query(query))
    End Sub
    Public Sub New(ByVal data As DataRow)
        dr = data
        bColCount = data.ItemArray.Length
    End Sub
    Public Sub New(ByVal data As DataSet)
        SetDataset(data)
    End Sub


    Property ColCount() As Integer
        Get
            Return bColCount
        End Get
        Set(ByVal value As Integer)
            bColCount = value
        End Set
    End Property
    ReadOnly Property RowCount() As Integer
        Get
            Return bRowCount
        End Get
    End Property

    Public Function GetDS() As DataSet
        Return ds
    End Function
    Public Function GetDT() As DataTable
        Return ds.Tables(tableIndex)
    End Function

    Public Sub SetDataset(ByVal data As DataSet)
        If data Is Nothing Then
            Return
        End If

        If data.Tables.Count = 0 Then
            Return
        End If

        tableCount = data.Tables.Count
        ds = data

        If data.Tables(0).Rows.Count > 0 Then
            bRowCount = data.Tables(0).Rows.Count
            ColCount = data.Tables(0).Rows(0).ItemArray.Length
            dr = data.Tables(0).Rows(0)
        End If

    End Sub

    Public Function NextResults() As Boolean
        If tableCount = 0 Then
            Return False
        End If

        If tableCount <= tableIndex Then
            Return False
        End If

        tableIndex = tableIndex + 1
        Return True
    End Function
    Public Function PrevResults() As Boolean
        If tableCount = 0 Then
            Return False
        End If

        If tableIndex <= 0 Then
            Return False
        End If

        tableIndex = tableIndex - 1
        Return True
    End Function
    Public Sub MoveFirst()
        rowIndex = 0
        dr = ds.Tables(tableIndex).Rows(rowIndex)
    End Sub
    Public Function MoveNext() As Boolean
        rowIndex = rowIndex + 1
        If rowIndex < RowCount Then
            dr = ds.Tables(tableIndex).Rows(rowIndex)
            Return True
        End If
        Return False
    End Function
    Public Function gRS(ByVal param As String) As String
        Return dr(param).ToString()
    End Function
    Public Function gRS(ByVal columnIndex As Integer) As String
        Return dr(columnIndex).ToString()
    End Function
    Public Function gRSInt(ByVal param As String) As Integer
        Return CInt(dr(param).ToString())
    End Function
    Public Function gRSInt(ByVal columnIndex As Integer) As Integer
        Return CInt(dr(columnIndex).ToString())
    End Function
    Public Function gRSDouble(ByVal param As String) As Double
        Return CDbl(dr(param).ToString())
    End Function
    Public Function gRSDouble(ByVal columnIndex As Integer) As Double
        Return CDbl(dr(columnIndex).ToString())
    End Function

End Class
