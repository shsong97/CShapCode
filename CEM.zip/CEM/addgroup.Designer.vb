<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_GroupAdd
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents txtGroup_Sec_Level As System.Windows.Forms.TextBox
	Public WithEvents txtMemo As System.Windows.Forms.TextBox
	Public WithEvents cboGroupUser As System.Windows.Forms.ComboBox
    Public WithEvents lblGroupUser As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents txtGroup_Name As System.Windows.Forms.TextBox
	Public WithEvents txt_ID As System.Windows.Forms.TextBox
    Public WithEvents lblmemo As System.Windows.Forms.Label
	Public WithEvents lblLevel As System.Windows.Forms.Label
	Public WithEvents lblGroupName As System.Windows.Forms.Label
	Public WithEvents lblGroupID As System.Windows.Forms.Label
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_GroupAdd))
        Me.txtGroup_Sec_Level = New System.Windows.Forms.TextBox
        Me.txtMemo = New System.Windows.Forms.TextBox
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.cmdUser = New System.Windows.Forms.Button
        Me.cboGroupUser = New System.Windows.Forms.ComboBox
        Me.lblGroupUser = New System.Windows.Forms.Label
        Me.txtGroup_Name = New System.Windows.Forms.TextBox
        Me.txt_ID = New System.Windows.Forms.TextBox
        Me.lblmemo = New System.Windows.Forms.Label
        Me.lblLevel = New System.Windows.Forms.Label
        Me.lblGroupName = New System.Windows.Forms.Label
        Me.lblGroupID = New System.Windows.Forms.Label
        Me.cmdOK = New System.Windows.Forms.Button
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtGroup_Sec_Level
        '
        Me.txtGroup_Sec_Level.AcceptsReturn = True
        Me.txtGroup_Sec_Level.BackColor = System.Drawing.SystemColors.Window
        Me.txtGroup_Sec_Level.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtGroup_Sec_Level.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtGroup_Sec_Level.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGroup_Sec_Level.Location = New System.Drawing.Point(151, 91)
        Me.txtGroup_Sec_Level.MaxLength = 5
        Me.txtGroup_Sec_Level.Name = "txtGroup_Sec_Level"
        Me.txtGroup_Sec_Level.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtGroup_Sec_Level.Size = New System.Drawing.Size(177, 21)
        Me.txtGroup_Sec_Level.TabIndex = 2
        '
        'txtMemo
        '
        Me.txtMemo.AcceptsReturn = True
        Me.txtMemo.BackColor = System.Drawing.SystemColors.Window
        Me.txtMemo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMemo.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtMemo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMemo.Location = New System.Drawing.Point(68, 210)
        Me.txtMemo.MaxLength = 20
        Me.txtMemo.Name = "txtMemo"
        Me.txtMemo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMemo.Size = New System.Drawing.Size(325, 21)
        Me.txtMemo.TabIndex = 3
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cmdUser)
        Me.Frame1.Controls.Add(Me.cboGroupUser)
        Me.Frame1.Controls.Add(Me.lblGroupUser)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(26, 122)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(389, 64)
        Me.Frame1.TabIndex = 11
        Me.Frame1.TabStop = False
        '
        'cmdUser
        '
        Me.cmdUser.Location = New System.Drawing.Point(273, 22)
        Me.cmdUser.Name = "cmdUser"
        Me.cmdUser.Size = New System.Drawing.Size(84, 24)
        Me.cmdUser.TabIndex = 13
        Me.cmdUser.Text = "�����"
        Me.cmdUser.UseVisualStyleBackColor = True
        '
        'cboGroupUser
        '
        Me.cboGroupUser.BackColor = System.Drawing.SystemColors.Window
        Me.cboGroupUser.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboGroupUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGroupUser.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cboGroupUser.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboGroupUser.Location = New System.Drawing.Point(125, 24)
        Me.cboGroupUser.Name = "cboGroupUser"
        Me.cboGroupUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboGroupUser.Size = New System.Drawing.Size(132, 20)
        Me.cboGroupUser.TabIndex = 6
        '
        'lblGroupUser
        '
        Me.lblGroupUser.BackColor = System.Drawing.SystemColors.Control
        Me.lblGroupUser.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroupUser.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblGroupUser.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroupUser.Location = New System.Drawing.Point(31, 29)
        Me.lblGroupUser.Name = "lblGroupUser"
        Me.lblGroupUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroupUser.Size = New System.Drawing.Size(86, 12)
        Me.lblGroupUser.TabIndex = 12
        Me.lblGroupUser.Text = "�׷� ����ڵ�"
        '
        'txtGroup_Name
        '
        Me.txtGroup_Name.AcceptsReturn = True
        Me.txtGroup_Name.BackColor = System.Drawing.SystemColors.Window
        Me.txtGroup_Name.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtGroup_Name.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtGroup_Name.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGroup_Name.Location = New System.Drawing.Point(151, 59)
        Me.txtGroup_Name.MaxLength = 20
        Me.txtGroup_Name.Name = "txtGroup_Name"
        Me.txtGroup_Name.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtGroup_Name.Size = New System.Drawing.Size(177, 21)
        Me.txtGroup_Name.TabIndex = 1
        '
        'txt_ID
        '
        Me.txt_ID.AcceptsReturn = True
        Me.txt_ID.BackColor = System.Drawing.Color.White
        Me.txt_ID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_ID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txt_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt_ID.Location = New System.Drawing.Point(151, 27)
        Me.txt_ID.MaxLength = 8
        Me.txt_ID.Name = "txt_ID"
        Me.txt_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt_ID.Size = New System.Drawing.Size(177, 21)
        Me.txt_ID.TabIndex = 0
        '
        'lblmemo
        '
        Me.lblmemo.BackColor = System.Drawing.SystemColors.Control
        Me.lblmemo.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblmemo.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblmemo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblmemo.Location = New System.Drawing.Point(29, 217)
        Me.lblmemo.Name = "lblmemo"
        Me.lblmemo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblmemo.Size = New System.Drawing.Size(35, 16)
        Me.lblmemo.TabIndex = 13
        Me.lblmemo.Text = "�޸�"
        '
        'lblLevel
        '
        Me.lblLevel.BackColor = System.Drawing.SystemColors.Control
        Me.lblLevel.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblLevel.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblLevel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblLevel.Location = New System.Drawing.Point(66, 93)
        Me.lblLevel.Name = "lblLevel"
        Me.lblLevel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblLevel.Size = New System.Drawing.Size(80, 16)
        Me.lblLevel.TabIndex = 10
        Me.lblLevel.Text = "���ȵ��"
        '
        'lblGroupName
        '
        Me.lblGroupName.BackColor = System.Drawing.SystemColors.Control
        Me.lblGroupName.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroupName.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblGroupName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroupName.Location = New System.Drawing.Point(66, 61)
        Me.lblGroupName.Name = "lblGroupName"
        Me.lblGroupName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroupName.Size = New System.Drawing.Size(105, 25)
        Me.lblGroupName.TabIndex = 9
        Me.lblGroupName.Text = "�׷��"
        '
        'lblGroupID
        '
        Me.lblGroupID.BackColor = System.Drawing.SystemColors.Control
        Me.lblGroupID.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroupID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblGroupID.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroupID.Location = New System.Drawing.Point(66, 29)
        Me.lblGroupID.Name = "lblGroupID"
        Me.lblGroupID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroupID.Size = New System.Drawing.Size(105, 25)
        Me.lblGroupID.TabIndex = 8
        Me.lblGroupID.Text = "�׷� ID"
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(103, 313)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(105, 29)
        Me.cmdOK.TabIndex = 14
        Me.cmdOK.Text = "���"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(239, 313)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(105, 30)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "���"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'frm_GroupAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(435, 370)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.txtGroup_Sec_Level)
        Me.Controls.Add(Me.txtMemo)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.txtGroup_Name)
        Me.Controls.Add(Me.txt_ID)
        Me.Controls.Add(Me.lblmemo)
        Me.Controls.Add(Me.lblLevel)
        Me.Controls.Add(Me.lblGroupName)
        Me.Controls.Add(Me.lblGroupID)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(130, 152)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_GroupAdd"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�׷� �߰� ( frm_GroupAdd )"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdUser As System.Windows.Forms.Button
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
#End Region 
End Class