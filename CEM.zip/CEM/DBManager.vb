﻿Imports System.Data.SqlClient
Imports System.Data.Odbc

Module DBManager

    Public SqlCon As SqlConnection
    Public OdbcCon As OdbcConnection

    Public ErrorMessage As String
    Public ConnectionType As String = "ODBC"

    Public ConnString As String = ""

    Public Sub SetConnectionString(ByVal connectionType As String, ByVal servername As String, ByVal dbname As String, ByVal id As String, ByVal password As String)

        DBManager.ConnectionType = connectionType
        Select Case connectionType
            Case "SqlConnection"
                ConnString = "Persist Security Info=False;Integrated Security=false;" & _
                    "Initial Catalog=" & dbname & _
                    ";server=" & servername & _
                    ";UID=" & id & _
                    ";PWD=" & password

            Case "ODBC"
                ConnString = "Driver={SQL Server};Server=" & servername & _
                    ";Database=" & dbname & _
                    ";Uid=" & id & _
                    ";Pwd=" & password

        End Select

    End Sub

    Public Function IsOpen() As Boolean

        Select Case DBManager.ConnectionType
            Case "SqlConnection"
                If SqlCon.State <> ConnectionState.Open Then
                    IsOpen = False
                Else
                    IsOpen = True
                End If

            Case "ODBC"
                If OdbcCon.State <> ConnectionState.Open Then
                    IsOpen = False
                Else
                    IsOpen = True
                End If
        End Select
    End Function

    Public Function Open() As Boolean
        Open = True

        Select Case DBManager.ConnectionType
            Case "SqlConnection"

                Try
                    If SqlCon Is Nothing Then
                        SqlCon = New SqlConnection(DBManager.ConnString)
                    End If

                    If (SqlCon.State <> ConnectionState.Open) Then
                        If (SqlCon.State = ConnectionState.Connecting) Then
                            SqlCon.Close()
                        End If
                        SqlCon.Open()
                    End If

                Catch se As SqlException
                    DBManager.ErrorMessage = se.Message.ToString()
                    Open = False
                Catch ex As Exception
                    DBManager.ErrorMessage = ex.Message.ToString()
                    Open = False
                End Try

            Case "ODBC"
                Try
                    If OdbcCon Is Nothing Then
                        OdbcCon = New OdbcConnection(DBManager.ConnString)
                    End If

                    If (OdbcCon.State <> ConnectionState.Open) Then
                        If (OdbcCon.State = ConnectionState.Connecting) Then
                            OdbcCon.Close()
                        End If
                        OdbcCon.Open()
                    End If

                Catch se As OdbcException
                    DBManager.ErrorMessage = se.Message.ToString()
                    Open = False
                Catch ex As Exception
                    DBManager.ErrorMessage = ex.Message.ToString()
                    Open = False
                End Try
        End Select

    End Function

    Public Function Close() As Boolean

        Select Case ConnString
            Case "SqlConnection"
                Try
                    If SqlCon Is Nothing Then
                        If SqlCon.State <> ConnectionState.Closed Then
                            SqlCon.Close()
                        End If
                    End If
                Catch se As SqlException
                    DBManager.ErrorMessage = se.Message.ToString()
                    Close = False
                Catch ex As Exception
                    DBManager.ErrorMessage = ex.Message.ToString()
                    Close = False
                End Try
            Case "ODBC"
                Try
                    If OdbcCon Is Nothing Then
                        If OdbcCon.State <> ConnectionState.Closed Then
                            OdbcCon.Close()
                        End If
                    End If
                Catch se As OdbcException
                    DBManager.ErrorMessage = se.Message.ToString()
                    Close = False
                Catch ex As Exception
                    DBManager.ErrorMessage = ex.Message.ToString()
                    Close = False
                End Try
        End Select

    End Function



    Public Function Execute(ByVal strQuery As String) As Integer
        Execute = 0
        Select Case ConnectionType
            Case "SqlConnection"
                Try
                    If SqlCon Is Nothing Then
                        Execute = -1
                    End If
                    Dim SqlCmd As SqlCommand = New SqlCommand()
                    SqlCmd.Connection = SqlCon
                    SqlCmd.CommandText = strQuery
                    Execute = SqlCmd.ExecuteNonQuery()
                Catch se As SqlException
                    DBManager.ErrorMessage = se.Message.ToString()
                    Execute = -1
                End Try
            Case "ODBC"
                Try
                    If OdbcCon Is Nothing Then
                        Execute = -1
                    End If
                    Dim SqlCmd As OdbcCommand = New OdbcCommand()
                    SqlCmd.Connection = OdbcCon
                    SqlCmd.CommandText = strQuery
                    Execute = SqlCmd.ExecuteNonQuery()
                Catch se As OdbcException
                    DBManager.ErrorMessage = se.Message.ToString()
                    Execute = -1
                End Try
        End Select

    End Function


    Public Function Query(ByVal strQuery As String) As DataSet
        Query = New DataSet()
        Select Case ConnectionType
            Case "SqlConnection"
                Try
                    If SqlCon Is Nothing Then
                        Return Nothing
                    End If

                    Dim SqlCmd As SqlCommand = New SqlCommand()
                    SqlCmd.Connection = SqlCon
                    SqlCmd.CommandText = strQuery
                    SqlCmd.CommandTimeout = 90
                    Dim SqlAdapter As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
                    SqlAdapter.Fill(Query)
                Catch se As SqlException
                    DBManager.ErrorMessage = se.Message.ToString()
                    MessageBox.Show(DBManager.ErrorMessage)
                End Try

            Case "ODBC"
                Try
                    If OdbcCon Is Nothing Then
                        Return Nothing
                    End If

                    Dim SqlCmd As OdbcCommand = New OdbcCommand()
                    SqlCmd.Connection = OdbcCon
                    SqlCmd.CommandText = strQuery
                    SqlCmd.CommandTimeout = 90
                    Dim SqlAdapter As OdbcDataAdapter = New OdbcDataAdapter(SqlCmd)
                    SqlAdapter.Fill(Query)
                Catch se As SqlException
                    DBManager.ErrorMessage = se.Message.ToString()
                    MessageBox.Show(DBManager.ErrorMessage)
                End Try

        End Select
    End Function
End Module
