<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmAuthorityProgram
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents _tabTab_TabPage0 As System.Windows.Forms.TabPage
    Public WithEvents _tabTab_TabPage1 As System.Windows.Forms.TabPage
    Public WithEvents _tabTab_TabPage2 As System.Windows.Forms.TabPage
	Public WithEvents cboFromDate As System.Windows.Forms.ComboBox
	Public WithEvents cboToDate As System.Windows.Forms.ComboBox
	Public WithEvents cmdInqueryHistory As System.Windows.Forms.Button
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents _tabTab_TabPage3 As System.Windows.Forms.TabPage
	Public WithEvents tabTab As System.Windows.Forms.TabControl
	Public WithEvents chkSave As System.Windows.Forms.CheckBox
	Public WithEvents txtName As System.Windows.Forms.TextBox
	Public WithEvents CmdList As System.Windows.Forms.Button
	Public WithEvents TxtCode As System.Windows.Forms.TextBox
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdInquery As System.Windows.Forms.Button
	Public WithEvents cboApplication As System.Windows.Forms.ComboBox
    Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.tabTab = New System.Windows.Forms.TabControl
        Me._tabTab_TabPage0 = New System.Windows.Forms.TabPage
        Me._tabTab_TabPage1 = New System.Windows.Forms.TabPage
        Me._tabTab_TabPage2 = New System.Windows.Forms.TabPage
        Me._tabTab_TabPage3 = New System.Windows.Forms.TabPage
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.cboFromDate = New System.Windows.Forms.ComboBox
        Me.cboToDate = New System.Windows.Forms.ComboBox
        Me.cmdInqueryHistory = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.chkSave = New System.Windows.Forms.CheckBox
        Me.txtName = New System.Windows.Forms.TextBox
        Me.CmdList = New System.Windows.Forms.Button
        Me.TxtCode = New System.Windows.Forms.TextBox
        Me.cmdClose = New System.Windows.Forms.Button
        Me.cmdInquery = New System.Windows.Forms.Button
        Me.cboApplication = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.spdUser = New FarPoint.Win.Spread.FpSpread
        Me.spdUser_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdProgram = New FarPoint.Win.Spread.FpSpread
        Me.spdProgram_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdCommonProgram = New FarPoint.Win.Spread.FpSpread
        Me.spdCommonProgram_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdHistory = New FarPoint.Win.Spread.FpSpread
        Me.spdHistory_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.tabTab.SuspendLayout()
        Me._tabTab_TabPage0.SuspendLayout()
        Me._tabTab_TabPage1.SuspendLayout()
        Me._tabTab_TabPage2.SuspendLayout()
        Me._tabTab_TabPage3.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.frmButton.SuspendLayout()
        CType(Me.spdUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdUser_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdProgram_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdCommonProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdCommonProgram_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHistory_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tabTab
        '
        Me.tabTab.Controls.Add(Me._tabTab_TabPage0)
        Me.tabTab.Controls.Add(Me._tabTab_TabPage1)
        Me.tabTab.Controls.Add(Me._tabTab_TabPage2)
        Me.tabTab.Controls.Add(Me._tabTab_TabPage3)
        Me.tabTab.ItemSize = New System.Drawing.Size(42, 18)
        Me.tabTab.Location = New System.Drawing.Point(0, 56)
        Me.tabTab.Name = "tabTab"
        Me.tabTab.SelectedIndex = 0
        Me.tabTab.Size = New System.Drawing.Size(961, 545)
        Me.tabTab.TabIndex = 9
        '
        '_tabTab_TabPage0
        '
        Me._tabTab_TabPage0.Controls.Add(Me.spdUser)
        Me._tabTab_TabPage0.Location = New System.Drawing.Point(4, 22)
        Me._tabTab_TabPage0.Name = "_tabTab_TabPage0"
        Me._tabTab_TabPage0.Size = New System.Drawing.Size(953, 519)
        Me._tabTab_TabPage0.TabIndex = 0
        Me._tabTab_TabPage0.Text = "User List"
        '
        '_tabTab_TabPage1
        '
        Me._tabTab_TabPage1.Controls.Add(Me.spdProgram)
        Me._tabTab_TabPage1.Location = New System.Drawing.Point(4, 22)
        Me._tabTab_TabPage1.Name = "_tabTab_TabPage1"
        Me._tabTab_TabPage1.Size = New System.Drawing.Size(953, 519)
        Me._tabTab_TabPage1.TabIndex = 1
        Me._tabTab_TabPage1.Text = "Program List"
        '
        '_tabTab_TabPage2
        '
        Me._tabTab_TabPage2.Controls.Add(Me.spdCommonProgram)
        Me._tabTab_TabPage2.Location = New System.Drawing.Point(4, 22)
        Me._tabTab_TabPage2.Name = "_tabTab_TabPage2"
        Me._tabTab_TabPage2.Size = New System.Drawing.Size(953, 519)
        Me._tabTab_TabPage2.TabIndex = 2
        Me._tabTab_TabPage2.Text = "COMMON Prog List"
        '
        '_tabTab_TabPage3
        '
        Me._tabTab_TabPage3.Controls.Add(Me.spdHistory)
        Me._tabTab_TabPage3.Controls.Add(Me.Frame1)
        Me._tabTab_TabPage3.Location = New System.Drawing.Point(4, 22)
        Me._tabTab_TabPage3.Name = "_tabTab_TabPage3"
        Me._tabTab_TabPage3.Size = New System.Drawing.Size(953, 519)
        Me._tabTab_TabPage3.TabIndex = 3
        Me._tabTab_TabPage3.Text = "History"
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cboFromDate)
        Me.Frame1.Controls.Add(Me.cboToDate)
        Me.Frame1.Controls.Add(Me.cmdInqueryHistory)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(8, 32)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(665, 49)
        Me.Frame1.TabIndex = 13
        Me.Frame1.TabStop = False
        '
        'cboFromDate
        '
        Me.cboFromDate.BackColor = System.Drawing.SystemColors.Window
        Me.cboFromDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboFromDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFromDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboFromDate.Location = New System.Drawing.Point(152, 16)
        Me.cboFromDate.Name = "cboFromDate"
        Me.cboFromDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboFromDate.Size = New System.Drawing.Size(145, 21)
        Me.cboFromDate.TabIndex = 16
        '
        'cboToDate
        '
        Me.cboToDate.BackColor = System.Drawing.SystemColors.Window
        Me.cboToDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboToDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboToDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboToDate.Location = New System.Drawing.Point(312, 16)
        Me.cboToDate.Name = "cboToDate"
        Me.cboToDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboToDate.Size = New System.Drawing.Size(145, 21)
        Me.cboToDate.TabIndex = 15
        '
        'cmdInqueryHistory
        '
        Me.cmdInqueryHistory.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInqueryHistory.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInqueryHistory.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInqueryHistory.Location = New System.Drawing.Point(472, 16)
        Me.cmdInqueryHistory.Name = "cmdInqueryHistory"
        Me.cmdInqueryHistory.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInqueryHistory.Size = New System.Drawing.Size(57, 25)
        Me.cmdInqueryHistory.TabIndex = 14
        Me.cmdInqueryHistory.Text = "��ȸ"
        Me.cmdInqueryHistory.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(137, 20)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "������ ( From ~ To )"
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.chkSave)
        Me.frmButton.Controls.Add(Me.txtName)
        Me.frmButton.Controls.Add(Me.CmdList)
        Me.frmButton.Controls.Add(Me.TxtCode)
        Me.frmButton.Controls.Add(Me.cmdClose)
        Me.frmButton.Controls.Add(Me.cmdInquery)
        Me.frmButton.Controls.Add(Me.cboApplication)
        Me.frmButton.Controls.Add(Me.Label2)
        Me.frmButton.Controls.Add(Me.Label8)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(963, 49)
        Me.frmButton.TabIndex = 0
        Me.frmButton.TabStop = False
        '
        'chkSave
        '
        Me.chkSave.BackColor = System.Drawing.SystemColors.Control
        Me.chkSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkSave.Font = New System.Drawing.Font("����", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.chkSave.ForeColor = System.Drawing.Color.Red
        Me.chkSave.Location = New System.Drawing.Point(744, 16)
        Me.chkSave.Name = "chkSave"
        Me.chkSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkSave.Size = New System.Drawing.Size(209, 17)
        Me.chkSave.TabIndex = 12
        Me.chkSave.Text = "�̷�����(���ڷ����������)"
        Me.chkSave.UseVisualStyleBackColor = False
        '
        'txtName
        '
        Me.txtName.AcceptsReturn = True
        Me.txtName.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtName.Location = New System.Drawing.Point(414, 18)
        Me.txtName.MaxLength = 0
        Me.txtName.Name = "txtName"
        Me.txtName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtName.Size = New System.Drawing.Size(131, 20)
        Me.txtName.TabIndex = 8
        '
        'CmdList
        '
        Me.CmdList.BackColor = System.Drawing.SystemColors.Control
        Me.CmdList.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdList.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdList.Location = New System.Drawing.Point(548, 18)
        Me.CmdList.Name = "CmdList"
        Me.CmdList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdList.Size = New System.Drawing.Size(25, 19)
        Me.CmdList.TabIndex = 7
        Me.CmdList.Text = "?"
        Me.CmdList.UseVisualStyleBackColor = False
        '
        'TxtCode
        '
        Me.TxtCode.AcceptsReturn = True
        Me.TxtCode.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TxtCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtCode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtCode.Location = New System.Drawing.Point(310, 18)
        Me.TxtCode.MaxLength = 0
        Me.TxtCode.Name = "TxtCode"
        Me.TxtCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtCode.Size = New System.Drawing.Size(103, 20)
        Me.TxtCode.TabIndex = 5
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(666, 16)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(65, 25)
        Me.cmdClose.TabIndex = 3
        Me.cmdClose.Text = "����"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdInquery
        '
        Me.cmdInquery.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInquery.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInquery.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInquery.Location = New System.Drawing.Point(590, 16)
        Me.cmdInquery.Name = "cmdInquery"
        Me.cmdInquery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInquery.Size = New System.Drawing.Size(65, 25)
        Me.cmdInquery.TabIndex = 2
        Me.cmdInquery.Text = "��ȸ"
        Me.cmdInquery.UseVisualStyleBackColor = False
        '
        'cboApplication
        '
        Me.cboApplication.BackColor = System.Drawing.SystemColors.Window
        Me.cboApplication.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboApplication.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboApplication.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboApplication.Location = New System.Drawing.Point(84, 18)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboApplication.Size = New System.Drawing.Size(151, 21)
        Me.cboApplication.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(258, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Program"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(16, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(73, 20)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Application"
        '
        'spdUser
        '
        Me.spdUser.AccessibleDescription = ""
        Me.spdUser.Location = New System.Drawing.Point(3, 3)
        Me.spdUser.Name = "spdUser"
        Me.spdUser.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdUser_Sheet1})
        Me.spdUser.Size = New System.Drawing.Size(946, 513)
        Me.spdUser.TabIndex = 0
        '
        'spdUser_Sheet1
        '
        Me.spdUser_Sheet1.Reset()
        Me.spdUser_Sheet1.SheetName = "Sheet1"
        '
        'spdProgram
        '
        Me.spdProgram.AccessibleDescription = ""
        Me.spdProgram.Location = New System.Drawing.Point(3, 3)
        Me.spdProgram.Name = "spdProgram"
        Me.spdProgram.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdProgram_Sheet1})
        Me.spdProgram.Size = New System.Drawing.Size(946, 513)
        Me.spdProgram.TabIndex = 0
        '
        'spdProgram_Sheet1
        '
        Me.spdProgram_Sheet1.Reset()
        Me.spdProgram_Sheet1.SheetName = "Sheet1"
        '
        'spdCommonProgram
        '
        Me.spdCommonProgram.AccessibleDescription = ""
        Me.spdCommonProgram.Location = New System.Drawing.Point(3, 3)
        Me.spdCommonProgram.Name = "spdCommonProgram"
        Me.spdCommonProgram.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdCommonProgram_Sheet1})
        Me.spdCommonProgram.Size = New System.Drawing.Size(946, 513)
        Me.spdCommonProgram.TabIndex = 0
        '
        'spdCommonProgram_Sheet1
        '
        Me.spdCommonProgram_Sheet1.Reset()
        Me.spdCommonProgram_Sheet1.SheetName = "Sheet1"
        '
        'spdHistory
        '
        Me.spdHistory.AccessibleDescription = ""
        Me.spdHistory.Location = New System.Drawing.Point(8, 87)
        Me.spdHistory.Name = "spdHistory"
        Me.spdHistory.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHistory_Sheet1})
        Me.spdHistory.Size = New System.Drawing.Size(941, 429)
        Me.spdHistory.TabIndex = 14
        '
        'spdHistory_Sheet1
        '
        Me.spdHistory_Sheet1.Reset()
        Me.spdHistory_Sheet1.SheetName = "Sheet1"
        '
        'frmAuthorityProgram
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(967, 609)
        Me.Controls.Add(Me.tabTab)
        Me.Controls.Add(Me.frmButton)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(-5, 333)
        Me.Name = "frmAuthorityProgram"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "�������ٱ��� ��ȸ ( frmAuthorityProgram )"
        Me.tabTab.ResumeLayout(False)
        Me._tabTab_TabPage0.ResumeLayout(False)
        Me._tabTab_TabPage1.ResumeLayout(False)
        Me._tabTab_TabPage2.ResumeLayout(False)
        Me._tabTab_TabPage3.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.frmButton.ResumeLayout(False)
        Me.frmButton.PerformLayout()
        CType(Me.spdUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdUser_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdProgram_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdCommonProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdCommonProgram_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHistory_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spdUser As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdUser_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdProgram As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdProgram_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdCommonProgram As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdCommonProgram_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdHistory As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHistory_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class