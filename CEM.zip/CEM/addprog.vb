Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frm_ProgAdd
	Inherits System.Windows.Forms.Form
	

	
    Public Function F_DBRecordDisplay() As Boolean

        F_DBRecordDisplay = True

        Gsql = ""
        Gsql = Gsql & " SELECT * "
        Gsql = Gsql & "   FROM program_info"
        Gsql = Gsql & "  WHERE program = '" & txt_ID.Text & "'"

        Dim g As GRSClass = New GRSClass(Gsql)

        If g.RowCount <> 1 Then
            txtProgram_Name.Text = ""
            txtSecurity_level.Text = ""
            txtDevelop_date.Text = ""
            txtDevelop_chng_date.Text = ""
            txtVersion.Text = ""
        Else
            txtProgram_Name.Text = g.gRS("program_name") & ""
            txtSecurity_level.Text = g.gRS("security_level")
            g_FindSetCombotIndex(cboDevelop_ID, g.gRS("develop_id") & "")
            txtDevelop_date.Text = VB6.Format(g.gRS("develop_date"), "yyyy/mm/dd hh:mm")
            g_FindSetCombotIndex(cboDevelop_chng_ID, g.gRS("develop_chng_id") & "")
            txtDevelop_chng_date.Text = VB6.Format(g.gRS("develop_chng_date"), "yyyy/mm/dd hh:mm")
            txtVersion.Text = g.gRS("Version") & ""
            g_FindSetCombotIndex(cboStatus, g.gRS("Status"))
        End If

    End Function
	
	Sub LF_ComboInit()
		
        cboStatus.Items.Add("����" & Space(50) & "S")
		cboStatus.Items.Add("����" & Space(50) & "T")
		cboStatus.Items.Add("��� ����" & Space(50) & "P")
		cboStatus.Items.Add("���" & Space(50) & "C")
        cboStatus.SelectedIndex = 0

        Gsql = ""
		Gsql = Gsql & " select user_id, user_name_k "
		Gsql = Gsql & " from user_info"
		Gsql = Gsql & " where active_flag <> 'T' AND active_flag <> 'D' and security_level=0"
        Gsql = Gsql & " order by user_id desc"

        Dim g As GRSClass = New GRSClass(Gsql)

        cboDevelop_ID.Items.Clear()
        cboDevelop_chng_ID.Items.Clear()

        For inx As Integer = 0 To g.RowCount - 1
            cboDevelop_ID.Items.Add(g.gRS(1) & Space(50) & g.gRS(0))
            cboDevelop_chng_ID.Items.Add(g.gRS(1) & Space(50) & g.gRS(0))
            g.MoveNext()
        Next

        cboDevelop_ID.SelectedIndex = 0
        cboDevelop_chng_ID.SelectedIndex = 0

    End Sub
	

	
	Private Sub frm_ProgAdd_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		g_CenterForm(Me)
		LF_ComboInit()
	End Sub
	
    Private Sub cmdOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOk.Click
        On Error GoTo Err_Handler
        Dim g As GRSClass
        Dim Kkey As String

        If Not CheckRequestNo() Then
            Exit Sub
        End If

        If Not IsNumeric(txtSecurity_level.Text) Then txtSecurity_level.Text = "999"

        If Len(Trim(txt_ID.Text)) > 0 Then
            txt_ID.Text = Trim(txt_ID.Text)
        Else
            Exit Sub
        End If

        If cmdOk.Text = "����" Then
            Kkey = "U"
        Else
            Kkey = "I"
        End If

        If gRequestNo = "" Then
            MsgBox("��û��ȣ(RequestNo)�� �����ϴ�.�۾��������� �ʽ��ϴ�.")
            Exit Sub
        End If

        Gsql = "exec sp_program_info '"
        Gsql = Gsql & Kkey & "','"
        Gsql = Gsql & gUSERID & "','"
        Gsql = Gsql & txt_ID.Text & "','"
        Gsql = Gsql & Trim(txtProgram_Name.Text) & "','"
        Gsql = Gsql & txtSecurity_level.Text & "','"

        Gsql = Gsql & Trim(VB.Right(cboDevelop_ID.Text, 50)) & "','"
        Gsql = Gsql & IIf(IsDate(txtDevelop_date.Text), txtDevelop_date.Text, Today) & "','"
        Gsql = Gsql & Trim(VB.Right(cboDevelop_ID.Text, 50)) & "','"
        Gsql = Gsql & IIf(IsDate(txtDevelop_chng_date.Text), txtDevelop_chng_date.Text, Today) & "','"
        Gsql = Gsql & VB.Right(cboStatus.Text, 1) & "','"

        Gsql = Gsql & Trim(txtVersion.Text) & "','"
        Gsql = Gsql & gRequestNo & "'"
        g = New GRSClass(Gsql)


        Dim nodT As ComctlLib.Node
        If cmdOk.Text = "����" Then
            gnodX.Text = txtProgram_Name.Text
            Me.Close()
        Else
            nodT = gnodX.Nodes.Add(txt_ID.Text, txtProgram_Name.Text)
            nodT.Tag = "P_X"
            txt_ID.Text = ""
            txtProgram_Name.Text = ""
        End If

        Exit Sub
Err_Handler:
        Select Case gF_Error_Handler()
            Case "X" : Exit Sub
            Case "R" : Resume
            Case "N" : Resume Next
            Case Else
                Exit Sub
        End Select
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub
End Class