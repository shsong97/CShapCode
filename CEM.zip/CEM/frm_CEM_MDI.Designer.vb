<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_CEM_MDI
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents mnu_editer_add As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_editer_edit As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_editer_delete As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_editer_1 As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnu_editer_refresh As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_editer_2 As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnu_editer_history As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_editer As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_RequestMgt As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnu_RequestDetails As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnu_RequestType As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_Request As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_searchuser As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnu_UserAuthorityCopy As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnu_User As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_AppAuthoiryInquiry As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_UserAuthority As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnu_retire_list As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_popup_manage As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_van_user As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_InfoAuth As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_UserHistory As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_GroupHistory As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_ProgramHistory As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnu_History As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents _mnu_View_icon_0 As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents _mnu_View_icon_1 As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents _mnu_View_icon_2 As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents _mnu_View_icon_3 As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_view As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnu_Window_cascade As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_Window_ho As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_Window_ve As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnu_Window As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents MainMenu1 As System.Windows.Forms.MenuStrip
	Public WithEvents tmr_Delay As System.Windows.Forms.Timer
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_CEM_MDI))
        Me.MainMenu1 = New System.Windows.Forms.MenuStrip
        Me.mnu_editer = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_editer_add = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_editer_edit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_editer_delete = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_editer_1 = New System.Windows.Forms.ToolStripSeparator
        Me.mnu_editer_refresh = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_editer_2 = New System.Windows.Forms.ToolStripSeparator
        Me.mnu_editer_history = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Request = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_RequestMgt = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_RequestDetails = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_RequestType = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_UserManage = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_User = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_searchuser = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_UserAuthorityCopy = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_InfoAuth = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_AppAuthoiryInquiry = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_UserAuthority = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_retire_list = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_popup_manage = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_van_user = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_History = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_UserHistory = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_GroupHistory = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_ProgramHistory = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_view = New System.Windows.Forms.ToolStripMenuItem
        Me._mnu_View_icon_0 = New System.Windows.Forms.ToolStripMenuItem
        Me._mnu_View_icon_1 = New System.Windows.Forms.ToolStripMenuItem
        Me._mnu_View_icon_2 = New System.Windows.Forms.ToolStripMenuItem
        Me._mnu_View_icon_3 = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Window = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Window_cascade = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Window_ho = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Window_ve = New System.Windows.Forms.ToolStripMenuItem
        Me.tmr_Delay = New System.Windows.Forms.Timer(Me.components)
        Me._mnu_View_icon_4 = New System.Windows.Forms.ToolStripMenuItem
        Me.MainMenu1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_editer, Me.mnu_Request, Me.mnu_User, Me.mnu_InfoAuth, Me.mnu_History, Me.mnu_view, Me.mnu_Window})
        Me.MainMenu1.Location = New System.Drawing.Point(0, 0)
        Me.MainMenu1.Name = "MainMenu1"
        Me.MainMenu1.Size = New System.Drawing.Size(705, 24)
        Me.MainMenu1.TabIndex = 1
        '
        'mnu_editer
        '
        Me.mnu_editer.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_editer_add, Me.mnu_editer_edit, Me.mnu_editer_delete, Me.mnu_editer_1, Me.mnu_editer_refresh, Me.mnu_editer_2, Me.mnu_editer_history})
        Me.mnu_editer.MergeAction = System.Windows.Forms.MergeAction.Remove
        Me.mnu_editer.Name = "mnu_editer"
        Me.mnu_editer.Size = New System.Drawing.Size(41, 20)
        Me.mnu_editer.Text = "�˾�"
        Me.mnu_editer.Visible = False
        '
        'mnu_editer_add
        '
        Me.mnu_editer_add.Name = "mnu_editer_add"
        Me.mnu_editer_add.Size = New System.Drawing.Size(128, 22)
        Me.mnu_editer_add.Text = "�߰�"
        '
        'mnu_editer_edit
        '
        Me.mnu_editer_edit.Name = "mnu_editer_edit"
        Me.mnu_editer_edit.Size = New System.Drawing.Size(128, 22)
        Me.mnu_editer_edit.Text = "����"
        '
        'mnu_editer_delete
        '
        Me.mnu_editer_delete.Name = "mnu_editer_delete"
        Me.mnu_editer_delete.Size = New System.Drawing.Size(128, 22)
        Me.mnu_editer_delete.Text = "����"
        '
        'mnu_editer_1
        '
        Me.mnu_editer_1.Name = "mnu_editer_1"
        Me.mnu_editer_1.Size = New System.Drawing.Size(125, 6)
        '
        'mnu_editer_refresh
        '
        Me.mnu_editer_refresh.Name = "mnu_editer_refresh"
        Me.mnu_editer_refresh.Size = New System.Drawing.Size(128, 22)
        Me.mnu_editer_refresh.Text = "�ٽ� ����"
        '
        'mnu_editer_2
        '
        Me.mnu_editer_2.Name = "mnu_editer_2"
        Me.mnu_editer_2.Size = New System.Drawing.Size(125, 6)
        '
        'mnu_editer_history
        '
        Me.mnu_editer_history.Name = "mnu_editer_history"
        Me.mnu_editer_history.Size = New System.Drawing.Size(128, 22)
        Me.mnu_editer_history.Text = "�̷� ��ȸ"
        '
        'mnu_Request
        '
        Me.mnu_Request.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_RequestMgt, Me.mnu_RequestDetails, Me.mnu_RequestType, Me.mnu_UserManage})
        Me.mnu_Request.MergeAction = System.Windows.Forms.MergeAction.Remove
        Me.mnu_Request.Name = "mnu_Request"
        Me.mnu_Request.Size = New System.Drawing.Size(65, 20)
        Me.mnu_Request.Text = "��û����"
        '
        'mnu_RequestMgt
        '
        Me.mnu_RequestMgt.Name = "mnu_RequestMgt"
        Me.mnu_RequestMgt.Size = New System.Drawing.Size(196, 22)
        Me.mnu_RequestMgt.Text = "����� ��û �Է�"
        '
        'mnu_RequestDetails
        '
        Me.mnu_RequestDetails.Name = "mnu_RequestDetails"
        Me.mnu_RequestDetails.Size = New System.Drawing.Size(196, 22)
        Me.mnu_RequestDetails.Text = "��û�� ���� ���泻��"
        '
        'mnu_RequestType
        '
        Me.mnu_RequestType.Name = "mnu_RequestType"
        Me.mnu_RequestType.Size = New System.Drawing.Size(196, 22)
        Me.mnu_RequestType.Text = "����� ��û ���� ����"
        '
        'mnu_UserManage
        '
        Me.mnu_UserManage.Name = "mnu_UserManage"
        Me.mnu_UserManage.Size = New System.Drawing.Size(196, 22)
        Me.mnu_UserManage.Text = "����ڰ���"
        '
        'mnu_User
        '
        Me.mnu_User.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_searchuser, Me.mnu_UserAuthorityCopy})
        Me.mnu_User.MergeAction = System.Windows.Forms.MergeAction.Remove
        Me.mnu_User.Name = "mnu_User"
        Me.mnu_User.Size = New System.Drawing.Size(81, 20)
        Me.mnu_User.Text = "����� ����"
        '
        'mnu_searchuser
        '
        Me.mnu_searchuser.Name = "mnu_searchuser"
        Me.mnu_searchuser.Size = New System.Drawing.Size(168, 22)
        Me.mnu_searchuser.Text = "����� ���� ����"
        '
        'mnu_UserAuthorityCopy
        '
        Me.mnu_UserAuthorityCopy.Name = "mnu_UserAuthorityCopy"
        Me.mnu_UserAuthorityCopy.Size = New System.Drawing.Size(168, 22)
        Me.mnu_UserAuthorityCopy.Text = "����� ���� ����"
        '
        'mnu_InfoAuth
        '
        Me.mnu_InfoAuth.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_AppAuthoiryInquiry, Me.mnu_UserAuthority, Me.mnu_retire_list, Me.mnu_popup_manage, Me.mnu_van_user})
        Me.mnu_InfoAuth.MergeAction = System.Windows.Forms.MergeAction.Remove
        Me.mnu_InfoAuth.Name = "mnu_InfoAuth"
        Me.mnu_InfoAuth.Size = New System.Drawing.Size(65, 20)
        Me.mnu_InfoAuth.Text = "�����"
        '
        'mnu_AppAuthoiryInquiry
        '
        Me.mnu_AppAuthoiryInquiry.Name = "mnu_AppAuthoiryInquiry"
        Me.mnu_AppAuthoiryInquiry.Size = New System.Drawing.Size(196, 22)
        Me.mnu_AppAuthoiryInquiry.Text = "�������ٱ��� ��ȸ"
        '
        'mnu_UserAuthority
        '
        Me.mnu_UserAuthority.Name = "mnu_UserAuthority"
        Me.mnu_UserAuthority.Size = New System.Drawing.Size(196, 22)
        Me.mnu_UserAuthority.Text = "����� ���� ��ȸ"
        '
        'mnu_retire_list
        '
        Me.mnu_retire_list.Name = "mnu_retire_list"
        Me.mnu_retire_list.Size = New System.Drawing.Size(196, 22)
        Me.mnu_retire_list.Text = "������������ڸ���Ʈ"
        '
        'mnu_popup_manage
        '
        Me.mnu_popup_manage.Name = "mnu_popup_manage"
        Me.mnu_popup_manage.Size = New System.Drawing.Size(196, 22)
        Me.mnu_popup_manage.Text = "VAN�˾�����"
        '
        'mnu_van_user
        '
        Me.mnu_van_user.Name = "mnu_van_user"
        Me.mnu_van_user.Size = New System.Drawing.Size(196, 22)
        Me.mnu_van_user.Text = "Van User����"
        '
        'mnu_History
        '
        Me.mnu_History.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_UserHistory, Me.mnu_GroupHistory, Me.mnu_ProgramHistory})
        Me.mnu_History.MergeAction = System.Windows.Forms.MergeAction.Remove
        Me.mnu_History.Name = "mnu_History"
        Me.mnu_History.Size = New System.Drawing.Size(65, 20)
        Me.mnu_History.Text = "�̷���ȸ"
        '
        'mnu_UserHistory
        '
        Me.mnu_UserHistory.Name = "mnu_UserHistory"
        Me.mnu_UserHistory.Size = New System.Drawing.Size(167, 22)
        Me.mnu_UserHistory.Text = "User History"
        '
        'mnu_GroupHistory
        '
        Me.mnu_GroupHistory.Name = "mnu_GroupHistory"
        Me.mnu_GroupHistory.Size = New System.Drawing.Size(167, 22)
        Me.mnu_GroupHistory.Text = "Group History"
        '
        'mnu_ProgramHistory
        '
        Me.mnu_ProgramHistory.Name = "mnu_ProgramHistory"
        Me.mnu_ProgramHistory.Size = New System.Drawing.Size(167, 22)
        Me.mnu_ProgramHistory.Text = "Program History"
        '
        'mnu_view
        '
        Me.mnu_view.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me._mnu_View_icon_0, Me._mnu_View_icon_1, Me._mnu_View_icon_2, Me._mnu_View_icon_3, Me._mnu_View_icon_4})
        Me.mnu_view.MergeAction = System.Windows.Forms.MergeAction.Remove
        Me.mnu_view.Name = "mnu_view"
        Me.mnu_view.Size = New System.Drawing.Size(59, 20)
        Me.mnu_view.Text = "����(&V)"
        '
        '_mnu_View_icon_0
        '
        Me._mnu_View_icon_0.Name = "_mnu_View_icon_0"
        Me._mnu_View_icon_0.Size = New System.Drawing.Size(161, 22)
        Me._mnu_View_icon_0.Text = "ū������(&G)"
        '
        '_mnu_View_icon_1
        '
        Me._mnu_View_icon_1.Name = "_mnu_View_icon_1"
        Me._mnu_View_icon_1.Size = New System.Drawing.Size(161, 22)
        Me._mnu_View_icon_1.Text = "���� ������(&M)"
        '
        '_mnu_View_icon_2
        '
        Me._mnu_View_icon_2.Name = "_mnu_View_icon_2"
        Me._mnu_View_icon_2.Size = New System.Drawing.Size(161, 22)
        Me._mnu_View_icon_2.Text = "���(&L)"
        '
        '_mnu_View_icon_3
        '
        Me._mnu_View_icon_3.Name = "_mnu_View_icon_3"
        Me._mnu_View_icon_3.Size = New System.Drawing.Size(161, 22)
        Me._mnu_View_icon_3.Text = "�ڼ���(&D)"
        '
        'mnu_Window
        '
        Me.mnu_Window.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_Window_cascade, Me.mnu_Window_ho, Me.mnu_Window_ve})
        Me.mnu_Window.MergeAction = System.Windows.Forms.MergeAction.Remove
        Me.mnu_Window.Name = "mnu_Window"
        Me.mnu_Window.Size = New System.Drawing.Size(49, 20)
        Me.mnu_Window.Text = "â(&W)"
        '
        'mnu_Window_cascade
        '
        Me.mnu_Window_cascade.Name = "mnu_Window_cascade"
        Me.mnu_Window_cascade.Size = New System.Drawing.Size(186, 22)
        Me.mnu_Window_cascade.Text = "��ܽĹ迭"
        '
        'mnu_Window_ho
        '
        Me.mnu_Window_ho.Name = "mnu_Window_ho"
        Me.mnu_Window_ho.Size = New System.Drawing.Size(186, 22)
        Me.mnu_Window_ho.Text = "�ٵ��ǽ� �迭(����)"
        '
        'mnu_Window_ve
        '
        Me.mnu_Window_ve.Name = "mnu_Window_ve"
        Me.mnu_Window_ve.Size = New System.Drawing.Size(186, 22)
        Me.mnu_Window_ve.Text = "�ٵ��ǽĹ迭(����)"
        '
        'tmr_Delay
        '
        Me.tmr_Delay.Interval = 2000
        '
        '_mnu_View_icon_4
        '
        Me._mnu_View_icon_4.Name = "_mnu_View_icon_4"
        Me._mnu_View_icon_4.Size = New System.Drawing.Size(161, 22)
        Me._mnu_View_icon_4.Text = "Ÿ��"
        '
        'frm_CEM_MDI
        '
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ClientSize = New System.Drawing.Size(705, 444)
        Me.Controls.Add(Me.MainMenu1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Location = New System.Drawing.Point(18, 171)
        Me.Name = "frm_CEM_MDI"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Common EnterPrise Manager"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MainMenu1.ResumeLayout(False)
        Me.MainMenu1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnu_UserManage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents _mnu_View_icon_4 As System.Windows.Forms.ToolStripMenuItem
#End Region 
End Class