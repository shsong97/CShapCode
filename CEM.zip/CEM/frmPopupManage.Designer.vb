<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmPopupManage
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
	Public WithEvents remark_Txt As System.Windows.Forms.TextBox
    Public WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents apply_Txt As System.Windows.Forms.TextBox
	Public WithEvents Code_Txt As System.Windows.Forms.TextBox
    Public WithEvents txtFromDate As System.Windows.Forms.MaskedTextBox
	Public WithEvents txtToDate As System.Windows.Forms.MaskedTextBox
    Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Me.Frame2 = New System.Windows.Forms.GroupBox
        Me.sp_pop = New FarPoint.Win.Spread.FpSpread
        Me.sp_pop_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.remark_Txt = New System.Windows.Forms.TextBox
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.can_button = New System.Windows.Forms.Button
        Me.see_button_1 = New System.Windows.Forms.Button
        Me.see_button = New System.Windows.Forms.Button
        Me.beg_button = New System.Windows.Forms.Button
        Me.del_button = New System.Windows.Forms.Button
        Me.mod_button = New System.Windows.Forms.Button
        Me.sub_button = New System.Windows.Forms.Button
        Me.sear_button = New System.Windows.Forms.Button
        Me.apply_Txt = New System.Windows.Forms.TextBox
        Me.Code_Txt = New System.Windows.Forms.TextBox
        Me.txtFromDate = New System.Windows.Forms.MaskedTextBox
        Me.txtToDate = New System.Windows.Forms.MaskedTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Frame2.SuspendLayout()
        CType(Me.sp_pop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sp_pop_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.sp_pop)
        Me.Frame2.Controls.Add(Me.remark_Txt)
        Me.Frame2.Controls.Add(Me.WebBrowser1)
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(13, 88)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(1064, 462)
        Me.Frame2.TabIndex = 1
        Me.Frame2.TabStop = False
        '
        'sp_pop
        '
        Me.sp_pop.AccessibleDescription = "sp_pop, Sheet1, Row 0, Column 0, "
        Me.sp_pop.Location = New System.Drawing.Point(9, 15)
        Me.sp_pop.Name = "sp_pop"
        Me.sp_pop.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sp_pop_Sheet1})
        Me.sp_pop.Size = New System.Drawing.Size(415, 429)
        Me.sp_pop.TabIndex = 23
        '
        'sp_pop_Sheet1
        '
        Me.sp_pop_Sheet1.Reset()
        Me.sp_pop_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.sp_pop_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.sp_pop_Sheet1.ColumnCount = 4
        Me.sp_pop_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Code"
        Me.sp_pop_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "���� ������"
        Me.sp_pop_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "���� ������"
        Me.sp_pop_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "���뿩��"
        Me.sp_pop_Sheet1.Columns.Get(0).CellType = TextCellType1
        Me.sp_pop_Sheet1.Columns.Get(0).Label = "Code"
        Me.sp_pop_Sheet1.Columns.Get(1).Label = "���� ������"
        Me.sp_pop_Sheet1.Columns.Get(1).Width = 92.0!
        Me.sp_pop_Sheet1.Columns.Get(2).Label = "���� ������"
        Me.sp_pop_Sheet1.Columns.Get(2).Width = 99.0!
        Me.sp_pop_Sheet1.Columns.Get(3).Label = "���뿩��"
        Me.sp_pop_Sheet1.Columns.Get(3).Width = 71.0!
        Me.sp_pop_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.sp_pop_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'remark_Txt
        '
        Me.remark_Txt.AcceptsReturn = True
        Me.remark_Txt.BackColor = System.Drawing.SystemColors.Window
        Me.remark_Txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.remark_Txt.ForeColor = System.Drawing.SystemColors.WindowText
        Me.remark_Txt.Location = New System.Drawing.Point(432, 15)
        Me.remark_Txt.MaxLength = 2048
        Me.remark_Txt.Multiline = True
        Me.remark_Txt.Name = "remark_Txt"
        Me.remark_Txt.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.remark_Txt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.remark_Txt.Size = New System.Drawing.Size(612, 429)
        Me.remark_Txt.TabIndex = 12
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(9, 7)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(167, 102)
        Me.WebBrowser1.TabIndex = 22
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.can_button)
        Me.Frame1.Controls.Add(Me.see_button_1)
        Me.Frame1.Controls.Add(Me.see_button)
        Me.Frame1.Controls.Add(Me.beg_button)
        Me.Frame1.Controls.Add(Me.del_button)
        Me.Frame1.Controls.Add(Me.mod_button)
        Me.Frame1.Controls.Add(Me.sub_button)
        Me.Frame1.Controls.Add(Me.sear_button)
        Me.Frame1.Controls.Add(Me.apply_Txt)
        Me.Frame1.Controls.Add(Me.Code_Txt)
        Me.Frame1.Controls.Add(Me.txtFromDate)
        Me.Frame1.Controls.Add(Me.txtToDate)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.Controls.Add(Me.Label6)
        Me.Frame1.Controls.Add(Me.Label5)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.Controls.Add(Me.Label3)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(13, 13)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(1065, 72)
        Me.Frame1.TabIndex = 0
        Me.Frame1.TabStop = False
        '
        'can_button
        '
        Me.can_button.Location = New System.Drawing.Point(959, 18)
        Me.can_button.Name = "can_button"
        Me.can_button.Size = New System.Drawing.Size(70, 25)
        Me.can_button.TabIndex = 29
        Me.can_button.Text = "����"
        Me.can_button.UseVisualStyleBackColor = True
        '
        'see_button_1
        '
        Me.see_button_1.Location = New System.Drawing.Point(824, 17)
        Me.see_button_1.Name = "see_button_1"
        Me.see_button_1.Size = New System.Drawing.Size(128, 26)
        Me.see_button_1.TabIndex = 28
        Me.see_button_1.Text = "����Ʈ�̸�����"
        Me.see_button_1.UseVisualStyleBackColor = True
        '
        'see_button
        '
        Me.see_button.Location = New System.Drawing.Point(705, 17)
        Me.see_button.Name = "see_button"
        Me.see_button.Size = New System.Drawing.Size(112, 26)
        Me.see_button.TabIndex = 27
        Me.see_button.Text = "�˾��̸�����"
        Me.see_button.UseVisualStyleBackColor = True
        '
        'beg_button
        '
        Me.beg_button.Location = New System.Drawing.Point(624, 17)
        Me.beg_button.Name = "beg_button"
        Me.beg_button.Size = New System.Drawing.Size(73, 26)
        Me.beg_button.TabIndex = 26
        Me.beg_button.Text = "�ʱ�ȭ"
        Me.beg_button.UseVisualStyleBackColor = True
        '
        'del_button
        '
        Me.del_button.Location = New System.Drawing.Point(549, 17)
        Me.del_button.Name = "del_button"
        Me.del_button.Size = New System.Drawing.Size(68, 26)
        Me.del_button.TabIndex = 25
        Me.del_button.Text = "����"
        Me.del_button.UseVisualStyleBackColor = True
        '
        'mod_button
        '
        Me.mod_button.Location = New System.Drawing.Point(470, 17)
        Me.mod_button.Name = "mod_button"
        Me.mod_button.Size = New System.Drawing.Size(72, 26)
        Me.mod_button.TabIndex = 24
        Me.mod_button.Text = "����"
        Me.mod_button.UseVisualStyleBackColor = True
        '
        'sub_button
        '
        Me.sub_button.Location = New System.Drawing.Point(387, 17)
        Me.sub_button.Name = "sub_button"
        Me.sub_button.Size = New System.Drawing.Size(76, 26)
        Me.sub_button.TabIndex = 23
        Me.sub_button.Text = "���"
        Me.sub_button.UseVisualStyleBackColor = True
        '
        'sear_button
        '
        Me.sear_button.Location = New System.Drawing.Point(308, 17)
        Me.sear_button.Name = "sear_button"
        Me.sear_button.Size = New System.Drawing.Size(72, 26)
        Me.sear_button.TabIndex = 22
        Me.sear_button.Text = "��ȸ"
        Me.sear_button.UseVisualStyleBackColor = True
        '
        'apply_Txt
        '
        Me.apply_Txt.AcceptsReturn = True
        Me.apply_Txt.BackColor = System.Drawing.SystemColors.Window
        Me.apply_Txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.apply_Txt.ForeColor = System.Drawing.SystemColors.WindowText
        Me.apply_Txt.Location = New System.Drawing.Point(245, 13)
        Me.apply_Txt.MaxLength = 0
        Me.apply_Txt.Name = "apply_Txt"
        Me.apply_Txt.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.apply_Txt.Size = New System.Drawing.Size(55, 21)
        Me.apply_Txt.TabIndex = 6
        '
        'Code_Txt
        '
        Me.Code_Txt.AcceptsReturn = True
        Me.Code_Txt.BackColor = System.Drawing.SystemColors.Window
        Me.Code_Txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Code_Txt.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Code_Txt.Location = New System.Drawing.Point(59, 14)
        Me.Code_Txt.MaxLength = 0
        Me.Code_Txt.Name = "Code_Txt"
        Me.Code_Txt.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Code_Txt.Size = New System.Drawing.Size(96, 21)
        Me.Code_Txt.TabIndex = 4
        '
        'txtFromDate
        '
        Me.txtFromDate.AllowPromptAsInput = False
        Me.txtFromDate.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtFromDate.Location = New System.Drawing.Point(82, 41)
        Me.txtFromDate.Mask = "####-##-##"
        Me.txtFromDate.Name = "txtFromDate"
        Me.txtFromDate.Size = New System.Drawing.Size(94, 21)
        Me.txtFromDate.TabIndex = 9
        Me.txtFromDate.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        'txtToDate
        '
        Me.txtToDate.AllowPromptAsInput = False
        Me.txtToDate.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtToDate.Location = New System.Drawing.Point(204, 40)
        Me.txtToDate.Mask = "####-##-##"
        Me.txtToDate.Name = "txtToDate"
        Me.txtToDate.Size = New System.Drawing.Size(94, 21)
        Me.txtToDate.TabIndex = 10
        Me.txtToDate.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(330, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(420, 16)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "���뿩��   Y: �˾�����     N:�˾�,����Ʈ������     F:����Ʈ����"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(184, 44)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(20, 16)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "~"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(13, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(77, 18)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "����Ⱓ:"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(164, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(73, 18)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "���뿩��:"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(13, 18)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(44, 18)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Code:"
        '
        'frmPopupManage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1087, 558)
        Me.Controls.Add(Me.Frame2)
        Me.Controls.Add(Me.Frame1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 30)
        Me.Name = "frmPopupManage"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "�˾�����(frmPopupManage)"
        Me.Frame2.ResumeLayout(False)
        Me.Frame2.PerformLayout()
        CType(Me.sp_pop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sp_pop_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents sp_pop As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sp_pop_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents del_button As System.Windows.Forms.Button
    Friend WithEvents mod_button As System.Windows.Forms.Button
    Friend WithEvents sub_button As System.Windows.Forms.Button
    Friend WithEvents sear_button As System.Windows.Forms.Button
    Friend WithEvents can_button As System.Windows.Forms.Button
    Friend WithEvents see_button_1 As System.Windows.Forms.Button
    Friend WithEvents see_button As System.Windows.Forms.Button
    Friend WithEvents beg_button As System.Windows.Forms.Button
#End Region 
End Class