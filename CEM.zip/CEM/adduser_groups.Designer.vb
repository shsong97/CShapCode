<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_UserAddGroup
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents lstSelectGroup As System.Windows.Forms.ListBox
	Public WithEvents lstGroup As System.Windows.Forms.ListBox
    Public WithEvents lblSelectGroup As System.Windows.Forms.Label
	Public WithEvents lblGroup As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents lblNameKorP As System.Windows.Forms.Label
	Public WithEvents lblUserIDP As System.Windows.Forms.Label
	Public WithEvents lblNameKor As System.Windows.Forms.Label
	Public WithEvents lblUserID As System.Windows.Forms.Label
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_UserAddGroup))
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.cmdDelete = New System.Windows.Forms.Button
        Me.cmdAppend = New System.Windows.Forms.Button
        Me.lstSelectGroup = New System.Windows.Forms.ListBox
        Me.lstGroup = New System.Windows.Forms.ListBox
        Me.lblSelectGroup = New System.Windows.Forms.Label
        Me.lblGroup = New System.Windows.Forms.Label
        Me.lblNameKorP = New System.Windows.Forms.Label
        Me.lblUserIDP = New System.Windows.Forms.Label
        Me.lblNameKor = New System.Windows.Forms.Label
        Me.lblUserID = New System.Windows.Forms.Label
        Me.cmdOk = New System.Windows.Forms.Button
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cmdDelete)
        Me.Frame1.Controls.Add(Me.cmdAppend)
        Me.Frame1.Controls.Add(Me.lstSelectGroup)
        Me.Frame1.Controls.Add(Me.lstGroup)
        Me.Frame1.Controls.Add(Me.lblSelectGroup)
        Me.Frame1.Controls.Add(Me.lblGroup)
        Me.Frame1.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(12, 96)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(409, 173)
        Me.Frame1.TabIndex = 10
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "�׷� ����"
        '
        'cmdDelete
        '
        Me.cmdDelete.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cmdDelete.Location = New System.Drawing.Point(176, 104)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(57, 33)
        Me.cmdDelete.TabIndex = 14
        Me.cmdDelete.Text = "����"
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'cmdAppend
        '
        Me.cmdAppend.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cmdAppend.Location = New System.Drawing.Point(176, 65)
        Me.cmdAppend.Name = "cmdAppend"
        Me.cmdAppend.Size = New System.Drawing.Size(57, 33)
        Me.cmdAppend.TabIndex = 13
        Me.cmdAppend.Text = "�߰�"
        Me.cmdAppend.UseVisualStyleBackColor = True
        '
        'lstSelectGroup
        '
        Me.lstSelectGroup.BackColor = System.Drawing.Color.White
        Me.lstSelectGroup.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstSelectGroup.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lstSelectGroup.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstSelectGroup.ItemHeight = 12
        Me.lstSelectGroup.Location = New System.Drawing.Point(248, 48)
        Me.lstSelectGroup.Name = "lstSelectGroup"
        Me.lstSelectGroup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstSelectGroup.Size = New System.Drawing.Size(153, 112)
        Me.lstSelectGroup.Sorted = True
        Me.lstSelectGroup.TabIndex = 3
        '
        'lstGroup
        '
        Me.lstGroup.BackColor = System.Drawing.Color.White
        Me.lstGroup.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstGroup.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lstGroup.ForeColor = System.Drawing.Color.Black
        Me.lstGroup.ItemHeight = 12
        Me.lstGroup.Location = New System.Drawing.Point(12, 48)
        Me.lstGroup.Name = "lstGroup"
        Me.lstGroup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstGroup.Size = New System.Drawing.Size(153, 112)
        Me.lstGroup.Sorted = True
        Me.lstGroup.TabIndex = 0
        '
        'lblSelectGroup
        '
        Me.lblSelectGroup.BackColor = System.Drawing.SystemColors.Control
        Me.lblSelectGroup.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblSelectGroup.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblSelectGroup.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblSelectGroup.Location = New System.Drawing.Point(248, 24)
        Me.lblSelectGroup.Name = "lblSelectGroup"
        Me.lblSelectGroup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblSelectGroup.Size = New System.Drawing.Size(153, 17)
        Me.lblSelectGroup.TabIndex = 12
        Me.lblSelectGroup.Text = "���õ� �׷�"
        '
        'lblGroup
        '
        Me.lblGroup.BackColor = System.Drawing.SystemColors.Control
        Me.lblGroup.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblGroup.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroup.Location = New System.Drawing.Point(12, 24)
        Me.lblGroup.Name = "lblGroup"
        Me.lblGroup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup.Size = New System.Drawing.Size(153, 17)
        Me.lblGroup.TabIndex = 11
        Me.lblGroup.Text = "�׷��"
        '
        'lblNameKorP
        '
        Me.lblNameKorP.BackColor = System.Drawing.Color.White
        Me.lblNameKorP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNameKorP.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblNameKorP.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblNameKorP.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblNameKorP.Location = New System.Drawing.Point(100, 48)
        Me.lblNameKorP.Name = "lblNameKorP"
        Me.lblNameKorP.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblNameKorP.Size = New System.Drawing.Size(145, 25)
        Me.lblNameKorP.TabIndex = 9
        '
        'lblUserIDP
        '
        Me.lblUserIDP.BackColor = System.Drawing.Color.White
        Me.lblUserIDP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUserIDP.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUserIDP.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblUserIDP.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUserIDP.Location = New System.Drawing.Point(100, 16)
        Me.lblUserIDP.Name = "lblUserIDP"
        Me.lblUserIDP.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUserIDP.Size = New System.Drawing.Size(145, 25)
        Me.lblUserIDP.TabIndex = 8
        '
        'lblNameKor
        '
        Me.lblNameKor.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblNameKor.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblNameKor.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblNameKor.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblNameKor.Location = New System.Drawing.Point(24, 52)
        Me.lblNameKor.Name = "lblNameKor"
        Me.lblNameKor.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblNameKor.Size = New System.Drawing.Size(73, 25)
        Me.lblNameKor.TabIndex = 7
        Me.lblNameKor.Text = "����(�ѱ�)"
        '
        'lblUserID
        '
        Me.lblUserID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblUserID.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUserID.Font = New System.Drawing.Font("����ü", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblUserID.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUserID.Location = New System.Drawing.Point(24, 16)
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUserID.Size = New System.Drawing.Size(77, 25)
        Me.lblUserID.TabIndex = 6
        Me.lblUserID.Text = "����� ID"
        '
        'cmdOk
        '
        Me.cmdOk.Location = New System.Drawing.Point(304, 16)
        Me.cmdOk.Name = "cmdOk"
        Me.cmdOk.Size = New System.Drawing.Size(114, 29)
        Me.cmdOk.TabIndex = 11
        Me.cmdOk.Text = "���"
        Me.cmdOk.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(304, 48)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(114, 29)
        Me.cmdCancel.TabIndex = 12
        Me.cmdCancel.Text = "���"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'frm_UserAddGroup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(435, 283)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOk)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.lblNameKorP)
        Me.Controls.Add(Me.lblUserIDP)
        Me.Controls.Add(Me.lblNameKor)
        Me.Controls.Add(Me.lblUserID)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(140, 144)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_UserAddGroup"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "����� �׷� ���� ( frm_UserAddGroup )"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents cmdAppend As System.Windows.Forms.Button
    Friend WithEvents cmdOk As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
#End Region 
End Class