<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmHistoryUser
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents cmdSearchInfo As System.Windows.Forms.Button
	Public WithEvents cmdInquery As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents txtUserId As System.Windows.Forms.TextBox
	Public WithEvents chkFlag As System.Windows.Forms.CheckBox
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
	'����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
	'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
	'�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmHistoryUser))
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.cmdSearchInfo = New System.Windows.Forms.Button
        Me.cmdInquery = New System.Windows.Forms.Button
        Me.cmdClose = New System.Windows.Forms.Button
        Me.txtUserId = New System.Windows.Forms.TextBox
        Me.chkFlag = New System.Windows.Forms.CheckBox
        Me.sprSpread = New FarPoint.Win.Spread.FpSpread
        Me.sprSpread_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.StatusBar1.SuspendLayout()
        Me.frmButton.SuspendLayout()
        CType(Me.sprSpread, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSpread_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusBar1
        '
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 414)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(687, 22)
        Me.StatusBar1.TabIndex = 6
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = False
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(963, 17)
        Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.cmdSearchInfo)
        Me.frmButton.Controls.Add(Me.cmdInquery)
        Me.frmButton.Controls.Add(Me.cmdClose)
        Me.frmButton.Controls.Add(Me.txtUserId)
        Me.frmButton.Controls.Add(Me.chkFlag)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(0, 0)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(641, 49)
        Me.frmButton.TabIndex = 1
        Me.frmButton.TabStop = False
        '
        'cmdSearchInfo
        '
        Me.cmdSearchInfo.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearchInfo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSearchInfo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSearchInfo.Image = CType(resources.GetObject("cmdSearchInfo.Image"), System.Drawing.Image)
        Me.cmdSearchInfo.Location = New System.Drawing.Point(224, 16)
        Me.cmdSearchInfo.Name = "cmdSearchInfo"
        Me.cmdSearchInfo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSearchInfo.Size = New System.Drawing.Size(23, 20)
        Me.cmdSearchInfo.TabIndex = 7
        Me.cmdSearchInfo.Text = "?"
        Me.cmdSearchInfo.UseVisualStyleBackColor = False
        '
        'cmdInquery
        '
        Me.cmdInquery.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInquery.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInquery.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInquery.Location = New System.Drawing.Point(406, 16)
        Me.cmdInquery.Name = "cmdInquery"
        Me.cmdInquery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInquery.Size = New System.Drawing.Size(65, 25)
        Me.cmdInquery.TabIndex = 5
        Me.cmdInquery.Text = "��ȸ"
        Me.cmdInquery.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(477, 16)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(65, 25)
        Me.cmdClose.TabIndex = 4
        Me.cmdClose.Text = "����"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'txtUserId
        '
        Me.txtUserId.AcceptsReturn = True
        Me.txtUserId.BackColor = System.Drawing.SystemColors.Window
        Me.txtUserId.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUserId.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUserId.Location = New System.Drawing.Point(112, 16)
        Me.txtUserId.MaxLength = 0
        Me.txtUserId.Name = "txtUserId"
        Me.txtUserId.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUserId.Size = New System.Drawing.Size(105, 20)
        Me.txtUserId.TabIndex = 3
        '
        'chkFlag
        '
        Me.chkFlag.BackColor = System.Drawing.SystemColors.Control
        Me.chkFlag.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkFlag.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkFlag.Location = New System.Drawing.Point(16, 16)
        Me.chkFlag.Name = "chkFlag"
        Me.chkFlag.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkFlag.Size = New System.Drawing.Size(73, 17)
        Me.chkFlag.TabIndex = 2
        Me.chkFlag.Text = "��ü Log"
        Me.chkFlag.UseVisualStyleBackColor = False
        '
        'sprSpread
        '
        Me.sprSpread.AccessibleDescription = ""
        Me.sprSpread.Location = New System.Drawing.Point(0, 55)
        Me.sprSpread.Name = "sprSpread"
        Me.sprSpread.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSpread_Sheet1})
        Me.sprSpread.Size = New System.Drawing.Size(675, 356)
        Me.sprSpread.TabIndex = 7
        '
        'sprSpread_Sheet1
        '
        Me.sprSpread_Sheet1.Reset()
        Me.sprSpread_Sheet1.SheetName = "Sheet1"
        '
        'frmHistoryUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(687, 436)
        Me.Controls.Add(Me.sprSpread)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.frmButton)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(200, 247)
        Me.Name = "frmHistoryUser"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "����� �̷� ��ȸ ( frmHistoryUser )"
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        Me.frmButton.ResumeLayout(False)
        Me.frmButton.PerformLayout()
        CType(Me.sprSpread, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSpread_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents sprSpread As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSpread_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class