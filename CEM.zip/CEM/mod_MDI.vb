Option Strict Off
Option Explicit On
Module mod_MDI

    Public gb_NotMSG As Boolean
	
	Public Function gF_FormChk(ByRef pform As String) As String
		
		Dim er As System.Windows.Forms.Form
		
		gF_FormChk = "N"
        For Each er In My.Application.OpenForms
            If er.Name = pform Then
                gF_FormChk = "Y"
                Exit Function
            End If
        Next er
		
	End Function
	
	Public Sub g_FormShow(ByRef ar_Frm As System.Windows.Forms.Form)
		
		ar_Frm.Show()
        g_MenuControl(2)
		
		If gF_FormChk((ar_Frm.Name)) = "Y" Then
			ar_Frm.BringToFront()
		End If
		
	End Sub
	
	Public Sub g_MenuControl(ByRef ar_Tag As Short)
        Select Case ar_Tag
            Case 1 'cem
                frm_CEM_MDI.mnu_view.Enabled = True
            Case 2 'other
                frm_CEM_MDI.mnu_view.Enabled = False
            Case Else
        End Select
	End Sub
	
End Module