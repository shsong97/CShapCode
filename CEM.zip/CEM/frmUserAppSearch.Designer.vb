<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmUserAppSearch
#Region "Windows Form �����̳ʿ��� ������ �ڵ� "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'�� ȣ���� Windows Form �����̳ʿ� �ʿ��մϴ�.
		InitializeComponent()
		'�� ���� MDI �ڽ��Դϴ�.
		'�� �ڵ�� 
		' �ڵ�����
		' MDI �ڽ��� �θ� �ε��Ͽ� ǥ���ϴ�
		' VB6�� ����� �ùķ��̼��մϴ�.
		Me.MDIParent = CEM.frm_CEM_MDI
		CEM.frm_CEM_MDI.Show
	End Sub
	'Form�� Dispose�� �������Ͽ� ���� ��� ����� �����մϴ�.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows Form �����̳ʿ� �ʿ��մϴ�.
	Private components As System.ComponentModel.IContainer
    Public WithEvents cmdDelete As System.Windows.Forms.Button
    Public WithEvents Option2 As System.Windows.Forms.RadioButton
	Public WithEvents Option1 As System.Windows.Forms.RadioButton
	Public WithEvents Frame3 As System.Windows.Forms.GroupBox
	Public WithEvents cboApp As System.Windows.Forms.ComboBox
	Public WithEvents txtValue As System.Windows.Forms.TextBox
	Public WithEvents CmdClose As System.Windows.Forms.Button
	Public WithEvents CmdQuery As System.Windows.Forms.Button
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents frmButton As System.Windows.Forms.GroupBox
    '����: ���� ���ν����� Windows Form �����̳ʿ� �ʿ��մϴ�.
    'Windows Form �����̳ʸ� ����Ͽ� ������ �� �ֽ��ϴ�.
    '�ڵ� �����⸦ ����Ͽ� �������� ���ʽÿ�.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.frmButton = New System.Windows.Forms.GroupBox
        Me.cmdDelete = New System.Windows.Forms.Button
        Me.Frame3 = New System.Windows.Forms.GroupBox
        Me.Option2 = New System.Windows.Forms.RadioButton
        Me.Option1 = New System.Windows.Forms.RadioButton
        Me.cboApp = New System.Windows.Forms.ComboBox
        Me.txtValue = New System.Windows.Forms.TextBox
        Me.CmdClose = New System.Windows.Forms.Button
        Me.CmdQuery = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.sprSearch = New FarPoint.Win.Spread.FpSpread
        Me.sprSearch_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.frmButton.SuspendLayout()
        Me.Frame3.SuspendLayout()
        CType(Me.sprSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprSearch_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'frmButton
        '
        Me.frmButton.BackColor = System.Drawing.SystemColors.Control
        Me.frmButton.Controls.Add(Me.cmdDelete)
        Me.frmButton.Controls.Add(Me.Frame3)
        Me.frmButton.Controls.Add(Me.cboApp)
        Me.frmButton.Controls.Add(Me.txtValue)
        Me.frmButton.Controls.Add(Me.CmdClose)
        Me.frmButton.Controls.Add(Me.CmdQuery)
        Me.frmButton.Controls.Add(Me.Label1)
        Me.frmButton.Controls.Add(Me.Label4)
        Me.frmButton.Controls.Add(Me.Label3)
        Me.frmButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmButton.Location = New System.Drawing.Point(8, 2)
        Me.frmButton.Name = "frmButton"
        Me.frmButton.Padding = New System.Windows.Forms.Padding(0)
        Me.frmButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmButton.Size = New System.Drawing.Size(865, 83)
        Me.frmButton.TabIndex = 1
        Me.frmButton.TabStop = False
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDelete.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDelete.Location = New System.Drawing.Point(680, 16)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDelete.Size = New System.Drawing.Size(79, 25)
        Me.cmdDelete.TabIndex = 12
        Me.cmdDelete.Text = "����"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.SystemColors.Control
        Me.Frame3.Controls.Add(Me.Option2)
        Me.Frame3.Controls.Add(Me.Option1)
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(48, 14)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(151, 57)
        Me.Frame3.TabIndex = 9
        Me.Frame3.TabStop = False
        Me.Frame3.Text = "�˻�����"
        '
        'Option2
        '
        Me.Option2.BackColor = System.Drawing.SystemColors.Control
        Me.Option2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Option2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Option2.Location = New System.Drawing.Point(20, 34)
        Me.Option2.Name = "Option2"
        Me.Option2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Option2.Size = New System.Drawing.Size(75, 17)
        Me.Option2.TabIndex = 11
        Me.Option2.TabStop = True
        Me.Option2.Text = "Group"
        Me.Option2.UseVisualStyleBackColor = False
        '
        'Option1
        '
        Me.Option1.BackColor = System.Drawing.SystemColors.Control
        Me.Option1.Checked = True
        Me.Option1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Option1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Option1.Location = New System.Drawing.Point(20, 16)
        Me.Option1.Name = "Option1"
        Me.Option1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Option1.Size = New System.Drawing.Size(97, 15)
        Me.Option1.TabIndex = 10
        Me.Option1.TabStop = True
        Me.Option1.Text = "Application"
        Me.Option1.UseVisualStyleBackColor = False
        '
        'cboApp
        '
        Me.cboApp.BackColor = System.Drawing.SystemColors.Window
        Me.cboApp.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboApp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboApp.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboApp.Location = New System.Drawing.Point(244, 42)
        Me.cboApp.Name = "cboApp"
        Me.cboApp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboApp.Size = New System.Drawing.Size(163, 21)
        Me.cboApp.TabIndex = 7
        '
        'txtValue
        '
        Me.txtValue.AcceptsReturn = True
        Me.txtValue.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtValue.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtValue.Enabled = False
        Me.txtValue.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtValue.Location = New System.Drawing.Point(736, 58)
        Me.txtValue.MaxLength = 0
        Me.txtValue.Name = "txtValue"
        Me.txtValue.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtValue.Size = New System.Drawing.Size(45, 20)
        Me.txtValue.TabIndex = 4
        Me.txtValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CmdClose
        '
        Me.CmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.CmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdClose.Location = New System.Drawing.Point(768, 16)
        Me.CmdClose.Name = "CmdClose"
        Me.CmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdClose.Size = New System.Drawing.Size(79, 25)
        Me.CmdClose.TabIndex = 3
        Me.CmdClose.Text = "����"
        Me.CmdClose.UseVisualStyleBackColor = False
        '
        'CmdQuery
        '
        Me.CmdQuery.BackColor = System.Drawing.SystemColors.Control
        Me.CmdQuery.Cursor = System.Windows.Forms.Cursors.Default
        Me.CmdQuery.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CmdQuery.Location = New System.Drawing.Point(592, 16)
        Me.CmdQuery.Name = "CmdQuery"
        Me.CmdQuery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CmdQuery.Size = New System.Drawing.Size(79, 25)
        Me.CmdQuery.TabIndex = 2
        Me.CmdQuery.Text = "��ȸ"
        Me.CmdQuery.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(246, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Lable1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(674, 62)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "��ȸ�Ǽ� :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(782, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(19, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "��"
        '
        'sprSearch
        '
        Me.sprSearch.AccessibleDescription = ""
        Me.sprSearch.Location = New System.Drawing.Point(8, 91)
        Me.sprSearch.Name = "sprSearch"
        Me.sprSearch.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprSearch_Sheet1})
        Me.sprSearch.Size = New System.Drawing.Size(949, 447)
        Me.sprSearch.TabIndex = 2
        '
        'sprSearch_Sheet1
        '
        Me.sprSearch_Sheet1.Reset()
        Me.sprSearch_Sheet1.SheetName = "Sheet1"
        '
        'frmUserAppSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(969, 550)
        Me.Controls.Add(Me.sprSearch)
        Me.Controls.Add(Me.frmButton)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(22, 122)
        Me.Name = "frmUserAppSearch"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "�׷캰 ����� ���� ( frmUserAppSearch )"
        Me.frmButton.ResumeLayout(False)
        Me.frmButton.PerformLayout()
        Me.Frame3.ResumeLayout(False)
        CType(Me.sprSearch, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprSearch_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents sprSearch As FarPoint.Win.Spread.FpSpread
    Friend WithEvents sprSearch_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region 
End Class