﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace utf_convert
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                System.Console.WriteLine("사용법 : utf_convert.exe 원본파일 변환파일");
                return;
            }
            string oldfilename = args[0];
            string newfilename = args[1];

            StreamReader sr = new StreamReader(oldfilename, System.Text.Encoding.Default);
            string strSrcTxt = sr.ReadToEnd() ;
			sr.Close();

            var utf8WithoutBom = new System.Text.UTF8Encoding(false);
            StreamWriter sw = new StreamWriter(newfilename, false, utf8WithoutBom);
			sw.Write (strSrcTxt.Substring(0,strSrcTxt.Length-2));
			sw.Flush();
			sw.Close();

        }
    }
}
