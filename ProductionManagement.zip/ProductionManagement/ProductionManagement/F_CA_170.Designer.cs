﻿namespace ProductionManagement
{
    partial class F_CA_170
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtGlobal_no = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboProduct = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtProdNo = new System.Windows.Forms.TextBox();
            this.txtBriefTrade = new System.Windows.Forms.TextBox();
            this.txtCostModel = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtModel_type = new System.Windows.Forms.TextBox();
            this.txtEquip_count = new System.Windows.Forms.TextBox();
            this.txtGaijung = new System.Windows.Forms.TextBox();
            this.txtMarket = new System.Windows.Forms.TextBox();
            this.mskSpec_rslt_date = new System.Windows.Forms.MaskedTextBox();
            this.mskGo1_date = new System.Windows.Forms.MaskedTextBox();
            this.mskGo2_date = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtSale_emp_name = new System.Windows.Forms.TextBox();
            this.txtCountry_name = new System.Windows.Forms.TextBox();
            this.txtRemark_f1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtInstAddress = new System.Windows.Forms.TextBox();
            this.mskMain_due_date = new System.Windows.Forms.MaskedTextBox();
            this.mskContDate = new System.Windows.Forms.MaskedTextBox();
            this.mskRecvDate = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(474, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Global_Unit:";
            // 
            // txtGlobal_no
            // 
            this.txtGlobal_no.Location = new System.Drawing.Point(556, 7);
            this.txtGlobal_no.Name = "txtGlobal_no";
            this.txtGlobal_no.Size = new System.Drawing.Size(91, 21);
            this.txtGlobal_no.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(226, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "제품";
            // 
            // cboProduct
            // 
            this.cboProduct.FormattingEnabled = true;
            this.cboProduct.Location = new System.Drawing.Point(269, 8);
            this.cboProduct.Name = "cboProduct";
            this.cboProduct.Size = new System.Drawing.Size(185, 20);
            this.cboProduct.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "제   번";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "고객명";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(269, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "원가모델";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "계약일";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 115);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 10;
            this.label8.Text = "접수일";
            // 
            // txtProdNo
            // 
            this.txtProdNo.Location = new System.Drawing.Point(75, 10);
            this.txtProdNo.Name = "txtProdNo";
            this.txtProdNo.Size = new System.Drawing.Size(131, 21);
            this.txtProdNo.TabIndex = 11;
            this.txtProdNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProdNo_KeyPress);
            // 
            // txtBriefTrade
            // 
            this.txtBriefTrade.Location = new System.Drawing.Point(76, 59);
            this.txtBriefTrade.Name = "txtBriefTrade";
            this.txtBriefTrade.Size = new System.Drawing.Size(186, 21);
            this.txtBriefTrade.TabIndex = 12;
            // 
            // txtCostModel
            // 
            this.txtCostModel.Location = new System.Drawing.Point(341, 59);
            this.txtCostModel.Name = "txtCostModel";
            this.txtCostModel.Size = new System.Drawing.Size(129, 21);
            this.txtCostModel.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 19;
            this.label9.Text = "모델";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(269, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 20;
            this.label10.Text = "대수";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(379, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 21;
            this.label11.Text = "계정";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(479, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 22;
            this.label12.Text = "시장";
            // 
            // txtModel_type
            // 
            this.txtModel_type.Location = new System.Drawing.Point(75, 35);
            this.txtModel_type.Name = "txtModel_type";
            this.txtModel_type.Size = new System.Drawing.Size(187, 21);
            this.txtModel_type.TabIndex = 23;
            // 
            // txtEquip_count
            // 
            this.txtEquip_count.Location = new System.Drawing.Point(313, 35);
            this.txtEquip_count.Name = "txtEquip_count";
            this.txtEquip_count.Size = new System.Drawing.Size(59, 21);
            this.txtEquip_count.TabIndex = 24;
            // 
            // txtGaijung
            // 
            this.txtGaijung.Location = new System.Drawing.Point(422, 35);
            this.txtGaijung.Name = "txtGaijung";
            this.txtGaijung.Size = new System.Drawing.Size(49, 21);
            this.txtGaijung.TabIndex = 25;
            // 
            // txtMarket
            // 
            this.txtMarket.Location = new System.Drawing.Point(523, 35);
            this.txtMarket.Name = "txtMarket";
            this.txtMarket.Size = new System.Drawing.Size(61, 21);
            this.txtMarket.TabIndex = 26;
            // 
            // mskSpec_rslt_date
            // 
            this.mskSpec_rslt_date.Location = new System.Drawing.Point(502, 86);
            this.mskSpec_rslt_date.Mask = "####-##-##";
            this.mskSpec_rslt_date.Name = "mskSpec_rslt_date";
            this.mskSpec_rslt_date.Size = new System.Drawing.Size(74, 21);
            this.mskSpec_rslt_date.TabIndex = 27;
            // 
            // mskGo1_date
            // 
            this.mskGo1_date.Location = new System.Drawing.Point(341, 109);
            this.mskGo1_date.Mask = "####-##-##";
            this.mskGo1_date.Name = "mskGo1_date";
            this.mskGo1_date.Size = new System.Drawing.Size(70, 21);
            this.mskGo1_date.TabIndex = 28;
            // 
            // mskGo2_date
            // 
            this.mskGo2_date.Location = new System.Drawing.Point(502, 110);
            this.mskGo2_date.Mask = "####-##-##";
            this.mskGo2_date.Name = "mskGo2_date";
            this.mskGo2_date.Size = new System.Drawing.Size(74, 21);
            this.mskGo2_date.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(269, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 30;
            this.label1.Text = "본체납기";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 149);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 31;
            this.label13.Text = "영업부서";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(181, 149);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 12);
            this.label14.TabIndex = 32;
            this.label14.Text = "국가명";
            // 
            // txtSale_emp_name
            // 
            this.txtSale_emp_name.Location = new System.Drawing.Point(76, 146);
            this.txtSale_emp_name.Name = "txtSale_emp_name";
            this.txtSale_emp_name.Size = new System.Drawing.Size(70, 21);
            this.txtSale_emp_name.TabIndex = 34;
            // 
            // txtCountry_name
            // 
            this.txtCountry_name.Location = new System.Drawing.Point(238, 146);
            this.txtCountry_name.Name = "txtCountry_name";
            this.txtCountry_name.Size = new System.Drawing.Size(156, 21);
            this.txtCountry_name.TabIndex = 35;
            // 
            // txtRemark_f1
            // 
            this.txtRemark_f1.Location = new System.Drawing.Point(76, 196);
            this.txtRemark_f1.Name = "txtRemark_f1";
            this.txtRemark_f1.Size = new System.Drawing.Size(605, 21);
            this.txtRemark_f1.TabIndex = 36;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 198);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 37;
            this.label15.Text = "비고";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(429, 89);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 12);
            this.label16.TabIndex = 38;
            this.label16.Text = "Spec확정";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(269, 115);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 12);
            this.label17.TabIndex = 39;
            this.label17.Text = "1차Go";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(429, 115);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 12);
            this.label18.TabIndex = 40;
            this.label18.Text = "2차Go";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(14, 174);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 41;
            this.label19.Text = "설치장소";
            // 
            // txtInstAddress
            // 
            this.txtInstAddress.Location = new System.Drawing.Point(76, 172);
            this.txtInstAddress.Name = "txtInstAddress";
            this.txtInstAddress.Size = new System.Drawing.Size(318, 21);
            this.txtInstAddress.TabIndex = 42;
            // 
            // mskMain_due_date
            // 
            this.mskMain_due_date.Location = new System.Drawing.Point(341, 86);
            this.mskMain_due_date.Mask = "####-##-##";
            this.mskMain_due_date.Name = "mskMain_due_date";
            this.mskMain_due_date.Size = new System.Drawing.Size(70, 21);
            this.mskMain_due_date.TabIndex = 43;
            // 
            // mskContDate
            // 
            this.mskContDate.Location = new System.Drawing.Point(76, 89);
            this.mskContDate.Mask = "####-##-##";
            this.mskContDate.Name = "mskContDate";
            this.mskContDate.Size = new System.Drawing.Size(70, 21);
            this.mskContDate.TabIndex = 44;
            // 
            // mskRecvDate
            // 
            this.mskRecvDate.Location = new System.Drawing.Point(77, 114);
            this.mskRecvDate.Mask = "####-##-##";
            this.mskRecvDate.Name = "mskRecvDate";
            this.mskRecvDate.Size = new System.Drawing.Size(69, 21);
            this.mskRecvDate.TabIndex = 45;
            // 
            // F_CA_170
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 225);
            this.Controls.Add(this.mskRecvDate);
            this.Controls.Add(this.mskContDate);
            this.Controls.Add(this.mskMain_due_date);
            this.Controls.Add(this.txtInstAddress);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtRemark_f1);
            this.Controls.Add(this.txtCountry_name);
            this.Controls.Add(this.txtSale_emp_name);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mskGo2_date);
            this.Controls.Add(this.mskGo1_date);
            this.Controls.Add(this.mskSpec_rslt_date);
            this.Controls.Add(this.txtMarket);
            this.Controls.Add(this.txtGaijung);
            this.Controls.Add(this.txtEquip_count);
            this.Controls.Add(this.txtModel_type);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtCostModel);
            this.Controls.Add(this.txtBriefTrade);
            this.Controls.Add(this.txtProdNo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cboProduct);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtGlobal_no);
            this.Controls.Add(this.label2);
            this.Name = "F_CA_170";
            this.Text = "제번대장 등록(F_CA_170)";
            this.Load += new System.EventHandler(this.F_CA_170_Load);
            this.Activated += new System.EventHandler(this.F_CA_170_Activated);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtGlobal_no;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboProduct;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtProdNo;
        private System.Windows.Forms.TextBox txtBriefTrade;
        private System.Windows.Forms.TextBox txtCostModel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtModel_type;
        private System.Windows.Forms.TextBox txtEquip_count;
        private System.Windows.Forms.TextBox txtGaijung;
        private System.Windows.Forms.TextBox txtMarket;
        private System.Windows.Forms.MaskedTextBox mskSpec_rslt_date;
        private System.Windows.Forms.MaskedTextBox mskGo1_date;
        private System.Windows.Forms.MaskedTextBox mskGo2_date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtSale_emp_name;
        private System.Windows.Forms.TextBox txtCountry_name;
        private System.Windows.Forms.TextBox txtRemark_f1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtInstAddress;
        private System.Windows.Forms.MaskedTextBox mskMain_due_date;
        private System.Windows.Forms.MaskedTextBox mskContDate;
        private System.Windows.Forms.MaskedTextBox mskRecvDate;
    }
}