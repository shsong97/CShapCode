﻿namespace ProductionManagement
{
    partial class F_HELP_ProdNo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboSort = new System.Windows.Forms.ComboBox();
            this.txtProd_no = new System.Windows.Forms.TextBox();
            this.fpSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lab_cnt = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // cboSort
            // 
            this.cboSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSort.FormattingEnabled = true;
            this.cboSort.Items.AddRange(new object[] {
            "Project           A",
            "납선명            B"});
            this.cboSort.Location = new System.Drawing.Point(3, 11);
            this.cboSort.Name = "cboSort";
            this.cboSort.Size = new System.Drawing.Size(132, 21);
            this.cboSort.TabIndex = 0;
            // 
            // txtProd_no
            // 
            this.txtProd_no.Location = new System.Drawing.Point(141, 13);
            this.txtProd_no.Name = "txtProd_no";
            this.txtProd_no.Size = new System.Drawing.Size(143, 20);
            this.txtProd_no.TabIndex = 1;
            // 
            // fpSpread1
            // 
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpread1.Location = new System.Drawing.Point(3, 39);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(648, 244);
            this.fpSpread1.TabIndex = 2;
            this.fpSpread1.CellDoubleClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpread1_CellDoubleClick);
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 6;
            this.fpSpread1_Sheet1.RowCount = 20;
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "제번";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "고객명";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Model Type";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Market";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Count";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Global UnitNo";
            this.fpSpread1_Sheet1.Columns.Get(0).Label = "제번";
            this.fpSpread1_Sheet1.Columns.Get(0).Locked = true;
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 86F;
            this.fpSpread1_Sheet1.Columns.Get(1).Label = "고객명";
            this.fpSpread1_Sheet1.Columns.Get(1).Locked = true;
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 165F;
            this.fpSpread1_Sheet1.Columns.Get(2).Label = "Model Type";
            this.fpSpread1_Sheet1.Columns.Get(2).Locked = true;
            this.fpSpread1_Sheet1.Columns.Get(2).Width = 138F;
            this.fpSpread1_Sheet1.Columns.Get(3).Label = "Market";
            this.fpSpread1_Sheet1.Columns.Get(3).Locked = true;
            this.fpSpread1_Sheet1.Columns.Get(3).Width = 45F;
            this.fpSpread1_Sheet1.Columns.Get(4).Label = "Count";
            this.fpSpread1_Sheet1.Columns.Get(4).Locked = true;
            this.fpSpread1_Sheet1.Columns.Get(4).Width = 48F;
            this.fpSpread1_Sheet1.Columns.Get(5).Label = "Global UnitNo";
            this.fpSpread1_Sheet1.Columns.Get(5).Locked = true;
            this.fpSpread1_Sheet1.Columns.Get(5).Width = 110F;
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(290, 11);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(65, 22);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 290);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "검색건수 : ";
            // 
            // lab_cnt
            // 
            this.lab_cnt.AutoSize = true;
            this.lab_cnt.Location = new System.Drawing.Point(69, 290);
            this.lab_cnt.Name = "lab_cnt";
            this.lab_cnt.Size = new System.Drawing.Size(13, 13);
            this.lab_cnt.TabIndex = 5;
            this.lab_cnt.Text = "0";
            // 
            // F_HELP_ProdNo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 314);
            this.Controls.Add(this.lab_cnt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.fpSpread1);
            this.Controls.Add(this.txtProd_no);
            this.Controls.Add(this.cboSort);
            this.Name = "F_HELP_ProdNo";
            this.Text = "F_HELP_ProdNo";
            this.Load += new System.EventHandler(this.F_HELP_ProdNo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboSort;
        private System.Windows.Forms.TextBox txtProd_no;
        private FarPoint.Win.Spread.FpSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lab_cnt;
    }
}