﻿
    partial class frm_App
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDomain = new System.Windows.Forms.Label();
            this.lblApp_program = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblDomain
            // 
            this.lblDomain.AutoSize = true;
            this.lblDomain.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblDomain.Location = new System.Drawing.Point(48, 27);
            this.lblDomain.Name = "lblDomain";
            this.lblDomain.Size = new System.Drawing.Size(109, 19);
            this.lblDomain.TabIndex = 0;
            this.lblDomain.Text = "생산시스템";
            // 
            // lblApp_program
            // 
            this.lblApp_program.AutoSize = true;
            this.lblApp_program.Font = new System.Drawing.Font("굴림체", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblApp_program.Location = new System.Drawing.Point(23, 86);
            this.lblApp_program.Name = "lblApp_program";
            this.lblApp_program.Size = new System.Drawing.Size(85, 24);
            this.lblApp_program.TabIndex = 1;
            this.lblApp_program.Text = "제품명";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("굴림체", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblVersion.Location = new System.Drawing.Point(24, 137);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(215, 16);
            this.lblVersion.TabIndex = 2;
            this.lblVersion.Text = "-----------------------";
            // 
            // frm_App
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 296);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.lblApp_program);
            this.Controls.Add(this.lblDomain);
            this.Name = "frm_App";
            this.Text = "Upgrade 중입니다...";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frm_App_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblDomain;
        public System.Windows.Forms.Label lblApp_program;
        public System.Windows.Forms.Label lblVersion;

    }
