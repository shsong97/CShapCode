﻿namespace ProductionManagement
{
    partial class F_EA_040
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType2 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.ComboBoxCellType comboBoxCellType1 = new FarPoint.Win.Spread.CellType.ComboBoxCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.ComplexBorder complexBorder1 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder2 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder3 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder4 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder5 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder6 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder7 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder8 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder9 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder10 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder11 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder12 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder13 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder14 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder15 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder16 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder17 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder18 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            this.label1 = new System.Windows.Forms.Label();
            this.txtProd_no = new System.Windows.Forms.TextBox();
            this.cmdProjectSearch = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPart4 = new System.Windows.Forms.TextBox();
            this.txtPart3 = new System.Windows.Forms.TextBox();
            this.txtPart2 = new System.Windows.Forms.TextBox();
            this.txtPart1 = new System.Windows.Forms.TextBox();
            this.txtPart0 = new System.Windows.Forms.TextBox();
            this.sprDesignList = new FarPoint.Win.Spread.FpSpread();
            this.sprDesignList_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.sprHead1 = new FarPoint.Win.Spread.FpSpread();
            this.sprHead1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.sprHead2 = new FarPoint.Win.Spread.FpSpread();
            this.sprHead2_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sprDesignList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprDesignList_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead1_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead2_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "제번:";
            // 
            // txtProd_no
            // 
            this.txtProd_no.Location = new System.Drawing.Point(61, 15);
            this.txtProd_no.MaxLength = 14;
            this.txtProd_no.Name = "txtProd_no";
            this.txtProd_no.Size = new System.Drawing.Size(145, 21);
            this.txtProd_no.TabIndex = 1;
            this.txtProd_no.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProd_no_KeyPress);
            // 
            // cmdProjectSearch
            // 
            this.cmdProjectSearch.Location = new System.Drawing.Point(213, 13);
            this.cmdProjectSearch.Name = "cmdProjectSearch";
            this.cmdProjectSearch.Size = new System.Drawing.Size(44, 21);
            this.cmdProjectSearch.TabIndex = 2;
            this.cmdProjectSearch.Text = "?";
            this.cmdProjectSearch.UseVisualStyleBackColor = true;
            this.cmdProjectSearch.Click += new System.EventHandler(this.cmdProjectSearch_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtPart4);
            this.groupBox1.Controls.Add(this.txtPart3);
            this.groupBox1.Controls.Add(this.txtPart2);
            this.groupBox1.Controls.Add(this.txtPart1);
            this.groupBox1.Controls.Add(this.txtPart0);
            this.groupBox1.Location = new System.Drawing.Point(265, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(251, 38);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Part";
            // 
            // txtPart4
            // 
            this.txtPart4.Location = new System.Drawing.Point(198, 13);
            this.txtPart4.MaxLength = 2;
            this.txtPart4.Name = "txtPart4";
            this.txtPart4.Size = new System.Drawing.Size(40, 21);
            this.txtPart4.TabIndex = 4;
            // 
            // txtPart3
            // 
            this.txtPart3.Location = new System.Drawing.Point(150, 13);
            this.txtPart3.MaxLength = 2;
            this.txtPart3.Name = "txtPart3";
            this.txtPart3.Size = new System.Drawing.Size(40, 21);
            this.txtPart3.TabIndex = 3;
            // 
            // txtPart2
            // 
            this.txtPart2.Location = new System.Drawing.Point(103, 13);
            this.txtPart2.MaxLength = 2;
            this.txtPart2.Name = "txtPart2";
            this.txtPart2.Size = new System.Drawing.Size(40, 21);
            this.txtPart2.TabIndex = 2;
            // 
            // txtPart1
            // 
            this.txtPart1.Location = new System.Drawing.Point(55, 13);
            this.txtPart1.MaxLength = 2;
            this.txtPart1.Name = "txtPart1";
            this.txtPart1.Size = new System.Drawing.Size(40, 21);
            this.txtPart1.TabIndex = 1;
            // 
            // txtPart0
            // 
            this.txtPart0.Location = new System.Drawing.Point(7, 13);
            this.txtPart0.MaxLength = 2;
            this.txtPart0.Name = "txtPart0";
            this.txtPart0.Size = new System.Drawing.Size(40, 21);
            this.txtPart0.TabIndex = 0;
            // 
            // sprDesignList
            // 
            this.sprDesignList.AccessibleDescription = "sprDesignList, Sheet1, Row 0, Column 0, ";
            this.sprDesignList.Location = new System.Drawing.Point(14, 91);
            this.sprDesignList.Name = "sprDesignList";
            this.sprDesignList.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprDesignList_Sheet1});
            this.sprDesignList.Size = new System.Drawing.Size(1246, 414);
            this.sprDesignList.TabIndex = 7;
            // 
            // sprDesignList_Sheet1
            // 
            this.sprDesignList_Sheet1.Reset();
            this.sprDesignList_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprDesignList_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprDesignList_Sheet1.ColumnCount = 19;
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "파트";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "항번";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Item No";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "계획일";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "완료일";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "품명";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "수량";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "조달";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "발송";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "설계";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "특화";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "원인";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 12).Value = "진행";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 13).Value = "발주일";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 14).Value = "발주번호";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 15).Value = "추출일";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 16).Value = "설계파트";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 17).Value = "취부";
            this.sprDesignList_Sheet1.ColumnHeader.Cells.Get(0, 18).Value = "Remark";
            this.sprDesignList_Sheet1.ColumnHeader.Rows.Get(0).Height = 26F;
            this.sprDesignList_Sheet1.Columns.Get(0).CellType = textCellType1;
            this.sprDesignList_Sheet1.Columns.Get(0).Label = "파트";
            this.sprDesignList_Sheet1.Columns.Get(0).Width = 44F;
            this.sprDesignList_Sheet1.Columns.Get(1).CellType = textCellType2;
            this.sprDesignList_Sheet1.Columns.Get(1).Label = "항번";
            this.sprDesignList_Sheet1.Columns.Get(1).Width = 42F;
            this.sprDesignList_Sheet1.Columns.Get(2).Label = "Item No";
            this.sprDesignList_Sheet1.Columns.Get(2).Width = 108F;
            this.sprDesignList_Sheet1.Columns.Get(3).Label = "계획일";
            this.sprDesignList_Sheet1.Columns.Get(3).Width = 62F;
            this.sprDesignList_Sheet1.Columns.Get(5).Label = "품명";
            this.sprDesignList_Sheet1.Columns.Get(5).Width = 132F;
            this.sprDesignList_Sheet1.Columns.Get(6).Label = "수량";
            this.sprDesignList_Sheet1.Columns.Get(6).Width = 50F;
            this.sprDesignList_Sheet1.Columns.Get(7).Label = "조달";
            this.sprDesignList_Sheet1.Columns.Get(7).Width = 36F;
            this.sprDesignList_Sheet1.Columns.Get(8).Label = "발송";
            this.sprDesignList_Sheet1.Columns.Get(8).Width = 31F;
            this.sprDesignList_Sheet1.Columns.Get(9).Label = "설계";
            this.sprDesignList_Sheet1.Columns.Get(9).Width = 34F;
            this.sprDesignList_Sheet1.Columns.Get(10).Label = "특화";
            this.sprDesignList_Sheet1.Columns.Get(10).Width = 34F;
            this.sprDesignList_Sheet1.Columns.Get(11).Label = "원인";
            this.sprDesignList_Sheet1.Columns.Get(11).Width = 38F;
            comboBoxCellType1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            comboBoxCellType1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            comboBoxCellType1.ButtonAlign = FarPoint.Win.ButtonAlign.Right;
            comboBoxCellType1.EditorValue = FarPoint.Win.Spread.CellType.EditorValue.ItemData;
            comboBoxCellType1.ItemData = new string[] {
        "",
        "A",
        "C",
        "E",
        "G",
        "L",
        "N",
        "R"};
            comboBoxCellType1.Items = new string[] {
        "발주계획",
        "발주확정",
        "수입검사대기",
        "자재입고대기",
        "출하요청",
        "제품입고대기",
        "제품입고",
        "출하완료"};
            this.sprDesignList_Sheet1.Columns.Get(12).CellType = comboBoxCellType1;
            this.sprDesignList_Sheet1.Columns.Get(12).Label = "진행";
            this.sprDesignList_Sheet1.Columns.Get(12).Width = 70F;
            this.sprDesignList_Sheet1.Columns.Get(16).CellType = textCellType3;
            this.sprDesignList_Sheet1.Columns.Get(16).Label = "설계파트";
            this.sprDesignList_Sheet1.Columns.Get(16).Width = 41F;
            this.sprDesignList_Sheet1.Columns.Get(17).Label = "취부";
            this.sprDesignList_Sheet1.Columns.Get(17).Width = 28F;
            this.sprDesignList_Sheet1.Columns.Get(18).Label = "Remark";
            this.sprDesignList_Sheet1.Columns.Get(18).Width = 170F;
            this.sprDesignList_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprDesignList_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // sprHead1
            // 
            this.sprHead1.AccessibleDescription = "sprHead1, Sheet1, Row 0, Column 0, 모델";
            this.sprHead1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            this.sprHead1.Location = new System.Drawing.Point(14, 42);
            this.sprHead1.Name = "sprHead1";
            this.sprHead1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprHead1_Sheet1});
            this.sprHead1.Size = new System.Drawing.Size(597, 41);
            this.sprHead1.TabIndex = 8;
            this.sprHead1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            // 
            // sprHead1_Sheet1
            // 
            this.sprHead1_Sheet1.Reset();
            this.sprHead1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprHead1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprHead1_Sheet1.ColumnCount = 6;
            this.sprHead1_Sheet1.RowCount = 2;
            this.sprHead1_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead1_Sheet1.Cells.Get(0, 0).Border = complexBorder1;
            this.sprHead1_Sheet1.Cells.Get(0, 0).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(0, 0).Value = "모델";
            this.sprHead1_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(0, 1).Border = complexBorder2;
            this.sprHead1_Sheet1.Cells.Get(0, 1).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprHead1_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead1_Sheet1.Cells.Get(0, 2).Border = complexBorder3;
            this.sprHead1_Sheet1.Cells.Get(0, 2).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(0, 2).Value = "대수";
            this.sprHead1_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(0, 3).Border = complexBorder4;
            this.sprHead1_Sheet1.Cells.Get(0, 3).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprHead1_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(0, 4).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead1_Sheet1.Cells.Get(0, 4).Border = complexBorder5;
            this.sprHead1_Sheet1.Cells.Get(0, 4).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(0, 4).Value = "계정";
            this.sprHead1_Sheet1.Cells.Get(0, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(0, 5).Border = complexBorder6;
            this.sprHead1_Sheet1.Cells.Get(0, 5).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprHead1_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead1_Sheet1.Cells.Get(1, 0).Border = complexBorder7;
            this.sprHead1_Sheet1.Cells.Get(1, 0).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(1, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 0).Value = "고객명";
            this.sprHead1_Sheet1.Cells.Get(1, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 1).Border = complexBorder8;
            this.sprHead1_Sheet1.Cells.Get(1, 1).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprHead1_Sheet1.Cells.Get(1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead1_Sheet1.Cells.Get(1, 2).Border = complexBorder9;
            this.sprHead1_Sheet1.Cells.Get(1, 2).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 2).Value = "국가";
            this.sprHead1_Sheet1.Cells.Get(1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 3).Border = complexBorder10;
            this.sprHead1_Sheet1.Cells.Get(1, 3).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(1, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprHead1_Sheet1.Cells.Get(1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 4).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead1_Sheet1.Cells.Get(1, 4).Border = complexBorder11;
            this.sprHead1_Sheet1.Cells.Get(1, 4).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(1, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 4).Value = "제품";
            this.sprHead1_Sheet1.Cells.Get(1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.Cells.Get(1, 5).Border = complexBorder12;
            this.sprHead1_Sheet1.Cells.Get(1, 5).Font = new System.Drawing.Font("굴림체", 9F);
            this.sprHead1_Sheet1.Cells.Get(1, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprHead1_Sheet1.Cells.Get(1, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead1_Sheet1.ColumnHeader.Visible = false;
            this.sprHead1_Sheet1.Columns.Get(1).Width = 222F;
            this.sprHead1_Sheet1.Columns.Get(3).Width = 115F;
            this.sprHead1_Sheet1.Columns.Get(5).Width = 68F;
            this.sprHead1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprHead1_Sheet1.RowHeader.Visible = false;
            this.sprHead1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // sprHead2
            // 
            this.sprHead2.AccessibleDescription = "sprHead2, Sheet1, Row 0, Column 0, A";
            this.sprHead2.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            this.sprHead2.Location = new System.Drawing.Point(709, 42);
            this.sprHead2.Name = "sprHead2";
            this.sprHead2.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprHead2_Sheet1});
            this.sprHead2.Size = new System.Drawing.Size(226, 41);
            this.sprHead2.TabIndex = 9;
            this.sprHead2.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            // 
            // sprHead2_Sheet1
            // 
            this.sprHead2_Sheet1.Reset();
            this.sprHead2_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprHead2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprHead2_Sheet1.ColumnCount = 3;
            this.sprHead2_Sheet1.RowCount = 2;
            this.sprHead2_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead2_Sheet1.Cells.Get(0, 0).Border = complexBorder13;
            this.sprHead2_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(0, 0).Value = "A";
            this.sprHead2_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead2_Sheet1.Cells.Get(0, 1).Border = complexBorder14;
            this.sprHead2_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(0, 1).Value = "B";
            this.sprHead2_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sprHead2_Sheet1.Cells.Get(0, 2).Border = complexBorder15;
            this.sprHead2_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(0, 2).Value = "C";
            this.sprHead2_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(1, 0).Border = complexBorder16;
            this.sprHead2_Sheet1.Cells.Get(1, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(1, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(1, 1).Border = complexBorder17;
            this.sprHead2_Sheet1.Cells.Get(1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(1, 2).Border = complexBorder18;
            this.sprHead2_Sheet1.Cells.Get(1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead2_Sheet1.Cells.Get(1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprHead2_Sheet1.ColumnHeader.Visible = false;
            this.sprHead2_Sheet1.Columns.Get(0).Width = 73F;
            this.sprHead2_Sheet1.Columns.Get(1).Width = 69F;
            this.sprHead2_Sheet1.Columns.Get(2).Width = 70F;
            this.sprHead2_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprHead2_Sheet1.RowHeader.Visible = false;
            this.sprHead2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(684, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 18);
            this.button1.TabIndex = 10;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(548, 11);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(116, 21);
            this.textBox1.TabIndex = 11;
            // 
            // F_EA_040
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1275, 509);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.sprHead2);
            this.Controls.Add(this.sprHead1);
            this.Controls.Add(this.sprDesignList);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmdProjectSearch);
            this.Controls.Add(this.txtProd_no);
            this.Controls.Add(this.label1);
            this.Name = "F_EA_040";
            this.Text = "제작통고서 조회(F_EA_040)";
            this.Load += new System.EventHandler(this.F_EA_040_Load);
            this.Activated += new System.EventHandler(this.F_EA_040_Activated);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sprDesignList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprDesignList_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead1_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead2_Sheet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtProd_no;
        private System.Windows.Forms.Button cmdProjectSearch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtPart4;
        private System.Windows.Forms.TextBox txtPart3;
        private System.Windows.Forms.TextBox txtPart2;
        private System.Windows.Forms.TextBox txtPart1;
        private System.Windows.Forms.TextBox txtPart0;
        private FarPoint.Win.Spread.FpSpread sprDesignList;
        private FarPoint.Win.Spread.SheetView sprDesignList_Sheet1;
        private FarPoint.Win.Spread.FpSpread sprHead1;
        private FarPoint.Win.Spread.SheetView sprHead1_Sheet1;
        private FarPoint.Win.Spread.FpSpread sprHead2;
        private FarPoint.Win.Spread.SheetView sprHead2_Sheet1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
    }
}