﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Windows;


namespace ProductionManagement
{

    public partial class MainMDI : Form
    {
        #region Variable declaration Start
        // 환경 변수 파일 부분
        const string cPgmTargetPath = @"C:\CWIS_CO\";
        const string cPgmConfigFile = "LGIE_CO.INI";
        const string BcpExeFile = @"ProdUsedFile$\\Exe\\BCP.EXE";

        // DB 접속 부분
        string ServerName = "CWDBS03";
        string DBName = "EL_CD";
        string DBId = "AppProd";
        string DBPwd = "app@.2012.04.PR";

        // application 설정 부분
        string gDomainName = "엘레베이터";
        string gAppName = "prod_project";


        public string gCur_Date = "";
        public string gUserID = "";
        public bool gCancelFlag = true;
        

        #endregion Variable declaration End

        public MainMDI()
        {
            InitializeComponent();
            // 여기는 실행안됨
        }

        public MainMDI(string [] args)
        {
            InitializeComponent();
            DBManager.SetConnectionString("ODBC", ServerName, DBName, DBId, DBPwd);
            if (!DBManager.Open())
            {
                MessageBox.Show("시스템에 접속하지 못했습니다");
                GlobalSetting.gCancelFlag = false;
                return;
            }

            Login login = new Login();
            args = new string[1];
            args[0] = "CWDBS03,lgjjg,acti08//";
            if (args.Length == 0)
            {
                login.txtDSN.Text = ServerName;
                login.gPgmTargetPath = cPgmTargetPath;
                login.gPgmConfigFile = cPgmConfigFile;

                login.ShowDialog();
                gCancelFlag = GlobalSetting.gCancelFlag;
                if (!gCancelFlag)
                {
                    gUserID = GlobalSetting.gUserID;
                }
            }
            else
            {
                if (args.Length == 1)
                {
                    // 외부에서 호출한 경우 처리
                    // 서버,아이디,패스워드 순으로 들어옴
                    string param = args[0];
                    string[] array=param.Split(new Char[]{','});
                    ServerName = array[0];
                    string userid = array[1];
                    string password = array[2];
                    login.gPgmTargetPath = cPgmTargetPath;
                    login.gPgmConfigFile = cPgmConfigFile;
                    login.LoginCheckWithoutForm(ServerName, userid, password);
                    gCancelFlag = GlobalSetting.gCancelFlag;
                }
            }

            // 메뉴 권한 처리는 FormLoad 시 처리함
        }

        public void F_FormShow(Form form)
        {
            // VB처럼 개체를 받는 방법은???
            Form f = null;

            foreach (Form child in MdiChildren)
            {
                if (child.Name.Equals(form.Name))
                {
                    f = child;
                    form.Close();
                }
            }

            if (f == null)
                f = form;

            f.MdiParent = this;
            f.Activate();
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }
        
        public void g_SysDate()
        {
            string dDate;
            string sTmp;

            sTmp = "SELECT getdate() ";
            GRS g = new GRS(DBManager.Query(sTmp));

            string gCur_Date = String.Format("{0:U}", g.gRS(0)).Substring(0, 10);
            GlobalSetting.gm_Sys_Date = gCur_Date;


            GlobalSetting.gm_sys_data_convert = gCur_Date.Substring(0, 4) + gCur_Date.Substring(5, 2) + gCur_Date.Substring(8, 2);

            sTmp = "exec el_cd.dbo.S_FIND_WEEK '" + gCur_Date + "'";
            g = new GRS(DBManager.Query(sTmp));
            if (g.RowCount > 0)
                GlobalSetting.gCur_Week = g.gRS(0);

            dDate = DateAdd("d", -7, gCur_Date);
            sTmp = "exec el_cd.dbo.S_FIND_WEEK '" + dDate + "'";
            g = new GRS(DBManager.Query(sTmp));
            if (g.RowCount > 0)
                GlobalSetting.gPrev_Week = g.gRS(0);

            dDate = DateAdd("d", 7, gCur_Date);
            sTmp = "exec el_cd.dbo.S_FIND_WEEK '" + dDate + "'";
            g = new GRS(DBManager.Query(sTmp));
            if (g.RowCount > 0)
                GlobalSetting.gNext_Week = g.gRS(0);

            sTmp = "exec el_cd.dbo.s_close_check 'A','19500101'";
            g = new GRS(DBManager.Query(sTmp));
            if (g.RowCount > 0)
                uBizDate.gClose_Date_A = g.gRS(1);
        }

        public void g_ButtonInitialize(string When)
        {
            if (When.Length < 6)
                return;

            for (int i = 0; i < 6; i++)
            {
                if (When.Substring(i, 1).Equals("T"))
                {
                    this.toolStrip.Items[i].Enabled = true;
                }
                else if (When.Substring(i, 1).Equals("F"))
                {
                    this.toolStrip.Items[i].Enabled = false;
                }
                else
                {
                    MessageBox.Show("Argument Error....");
                    break;
                }
            }
        }

        public string DateAdd(string type, int day, string date)
        {
            return date;
        }

        private void toolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            LForm f = null;
            switch (e.ClickedItem.Name)
            {
                case "NewButton":
                    f = (LForm)ActiveMdiChild;
                    f.F_NEW();
                    break;
                case "SaveButton":
                    f = (LForm)ActiveMdiChild;
                    f.F_SAVE();
                    break;
                case "DeleteButton":
                    f = (LForm)ActiveMdiChild;
                    f.F_DELETE();
                    break;
                case "PrintButton":
                    f = (LForm)ActiveMdiChild;
                    f.F_PRINT();
                    break;
                case "SearchButton":
                    ((LForm)ActiveMdiChild).F_SEARCH();
                    //f.F_SEARCH();
                    break;
                case "CloseButton":
                    if (ActiveMdiChild == null)
                        this.Close();
                    else
                    {
                        f = (LForm)ActiveMdiChild;
                        f.F_CLOSE();
                    }
                    break;
            }
        }
        
        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void MainMDI_Load(object sender, EventArgs e)
        {
            if (gCancelFlag)
            {
                Close();
                return;
            }

            // 메뉴 권한 처리는 FormLoad 시 처리함
            if (UserAuthority.UserLevel(GlobalSetting.gUserID)<0)
            {
                MessageBox.Show("사용자 Level를 찾지 못했습니다.전산실 문의 바람");
                Close();
                return;
            }
            //MenuAuthority 는 menu enable/disable 
            MenuCheck();

            GlobalSetting.gBcpExeFile = @"\\" + GlobalSetting.gCo_Server + "\\" + BcpExeFile;
            g_SysDate();
            g_ButtonInitialize("FFFFFT");

            string SQL = "EXEC common.dbo.sp_user_mrp_info '" + GlobalSetting.gUserID + "'";
            GRS g=new GRS(DBManager.Query(SQL));
            if(g.RowCount>0)
                GlobalSetting.gGaijung = g.gRS("gaijung");
            else
                GlobalSetting.gGaijung = "";

        }
        private void MenuCheck()
        {
            string[] Menu = UserAuthority.GetMenuList(gDomainName, gAppName, GlobalSetting.gUserID, "E");
            int menuCount = menuStrip.Items.Count;
            //menuStrip 안의 메뉴 tag를 읽어서 Enable/Disable 함
            for (int i = 0; i < menuCount-1; i++) // 새창 부분은 제외에서 -1을 함
            {
                ToolStripMenuItem item = (ToolStripMenuItem)menuStrip.Items[i];
                for (int j = 0; j < item.DropDownItems.Count; j++)
                {
                    ToolStripItem subItem = item.DropDownItems[j];
                    subItem.Enabled = false;
                    for (int k = 0; k < Menu.Length; k++)
                    {
                        if (subItem.Tag != null)
                        {
                            if (Menu[k] == subItem.Tag.ToString())
                            {
                                subItem.Enabled = true;
                            }
                        }
                    }

                }
            }
        }
        private void MainMDI_FormClosed(object sender, FormClosedEventArgs e)
        {
            DBManager.Close();
        }
        
        private void M_P_EA_040_Click(object sender, EventArgs e)
        {
            //F_FormShow(new F_EA_040());
        }

        private void M_P_CA_060_Click(object sender, EventArgs e)
        {
            //F_FormShow(new F_CA_170());
        }

        private void M_P_CE_100_Click(object sender, EventArgs e)
        {
            //F_CE_100 f = new F_CE_100();
            //f.isButton = "TTTFTT";
            //f.isControl = true;
            //F_FormShow(f);
        }

        private void M_P_EX_000_Click(object sender, EventArgs e)
        {
            //F_EX_000 f = new F_EX_000();
            //f.isButton = "FTTFTT";
            //F_FormShow(f);
        }

        private void M_P_EX_020_Click(object sender, EventArgs e)
        {
            //F_EX_020 f = new F_EX_020();
            //f.isButton = "FTTFTT";
            //f.Text = "코드 관리(일반) (F_EX_020)";
            //F_FormShow(f);
        }

        private void M_P_EA_010_Click(object sender, EventArgs e)
        {
        }

    }
}
