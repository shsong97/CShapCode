﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Windows;
using FarPoint.Win.Spread;
using FarPoint.Win.Spread.CellType;

namespace ProductionManagement
{
    public partial class F_CE_100 : LForm
    {
        
        public bool isControl = false;
        string projectNo;
        string mfgNo;
     
        /* vaspread 2.5 Celltype 참조
        ' CellType property settings
        Public Const SS_CELL_TYPE_DATE = 0
        Public Const SS_CELL_TYPE_EDIT = 1
        Public Const SS_CELL_TYPE_FLOAT = 2
        Public Const SS_CELL_TYPE_INTEGER = 3
        Public Const SS_CELL_TYPE_PIC = 4
        Public Const SS_CELL_TYPE_STATIC_TEXT = 5
        Public Const SS_CELL_TYPE_TIME = 6
        Public Const SS_CELL_TYPE_BUTTON = 7
        Public Const SS_CELL_TYPE_COMBOBOX = 8
        Public Const SS_CELL_TYPE_PICTURE = 9
        Public Const SS_CELL_TYPE_CHECKBOX = 10
        Public Const SS_CELL_TYPE_OWNER_DRAWN = 11
        */

        public F_CE_100()
        {
            InitializeComponent(); 
        }
        public override void F_SEARCH()
        {
            DataSearch();
        }
        private void DataSearch()
        {
            int save_degree=0;
            string Close_Max_Prod_date = "", Close_Max_Sale_date = "";
            
            string SQL;
            
            txtProd_no.Text = txtProd_no.Text.ToUpper();
            txtPart.Text = txtPart.Text.ToUpper();
            projectNo = txtProd_no.Text.Substring(0, 11);
            mfgNo = txtProd_no.Text.Substring(11, 3);
            Close_Max_Prod_date = ""; 
            Close_Max_Sale_date = "";
                
            this.Cursor = Cursors.WaitCursor;

            Head_Display();
            
            SQL = "exec S_CE_100_3 '" + projectNo + "','" + mfgNo + "'";
            GRS g = new GRS(SQL);

            if (g.RowCount == 0)
            {
                MessageBox.Show("데이터가 없습니다");
                this.Cursor = Cursors.Default;
                return;
            }


            SheetView sv = vaSpread0.Sheets[0];
  
    
            sv.Cells[1, 0].Text = g.gRS("cc_010_cw_cont");
            sv.Cells[1, 1].Text = g.gRS("cc_010_block"); 
            sv.Cells[1,2].Text=g.gRS("date_comp");

            if(g.gRS("manual_wb_flag").Equals("Y"))
            {
                sv.Cells[1,2].BackColor = Color.FromArgb(226, 254, 231);
            }
            else 
            {
                sv.Cells[1,2].BackColor = Color.FromArgb(254, 234, 234);
            }

            sv.Cells[1,3].Text=g.gRS("design_complete_date");
            sv.Cells[1,4].Text=g.gRS("poc_worksbilling");

            if(g.gRS("date_comp").CompareTo("0")<0) 
            {
                cmdCompCancel0.Visible = true;
                cmdCompCancel1.Visible = false;
            }
            else
            {
                cmdCompCancel1.Visible = true;
                cmdCompCancel0.Visible = false;
            }
                
            if(g.gRS("poc_worksbilling").Equals("Y")) 
            {
                cmdTransWB1.Visible = false;
                cmdTransWB0.Visible = true;
            }
            else
            {
                cmdTransWB1.Visible = true;
                cmdTransWB0.Visible = false;
            }
            sv.Cells[1,4].Text=g.gRS("proc_message");

            SheetView sv3=vaSpread3.Sheets[0];
 
            sv3.Cells[0,1].Text=g.gRS("brief_trade");
            sv3.Cells[0,3].Text=g.gRS("cost_model");
            sv3.Cells[1,1].Text=g.gRS("model_type");
            sv3.Cells[1,3].Text=g.gRS("equip_count");

            SQL = "exec S_CE_100_6 '" + projectNo + "','" + mfgNo + "'";
            g = new GRS(SQL);

            if (g.RowCount == 0)
            {
                this.Cursor = Cursors.Default;
                return;
            }

            cmdHold.Text = g.gRS("hold");
            lblDormant.Text = g.gRS("dormant");


            SQL = "exec s_CE_100_1_part '" + projectNo + "','" + mfgNo + "','" + txtPart.Text + "'";
            g = new GRS(SQL);
            if (g.RowCount == 0)
            {
                this.Cursor = Cursors.Default;
                return;
            }

            SheetView sv1=vaSpread1.Sheets[0];

            if (g.RowCount > 0)
            {

                sv1.Rows.Count=0;
                sv1.Rows.Count = g.RowCount;
                for (int i = 0; i < g.RowCount; i++)
                {
                    //수정모드 처리 방법
                    sv1.RowHeader.Rows[i].Label = "=";
                    sv1.Cells[i,0].Text=g.gRS("PARTa");
                    sv1.Cells[i,1].Text=g.gRS("ITEM_GROUP_SUB");
                    sv1.Cells[i,2].Text=g.gRS("DEGREE");
                    save_degree = g.gRSInt("degree");

                    sv1.Cells[i,3].Text=g.gRS("ITEM_GROUP_SUB_desc");
                    sv1.Cells[i,4].Text=g.gRS("CONT_QTY");
                    sv1.Cells[i,5].Text=g.gRS("PROD_QTY");
                    sv1.Cells[i,6].Text=g.gRS("SALE_QTY");
                    sv1.Cells[i,7].Text=g.gRS("factory_price");


                    if( g.gRSInt("factory_price") == 0 && 
                        g.gRS("close_out_date").CompareTo("0") < 0 &&
                        g.gRS("close_in_date").CompareTo("0") < 0 &&
                        g.gRS("packing_date").CompareTo("0") < 0)
                    {
                        sv1.Cells[i, 7].Locked = false;
                    }

                    sv1.Cells[i, 8].Text = g.gRS("PROD_AMT_fp");
                    sv1.Cells[i, 9].Text = g.gRS("CLOSE_IN_DATE");

                    if( !g.gRS("parta").Equals("WT") && g.gRS("close_in_date").CompareTo(Close_Max_Prod_date)>0 ) 
                    {
                        Close_Max_Prod_date = g.gRS("close_in_date");
                    }

                    sv1.Cells[i, 10].Text = g.gRS("SALE_AMT_fp");
                    sv1.Cells[i, 11].Text = g.gRS("CLOSE_OUT_DATE");

                    if (!g.gRS("parta").Equals("WT") && g.gRS("close_out_date").CompareTo(Close_Max_Sale_date) > 0)
                    {
                        Close_Max_Sale_date = g.gRS("close_out_date");
                    }

                    if (sv1.Cells[i, 11].Text.ToString().CompareTo("0")>0 || save_degree < 4 )
                    {
                        TextCellType t=new TextCellType();
                        
                        sv1.Cells[i, 12].CellType =t;// Type Text
                        sv1.Cells[i, 19].CellType =t;// Type Text
                        //sv1.Cells[i, -1].Locked =true;

                    }
                    else
                    {
                        if(int.Parse(g.gRS("cont_qty")) == 0 && 
                            int.Parse(g.gRS("prod_qty")) == 0 && 
                            int.Parse(g.gRS("sale_qty")) == 0)
                        {
                            sv1.Cells[i, 1].BackColor = Color.FromArgb(225, 254, 220);
                            sv1.Cells[i, 13].Locked =false;
                        }
                        else
                        {
                            sv1.Cells[i, -1].BackColor = Color.FromArgb(254, 231, 228);
                        }
                        sv1.Cells[i, 0].Locked =false;
                        sv1.Cells[i, 11].Locked =false;

                        if (g.gRSInt("sale_amt_arb") == 0 && 
                            g.gRSInt("prod_amt_arb") == 0 )
                        {
                            sv1.Cells[i, 13].Locked =false;
                        }
                    }
                    
                    sv1.Cells[i,13].Text=g.gRS("cont_AMT");
                    sv1.Cells[i,14].Text=g.gRS("PROD_AMT_arb");
                    sv1.Cells[i,15].Text=g.gRS("SALE_AMT_arb");
                    sv1.Cells[i,16].Text=g.gRS("packing_qty");
                    sv1.Cells[i,17].Text=g.gRS("packing_cost");
                    sv1.Cells[i,18].Text=g.gRS("packing_date");

                    if (g.gRS("packing_date").CompareTo("0") > 0)
                    {
                        TextCellType t = new TextCellType();// text type 설정하기 위해서
                        //sample code 참조
                        //t.CharacterCasing = CharacterCasing.Upper; 
                        //t.CharacterSet = FarPoint.Win.Spread.CellType.CharacterSet.Ascii; 
                        //t.MaxLength = 30; t.Multiline = true; 
                        //fpSpread1.ActiveSheet.Cells[0, 0].Text = "This is a text cell. ";
                        //fpSpread1.ActiveSheet.Cells[0, 0].CellType = t;


                        sv1.Cells[i, 19].CellType = t;// Type Text
                        sv1.Cells[i, 17].Locked = true;
                    }
                    
                    sv1.Cells[i,20].Text=g.gRS("clc");
                    sv1.Cells[i,21].Text=g.gRS("ctc");
                    sv1.Cells[i,22].Text=g.gRS("oversea_trans");

                    g.MoveNext();
                    
                }

                
                if (g.NextResults())
                {
                    SheetView sv2=vaSpread2.Sheets[0];

                    sv2.Cells[0, 1].Text = "합계";
                    sv2.Cells[0, 3].Text = "Warrenty 제외";
                    sv2.Cells[0, 4].Text = g.gRS("Cont_Qty_Sum")==null?"0":g.gRS("Cont_Qty_Sum");
                    sv2.Cells[0, 5].Text = g.gRS("Prod_Qty_Sum");
                    sv2.Cells[0, 6].Text = g.gRS("Sale_Qty_Sum"); 
                    sv2.Cells[0, 7].Text = g.gRS("Cont_amt_sum_fp");
                    sv2.Cells[0, 8].Text = g.gRS("Prod_amt_sum_fp");

                    if (g.gRSDouble("Cont_amt_sum_fp") == g.gRSDouble("Prod_amt_sum_fp"))
                    {
                        sv2.Cells[0, 9].Text = Close_Max_Prod_date;
                    }
                    else
                    {
                        sv2.Cells[0, 9].Text = "";
                    }

                    sv2.Cells[0, 10].Text = g.gRS("Sale_amt_sum_fp");

                    if (g.gRSDouble("Cont_amt_sum_fp") == g.gRSDouble("Sale_amt_sum_fp"))
                    {
                        sv2.Cells[0, 11].Text=Close_Max_Sale_date;
                    }
                    else
                    {
                        sv2.Cells[0, 11].Text="";
                    }

                    sv2.Cells[0, 13].Text = g.gRS("Cont_amt_sum_arb");
                    sv2.Cells[0, 14].Text = g.gRS("Prod_amt_sum_arb");
                    sv2.Cells[0, 15].Text = g.gRS("Sale_amt_sum_arb");
                    sv2.Cells[0, 17].Text = g.gRS("packing_cost_sum");
                    sv2.Cells[0, 20].Text = g.gRS("clc_sum");
                    sv2.Cells[0, 21].Text = g.gRS("ctc_sum");
                    sv2.Cells[0, 22].Text = g.gRS("oversea_trans_sum");

                    sv2.Cells[1, 7].Value = g.gRSDouble("Cont_amt_sum_fp") - g.gRSDouble("Sale_amt_sum_fp");

                    if (g.gRSDouble("Cont_amt_sum_fp") > 0)
                    {
                        sv2.Cells[1, 8].Value =g.gRSDouble("Prod_amt_sum_fp") * 100 / g.gRSDouble("Cont_amt_sum_fp");
                        sv2.Cells[1, 10].Value = g.gRSDouble("Sale_amt_sum_fp") * 100 / g.gRSDouble("Cont_amt_sum_fp");
                    }
                    else
                    {
                        sv2.Cells[1, 8].Value = 0;
                        sv2.Cells[1, 10].Value = 0;
                    }

                    sv2.Cells[1, 13].Value = g.gRSDouble("Cont_amt_sum_arb") - g.gRSDouble("Sale_amt_sum_arb");

                    if (double.Parse(g.gRS("Cont_amt_sum_arb")) > 0)
                    {
                        sv2.Cells[1, 14].Value = g.gRSDouble("Prod_amt_sum_arb") * 100 / g.gRSDouble("Cont_amt_sum_arb");
                        sv2.Cells[1, 15].Value = g.gRSDouble("Sale_amt_sum_arb") * 100 / g.gRSDouble("Cont_amt_sum_arb");
                    }
                    else
                    {
                        sv2.Cells[1, 14].Value = 0;
                        sv2.Cells[1, 15].Value = 0;
                    }

                    sv2.Cells[1, 17].Value = g.gRS("packing_cost_act_sum");
                    sv2.Cells[1, 20].Value = g.gRS("clc_act_sum");
                    sv2.Cells[1, 21].Value = g.gRS("ctc_act_sum");
                    sv2.Cells[1, 22].Value = g.gRS("oversea_trans_act_sum");
                }
            }
            this.Cursor = Cursors.Default;
            txtProd_no.Focus();
        }
        
        private void Head_Display()
        {
        
            int i;
            txtProd_no.Text = txtProd_no.Text.ToUpper();
            string SQL = " exec s_cc_020_2 '" + txtProd_no.Text + "'";
            GRS g = new GRS(SQL);

            for (i = 0; i < g.RowCount; i++)
            {
                string data=g.gRS("plan_date");
                uSpread.Spread_Unit_Data_Set(sprHead.Sheets[0], 0, 2 * i+1, data, true, false);
                g.MoveNext();
            }
        
        }

        private void F_CE_100_Load(object sender, EventArgs e)
        {
            //this 가 F_CE_100이고 Parent는 MdiClient 형이어서 한번더 해줘야함.
            mdi = (MainMDI)this.Parent.Parent;
            mdi.g_ButtonInitialize(isButton);

            cmd25.Visible = isControl;
            cmdAct.Visible = isControl;
            cmdCompute.Visible = isControl;
            cmdContDist.Visible = isControl;
            cmdCancel.Visible = isControl;
            cmdConfirm.Visible = isControl;
            cmdAllSet.Visible = isControl;
            cmdReverse.Visible = isControl;
            cmdZero.Visible = isControl;
            cmdCostCalc.Visible = isControl;
            cmdTransWB0.Enabled = isControl;
            cmdTransWB1.Enabled = isControl;
            cmdCompCancel0.Enabled = isControl;
            cmdCompCancel1.Enabled = isControl;

            mebProcDate.Text = mdi.gCur_Date;

            vaSpread1.Sheets[0].Rows.Count = 0;
            
            cmdCompCancel0.Visible = false;
            cmdCompCancel1.Visible = false;
            cmdTransWB0.Visible = false;
            cmdTransWB1.Visible = false;
            
            string SQL = "exec S_EB_610_3 'R','" + mdi.gUserID + "'";

            cmdHold.Visible = false;
            GRS g = new GRS(SQL);
            if (g.RowCount > 0)
            {
                if (g.gRS(0).Equals("Y"))
                {
                    cmdHold.Visible = true;
                }
            }
        }

        private void cmd25_Click(object sender, EventArgs e)
        {
            if (f_Complete_Check(0)==false)
            {
                return;
            }

            this.Cursor = Cursors.WaitCursor;
            string sSQL = "exec S_CE_100_2 '" + projectNo + "','" + mfgNo + "'";

            DBManager.Execute(sSQL);

            this.Cursor = Cursors.Default;

            MessageBox.Show("2000/12/25일 까지만 반영되었읍니다");
            F_SEARCH();
        }

        private bool f_Complete_Check(int Sproc)
        {
            string sSQL;

            txtProd_no.Text = txtProd_no.Text.ToUpper();
            txtPart.Text = txtPart.Text.ToUpper();
            projectNo = txtProd_no.Text.Substring(0, 11);
            mfgNo = txtProd_no.Text.Substring(11, 3);


            this.Cursor = Cursors.WaitCursor;

            sSQL = "exec S_CE_100_0 '" + projectNo + "','" + mfgNo + "'";
            GRS g = new GRS(sSQL);

            if (g.RowCount > 0)
            {
                if (Sproc == 0) //' Conversion
                {
                    if (g.gRSInt("flag")>1)
                    {
                        string msg = "작업불가 ==> " + g.gRS("err_desc");
                        MessageBox.Show(msg);
                        this.Cursor = Cursors.Default;
                        return false;
                    }
                }
                else if (Sproc == 1) //'실적처리(batch)
                {
                    if (g.gRSInt("flag") == 1)
                    {
                        string msg = "작업불가 ==> " + g.gRS("err_desc");
                        MessageBox.Show(msg);
                        this.Cursor = Cursors.Default;
                        return false;
                    }
                }
                else if (Sproc == 2) //'실적처리(each)
                {
                    if (g.gRSInt("flag") == 1)
                    {
                        string msg = "작업불가 ==> " + g.gRS("err_desc");
                        MessageBox.Show(msg);
                        this.Cursor = Cursors.Default;
                        return false;
                    }
                    else if (g.gRSInt("flag") < 2)
                    {
                        string msg = "Conversion 확정후 작업이 가능합니다";
                        MessageBox.Show(msg);
                        this.Cursor = Cursors.Default;
                        return false;
                    }
                }

            }
            this.Cursor = Cursors.Default;
            return true;
        }

        private void cmdAct_Click(object sender, EventArgs e)
        {
            if (f_Complete_Check(1) == false)
            {
                return;
            }


            this.Cursor = Cursors.WaitCursor;
            string sSQL = "exec s_CE_100_2_ADD '" + projectNo + "','" + mfgNo + "'";

            DBManager.Execute(sSQL);

            this.Cursor = Cursors.Default;
            MessageBox.Show("2000/12/26일부터 실적반영 되었읍니다");
            F_SEARCH();
        }

        private void cmdAllSet_Click(object sender, EventArgs e)
        {
            cmdCheckButtonSet("1");
        }

        private void cmdCheckButtonSet(string s)
        {
            string Part="", Spart="";

            txtPart.Text = txtPart.Text.ToString().ToUpper();
            
            SheetView sv=vaSpread1.Sheets[0];
            if (txtPart.Text.CompareTo("0")<0)
            {
                for( int i = 0; i<sv.Rows.Count; i++ )
                {
                    //ICellType cType = sv.Cells[i, 12].CellType;

                    if (sv.Cells[i, 12].Value != null) //if (typeof(cType) == TextCellType) //.CellType <> 0 체크박스인지 물어보는것
                    {
                        //sv.Cells[i, 12].Text = s;
                        if ((bool)sv.Cells[i, 12].Value==true)
                        {
                            sv.Cells[i, 11].Text = mebProcDate.Text.Substring(0, 4) + "-" + mebProcDate.Text.Substring(4, 2) + "-" + mebProcDate.Text.Substring(6, 2);
                        }
                        else
                        {
                            sv.Cells[i, 11].Text = "";
                        }
                    }
                }
            }
            else
            {
                for(int j = 0 ; j<= 4 ; j++ )
                {
                    Part = txtPart.Text.Substring(j * 3, 2);
                    if( Part.CompareTo("0")>0 )
                    {
                        for(int i = 0 ; i<vaSpread1.Sheets[0].Rows.Count; i++ )
                        {
                            Spart=sv.Cells[i,0].Text;
                            if(true) //if (typeof(cType) == TextCellType && Part.Equals(Spart)) //.CellType <> 0 체크박스인지 물어보는것
                            {
                                sv.Cells[i, 12].Text = s;
                                if (s.Equals("1"))
                                {
                                    sv.Cells[i, 11].Text = mebProcDate.Text.Substring(0, 4) + "-" + mebProcDate.Text.Substring(4, 2) + "-" + mebProcDate.Text.Substring(6, 2);
                                }
                                else
                                {
                                    sv.Cells[i, 11].Text = "";
                                }
                            }                            
                        }
                    }
                }
            }
            
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            txtProd_no.Text = txtProd_no.Text.ToUpper();
            projectNo = txtProd_no.Text.Substring(1, 11);
            mfgNo = txtProd_no.Text.Substring(12, 3);

            string sSQL = "update project_err set conversion_close_date = convert(smalldatetime,null) from project_err where " +
                    " Project_no = '" + projectNo + "' and mfg_no = '" + mfgNo + "'";
            DBManager.Execute(sSQL);
            MessageBox.Show("해제되었읍니다");
        }

        private void cmdCompCancel1_Click(object sender, EventArgs e)
        {
            string poc_flag="";

            string msg="정말로" + "해제" + "하시겠습니까 ??";
			MessageBoxButtons buttons = MessageBoxButtons.YesNo;
			DialogResult result;

    		result = MessageBox.Show(this, msg, "Confirm", buttons);

            if(result  != DialogResult.Yes )
            {
                return;
            }

            txtProd_no.Text = txtProd_no.Text.ToUpper();
            projectNo = txtProd_no.Text.Substring(0, 11);
            mfgNo = txtProd_no.Text.Substring(11, 3);

            poc_flag = uSpread.Spread_Unit_Data_Get(vaSpread0,1, 4);

            string sSQL = "update project_err set date_comp = convert(smalldatetime,null),manual_wb_flag='' from project_err where " +
                        " Project_no = '" + projectNo + "' and mfg_no = '" + mfgNo + "'";
            msg = "완료해제되었읍니다";
            DBManager.Execute(sSQL);
            MessageBox.Show(msg);
            F_SEARCH();
        }

        private void cmdCompCancel0_Click(object sender, EventArgs e)
        {
            string sale_date = "";
            string poc_flag = "";

            string msg = "정말로" + "완료" + "하시겠습니까 ??";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show(this, msg, "Confirm", buttons);

            if (result != DialogResult.Yes)
            {
                return;
            }

            txtProd_no.Text = txtProd_no.Text.ToUpper();
            projectNo = txtProd_no.Text.Substring(0, 11);
            mfgNo = txtProd_no.Text.Substring(11, 3);

            poc_flag = uSpread.Spread_Unit_Data_Get(vaSpread0, 1, 4);

            string sSQL="";
            uBizDate date=new uBizDate();
            if (poc_flag.Equals("Y"))
            {
                sale_date = uSpread.Spread_Unit_Data_Get(vaSpread0, 2, 1); 
                if (sale_date.CompareTo("0") < 0)
                {
                    sale_date = mebProcDate.Text;
                }
                if(date.g_Close_Date_Check("C", sale_date) == false)
                {
                    return;
                }
                sSQL = " exec S_CE_100_POC_WB_Force '" + projectNo + "','" + mfgNo + "','" + sale_date + "'";
            }
            else
            {
                sSQL = "update project_err set date_comp = getdate(),manual_wb_flag='' from project_err where " +
                                " Project_no = '" + projectNo + "' and mfg_no = '" + mfgNo + "'";
            }

            msg = "강제완료되었읍니다";
            DBManager.Execute(sSQL);
            MessageBox.Show(msg);
            F_SEARCH();
        }

        private void cmdCompute_Click(object sender, EventArgs e)
        {
            if (f_Complete_Check(0) == false)
            {
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            string sSQL = "exec S_CE_100_2_ALL '" + projectNo + "','" + mfgNo + "'";
            DBManager.Execute(sSQL);

            this.Cursor = Cursors.Default;
            MessageBox.Show("전기간 반영되었읍니다");
            F_SEARCH();
        }

        private void cmdConfirm_Click(object sender, EventArgs e)
        {
            txtProd_no.Text = txtProd_no.Text.ToUpper();
            projectNo = txtProd_no.Text.Substring(0, 11);
            mfgNo = txtProd_no.Text.Substring(11, 3);

            string sSQL = "update project_err set conversion_close_date = '20000101' from project_err where " +
                    " Project_no = '" + projectNo + "' and mfg_no = '" + mfgNo + "'";
            DBManager.Execute(sSQL);
            MessageBox.Show("Conversion이 확정되었읍니다");
        }

        private void cmdContDist_Click(object sender, EventArgs e)
        {
            if (f_Complete_Check(1) == false)
            {
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            string sSQL = "exec s_CE_100_ContDist '" + projectNo + "','" + mfgNo + "'";
            GRS g=new GRS(sSQL);
            MessageBox.Show(g.gRS(0));

            this.Cursor = Cursors.Default;

            F_SEARCH();
        }

        private void cmdCostCalc_Click(object sender, EventArgs e)
        {
            
            this.Cursor = Cursors.WaitCursor;

            string sSQL = "exec S_CJ_100_2 '','P','B', '" + txtProd_no.Text + "'";
            GRS g = new GRS(sSQL);
            MessageBox.Show(g.gRS(0));

            this.Cursor = Cursors.Default;
            F_SEARCH();
        }

        private void cmdHold_Click(object sender, EventArgs e)
        {
            string sSQL = "exec S_CE_100_6 '" + projectNo + "','" + mfgNo + "','Y','" + mdi.gUserID + "'";

            GRS g = new GRS(sSQL);
            MessageBox.Show(g.gRS("msg"));

            cmdHold.Text = g.gRS("hold");
            lblDormant.Text = g.gRS("dormant");
        }

        private void cmdMoveInquiry_Click(object sender, EventArgs e)
        {
            //    F_CE_103.txtProd_no.Text = txtProd_no.Text
            //    Call F_CE_103.cmdSearch_Click
            //    F_CE_103.Show 1
        }

        private void cmdReverse_Click(object sender, EventArgs e)
        {
            cmdCheckButtonSet("0");
        }

        private void cmdTransWB0_Click(object sender, EventArgs e)
        {
            string msg="정규" + "로 전환하시겠습니까 ??";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show(this, msg, "Confirm", buttons);
            if(result  != DialogResult.Yes ) 
            {
                return;
            }

            string sSQL = "exec S_CE_100_POC_Translation '" + projectNo + "','" + mfgNo + "','A'";

            GRS g = new GRS(sSQL);
            MessageBox.Show(g.gRS(0));

            F_SEARCH();
        }

        private void cmdTransWB1_Click(object sender, EventArgs e)
        {
            string msg = "POC" + "로 전환하시겠습니까 ??";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show(this, msg, "Confirm", buttons);
            if (result != DialogResult.Yes)
            {
                return;
            }

            string sSQL = "exec S_CE_100_POC_Translation '" + projectNo + "','" + mfgNo + "',''";
            GRS g = new GRS(sSQL);
            MessageBox.Show(g.gRS(0));

            F_SEARCH();
        }

        private void cmdZero_Click(object sender, EventArgs e)
        {
            string ProcDate="";
            SheetView sv = vaSpread1.Sheets[0];

            for (int i = 0; i < sv.RowCount; i++)
            {
                //check box인 경우 값을 체크하나 value로 체크하여 값 비교하였음
                bool value=false;
                if(sv.Cells[i, 12].Value!=null)
                {
                    value= (bool)sv.Cells[i, 12].Value;
                }
                if (value)
                {
                    ProcDate = sv.Cells[i, 11].Text;
                    if (ProcDate.CompareTo("20001226") < 0)
                    {
                        if (sv.Cells[i, 13].Locked == false)
                        {
                            sv.Cells[i, 13].Value = false;
                            sv.RowHeader.Rows[i].Label = "M";
                        }
                    }
                }
            }
        }

        private void F_CE_100_Activated(object sender, EventArgs e)
        {
            mdi.g_ButtonInitialize(isButton);
        }

        //top row 부분 미해결
        public override void F_NEW()
        {
            int RowSave=0;

            RowSave = vaSpread1.Sheets[0].RowCount;
            vaSpread1.Sheets[0].RowCount = vaSpread1.Sheets[0].RowCount + 20;

            SheetView sv = vaSpread1.Sheets[0];
            for (int i = RowSave; i < sv.RowCount; i++)
            {
                sv.Cells[i, 1].Locked = true; sv.Cells[i, 1].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 2].Locked = true; sv.Cells[i, 2].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 7].Locked = true; sv.Cells[i, 7].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 11].Locked = true; sv.Cells[i, 11].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 12].Locked = true; sv.Cells[i, 12].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 13].Locked = true; sv.Cells[i, 13].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 17].Locked = true; sv.Cells[i, 17].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 18].Locked = true; sv.Cells[i, 18].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 20].Locked = true; sv.Cells[i, 20].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 21].Locked = true; sv.Cells[i, 21].BackColor = Color.FromArgb(225, 235, 255);
                sv.Cells[i, 22].Locked = true; sv.Cells[i, 22].BackColor = Color.FromArgb(225, 235, 255);

            }
            if (RowSave > 1)
            {
                //TopRow개념
                //sv.FrozenRowCount = RowSave;
            }

        }

        private void txtProd_no_TextChanged(object sender, EventArgs e)
        {
            cmdTransWB0.Visible = false;
            cmdCompCancel0.Visible = false;
            cmdTransWB1.Visible = false;
            cmdCompCancel1.Visible = false;
            vaSpread1.Sheets[0].RowCount = 0;
        }

        private void txtProd_no_KeyPress(object sender, KeyPressEventArgs e)
        {
            cmdTransWB0.Visible = false;
            cmdTransWB1.Visible = false;
            cmdCompCancel0.Visible = false;
            cmdCompCancel1.Visible = false;
            vaSpread1.Sheets[0].RowCount = 0;

            if (e.KeyChar == 13)
            {
                F_SEARCH();
            }
        }

        private void vaSpread1_ButtonClicked(object sender, EditorNotifyEventArgs e)
        {
            if (e.Row > 0 && (e.Column == 12 || e.Column == 19))
            {
                SheetView sv=vaSpread1.Sheets[0];
                //check box value 확인
                if (sv.Cells[e.Row, e.Column].Value != null)
                {
                    if ((bool)sv.Cells[e.Row, e.Column].Value == true)
                    {
                        sv.Cells[e.Row, e.Column - 1].Text = mebProcDate.Text.Substring(0, 4) + "-" +
                            mebProcDate.Text.Substring(4, 2) + "-" + mebProcDate.Text.Substring(6, 2);
                    }
                    else
                    {
                        sv.Cells[e.Row, e.Column - 1].Text = "";
                    }
                }
            }
        }

        // top row 부분 미해결
        public override void F_SAVE()
        {

            string Pumbun="", ProcDate="";
            int Degree=0;
            int count = 0;
            double ContAmt=0, ContFp=0;
            int TempCnt=0;
            string Date_Comp="";
            string design_comp = "";
            int packing_cost=0,clc=0,ctc=0,Oversea_trans=0;

            if (f_Complete_Check(2) == false)
            {
                return;
            }

            if (F_Data_Check() == false)
            {
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            //'SCR
            Date_Comp = uSpread.Spread_Unit_Data_Get(vaSpread0,1, 2);
            design_comp = uSpread.Spread_Unit_Data_Get(vaSpread0, 1, 3);


            string sSQL = "exec S_CE_100_4 '" + projectNo + "','" + mfgNo + "','" + Date_Comp + "','" + design_comp + "'";
            MessageBox.Show(sSQL);
            //db.DbExecute(sSQL);

            int maxrows = uSpread.MaxRows(vaSpread1);
            SheetView sv=vaSpread1.Sheets[0];
            for (int i = 0; i < maxrows; i++)
            {
                TempCnt = 0;
                Pumbun = sv.Cells[i, 1].Text.Trim();
                Degree = sv.Cells[i, 2].Text.CompareTo("4") < 0 ? 4 : int.Parse(sv.Cells[i, 2].Text);
                if (sv.RowHeader.Rows[i].Label.Equals("M"))
                {
                    ContFp=(double)sv.Cells[i,7].Value;
                    ContAmt=(double)sv.Cells[i,13].Value;
                    packing_cost=sv.Cells[i,17].Text.Equals("")?0:(int)sv.Cells[i,17].Value;
                    clc=sv.Cells[i,20].Text.Equals("")?0:(int)sv.Cells[i,20].Value;
                    ctc=sv.Cells[i,21].Text.Equals("")?0:(int)sv.Cells[i,21].Value;
                    Oversea_trans=sv.Cells[i,22].Text.Equals("")?0:(int)sv.Cells[i,22].Value;                  

                    sSQL = "exec s_CE_100_ContChange '" + projectNo + "','" + mfgNo +
                            "','" + Pumbun + "'," + Degree + "," + ContAmt + "," +
                            packing_cost + "," + clc + "," + ctc + "," + Oversea_trans + "," + ContFp;
                    MessageBox.Show(sSQL);
                    //db.DbExecute(sSQL);
                    TempCnt = 1;
                }
                if (sv.RowHeader.Rows[i].Label.Equals("A"))
                {
                    ContFp = (double)sv.Cells[i, 7].Value;
                    ContAmt = (double)sv.Cells[i, 13].Value;
                    packing_cost = sv.Cells[i, 17].Text.Equals("") ? 0 : (int)sv.Cells[i, 17].Value;
                    clc = sv.Cells[i, 20].Text.Equals("") ? 0 : (int)sv.Cells[i, 20].Value;
                    ctc = sv.Cells[i, 21].Text.Equals("") ? 0 : (int)sv.Cells[i, 21].Value;
                    Oversea_trans = sv.Cells[i, 22].Text.Equals("") ? 0 : (int)sv.Cells[i, 22].Value;

                    sSQL = "exec s_CE_100_InformalInsert '" + projectNo + "','" + mfgNo +
                            "','" + Pumbun + "'," + Degree + "," + ContFp + "," + ContAmt + "," +
                            packing_cost + "," + clc + "," + ctc + "," + Oversea_trans;
                    MessageBox.Show(sSQL);
                    DataSet ds = null;
                    //DataSet ds=db.DbQuery(sSQL);
                    GRS g = new GRS(ds.Tables[0].Rows[0]);
                    if (g.gRSInt("flag") != 0)
                    {
                        sv.Cells[i, 1].BackColor = Color.FromArgb(255, 255, 0);
                        // TopRow로 이동방법??
                        //.TopRow = .Row
                        MessageBox.Show(g.gRS("err_desc"));
                        this.Cursor = Cursors.Default;
                        return;
                    }
                    TempCnt = 1;
                }
                if((bool)sv.Cells[i,12].Value) //.Col = 13   '처리-체크박스
                {
                    ProcDate=sv.Cells[i,11].Text;
                    
                    sSQL = "exec s_CE_100_InformalProc '" + projectNo + "','" + mfgNo +
                            "','" + Pumbun + "'," + Degree + ",'" + ProcDate + "'";
                    MessageBox.Show(sSQL);
                    //db.DbExecute(sSQL);
                    TempCnt = 1;
                }
                count = count + TempCnt;
                sv.RowHeader.Rows[i].Label= "=";
            }

            this.Cursor = Cursors.Default;

            MessageBox.Show(count + "건이 처리 되었읍니다");
            F_SEARCH();
        }

        // top row부분 미해결
        private bool F_Data_Check()
        {

            string Cmd="";
            double cont_amt=0;
            double factory_price=0;
            string prod_date="", sale_date = "";
            bool Data_Check = true;
            
            SheetView sv=vaSpread1.Sheets[0];
            int maxrows = sv.RowCount;

            for (int i = 0; i < maxrows; i++)
            {
                Cmd = sv.RowHeader.Rows[i].Label;
                if ((bool)sv.Cells[i, 12].Value && Cmd.Equals("M"))
                {
                    prod_date = sv.Cells[i, 9].Text;
                    sale_date = sv.Cells[i, 11].Text;

                    if (prod_date.CompareTo(sale_date) > 0)
                    {
                        Data_Check = false;
                        sv.Cells[i, 11].BackColor = Color.FromArgb(255, 255, 0);
                        //                    .TopRow = .Row
                        MessageBox.Show(" 생산완료일자가 출하일자보다 더 큽니다");

                    }
                }
                if ((bool)sv.Cells[i, 12].Value)
                {
                    prod_date = sv.Cells[i, 9].Text;
                    sale_date = sv.Cells[i, 11].Text;
                    cont_amt = (double)sv.Cells[i, 13].Value;
                    factory_price = (double)sv.Cells[i, 7].Value;//'2004.7.9  노중기, 박종진 요청

                    uBizDate date=new uBizDate();

                    if (txtProd_no.Text.Substring(4, 2).Equals("T "))
                    {
                        if (cont_amt != 0 && !date.g_Close_Date_Check("X", sale_date))
                        {
                            Data_Check = false;
                            sv.Cells[i, 7].BackColor = Color.FromArgb(255, 255, 0);
                            //.TopRow = .Row
                            MessageBox.Show(" 수주금액이 있는 경우 일자는 " + uBizDate.gClose_Date_X + " 보다 크야 합니다");
                        }
                    }
                    else
                    {
                        //'2004.7.9  마감완료일 check부분 수정 - 노중기, 박종진 요청
                        if( (cont_amt != 0 || factory_price != 0) && date.g_Close_Date_Check("C", sale_date) == false )
                        {
                            Data_Check = false;
                            sv.Cells[i, 7].BackColor = Color.FromArgb(255, 255, 0);
                            //.TopRow = .Row
                            MessageBox.Show(" 수주금액이 있는 경우 일자는 " + uBizDate.gClose_Date_C + " 보다 크야 합니다");
                        }
                    }
                }
                if (sv.RowHeader.Rows[i].Label.Equals("A"))
                {
                    sv.Cells[i, 1].Text = sv.Cells[i, i].Text.ToUpper();
                    if (sv.Cells[i, 1].Text.CompareTo("A") < 0)
                    {
                        sv.RowHeader.Rows[i].Label = " ";
                    }
                    else
                    {
                        if (sv.Cells[i, 2].Text.CompareTo("4") < 0)
                        {
                            sv.Cells[i, 2].Text = "4";
                        }
                    }
                }

            }
            return Data_Check;
        }

        public override void F_DELETE()
        {

            int s1=0, s2=0;
            string Degree;
            string Pumbun;

            if (vaSpread1.Sheets[0].IsBlockSelected) // block이 선택되었을때
            {
                MessageBoxButtons buttons = MessageBoxButtons.YesNoCancel;
                DialogResult result;

                result = MessageBox.Show(this, "삭제하시겠습니까?", "파일삭제", buttons, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    SheetView sv=vaSpread1.Sheets[0];
                    SheetView.DocumentModels dm = new SheetView.DocumentModels();
                    dm = vaSpread1.ActiveSheet.Models;
                    int rowBegin=dm.Selection.AnchorRow;
                    int rowEnd = dm.Selection.LeadRow;
                    int colBegin=dm.Selection.AnchorColumn;
                    int colEnd = dm.Selection.LeadColumn;

                    if (rowEnd == 0 && colEnd==0) //If .SelBlockRow = -1 Then
                    {
                        s1 = 0;
                        s2 = sv.RowCount;
                    }
                    else
                    {
                        s1 = rowBegin;
                        s2 = rowEnd+1;
                    }

                    for(int i = s1; i < s2;i++)
                    {
                        Pumbun=sv.Cells[i,1].Text.Trim();
                        Degree=sv.Cells[i,2].Text.Trim();
                        string SQL = "exec S_CE_100_5 '" +projectNo + "','" + mfgNo + "','" + Pumbun + "',"+ Degree; //'20041029수정(차수 입력)
                        MessageBox.Show(SQL);
                        //db.DbExecute(SQL);
                    }
                    F_SEARCH();
                }
            }

        }

        private void vaSpread1_Change(object sender, ChangeEventArgs e)
        {
            if (e.Row > 0 && e.Column > 0)
            {
                SheetView sv = vaSpread1.Sheets[0];
                if(!sv.Cells[e.Row,e.Column].Locked && e.Column != 12)
                {
                    if (sv.RowHeader.Rows[e.Row].Label.Equals("=") ||
                        sv.RowHeader.Rows[e.Row].Label.Equals("M"))
                    {
                        sv.RowHeader.Rows[e.Row].Label = "M";
                    }
                    else
                    {
                        sv.RowHeader.Rows[e.Row].Label = "A";
                    }
                }
            }
        }

        //leftColumn 이동 ??
        private void vaSpread1_LeftChange(object sender, LeftChangeEventArgs e)
        {

            // vb topleftchange 와 동일한 기능 : top, left change별도
            //Private Sub vaSpread1_TopLeftChange(ByVal OldLeft As Long, ByVal OldTop As Long, ByVal NewLeft As Long, ByVal NewTop As Long)
            //    vaSpread2.LeftCol = vaSpread1.LeftCol
            //End Sub
            //vaSpread2. = e.NewLeft;

        }

        //leftColumn 이동 ??
        private void vaSpread2_LeftChange(object sender, LeftChangeEventArgs e)
        {
            //Private Sub vaSpread2_TopLeftChange(ByVal OldLeft As Long, ByVal OldTop As Long, ByVal NewLeft As Long, ByVal NewTop As Long)
            //    vaSpread1.LeftCol = vaSpread2.LeftCol
            //End Sub
        }

        private void vaSpread1_CellClick(object sender, CellClickEventArgs e)
        {
            if (e.Row >= 0 && e.Column >= 0 && e.Column != 12)
            {
                SheetView sv = vaSpread1.Sheets[0];
                if (sv.Cells[e.Row, e.Column].Locked == false)
                {
                    if (sv.RowHeader.Rows[e.Row].Label.Equals("=") ||
                        sv.RowHeader.Rows[e.Row].Label.Equals("M"))
                    {
                        sv.RowHeader.Rows[e.Row].Label = "M";
                    }
                    else
                    {
                        sv.RowHeader.Rows[e.Row].Label = "A";
                    }
                }
            }
        }

        private void vaSpread1_CellDoubleClick(object sender, CellClickEventArgs e)
        {
            SheetView sv = vaSpread1.Sheets[0];
            if (e.Row >= 0 && (e.Column == 1 || e.Column == 8 || e.Column == 10 || e.Column == 14 || e.Column == 15))
            {
                if (sv.RowHeader.Rows[e.Row].Label.Equals("=") ||
                    sv.RowHeader.Rows[e.Row].Label.Equals("M"))
                {
                    if (sv.Cells[e.Row, 1].Text.CompareTo("0") > 0)
                    {
                        if (e.Column==2)
                        {
                            //                    F_CE_101.txtProd_no.Text = txtProd_no.Text
                            //                    F_CE_101.txtPumbun.Text = vaSpread1.Text
                            if (sv.Cells[e.Row, 0].Text.Equals("AL")) //'POC 제번의 파트인 경우
                            {
                                //                        vaSpread2.Col = 8 'FP 계산하기 위해서 품번별 진행현황 화면으로 넘김.
                                //                        vaSpread2.Row = 1
                                //                        F_CE_101.fp_total = vaSpread2.Text
                            }
                            else //'POC제번이 아니며 실제 파트인 경우
                            {
                                //                        vaSpread1.Col = 8
                                //                        vaSpread1.Row = Row
                                //                        F_CE_101.fp_total = vaSpread1.Text
                            }
                            //                    Call F_CE_101.BoxNoSet
                            //                    Call F_CE_101.cmdSearch_Click

                            //                    F_CE_101.Show 1
                        }
                        else
                        {
                            string pumbun = sv.Cells[e.Row, 1].Text.Trim();

                            if( txtProd_no.Text.Substring(4, 1).Equals("G")
                                || pumbun.Equals("A361A")
                                || pumbun.Equals("A366A")
                                || pumbun.Equals("A375A"))
                            {
                                //F_CE_102.txtProd_no.Text = txtProd_no.Text
                                //F_CE_102.txtPumbun.Text = vaSpread1.Text
                                //Call F_CE_102.cmdSearch_Click
                                //F_CE_102.Show 1
                            }
                        }
                    }
                }
            }
        }


    }
}
