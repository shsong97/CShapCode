﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ProductionManagement
{
    public partial class F_CA_170 : LForm
    {
        public F_CA_170()
        {
            InitializeComponent();
        }

        public override void F_SEARCH()
        {
            if (txtProdNo.TextLength < 14)
            {
                MessageBox.Show("제번은 14자리입니다");
                return;
            }

            String sql = "exec S_CA_170_1 '" + txtProdNo.Text.Substring(0, 11) + "',"
                     + "'" + txtProdNo.Text.Substring(11, 3) + "',"
                     + "'" + txtGlobal_no.Text + "'";

            GRS g = new GRS(sql);

            if (g.RowCount == 0)
            {
                MessageBox.Show("제번/Global Unit No 을 정확하게 입력하세요!!");
                return;
            }

            string product_code = g.gRS("product_code");
            uCtrl.SetCboIndex(cboProduct, product_code);
            txtBriefTrade.Text = g.gRS("brief_trade");
            txtCostModel.Text = g.gRS("cost_model");
            mskRecvDate.Text = g.gRS("recv_date");
            mskContDate.Text = g.gRS("cont_date");
            txtGlobal_no.Text = g.gRS("unit_no");

            txtModel_type.Text = g.gRS("model_type"); //모델타입
            txtEquip_count.Text = g.gRS("Equip_count"); //대수

            txtGaijung.Text = g.gRS("Gaijung"); //계정
            txtMarket.Text = g.gRS("market_flag"); //시장
            txtSale_emp_name.Text = g.gRS("Sale_emp_name"); //영업담당이름
            txtCountry_name.Text = g.gRS("Country_name"); //국가명
            txtRemark_f1.Text = g.gRS("Remark_f1"); //비고
            
            mskMain_due_date.Text = g.gRS("main_due_date"); //본체 납기
            mskSpec_rslt_date.Text = g.gRS("Spec_rslt_date"); //SPEC확정
            mskGo1_date.Text = g.gRS("Go1_date"); //1차GO일
            mskGo2_date.Text = g.gRS("Go2_date"); //2차GO일

            txtInstAddress.Text = g.gRS("inst_dept_desc"); //설치장소

            //txtMoney_unit.Text = g.gRS("Money_unit"); //화폐단위
            //txtSuju_close_flag.Text = g.gRS("Suju_close_flag"); //제번상태
            //txtInst_emp_id.Text = g.gRS("Inst_emp_id"); //설치부서ID
            //txtInst_dept_desc.Text = g.gRS("Inst_dept_desc"); //설치부서 이름
            //txtTech_dept_desc.Text = g.gRS("Tech_dept_desc"); //영업부서ID
            //txtTech_post_person.Text = g.gRS("Tech_post_person"); //영업부서이름
            //txtCountry_no.Text = g.gRS("Country_no"); //국가ID
            //txtSale_emp_id.Text = g.gRS("Sale_emp_id"); //영업담당ID
            
        }
        public override void F_NEW()
        {
            txtProdNo.Text = ""; //제번
            txtModel_type.Text = ""; //모델타입
            txtEquip_count.Text = ""; //대수
            txtBriefTrade.Text = ""; //  '고객명
            txtGaijung.Text = ""; //계정
            txtMarket.Text = ""; //시장
            txtCostModel.Text = ""; //원가모델
            //txtInst_emp_id.Text = ""; //설치부서ID
            //txtInst_dept_desc.Text = ""; //설치부서 이름
            

            //txtSale_emp_id.Text = "";//  '영업담당ID
            txtSale_emp_name.Text = ""; //영업담당이름
            txtCountry_name.Text = ""; //국가명
            txtRemark_f1.Text = ""; //비고

            mskRecvDate.Text = ""; // '계약일
            mskContDate.Text = ""; // '접수일
            mskMain_due_date.Text = ""; // '본체 납기
            mskSpec_rslt_date.Text = ""; // 'SPEC확정
            mskGo1_date.Text = ""; // '1차GO일
            mskGo2_date.Text = ""; // '2차GO일
        }
        private void F_CA_170_Load(object sender, EventArgs e)
        {
            
            //mdi = (MainMDI)this.Parent.Parent;
            //isButton = "TTTFTT";
            //mdi.g_ButtonInitialize(isButton);

            uCtrl.FillCombo(cboProduct, "A20", "  ");
        }

        private void F_CA_170_Activated(object sender, EventArgs e)
        {
            //mdi.g_ButtonInitialize(isButton);
        }

        private void txtProdNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                F_SEARCH();
        }

        public override void F_DELETE()
        {
            if( MessageBox.Show("해당 제번을 정말 삭제하시겠습니까?","삭제확인",MessageBoxButtons.YesNo) == DialogResult.Yes )
            {
                if( F_DB_Chk("D") )
                {
                    string SQL = "exec S_CA_170_2 'D', "
                        + "'" + txtProdNo.Text.Substring(0, 11) + "',"
                        + "'" + txtProdNo.Text.Substring(11, 3) + "',"
                        + "'" + txtGlobal_no.Text + "'";
                    
                    DBManager.Execute(SQL);
                    F_NEW();
                }
                else
                {
                    MessageBox.Show("해당 제번 삭제작업이 실패하였습니다.\n동일제번이 존재하지 않거나, 제통에 데이타가 존재합니다.");
                }
            }
        }
        private bool F_DB_Chk(string sFlag)
        {
            //해당제번 확인
            string SQL = "exec S_CA_170_3 '" + sFlag + "',"
                        + txtProdNo.Text.Substring(0, 11) + "',"
                        + txtProdNo.Text.Substring(11, 3) + "',"
                        + txtGlobal_no.Text + "',"
                        + txtMarket.Text + "'";
            GRS g=new GRS(SQL);    
            return g.gRSInt(0)==1?true:false;
        }
        public override void F_SAVE()
        {
            if( txtGaijung.Text.Length != 4 ) //계정
            {
                MessageBox.Show( "계정이 정확하지 않습니다.\n작업이 취소됩니다!");
                return;
            }
            if( txtMarket.Text.Length != 1 ) //시장
            {
                MessageBox.Show( "시장이 정확하지 않습니다.\n작업이 취소됩니다!");
                return;
            }
            if( txtCostModel.Text.Length == 0 ) //원가모델
            {
                MessageBox.Show( "원가모델이 정확하지 않습니다.\n작업이 취소됩니다!");
                return;
            }
            if( !uBizDate.g_Date_Check(mskContDate.Text) ) //계약일
            {
                MessageBox.Show( "계약일이 정확하지 않습니다.\n작업이 취소됩니다!");
                return;
            }
            if( !uBizDate.g_Date_Check(mskRecvDate.Text) ) //접수일
            {
                MessageBox.Show( "접수일이 정확하지 않습니다.\n작업이 취소됩니다!");
                return;
            }
            
            
            if( MessageBox.Show("해당 제번을 생성 하시겠습니까?","생성확인",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if( F_DB_Chk("I") )
                {
                    string SQL = "exec S_CA_170_2 'I', "
                    + "'" + txtProdNo.Text.Substring(0, 11) + "',"
                    + "'" + txtProdNo.Text.Substring(11, 3) + "',"
                    + "'" + txtGlobal_no.Text + "',"
                    + "'" + txtGaijung.Text + "',"
                    + "'" + Strings.Right(cboProduct.Text, 2) + "',"
                    + "'" + txtMarket.Text + "',"
                    + "'" + txtModel_type.Text + "',"
                    + "'" + txtCostModel.Text + "',"
                    + "'" + txtEquip_count.Text + "',"
                    + "'" + "" + "',"
                    + "'" + "" + "',"
                    + "'" + "" + "',"
                    + "'" + "" + "',"
                    + "'" + txtBriefTrade.Text + "',"
                    + "'" + "" + "',"
                    + "'" + "" + "',"
                    + "'" + mskRecvDate.Text + "',"
                    + "'" + mskContDate.Text + "',"
                    + "'" + "" + "',"
                    + "'" + mskMain_due_date.Text + "',"
                    + "'" + mskGo1_date.Text + "',"
                    + "'" + mskGo2_date.Text + "',"
                    + "'" + ""+ "',"
                    + "'" + txtRemark_f1.Text + "',"
                    + "'" + GlobalSetting.gUserID + "',"
                    + "'" + "" + "'";
                    GRS g=new GRS(SQL);
                    
                    F_SEARCH();
                }
                else
                {
                    MessageBox.Show("해당 제번 생성작업이 실패하였습니다.\n동일제번이 존재 또는 제번형식을 확인 바랍니다.");
                    return;
                }
            }
        }
    }
}
