﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FarPoint.Win.Spread;

namespace ProductionManagement
{
    public partial class F_EX_000 : LForm
    {
        public F_EX_000()
        {
            InitializeComponent();
        }

        public override void F_SEARCH()
        {
            string SQL="select * from T_EX_001  order by code_SELECT ";
            GRS g = new GRS(SQL);

            SheetView sv=sprList.Sheets[0];
            int rowCount = g.RowCount;
            if (rowCount > 0)
            {
                uSpread.MaxRows(sprList,0);
                uSpread.MaxRows(sprList,rowCount+20);
                for(int i=0;i<rowCount;i++)
                {
                    sv.RowHeader.Rows[i].Label = "=";
                    sv.Cells[i, 0].Text = g.gRS("code_select");
                    sv.Cells[i, 0].Locked = true;
                    sv.Cells[i, 1].Text = g.gRS("code_select_desc");
                    sv.Cells[i, 2].Text = g.gRS("tablename");
                    sv.Cells[i, 3].Text = g.gRS("length");
                    sv.Cells[i, 4].Text = g.gRS("min_length");
                    g.MoveNext();
                }

                if (rowCount == 0)
                {
                    MessageBox.Show("해당 데이터가 존재하지 않습니다.", "조회");
                }
            }

            
        }

        public override void F_SAVE()
        {
            int upd_cnt = 0;
            
            SheetView sv=sprList.Sheets[0];
            int dataRowCnt = sv.RowCount;
            for(int i=0;i<dataRowCnt;i++)
            {
                if (sv.RowHeader.Rows[i].Label.Equals("M") || sv.RowHeader.Rows[i].Label.Equals("A"))
                {
                    if ( uSpread.Spread_Unit_Data_Get(sprList, i, 0).Length != 3) 
                    {
                        MessageBox.Show("3자리만큼 코드를 입력하세요");
                        // focus 이동 후, 수정 모드로 변경
                        //Call g_Spread_SetCell(sprList, 1, i)
                        //.EditMode = True
                        return;
                    }
                    if( uSpread.Spread_Unit_Data_Get(sprList, i, 1).CompareTo("") < 0 )
                    { 
                        MessageBox.Show("Description을 다시 입력하세요");
                        //Call g_Spread_SetCell(sprList, 2, i)
                        //.EditMode = True
                        return;
                    }

                    if( uSpread.Spread_Unit_Data_Get(sprList, i, 2).CompareTo("") < 0 )
                    {
                        MessageBox.Show("Table Name을 다시 입력하세요");
                        //Call g_Spread_SetCell(sprList, 3, i)
                        //.EditMode = True
                        return;
                    }

                    if( uSpread.Spread_Unit_Data_Get(sprList, i, 3).Equals("") )
                    {
                        MessageBox.Show("Length을 다시 입력하세요");
                        //Call g_Spread_SetCell(sprList, 4, i)
                        //.EditMode = True
                        return;
                    }

                    if( uSpread.Spread_Unit_Data_Get(sprList, i, 4).Equals("") )
                    {
                        MessageBox.Show("Minimum Length을 다시 입력하세요");
                        //Call g_Spread_SetCell(sprList, 5, i)
                        //.EditMode = True
                        return;
                    }

                    upd_cnt++;
                    string SQL="";
                    if(sv.RowHeader.Rows[i].Label.Equals("M"))
                    {
                        sv.RowHeader.Rows[i].Label = "=";
                        SQL = " update T_EX_001 set code_select_desc = '" + 
                            uSpread.Spread_Unit_Data_Get(sprList, i, 1) + "', TABLENAME ='" +
                            uSpread.Spread_Unit_Data_Get(sprList, i, 2).ToUpper() + "',LENGTH=" +
                            uSpread.Spread_Unit_Data_Get(sprList, i, 3) + ",min_length= " +
                            uSpread.Spread_Unit_Data_Get(sprList, i, 4) + " " +
                            " from t_ex_001 where code_select = '" + 
                            uSpread.Spread_Unit_Data_Get(sprList, i, 0).ToUpper() + "' ";
                        DBManager.Execute(SQL);
                        //MessageBox.Show(SQL);
                    }
                    else
                    {
                        sv.RowHeader.Rows[i].Label = "=";
                        SQL = " insert into T_EX_001 values ('" + 
                            uSpread.Spread_Unit_Data_Get(sprList, i, 0).ToUpper() + "','" +
                            uSpread.Spread_Unit_Data_Get(sprList, i, 1) + "','" + 
                            uSpread.Spread_Unit_Data_Get(sprList, i, 2).ToUpper() + "'," + 
                            uSpread.Spread_Unit_Data_Get(sprList, i, 3) + "," + 
                            uSpread.Spread_Unit_Data_Get(sprList, i, 4) + ")";
                        DBManager.Execute(SQL);
                        //MessageBox.Show(SQL);
                    }

                }
            }
            
            MessageBox.Show(upd_cnt + "건의 자료가 저장되었읍니다");
            F_SEARCH();
        }

        public override void F_DELETE()
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show(this, "선택한 레코드를 삭제 합니다!", "삭제확인", buttons, MessageBoxIcon.Exclamation);
            if (result == DialogResult.No)
            {
                this.Cursor = Cursors.Default;//조회끝
                sprList.Enabled = true;
            }
            else
            {
                int row = sprList.Sheets[0].ActiveRow.Index;
                string SQL = "delete from t_ex_001 where code_select = '" + uSpread.Spread_Unit_Data_Get(sprList, row, 0) + "'";
                DBManager.Execute(SQL);
                //MessageBox.Show(SQL);
                F_SEARCH();
            }
        }


        private void F_EX_000_Activated()
        {
            mdi.g_ButtonInitialize(isButton);
        }

        private void F_EX_000_Load(object sender, EventArgs e)
        {
            mdi = (MainMDI)this.Parent.Parent;
            mdi.g_ButtonInitialize(isButton);
            F_SEARCH();
        }

        private void sprList_Change(object sender, FarPoint.Win.Spread.ChangeEventArgs e)
        {
            uSpread.Set_Change_Spread_Event(sprList, e.Column, e.Row);
        }
    }
}
