﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using FarPoint.Win.Spread;

namespace ProductionManagement
{
    public partial class F_HELP_ProdNo : Form
    {
        public string ProdNo = "";
        public F_HELP_ProdNo()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string SQL="";
    
            if( Strings.Right(cboSort.Text, 1) == "A" )
            {
                SQL = "select project_no + mfg_no, BRIEF_TRADE,MODEL_TYPE,MARKET_FLAG,EQUIP_COUNT,UNIT_NO from el_cd.dbo.T_CC_010 " 
                     + " where project_no between '" + txtProd_no.Text + "' and '" + txtProd_no.Text + "zzzz'";

            }
            else
            {
                SQL = "select project_no + mfg_no, BRIEF_TRADE,MODEL_TYPE,MARKET_FLAG,EQUIP_COUNT,UNIT_NO from el_cd.dbo.T_CC_010 " 
                     + " where brief_trade like '%" + txtProd_no.Text + "%'";
            }
            
            GRS g=new GRS(SQL);
            SheetView sv = fpSpread1.Sheets[0];
            
            if( g.RowCount == 0 )
            {
                lab_cnt.Text = "0";
                sv.RowCount = 0;
                MessageBox.Show("해당 제번이 존재하지 않습니다.","조회");
            }
            else
            {
                lab_cnt.Text = g.RowCount.ToString();
                sv.RowCount = g.RowCount;
                for (int i = 0; i < g.RowCount; i++)
                {
                    sv.Cells[i, 0].Text = g.gRS(0);
                    sv.Cells[i, 1].Text = g.gRS(1);
                    sv.Cells[i, 2].Text = g.gRS(2);
                    sv.Cells[i, 3].Text = g.gRS(3);
                    sv.Cells[i, 4].Text = g.gRS(4);
                    sv.Cells[i, 5].Text = g.gRS(5);
                    g.MoveNext();
                }
            }
            
        }

        private void F_HELP_ProdNo_Load(object sender, EventArgs e)
        {
            cboSort.SelectedIndex = 0;
        }


        private void fpSpread1_CellDoubleClick(object sender, CellClickEventArgs e)
        {
            ProdNo = fpSpread1.Sheets[0].Cells[e.Row, 0].Text;
            this.Close();
        }
    }
}
