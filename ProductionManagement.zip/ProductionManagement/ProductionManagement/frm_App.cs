﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

public partial class frm_App : Form
{
    public frm_App()
    {
        InitializeComponent();
    }

    private void frm_App_Load(object sender, EventArgs e)
    {
        CenterToParent();
        //Animation1.Open App.path & "\icon\FILECOPY.AVI"
        //ZOrder
    }
}

