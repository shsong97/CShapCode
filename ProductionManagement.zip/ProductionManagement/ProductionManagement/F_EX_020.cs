﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FarPoint.Win.Spread;

namespace ProductionManagement
{
    public partial class F_EX_020 : LForm
    {
        int  Code_length, Code_min_length;
        string Code_Select, Table_Name = "T_EX_000";

        public F_EX_020()
        {
            InitializeComponent();
        }

        private void cboCodeFlag_Click(object sender, EventArgs e)
        {

        }

        private void F_EX_020_Activated(object sender, EventArgs e)
        {
            mdi.g_ButtonInitialize(isButton);
        }

        private void F_EX_020_Load(object sender, EventArgs e)
        {
            mdi = (MainMDI)this.Parent.Parent;
            mdi.g_ButtonInitialize(isButton);
            int s_len = 0, m_len=0;

            string SQL = "select * from t_ex_001 WHERE TABLENAME =  '" + Table_Name + "' ORDER BY  code_SELECT ";
            GRS g=new GRS(SQL);

            SheetView sv = sprList.Sheets[0];
            int rowCount = g.RowCount;
            if (rowCount > 0)
            {
                cboCodeFlag.Items.Clear();

                for (int i = 0; i < rowCount; i++)
                {
                    s_len = g.gRS("length").Length;
                    m_len = g.gRS("min_length").Length;

                    string slength=s_len == 1?"0" + g.gRS("LENGTH"):g.gRS("LENGTH");
                    string mlength=s_len == 1?"0" + g.gRS("min_LENGTH"):g.gRS("min_LENGTH");
                    string item=g.gRS("CODE_SELECT_DESC") + 
                        Space(35 - g.gRS("CODE_SELECT_DESC").Length * 2) + 
                        g.gRS("CODE_SELECT") + " " + slength + " " + mlength;
                    cboCodeFlag.Items.Add(item);
                    g.MoveNext();
                }


                cboCodeFlag.SelectedIndex = 0;

            }
            else
            {
                MessageBox.Show("해당 데이터가 존재하지 않습니다.", "조회");
            }
        }
        public string Space(int length)
        {
            if (length < 0)
                return "     ";


            return "            ";
        }
        public override void F_SEARCH()
        {
            string SQL = "select code,code_desc,update_man,date_update from " + Table_Name + " where code_select = '" + Code_Select + "' and code between '0' and 'ZZZZZ' order by code ";
            GRS g=new GRS(SQL);

            uSpread.MaxRows(sprList, 0);           
            SheetView sv = sprList.Sheets[0];
            int rowCount = g.RowCount;
            if (rowCount > 0)
            {
                uSpread.MaxRows(sprList, rowCount + 20);
                for (int i = 0; i < rowCount; i++)
                {
                    sv.RowHeader.Rows[i].Label = "=";
                    sv.Cells[i, 0].Text = g.gRS("code");
                    sv.Cells[i, 0].Locked = true;
                    sv.Cells[i, 1].Text = g.gRS("code_desc");
                    sv.Cells[i, 2].Text = g.gRS("update_man");
                    sv.Cells[i, 3].Text = g.gRS("date_update");
                    g.MoveNext();
                }

                if (rowCount == 0)
                {
                    MessageBox.Show("해당 데이터가 존재하지 않습니다.", "조회");
                }
            }
            else
            {
                uSpread.MaxRows(sprList, 20);
            }
        }

        public override void F_SAVE()
        {
            int upd_cnt = 0;

            SheetView sv = sprList.Sheets[0];
            int dataRowCnt = sv.RowCount;
            for (int i = 0; i < dataRowCnt; i++)
            {
                if (sv.RowHeader.Rows[i].Label.Equals("M") || sv.RowHeader.Rows[i].Label.Equals("A"))
                {
                    if (int.Parse(uSpread.Spread_Unit_Data_Get(sprList, i, 0))<Code_min_length ||
                        uSpread.Spread_Unit_Data_Get(sprList, i, 0).Length>Code_length)
                    {
                        MessageBox.Show(Code_min_length + "자리만큼 코드를 입력하세요");
                        // focus 이동 후, 수정 모드로 변경
                        //Call g_Spread_SetCell(sprList, 1, i)
                        //.EditMode = True
                        return;
                    }
                    if (uSpread.Spread_Unit_Data_Get(sprList, i, 1).CompareTo("") < 0)
                    {
                        MessageBox.Show("Description을 다시 입력하세요");
                        //Call g_Spread_SetCell(sprList, 2, i)
                        //.EditMode = True
                        return;
                    }

                    upd_cnt++;
                    string SQL = "";
                    if (sv.RowHeader.Rows[i].Label.Equals("M"))
                    {
                        sv.RowHeader.Rows[i].Label = "=";
                        SQL = " update " + Table_Name + " set code_desc = '" +
                                uSpread.Spread_Unit_Data_Get(sprList, i, 1).ToUpper() +
                                "', update_man='" + mdi.gUserID + "',date_update = getdate() " +
                                " from " + Table_Name + " where code_select = '" + Code_Select +
                                "' and code = '" + uSpread.Spread_Unit_Data_Get(sprList, i, 0).ToUpper() + "' ";
                        DBManager.Execute(SQL);
                        //MessageBox.Show(SQL);
                    }
                    else
                    {
                        SQL = "select * from " + Table_Name + " where code_select= '" +
                            Code_Select + "' and code='" + uSpread.Spread_Unit_Data_Get(sprList, i, 0).ToUpper() + "'";
                        
                        GRS g1=new GRS(SQL);
                        if (g1.RowCount > 0)
                        {
                            MessageBox.Show("이미 있는 코드 입니다.?\n다른 코드를 입력해 주세요.!");
                            //Call g_Spread_SetCell(sprList, 1, i)
                            //.EditMode = True
                            return;
                        }
                        else
                        {
                            sv.RowHeader.Rows[i].Label = "=";
                            SQL = " insert into " + Table_Name + " values ('" + Code_Select + "','" +
                            uSpread.Spread_Unit_Data_Get(sprList, i, 0).ToUpper() + "','" +
                            uSpread.Spread_Unit_Data_Get(sprList, i, 1) + "','" +
                            mdi.gUserID + "',getdate()) ";
                            DBManager.Execute(SQL);
                            //MessageBox.Show(SQL);
                        }
                    }

                }
            }

            MessageBox.Show(upd_cnt + "건의 자료가 저장되었읍니다");
            F_SEARCH();
        }

        public override void F_DELETE()
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show(this, "선택한 레코드를 삭제 합니다!", "삭제확인", buttons, MessageBoxIcon.Exclamation);
            if (result == DialogResult.No)
            {
                this.Cursor = Cursors.Default;//조회끝
                sprList.Enabled = true;
            }
            else
            {
                int row = sprList.Sheets[0].ActiveRow.Index;
                string SQL = "delete from " + Table_Name + " where code_select = '" + Code_Select + "' and code = '" + uSpread.Spread_Unit_Data_Get(sprList, row, 0) + "'";
                DBManager.Execute(SQL);
                //MessageBox.Show(SQL);
                F_SEARCH();
            }
        }

        private void sprList_Change(object sender, FarPoint.Win.Spread.ChangeEventArgs e)
        {
            uSpread.Set_Change_Spread_Event(sprList, e.Column, e.Row);
        }

        private void cboCodeFlag_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s_code = cboCodeFlag.Text.Substring(cboCodeFlag.Text.Length - 9, 9);
            Code_Select = s_code.Substring(0, 3);
            Code_length = int.Parse(s_code.Substring(4, 2));
            Code_min_length = int.Parse(s_code.Substring(7, 2));
            F_SEARCH();
        }
    }
}
