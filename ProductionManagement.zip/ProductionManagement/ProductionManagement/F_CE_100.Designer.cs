﻿namespace ProductionManagement
{
    partial class F_CE_100
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.ComplexBorder complexBorder1 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder2 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder3 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder4 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder5 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder6 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder7 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder8 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder9 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.Spread.CellType.MaskCellType maskCellType1 = new FarPoint.Win.Spread.CellType.MaskCellType();
            FarPoint.Win.ComplexBorder complexBorder10 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.Spread.CellType.MaskCellType maskCellType2 = new FarPoint.Win.Spread.CellType.MaskCellType();
            FarPoint.Win.ComplexBorder complexBorder11 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder12 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder13 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder14 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder15 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder16 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder17 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder18 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder19 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder20 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder21 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder22 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder23 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder24 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder25 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.ComplexBorder complexBorder26 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType2 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType1 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType2 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType3 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType4 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType5 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType6 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType1 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType7 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType8 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType9 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType10 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType11 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType2 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType12 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType13 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType14 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer3 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer4 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType15 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType16 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType17 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType18 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType19 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType20 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType4 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType21 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType22 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType23 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType24 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType25 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType5 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType26 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType27 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType28 = new FarPoint.Win.Spread.CellType.NumberCellType();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProd_no = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.mebProcDate = new System.Windows.Forms.MaskedTextBox();
            this.cmd25 = new System.Windows.Forms.Button();
            this.cmdAct = new System.Windows.Forms.Button();
            this.cmdCompute = new System.Windows.Forms.Button();
            this.cmdContDist = new System.Windows.Forms.Button();
            this.cmdAllSet = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPart = new System.Windows.Forms.TextBox();
            this.cmdReverse = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.cmdConfirm = new System.Windows.Forms.Button();
            this.cmdHold = new System.Windows.Forms.Button();
            this.lblDormant = new System.Windows.Forms.Label();
            this.cmdCostCalc = new System.Windows.Forms.Button();
            this.cmdMoveInquiry = new System.Windows.Forms.Button();
            this.vaSpread0 = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.sprHead = new FarPoint.Win.Spread.FpSpread();
            this.sprHead_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.vaSpread3 = new FarPoint.Win.Spread.FpSpread();
            this.vaSpread3_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.vaSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.vaSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.cmdCompCancel0 = new System.Windows.Forms.Button();
            this.cmdCompCancel1 = new System.Windows.Forms.Button();
            this.cmdTransWB1 = new System.Windows.Forms.Button();
            this.cmdTransWB0 = new System.Windows.Forms.Button();
            this.vaSpread2 = new FarPoint.Win.Spread.FpSpread();
            this.vaSpread2_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.cmdZero = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread3_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread1_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread2_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "제  번";
            // 
            // txtProd_no
            // 
            this.txtProd_no.Location = new System.Drawing.Point(55, 8);
            this.txtProd_no.Name = "txtProd_no";
            this.txtProd_no.Size = new System.Drawing.Size(108, 20);
            this.txtProd_no.TabIndex = 1;
            this.txtProd_no.TextChanged += new System.EventHandler(this.txtProd_no_TextChanged);
            this.txtProd_no.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProd_no_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "처리일자";
            // 
            // mebProcDate
            // 
            this.mebProcDate.Location = new System.Drawing.Point(73, 40);
            this.mebProcDate.Name = "mebProcDate";
            this.mebProcDate.Size = new System.Drawing.Size(90, 20);
            this.mebProcDate.TabIndex = 3;
            // 
            // cmd25
            // 
            this.cmd25.Location = new System.Drawing.Point(169, 8);
            this.cmd25.Name = "cmd25";
            this.cmd25.Size = new System.Drawing.Size(50, 29);
            this.cmd25.TabIndex = 4;
            this.cmd25.Text = "~25";
            this.cmd25.UseVisualStyleBackColor = true;
            this.cmd25.Click += new System.EventHandler(this.cmd25_Click);
            // 
            // cmdAct
            // 
            this.cmdAct.Location = new System.Drawing.Point(225, 8);
            this.cmdAct.Name = "cmdAct";
            this.cmdAct.Size = new System.Drawing.Size(50, 29);
            this.cmdAct.TabIndex = 5;
            this.cmdAct.Text = "실적";
            this.cmdAct.UseVisualStyleBackColor = true;
            this.cmdAct.Click += new System.EventHandler(this.cmdAct_Click);
            // 
            // cmdCompute
            // 
            this.cmdCompute.Location = new System.Drawing.Point(281, 8);
            this.cmdCompute.Name = "cmdCompute";
            this.cmdCompute.Size = new System.Drawing.Size(53, 29);
            this.cmdCompute.TabIndex = 6;
            this.cmdCompute.Text = "All반영";
            this.cmdCompute.UseVisualStyleBackColor = true;
            this.cmdCompute.Click += new System.EventHandler(this.cmdCompute_Click);
            // 
            // cmdContDist
            // 
            this.cmdContDist.Location = new System.Drawing.Point(340, 8);
            this.cmdContDist.Name = "cmdContDist";
            this.cmdContDist.Size = new System.Drawing.Size(55, 29);
            this.cmdContDist.TabIndex = 7;
            this.cmdContDist.Text = "배분";
            this.cmdContDist.UseVisualStyleBackColor = true;
            this.cmdContDist.Click += new System.EventHandler(this.cmdContDist_Click);
            // 
            // cmdAllSet
            // 
            this.cmdAllSet.Location = new System.Drawing.Point(169, 40);
            this.cmdAllSet.Name = "cmdAllSet";
            this.cmdAllSet.Size = new System.Drawing.Size(33, 25);
            this.cmdAllSet.TabIndex = 8;
            this.cmdAllSet.Text = "All";
            this.cmdAllSet.UseVisualStyleBackColor = true;
            this.cmdAllSet.Click += new System.EventHandler(this.cmdAllSet_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(210, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "파트";
            // 
            // txtPart
            // 
            this.txtPart.Location = new System.Drawing.Point(247, 40);
            this.txtPart.Name = "txtPart";
            this.txtPart.Size = new System.Drawing.Size(75, 20);
            this.txtPart.TabIndex = 10;
            // 
            // cmdReverse
            // 
            this.cmdReverse.Location = new System.Drawing.Point(328, 40);
            this.cmdReverse.Name = "cmdReverse";
            this.cmdReverse.Size = new System.Drawing.Size(27, 20);
            this.cmdReverse.TabIndex = 11;
            this.cmdReverse.Text = "-";
            this.cmdReverse.UseVisualStyleBackColor = true;
            this.cmdReverse.Click += new System.EventHandler(this.cmdReverse_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.Location = new System.Drawing.Point(15, 66);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(61, 26);
            this.cmdCancel.TabIndex = 12;
            this.cmdCancel.Text = "해제";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // cmdConfirm
            // 
            this.cmdConfirm.Location = new System.Drawing.Point(82, 66);
            this.cmdConfirm.Name = "cmdConfirm";
            this.cmdConfirm.Size = new System.Drawing.Size(64, 26);
            this.cmdConfirm.TabIndex = 13;
            this.cmdConfirm.Text = "확정";
            this.cmdConfirm.UseVisualStyleBackColor = true;
            this.cmdConfirm.Click += new System.EventHandler(this.cmdConfirm_Click);
            // 
            // cmdHold
            // 
            this.cmdHold.Location = new System.Drawing.Point(152, 67);
            this.cmdHold.Name = "cmdHold";
            this.cmdHold.Size = new System.Drawing.Size(63, 25);
            this.cmdHold.TabIndex = 14;
            this.cmdHold.Text = "Hold";
            this.cmdHold.UseVisualStyleBackColor = true;
            this.cmdHold.Click += new System.EventHandler(this.cmdHold_Click);
            // 
            // lblDormant
            // 
            this.lblDormant.Location = new System.Drawing.Point(224, 67);
            this.lblDormant.Name = "lblDormant";
            this.lblDormant.Size = new System.Drawing.Size(171, 25);
            this.lblDormant.TabIndex = 15;
            // 
            // cmdCostCalc
            // 
            this.cmdCostCalc.Location = new System.Drawing.Point(435, 87);
            this.cmdCostCalc.Name = "cmdCostCalc";
            this.cmdCostCalc.Size = new System.Drawing.Size(110, 22);
            this.cmdCostCalc.TabIndex = 16;
            this.cmdCostCalc.Text = "발송원가계산";
            this.cmdCostCalc.UseVisualStyleBackColor = true;
            this.cmdCostCalc.Click += new System.EventHandler(this.cmdCostCalc_Click);
            // 
            // cmdMoveInquiry
            // 
            this.cmdMoveInquiry.Location = new System.Drawing.Point(551, 86);
            this.cmdMoveInquiry.Name = "cmdMoveInquiry";
            this.cmdMoveInquiry.Size = new System.Drawing.Size(116, 23);
            this.cmdMoveInquiry.TabIndex = 17;
            this.cmdMoveInquiry.Text = "이동계획조회";
            this.cmdMoveInquiry.UseVisualStyleBackColor = true;
            this.cmdMoveInquiry.Click += new System.EventHandler(this.cmdMoveInquiry_Click);
            // 
            // vaSpread0
            // 
            this.vaSpread0.AccessibleDescription = "vaSpread0, Sheet1, Row 0, Column 0, 수주가(CW)";
            this.vaSpread0.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            this.vaSpread0.Location = new System.Drawing.Point(401, 8);
            this.vaSpread0.Name = "vaSpread0";
            this.vaSpread0.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.vaSpread0.Size = new System.Drawing.Size(631, 44);
            this.vaSpread0.TabIndex = 18;
            this.vaSpread0.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 6;
            this.fpSpread1_Sheet1.RowCount = 2;
            this.fpSpread1_Sheet1.Cells.Get(0, 0).Border = complexBorder1;
            this.fpSpread1_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 0).Value = "수주가(CW)";
            this.fpSpread1_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 1).Border = complexBorder2;
            this.fpSpread1_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 1).Value = "수주가(BLK)";
            this.fpSpread1_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 2).Border = complexBorder3;
            this.fpSpread1_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.fpSpread1_Sheet1.Cells.Get(0, 2).Value = "출하";
            this.fpSpread1_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 3).Border = complexBorder4;
            this.fpSpread1_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 3).Value = "설계완료";
            this.fpSpread1_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 4).Border = complexBorder5;
            this.fpSpread1_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 4).Value = "POC";
            this.fpSpread1_Sheet1.Cells.Get(0, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 5).Border = complexBorder6;
            this.fpSpread1_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(0, 5).Value = "Processing Message";
            this.fpSpread1_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.Cells.Get(1, 0).Border = complexBorder7;
            this.fpSpread1_Sheet1.Cells.Get(1, 1).Border = complexBorder8;
            this.fpSpread1_Sheet1.Cells.Get(1, 2).Border = complexBorder9;
            maskCellType1.Mask = "####-##-##";
            this.fpSpread1_Sheet1.Cells.Get(1, 2).CellType = maskCellType1;
            this.fpSpread1_Sheet1.Cells.Get(1, 3).Border = complexBorder10;
            maskCellType2.Mask = "####-##-##";
            this.fpSpread1_Sheet1.Cells.Get(1, 3).CellType = maskCellType2;
            this.fpSpread1_Sheet1.Cells.Get(1, 4).Border = complexBorder11;
            this.fpSpread1_Sheet1.Cells.Get(1, 5).Border = complexBorder12;
            this.fpSpread1_Sheet1.ColumnHeader.Visible = false;
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 96F;
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 93F;
            this.fpSpread1_Sheet1.Columns.Get(2).Width = 86F;
            this.fpSpread1_Sheet1.Columns.Get(3).Width = 76F;
            this.fpSpread1_Sheet1.Columns.Get(4).Width = 49F;
            this.fpSpread1_Sheet1.Columns.Get(5).Width = 247F;
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.RowHeader.Visible = false;
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // sprHead
            // 
            this.sprHead.AccessibleDescription = "fpSpread2, Sheet1, Row 0, Column 0, A";
            this.sprHead.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            this.sprHead.Location = new System.Drawing.Point(415, 56);
            this.sprHead.Name = "sprHead";
            this.sprHead.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprHead_Sheet1});
            this.sprHead.Size = new System.Drawing.Size(252, 24);
            this.sprHead.TabIndex = 19;
            this.sprHead.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            // 
            // sprHead_Sheet1
            // 
            this.sprHead_Sheet1.Reset();
            this.sprHead_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprHead_Sheet1.ColumnCount = 6;
            this.sprHead_Sheet1.RowCount = 1;
            this.sprHead_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sprHead_Sheet1.Cells.Get(0, 0).Border = complexBorder13;
            this.sprHead_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead_Sheet1.Cells.Get(0, 0).Value = "A";
            this.sprHead_Sheet1.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sprHead_Sheet1.Cells.Get(0, 1).Border = complexBorder14;
            this.sprHead_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead_Sheet1.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sprHead_Sheet1.Cells.Get(0, 2).Border = complexBorder15;
            this.sprHead_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead_Sheet1.Cells.Get(0, 2).Value = "B";
            this.sprHead_Sheet1.Cells.Get(0, 3).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sprHead_Sheet1.Cells.Get(0, 3).Border = complexBorder16;
            this.sprHead_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead_Sheet1.Cells.Get(0, 4).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sprHead_Sheet1.Cells.Get(0, 4).Border = complexBorder17;
            this.sprHead_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead_Sheet1.Cells.Get(0, 4).Value = "C";
            this.sprHead_Sheet1.Cells.Get(0, 5).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sprHead_Sheet1.Cells.Get(0, 5).Border = complexBorder18;
            this.sprHead_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprHead_Sheet1.ColumnHeader.Visible = false;
            this.sprHead_Sheet1.Columns.Get(0).Width = 26F;
            this.sprHead_Sheet1.Columns.Get(2).Width = 21F;
            this.sprHead_Sheet1.Columns.Get(4).Width = 21F;
            this.sprHead_Sheet1.GrayAreaBackColor = System.Drawing.Color.Silver;
            this.sprHead_Sheet1.NullBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sprHead_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprHead_Sheet1.RowHeader.Visible = false;
            this.sprHead_Sheet1.SelectionBackColor = System.Drawing.Color.White;
            this.sprHead_Sheet1.SelectionForeColor = System.Drawing.Color.White;
            this.sprHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // vaSpread3
            // 
            this.vaSpread3.AccessibleDescription = "fpSpread3, Sheet1, Row 0, Column 0, 납선";
            this.vaSpread3.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            this.vaSpread3.Location = new System.Drawing.Point(673, 56);
            this.vaSpread3.Name = "vaSpread3";
            this.vaSpread3.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.vaSpread3_Sheet1});
            this.vaSpread3.Size = new System.Drawing.Size(359, 44);
            this.vaSpread3.TabIndex = 20;
            this.vaSpread3.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            // 
            // vaSpread3_Sheet1
            // 
            this.vaSpread3_Sheet1.Reset();
            this.vaSpread3_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.vaSpread3_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.vaSpread3_Sheet1.ColumnCount = 4;
            this.vaSpread3_Sheet1.RowCount = 2;
            this.vaSpread3_Sheet1.Cells.Get(0, 0).Border = complexBorder19;
            this.vaSpread3_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.vaSpread3_Sheet1.Cells.Get(0, 0).Value = "납선";
            this.vaSpread3_Sheet1.Cells.Get(0, 1).Border = complexBorder20;
            this.vaSpread3_Sheet1.Cells.Get(0, 2).Border = complexBorder21;
            this.vaSpread3_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.vaSpread3_Sheet1.Cells.Get(0, 2).Value = "KMDL";
            this.vaSpread3_Sheet1.Cells.Get(0, 3).Border = complexBorder22;
            this.vaSpread3_Sheet1.Cells.Get(1, 0).Border = complexBorder23;
            this.vaSpread3_Sheet1.Cells.Get(1, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.vaSpread3_Sheet1.Cells.Get(1, 0).Value = "모델";
            this.vaSpread3_Sheet1.Cells.Get(1, 1).Border = complexBorder24;
            this.vaSpread3_Sheet1.Cells.Get(1, 2).Border = complexBorder25;
            this.vaSpread3_Sheet1.Cells.Get(1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.vaSpread3_Sheet1.Cells.Get(1, 2).Value = "대수";
            this.vaSpread3_Sheet1.Cells.Get(1, 3).Border = complexBorder26;
            this.vaSpread3_Sheet1.ColumnHeader.Visible = false;
            this.vaSpread3_Sheet1.Columns.Get(0).Width = 40F;
            this.vaSpread3_Sheet1.Columns.Get(1).Width = 204F;
            this.vaSpread3_Sheet1.Columns.Get(2).Width = 39F;
            this.vaSpread3_Sheet1.Columns.Get(3).Width = 72F;
            this.vaSpread3_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.vaSpread3_Sheet1.RowHeader.Visible = false;
            this.vaSpread3_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // vaSpread1
            // 
            this.vaSpread1.AccessibleDescription = "vaSpread1, Sheet1, Row 0, Column 0, ";
            this.vaSpread1.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.vaSpread1.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.vaSpread1.HorizontalScrollBar.Name = "";
            this.vaSpread1.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.vaSpread1.HorizontalScrollBar.TabIndex = 8;
            this.vaSpread1.Location = new System.Drawing.Point(12, 115);
            this.vaSpread1.Name = "vaSpread1";
            this.vaSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.vaSpread1_Sheet1});
            this.vaSpread1.Size = new System.Drawing.Size(1030, 354);
            this.vaSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.vaSpread1.TabIndex = 21;
            this.vaSpread1.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.vaSpread1.VerticalScrollBar.Name = "";
            this.vaSpread1.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.vaSpread1.VerticalScrollBar.TabIndex = 9;
            this.vaSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.vaSpread1.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.vaSpread1_CellClick);
            this.vaSpread1.Change += new FarPoint.Win.Spread.ChangeEventHandler(this.vaSpread1_Change);
            this.vaSpread1.LeftChange += new FarPoint.Win.Spread.LeftChangeEventHandler(this.vaSpread1_LeftChange);
            this.vaSpread1.CellDoubleClick += new FarPoint.Win.Spread.CellClickEventHandler(this.vaSpread1_CellDoubleClick);
            this.vaSpread1.ButtonClicked += new FarPoint.Win.Spread.EditorNotifyEventHandler(this.vaSpread1_ButtonClicked);
            // 
            // vaSpread1_Sheet1
            // 
            this.vaSpread1_Sheet1.Reset();
            this.vaSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.vaSpread1_Sheet1.ColumnCount = 23;
            this.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "파트";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "품번";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "차수";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "품번명";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "수주량";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "생산량";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "출하량";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "F/P";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "F/P생산액";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "생산완료";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "F/P매출액";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "매출완료";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 12).Value = "처리";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 13).Value = "수주가";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 14).Value = "생산액";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 15).Value = "매출액";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 16).Value = "포장량";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 17).Value = "포장비";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 18).Value = "포장일자";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 19).Value = "처리";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 20).Value = "CLC";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 21).Value = "CTC";
            this.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 22).Value = "해상운반비";
            this.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 42F;
            textCellType1.MaxLength = 2;
            this.vaSpread1_Sheet1.Columns.Get(0).CellType = textCellType1;
            this.vaSpread1_Sheet1.Columns.Get(0).Label = "파트";
            this.vaSpread1_Sheet1.Columns.Get(0).Width = 31F;
            this.vaSpread1_Sheet1.Columns.Get(1).CellType = textCellType2;
            this.vaSpread1_Sheet1.Columns.Get(1).Label = "품번";
            this.vaSpread1_Sheet1.Columns.Get(2).Label = "차수";
            this.vaSpread1_Sheet1.Columns.Get(2).Width = 35F;
            this.vaSpread1_Sheet1.Columns.Get(3).Label = "품번명";
            this.vaSpread1_Sheet1.Columns.Get(3).Width = 121F;
            numberCellType1.DecimalPlaces = 0;
            numberCellType1.MaximumValue = 10000000;
            numberCellType1.MinimumValue = -10000000;
            numberCellType1.Separator = ",";
            numberCellType1.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(4).CellType = numberCellType1;
            this.vaSpread1_Sheet1.Columns.Get(4).Label = "수주량";
            this.vaSpread1_Sheet1.Columns.Get(4).Width = 67F;
            numberCellType2.DecimalPlaces = 0;
            numberCellType2.MaximumValue = 10000000;
            numberCellType2.MinimumValue = -10000000;
            numberCellType2.Separator = ",";
            numberCellType2.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(5).CellType = numberCellType2;
            this.vaSpread1_Sheet1.Columns.Get(5).Label = "생산량";
            this.vaSpread1_Sheet1.Columns.Get(5).Width = 71F;
            numberCellType3.DecimalPlaces = 0;
            numberCellType3.MaximumValue = 10000000;
            numberCellType3.MinimumValue = -10000000;
            numberCellType3.Separator = ",";
            numberCellType3.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(6).CellType = numberCellType3;
            this.vaSpread1_Sheet1.Columns.Get(6).Label = "출하량";
            this.vaSpread1_Sheet1.Columns.Get(6).Width = 65F;
            numberCellType4.DecimalPlaces = 0;
            numberCellType4.MaximumValue = 10000000;
            numberCellType4.MinimumValue = -10000000;
            numberCellType4.Separator = ",";
            numberCellType4.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(7).CellType = numberCellType4;
            this.vaSpread1_Sheet1.Columns.Get(7).Label = "F/P";
            this.vaSpread1_Sheet1.Columns.Get(7).Width = 119F;
            numberCellType5.DecimalPlaces = 0;
            numberCellType5.MaximumValue = 10000000;
            numberCellType5.MinimumValue = -10000000;
            numberCellType5.Separator = ",";
            numberCellType5.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(8).CellType = numberCellType5;
            this.vaSpread1_Sheet1.Columns.Get(8).Label = "F/P생산액";
            this.vaSpread1_Sheet1.Columns.Get(8).Width = 100F;
            this.vaSpread1_Sheet1.Columns.Get(9).Label = "생산완료";
            this.vaSpread1_Sheet1.Columns.Get(9).Width = 68F;
            numberCellType6.DecimalPlaces = 0;
            numberCellType6.MaximumValue = 10000000;
            numberCellType6.MinimumValue = -10000000;
            numberCellType6.Separator = ",";
            numberCellType6.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(10).CellType = numberCellType6;
            this.vaSpread1_Sheet1.Columns.Get(10).Label = "F/P매출액";
            this.vaSpread1_Sheet1.Columns.Get(10).Width = 100F;
            this.vaSpread1_Sheet1.Columns.Get(11).Label = "매출완료";
            this.vaSpread1_Sheet1.Columns.Get(11).Width = 61F;
            this.vaSpread1_Sheet1.Columns.Get(12).CellType = checkBoxCellType1;
            this.vaSpread1_Sheet1.Columns.Get(12).Label = "처리";
            this.vaSpread1_Sheet1.Columns.Get(12).Width = 26F;
            numberCellType7.DecimalPlaces = 0;
            numberCellType7.MaximumValue = 10000000;
            numberCellType7.MinimumValue = -10000000;
            numberCellType7.Separator = ",";
            numberCellType7.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(13).CellType = numberCellType7;
            this.vaSpread1_Sheet1.Columns.Get(13).Label = "수주가";
            this.vaSpread1_Sheet1.Columns.Get(13).Width = 96F;
            numberCellType8.DecimalPlaces = 0;
            numberCellType8.MaximumValue = 10000000;
            numberCellType8.MinimumValue = -10000000;
            numberCellType8.Separator = ",";
            numberCellType8.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(14).CellType = numberCellType8;
            this.vaSpread1_Sheet1.Columns.Get(14).Label = "생산액";
            this.vaSpread1_Sheet1.Columns.Get(14).Width = 98F;
            numberCellType9.DecimalPlaces = 0;
            numberCellType9.MaximumValue = 10000000;
            numberCellType9.MinimumValue = -10000000;
            numberCellType9.Separator = ",";
            numberCellType9.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(15).CellType = numberCellType9;
            this.vaSpread1_Sheet1.Columns.Get(15).Label = "매출액";
            this.vaSpread1_Sheet1.Columns.Get(15).Width = 98F;
            numberCellType10.DecimalPlaces = 0;
            numberCellType10.MaximumValue = 10000000;
            numberCellType10.MinimumValue = -10000000;
            numberCellType10.Separator = ",";
            numberCellType10.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(16).CellType = numberCellType10;
            this.vaSpread1_Sheet1.Columns.Get(16).Label = "포장량";
            this.vaSpread1_Sheet1.Columns.Get(16).Width = 70F;
            numberCellType11.DecimalPlaces = 0;
            numberCellType11.MaximumValue = 10000000;
            numberCellType11.MinimumValue = -10000000;
            numberCellType11.Separator = ",";
            numberCellType11.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(17).CellType = numberCellType11;
            this.vaSpread1_Sheet1.Columns.Get(17).Label = "포장비";
            this.vaSpread1_Sheet1.Columns.Get(17).Width = 92F;
            this.vaSpread1_Sheet1.Columns.Get(18).Label = "포장일자";
            this.vaSpread1_Sheet1.Columns.Get(18).Width = 69F;
            this.vaSpread1_Sheet1.Columns.Get(19).CellType = checkBoxCellType2;
            this.vaSpread1_Sheet1.Columns.Get(19).Label = "처리";
            this.vaSpread1_Sheet1.Columns.Get(19).Width = 21F;
            numberCellType12.DecimalPlaces = 0;
            numberCellType12.MaximumValue = 10000000;
            numberCellType12.MinimumValue = -10000000;
            numberCellType12.Separator = ",";
            numberCellType12.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(20).CellType = numberCellType12;
            this.vaSpread1_Sheet1.Columns.Get(20).Label = "CLC";
            this.vaSpread1_Sheet1.Columns.Get(20).Width = 95F;
            numberCellType13.DecimalPlaces = 0;
            numberCellType13.MaximumValue = 10000000;
            numberCellType13.MinimumValue = -10000000;
            numberCellType13.Separator = ",";
            numberCellType13.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(21).CellType = numberCellType13;
            this.vaSpread1_Sheet1.Columns.Get(21).Label = "CTC";
            this.vaSpread1_Sheet1.Columns.Get(21).Width = 103F;
            numberCellType14.DecimalPlaces = 0;
            numberCellType14.MaximumValue = 10000000;
            numberCellType14.MinimumValue = -10000000;
            numberCellType14.Separator = ",";
            numberCellType14.ShowSeparator = true;
            this.vaSpread1_Sheet1.Columns.Get(22).CellType = numberCellType14;
            this.vaSpread1_Sheet1.Columns.Get(22).Label = "해상운반비";
            this.vaSpread1_Sheet1.Columns.Get(22).Width = 90F;
            this.vaSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.vaSpread1_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.vaSpread1_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread1_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // cmdCompCancel0
            // 
            this.cmdCompCancel0.Location = new System.Drawing.Point(632, 10);
            this.cmdCompCancel0.Name = "cmdCompCancel0";
            this.cmdCompCancel0.Size = new System.Drawing.Size(46, 21);
            this.cmdCompCancel0.TabIndex = 24;
            this.cmdCompCancel0.Text = "완료";
            this.cmdCompCancel0.UseVisualStyleBackColor = true;
            this.cmdCompCancel0.Click += new System.EventHandler(this.cmdCompCancel0_Click);
            // 
            // cmdCompCancel1
            // 
            this.cmdCompCancel1.Location = new System.Drawing.Point(632, 10);
            this.cmdCompCancel1.Name = "cmdCompCancel1";
            this.cmdCompCancel1.Size = new System.Drawing.Size(46, 22);
            this.cmdCompCancel1.TabIndex = 25;
            this.cmdCompCancel1.Text = "해제";
            this.cmdCompCancel1.UseVisualStyleBackColor = true;
            this.cmdCompCancel1.Click += new System.EventHandler(this.cmdCompCancel1_Click);
            // 
            // cmdTransWB1
            // 
            this.cmdTransWB1.Location = new System.Drawing.Point(801, 10);
            this.cmdTransWB1.Name = "cmdTransWB1";
            this.cmdTransWB1.Size = new System.Drawing.Size(55, 25);
            this.cmdTransWB1.TabIndex = 26;
            this.cmdTransWB1.Text = "->POC";
            this.cmdTransWB1.UseVisualStyleBackColor = true;
            this.cmdTransWB1.Click += new System.EventHandler(this.cmdTransWB1_Click);
            // 
            // cmdTransWB0
            // 
            this.cmdTransWB0.Location = new System.Drawing.Point(801, 10);
            this.cmdTransWB0.Name = "cmdTransWB0";
            this.cmdTransWB0.Size = new System.Drawing.Size(55, 25);
            this.cmdTransWB0.TabIndex = 27;
            this.cmdTransWB0.Text = "->정규";
            this.cmdTransWB0.UseVisualStyleBackColor = true;
            this.cmdTransWB0.Click += new System.EventHandler(this.cmdTransWB0_Click);
            // 
            // vaSpread2
            // 
            this.vaSpread2.AccessibleDescription = "vaSpread2, Sheet1, Row 0, Column 0, ";
            this.vaSpread2.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.vaSpread2.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.vaSpread2.HorizontalScrollBar.Name = "";
            this.vaSpread2.HorizontalScrollBar.Renderer = defaultScrollBarRenderer3;
            this.vaSpread2.HorizontalScrollBar.TabIndex = 12;
            this.vaSpread2.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            this.vaSpread2.Location = new System.Drawing.Point(12, 475);
            this.vaSpread2.Name = "vaSpread2";
            this.vaSpread2.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.vaSpread2_Sheet1});
            this.vaSpread2.Size = new System.Drawing.Size(1030, 44);
            this.vaSpread2.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.vaSpread2.TabIndex = 28;
            this.vaSpread2.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.vaSpread2.VerticalScrollBar.Name = "";
            this.vaSpread2.VerticalScrollBar.Renderer = defaultScrollBarRenderer4;
            this.vaSpread2.VerticalScrollBar.TabIndex = 13;
            this.vaSpread2.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never;
            this.vaSpread2.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.vaSpread2.LeftChange += new FarPoint.Win.Spread.LeftChangeEventHandler(this.vaSpread2_LeftChange);
            // 
            // vaSpread2_Sheet1
            // 
            this.vaSpread2_Sheet1.Reset();
            this.vaSpread2_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.vaSpread2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.vaSpread2_Sheet1.ColumnCount = 23;
            this.vaSpread2_Sheet1.RowCount = 2;
            this.vaSpread2_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread2_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.vaSpread2_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread2_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "파트";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "품번";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "차수";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "품번명";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "수주량";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "생산량";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "출하량";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "F/P";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "F/P생산액";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "생산완료";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "F/P매출액";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "매출완료";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 12).Value = "처리";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 13).Value = "수주가";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 14).Value = "생산액";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 15).Value = "매출액";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 16).Value = "포장량";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 17).Value = "포장비";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 18).Value = "포장일자";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 19).Value = "처리";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 20).Value = "CLC";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 21).Value = "CTC";
            this.vaSpread2_Sheet1.ColumnHeader.Cells.Get(0, 22).Value = "해상운반비";
            this.vaSpread2_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread2_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.vaSpread2_Sheet1.ColumnHeader.Rows.Get(0).Height = 42F;
            this.vaSpread2_Sheet1.ColumnHeader.Visible = false;
            textCellType3.MaxLength = 2;
            this.vaSpread2_Sheet1.Columns.Get(0).CellType = textCellType3;
            this.vaSpread2_Sheet1.Columns.Get(0).Label = "파트";
            this.vaSpread2_Sheet1.Columns.Get(0).Width = 30F;
            this.vaSpread2_Sheet1.Columns.Get(2).Label = "차수";
            this.vaSpread2_Sheet1.Columns.Get(2).Width = 35F;
            this.vaSpread2_Sheet1.Columns.Get(3).Label = "품번명";
            this.vaSpread2_Sheet1.Columns.Get(3).Width = 121F;
            numberCellType15.DecimalPlaces = 0;
            numberCellType15.MaximumValue = 10000000;
            numberCellType15.MinimumValue = -10000000;
            numberCellType15.Separator = ",";
            numberCellType15.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(4).CellType = numberCellType15;
            this.vaSpread2_Sheet1.Columns.Get(4).Label = "수주량";
            this.vaSpread2_Sheet1.Columns.Get(4).Width = 67F;
            numberCellType16.DecimalPlaces = 0;
            numberCellType16.MaximumValue = 10000000;
            numberCellType16.MinimumValue = -10000000;
            numberCellType16.Separator = ",";
            numberCellType16.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(5).CellType = numberCellType16;
            this.vaSpread2_Sheet1.Columns.Get(5).Label = "생산량";
            this.vaSpread2_Sheet1.Columns.Get(5).Width = 71F;
            numberCellType17.DecimalPlaces = 0;
            numberCellType17.MaximumValue = 10000000;
            numberCellType17.MinimumValue = -10000000;
            numberCellType17.Separator = ",";
            numberCellType17.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(6).CellType = numberCellType17;
            this.vaSpread2_Sheet1.Columns.Get(6).Label = "출하량";
            this.vaSpread2_Sheet1.Columns.Get(6).Width = 65F;
            numberCellType18.DecimalPlaces = 0;
            numberCellType18.MaximumValue = 10000000;
            numberCellType18.MinimumValue = -10000000;
            numberCellType18.Separator = ",";
            numberCellType18.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(7).CellType = numberCellType18;
            this.vaSpread2_Sheet1.Columns.Get(7).Label = "F/P";
            this.vaSpread2_Sheet1.Columns.Get(7).Width = 119F;
            numberCellType19.DecimalPlaces = 0;
            numberCellType19.MaximumValue = 10000000;
            numberCellType19.MinimumValue = -10000000;
            numberCellType19.Separator = ",";
            numberCellType19.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(8).CellType = numberCellType19;
            this.vaSpread2_Sheet1.Columns.Get(8).Label = "F/P생산액";
            this.vaSpread2_Sheet1.Columns.Get(8).Width = 100F;
            this.vaSpread2_Sheet1.Columns.Get(9).Label = "생산완료";
            this.vaSpread2_Sheet1.Columns.Get(9).Width = 68F;
            numberCellType20.DecimalPlaces = 0;
            numberCellType20.MaximumValue = 10000000;
            numberCellType20.MinimumValue = -10000000;
            numberCellType20.Separator = ",";
            numberCellType20.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(10).CellType = numberCellType20;
            this.vaSpread2_Sheet1.Columns.Get(10).Label = "F/P매출액";
            this.vaSpread2_Sheet1.Columns.Get(10).Width = 100F;
            this.vaSpread2_Sheet1.Columns.Get(11).Label = "매출완료";
            this.vaSpread2_Sheet1.Columns.Get(11).Width = 61F;
            this.vaSpread2_Sheet1.Columns.Get(12).CellType = textCellType4;
            this.vaSpread2_Sheet1.Columns.Get(12).Label = "처리";
            this.vaSpread2_Sheet1.Columns.Get(12).Width = 26F;
            numberCellType21.DecimalPlaces = 0;
            numberCellType21.MaximumValue = 10000000;
            numberCellType21.MinimumValue = -10000000;
            numberCellType21.Separator = ",";
            numberCellType21.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(13).CellType = numberCellType21;
            this.vaSpread2_Sheet1.Columns.Get(13).Label = "수주가";
            this.vaSpread2_Sheet1.Columns.Get(13).Width = 96F;
            numberCellType22.DecimalPlaces = 0;
            numberCellType22.MaximumValue = 10000000;
            numberCellType22.MinimumValue = -10000000;
            numberCellType22.Separator = ",";
            numberCellType22.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(14).CellType = numberCellType22;
            this.vaSpread2_Sheet1.Columns.Get(14).Label = "생산액";
            this.vaSpread2_Sheet1.Columns.Get(14).Width = 98F;
            numberCellType23.DecimalPlaces = 0;
            numberCellType23.MaximumValue = 10000000;
            numberCellType23.MinimumValue = -10000000;
            numberCellType23.Separator = ",";
            numberCellType23.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(15).CellType = numberCellType23;
            this.vaSpread2_Sheet1.Columns.Get(15).Label = "매출액";
            this.vaSpread2_Sheet1.Columns.Get(15).Width = 98F;
            numberCellType24.DecimalPlaces = 0;
            numberCellType24.MaximumValue = 10000000;
            numberCellType24.MinimumValue = -10000000;
            numberCellType24.Separator = ",";
            numberCellType24.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(16).CellType = numberCellType24;
            this.vaSpread2_Sheet1.Columns.Get(16).Label = "포장량";
            this.vaSpread2_Sheet1.Columns.Get(16).Width = 70F;
            numberCellType25.DecimalPlaces = 0;
            numberCellType25.MaximumValue = 10000000;
            numberCellType25.MinimumValue = -10000000;
            numberCellType25.Separator = ",";
            numberCellType25.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(17).CellType = numberCellType25;
            this.vaSpread2_Sheet1.Columns.Get(17).Label = "포장비";
            this.vaSpread2_Sheet1.Columns.Get(17).Width = 92F;
            this.vaSpread2_Sheet1.Columns.Get(18).Label = "포장일자";
            this.vaSpread2_Sheet1.Columns.Get(18).Width = 69F;
            this.vaSpread2_Sheet1.Columns.Get(19).CellType = textCellType5;
            this.vaSpread2_Sheet1.Columns.Get(19).Label = "처리";
            this.vaSpread2_Sheet1.Columns.Get(19).Width = 21F;
            numberCellType26.DecimalPlaces = 0;
            numberCellType26.MaximumValue = 10000000;
            numberCellType26.MinimumValue = -10000000;
            numberCellType26.Separator = ",";
            numberCellType26.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(20).CellType = numberCellType26;
            this.vaSpread2_Sheet1.Columns.Get(20).Label = "CLC";
            this.vaSpread2_Sheet1.Columns.Get(20).Width = 95F;
            numberCellType27.DecimalPlaces = 0;
            numberCellType27.MaximumValue = 10000000;
            numberCellType27.MinimumValue = -10000000;
            numberCellType27.Separator = ",";
            numberCellType27.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(21).CellType = numberCellType27;
            this.vaSpread2_Sheet1.Columns.Get(21).Label = "CTC";
            this.vaSpread2_Sheet1.Columns.Get(21).Width = 103F;
            numberCellType28.DecimalPlaces = 0;
            numberCellType28.MaximumValue = 10000000;
            numberCellType28.MinimumValue = -10000000;
            numberCellType28.Separator = ",";
            numberCellType28.ShowSeparator = true;
            this.vaSpread2_Sheet1.Columns.Get(22).CellType = numberCellType28;
            this.vaSpread2_Sheet1.Columns.Get(22).Label = "해상운반비";
            this.vaSpread2_Sheet1.Columns.Get(22).Width = 90F;
            this.vaSpread2_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.vaSpread2_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread2_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.vaSpread2_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.vaSpread2_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.vaSpread2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // cmdZero
            // 
            this.cmdZero.Location = new System.Drawing.Point(1040, 475);
            this.cmdZero.Name = "cmdZero";
            this.cmdZero.Size = new System.Drawing.Size(18, 44);
            this.cmdZero.TabIndex = 29;
            this.cmdZero.Text = "0";
            this.cmdZero.UseVisualStyleBackColor = true;
            this.cmdZero.Click += new System.EventHandler(this.cmdZero_Click);
            // 
            // F_CE_100
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 531);
            this.Controls.Add(this.cmdZero);
            this.Controls.Add(this.vaSpread2);
            this.Controls.Add(this.cmdTransWB0);
            this.Controls.Add(this.cmdTransWB1);
            this.Controls.Add(this.cmdCompCancel1);
            this.Controls.Add(this.cmdCompCancel0);
            this.Controls.Add(this.vaSpread1);
            this.Controls.Add(this.vaSpread3);
            this.Controls.Add(this.sprHead);
            this.Controls.Add(this.vaSpread0);
            this.Controls.Add(this.cmdMoveInquiry);
            this.Controls.Add(this.cmdCostCalc);
            this.Controls.Add(this.lblDormant);
            this.Controls.Add(this.cmdHold);
            this.Controls.Add(this.cmdConfirm);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.cmdReverse);
            this.Controls.Add(this.txtPart);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmdAllSet);
            this.Controls.Add(this.cmdContDist);
            this.Controls.Add(this.cmdCompute);
            this.Controls.Add(this.cmdAct);
            this.Controls.Add(this.cmd25);
            this.Controls.Add(this.mebProcDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtProd_no);
            this.Controls.Add(this.label1);
            this.Name = "F_CE_100";
            this.Text = "Worksbilling(F_CE_100)";
            this.Load += new System.EventHandler(this.F_CE_100_Load);
            this.Activated += new System.EventHandler(this.F_CE_100_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprHead_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread3_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread1_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaSpread2_Sheet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtProd_no;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox mebProcDate;
        private System.Windows.Forms.Button cmd25;
        private System.Windows.Forms.Button cmdAct;
        private System.Windows.Forms.Button cmdCompute;
        private System.Windows.Forms.Button cmdContDist;
        private System.Windows.Forms.Button cmdAllSet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPart;
        private System.Windows.Forms.Button cmdReverse;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.Button cmdConfirm;
        private System.Windows.Forms.Button cmdHold;
        private System.Windows.Forms.Label lblDormant;
        private System.Windows.Forms.Button cmdCostCalc;
        private System.Windows.Forms.Button cmdMoveInquiry;
        private FarPoint.Win.Spread.FpSpread vaSpread0;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private FarPoint.Win.Spread.FpSpread sprHead;
        private FarPoint.Win.Spread.SheetView sprHead_Sheet1;
        private FarPoint.Win.Spread.FpSpread vaSpread3;
        private FarPoint.Win.Spread.SheetView vaSpread3_Sheet1;
        private FarPoint.Win.Spread.FpSpread vaSpread1;
        private FarPoint.Win.Spread.SheetView vaSpread1_Sheet1;
        private System.Windows.Forms.Button cmdCompCancel0;
        private System.Windows.Forms.Button cmdCompCancel1;
        private System.Windows.Forms.Button cmdTransWB1;
        private System.Windows.Forms.Button cmdTransWB0;
        private FarPoint.Win.Spread.FpSpread vaSpread2;
        private FarPoint.Win.Spread.SheetView vaSpread2_Sheet1;
        private System.Windows.Forms.Button cmdZero;

    }
}