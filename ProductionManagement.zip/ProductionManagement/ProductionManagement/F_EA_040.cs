﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FarPoint.Win.Spread;
using Microsoft.VisualBasic;

namespace ProductionManagement
{
    public partial class F_EA_040 : LForm
    {
        public F_EA_040()
        {
            InitializeComponent();
        }

        private void F_EA_040_Load(object sender, EventArgs e)
        {
            mdi = (MainMDI)this.Parent.Parent;
            isButton = "FFFFTT";
            mdi.g_ButtonInitialize(isButton);
        }

        private void F_EA_040_Activated(object sender, EventArgs e)
        {
            mdi.g_ButtonInitialize(isButton);
        }

        private void cmdProjectSearch_Click(object sender, EventArgs e)
        {
            F_HELP_ProdNo f = new F_HELP_ProdNo();
            f.ShowDialog();
            txtProd_no.Text = f.ProdNo;
        }
        public override void F_SEARCH()
        {
            this.Cursor=Cursors.WaitCursor;
            Head_Display();
            cmdSearch();
            this.Cursor=Cursors.Default;

        }
        private void Head_Display()
        {           
            txtProd_no.Text = txtProd_no.Text.ToUpper();
                    
            string SQL = "exec s_eb_080_2_1 '" + txtProd_no.Text.Substring(0, 11) + "','" + txtProd_no.Text.Substring(11, 3) + "'";
            GRS g=new GRS(SQL);
            if( g.RowCount > 0 )
            {
                uSpread.Spread_Unit_Data_Set(sprHead1, 0, 1, g.gRS("model_type"), true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 1, 1, g.gRS("brief_trade"), true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 0, 3, g.gRS("equip_count"), true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 1, 3, g.gRS("country_name"), true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 0, 5, g.gRS("gaijung"), true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 1, 5, g.gRS("product_code"), true, false);
            }
            else
            {
                uSpread.Spread_Unit_Data_Set(sprHead1, 0, 1, "", true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 1, 1, "", true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 0, 3, "", true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 1, 3, "", true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 0, 5, "", true, false);
                uSpread.Spread_Unit_Data_Set(sprHead1, 1, 5, "", true, false);
            }

            
            SQL = " exec s_cc_020_2 '" + txtProd_no.Text + "'";
            g=new GRS(SQL);

            uSpread.Spread_Unit_Data_Set(sprHead2, 1, 0, "", true, false);
            uSpread.Spread_Unit_Data_Set(sprHead2, 1, 1, "", true, false);
            uSpread.Spread_Unit_Data_Set(sprHead2, 1, 2, "", true, false);


            for(int i = 0; i< g.RowCount; i++)
            {
                if( g.gRS("block") == "A" )
                    uSpread.Spread_Unit_Data_Set(sprHead2, 1, 0, g.gRS("plan_date"), true, false);
                else if( g.gRS("block") == "B" )
                    uSpread.Spread_Unit_Data_Set(sprHead2, 1, 1, g.gRS("plan_date"), true, false);
                else if (g.gRS("block") == "C")
                    uSpread.Spread_Unit_Data_Set(sprHead2, 1, 2, g.gRS("plan_date"), true, false);
                g.MoveNext();
            }

        }
        private void cmdSearch()
        {
            SheetView sv=sprDesignList.Sheets[0];
            
            txtProd_no.Text = txtProd_no.Text.ToUpper();
            if( txtProd_no.Text == "" ) 
            {
                MessageBox.Show("제번을 입력하세요");
                return;
            }

            txtPart0.Text = txtPart0.Text.ToUpper();
            txtPart1.Text = txtPart1.Text.ToUpper();
            txtPart2.Text = txtPart2.Text.ToUpper();
            txtPart3.Text = txtPart3.Text.ToUpper();
            txtPart4.Text = txtPart4.Text.ToUpper();
            
            string SQL = "EXEC S_CC_010_2 '" + txtProd_no.Text.Substring(0, 11) + "','" + txtProd_no.Text.Substring(11, 3) + "'";
            GRS g=new GRS(SQL);
            
            if( g.RowCount == 0 )
            {
                MessageBox.Show("제번을 다시 입력하세요");
                sv.RowCount = 0;
                return;
            }

            SQL = "EXEC S_EA_040_1_CC '" + txtProd_no.Text.Substring(0, 11) + "','" + txtProd_no.Text.Substring(11, 3) + "','" + 
                txtPart0.Text + "','" + txtPart1.Text + "','" + txtPart2.Text + "','" + txtPart3.Text + "','" + txtPart4.Text + "',''";
            g=new GRS(SQL);

            sv.RowCount=g.RowCount;
            for (int i = 0; i < g.RowCount; i++)
            {
                sv.Cells[i, 0].Text=g.gRS("part");
                sv.Cells[i, 1].Text=g.gRS("part_seq");
                sv.Cells[i, 2].Text=g.gRS("item_no");
                sv.Cells[i, 3].Text=g.gRS("due_date");
                sv.Cells[i, 4].Text=g.gRS("last_in_date");
                sv.Cells[i, 5].Text=g.gRS("eng_desc");
                sv.Cells[i, 6].Text=g.gRS("cont_qty");
                sv.Cells[i, 7].Text=g.gRS("order_select");

                sv.Cells[i, 8].Text=g.gRS("ship_flag");
                sv.Cells[i, 9].Text=g.gRS("confirm_flag");
                sv.Cells[i, 10].Text=g.gRS("out_factory_flag");
                sv.Cells[i, 11].Text=g.gRS("cause_code");
                sv.Cells[i, 12].Value = g.gRS("run_status");

                sv.Cells[i, 13].Text=g.gRS("concern_order_date");
                sv.Cells[i, 14].Text=g.gRS("concern_order_no");
                sv.Cells[i, 15].Text=g.gRS("draw_cfm_date");
                sv.Cells[i, 16].Text=g.gRS("part_pdm");
                sv.Cells[i, 17].Text=g.gRS("amt_divide_flag");
                sv.Cells[i, 18].Text = g.gRS("remark");

                g.MoveNext();
            }
        }

        private void txtProd_no_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                F_SEARCH();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SheetView sv = sprDesignList.Sheets[0];
            int row = int.Parse(textBox1.Text);
            sv.Cells[row, 2].CanFocus = true;
            //Dim celltest As New FarPoint.Win.Spread.CellType.GeneralCellType();
            //celltest.FocusPosition = FarPoint.Win.Spread.CellType.EditorFocusCursorPosition.MouseLocation;
            //FpSpread1.Sheets[0].Cells[0, 0].CellType = celltest;

            FarPoint.Win.Spread.CellType.GeneralCellType celltype = new FarPoint.Win.Spread.CellType.GeneralCellType();
            celltype.FocusPosition = FarPoint.Win.Spread.CellType.EditorFocusCursorPosition.SelectAll;
            sv.Cells[row, 2].CellType=celltype;
        }
    }
}
