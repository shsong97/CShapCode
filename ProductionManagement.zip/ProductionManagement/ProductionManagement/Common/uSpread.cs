﻿using System;
using System.Collections.Generic;
using System.Text;
using FarPoint.Win.Spread;
using FarPoint.Win.Spread.CellType;
using Microsoft.VisualBasic;

public class uSpread
{
    public static void Spread_Unit_Data_Set(FpSpread fSpread, int row, int col, string data, bool locktype, bool overflow)
    {
        Spread_Unit_Data_Set(fSpread.Sheets[0], row, col, data, locktype, overflow);
    }
    public static void Spread_Unit_Data_Set(FpSpread fSpread, int row, int col, string data)
    {
        Spread_Unit_Data_Set(fSpread.Sheets[0], row, col, data, false, false);
    }
    public static void Spread_Unit_Data_Set(SheetView fSpread, int row, int col, string data, bool locktype, bool overflow)
    {
        if(fSpread.RowCount < row)
        {
            fSpread.RowCount = row;
        }

        fSpread.Cells[row,col].Text=data;

        if(overflow == true)
        {
            //fSpread.Cells[row, col]. = LenB(Data);
        }

        if(locktype == true)
        {
            fSpread.Cells[row, col].Locked = true;
        }
    }
    public static string Spread_Unit_Data_Get(FpSpread fSpread,int row, int col)
    {
        string data="";
        data = fSpread.Sheets[0].Cells[row, col].Text;
        return data;
    }
    public static string Spread_Unit_Data_Get(SheetView fSpread, int row, int col)
    {
        string data = "";
        data = fSpread.Cells[row, col].Text;
        return data;
    }

    public static int MaxRows(FpSpread fSpread)
    {
        return fSpread.Sheets[0].RowCount;
    }
    public static void MaxRows(FpSpread fSpread,int maxrows)
    {
        fSpread.Sheets[0].RowCount = maxrows;
    }

    public static void Set_Change_Spread_Event(FpSpread fSpread, int col, int row)
    {
        SheetView sv=fSpread.Sheets[0];
        if(sv.Cells[row,col].Locked)
            return;

        if(sv.Cells[row,col].Text.CompareTo("")>0)
        {

            if(sv.RowHeader.Rows[row].Label.Equals("M") ||
                sv.RowHeader.Rows[row].Label.Equals("="))
            {
                sv.RowHeader.Rows[row].Label="M";
            }
            else
            {
                sv.RowHeader.Rows[row].Label="A";
            }
        }
    }
    public static void SetCboIndex(SheetView fSpread, string code,int length,int row, int col)
    {
        if (length < 1)
            length = 1;

        ComboBoxCellType Combo = (ComboBoxCellType)fSpread.Cells[row, col].Column.CellType;
        
        //Combo.SelectedIndex = 0;
        //for (int k = 0; k < Combo.Items.Count - 1; k++)
        //{
        //    if (i_code.Equals(code))
        //    {
        //        Combo.SelectedIndex = k;
        //    }
        //}
    }

    public static void FillCombo(SheetView fSpread, int row, int col, string CodeSelect, string code, string sstable, string process_flag, bool bFlagCell)
    {
        string Total_Diplay_flag = "";
        string Gsql = "";
        string ttable = "";

        if (code.Equals(""))
            code = " ";
        Total_Diplay_flag = process_flag.Substring(0, 1);

        if (sstable.CompareTo("0") > 0)
            ttable = sstable;
        else
            ttable = "T_EX_000";

        if (CodeSelect.Length > 10)
            Gsql = CodeSelect;
        else
            Gsql = "EXEC el_cd.dbo.s_ex_code_1 '" + ttable + "','" + CodeSelect + "'";

        GRS g = new GRS(Gsql);
        if (g.RowCount == 0)
            return;

        // CellType이 ComboBox인 객체를 생성
        ComboBoxCellType cb = new ComboBoxCellType();
        int allCount = Total_Diplay_flag.Equals("A") ? 1 : 0;

        string[] item = new string[g.RowCount + allCount];
        string[] itemData = new string[g.RowCount + allCount];
        
        if (Total_Diplay_flag.Equals("A"))
        {
            item[0] = "전체";
            itemData[0] = "";
        }

        for (int i = allCount; i < g.RowCount + allCount; i++)
        {
            item[i] = g.gRS("code_desc");
            itemData[i] = g.gRS("code");
            g.MoveNext();
        }

        cb.Items = item;
        cb.ItemData = itemData;

        // 셀 선택일 경우 셀을 지정
        if (bFlagCell)
            fSpread.Cells[row, col].CellType = cb;
        else
        {
            // 셀 선택이 아닐경우 컬럼 지정
            fSpread.Columns[col].CellType = cb;
        }

        uSpread.SetCboIndex(fSpread, code, code.Length, row, col);
    }
    public static void FillCombo(SheetView fSpread, int row, int col, string query, bool bFlagCell)
    {
        GRS g = new GRS(query);
        if (g.RowCount > 0)
        {
            // CellType이 ComboBox인 객체를 생성
            ComboBoxCellType cb = new ComboBoxCellType();
            string[] item=new string[g.RowCount];
            string[] itemData = new string[g.RowCount];
            for (int i = 0; i < g.RowCount; i++)
            {
                item[i] = g.gRS("code_desc");
                itemData[i] = g.gRS("code");
                g.MoveNext();
            }
            cb.Items = item;
            cb.ItemData = itemData;

            // 셀 선택일 경우 셀을 지정
            if (bFlagCell)
                fSpread.Cells[row, col].CellType = cb;
            else
            {
                // 셀 선택이 아닐경우 컬럼 지정
                fSpread.Columns[col].CellType = cb;
            }
        }
    }
}

