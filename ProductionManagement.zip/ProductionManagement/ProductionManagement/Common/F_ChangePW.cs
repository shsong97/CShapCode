﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


public partial class F_ChangePW : Form
{
    public bool result = false;
    Encrypt enc = new Encrypt();

    public F_ChangePW()
    {
        InitializeComponent();
    }

    private bool lValidataPasswordRule(string userid, string lOldPassword, string lNewPassword, string lRetryPassword)
    {

        int int_cnt = 0, char_cnt = 0;

        if (lNewPassword == lOldPassword)
        {
            MessageBox.Show("과거 비밀번호와 신규비밀번호는 달라야 합니다");
            return false;
        }
        if (lNewPassword.Length < 6)
        {
            MessageBox.Show(" 비밀번호는 6자리 이상이여야 합니다");
            return false;
        }

        int valid = -1;
        if (int.TryParse(lNewPassword, out valid))
        {
            MessageBox.Show(" 비밀번호는 문자,숫자 조합이여야 합니다");
            return false;
        }
        if (!lNewPassword.Equals(lRetryPassword))
        {
            MessageBox.Show("신규 비밀번호가 같지 않습니다. 다시 입력하세요");
            return false;
        }
        if (lNewPassword.Equals(GlobalSetting.gUserID))
        {
            MessageBox.Show("쉽게 유추할 수 있는 비밀번호는 허용하지 않습니다.");
            return false;
        }

        if (lNewPassword.Length > 0 && !int.TryParse(lNewPassword, out valid))
        {
            for (int i = 0; i < lNewPassword.Length; i++)
            {
                if (int.TryParse(lNewPassword.Substring(i, 1), out valid))
                    int_cnt++;
                else
                    char_cnt++;
            }
            if (int_cnt == 0)
            {
                MessageBox.Show(" 비밀번호는 문자,숫자 조합이여야 합니다!!");
                return false;
            }
        }

        return true;
    }

    private void cmd3DOk_Click(object sender, EventArgs e)
    {
        if (GlobalSetting.gMustBeChanged)
            GlobalSetting.gIsValidUser = false;

        if (!lValidataPasswordRule(GlobalSetting.gUserID, txtOldPassword.Text, txtNewPassword.Text, txtRetryPassword.Text))
        {
            txtNewPassword.Text = "";
            txtRetryPassword.Text = "";
            return;
        }

        string gSql = "EXEC common.dbo.sp_id_pwd_check 'P','" + GlobalSetting.gUserID + "','',''";
        GRS g = new GRS(gSql);
        if (g.RowCount == 0)
        {
            MessageBox.Show("Error:" + gSql);
            return;

        }

        if (g.gRSInt(0) != 0)
        {
            MessageBox.Show(g.gRS(1));
            return;
        }

        if (!enc.IsCorectPassword(txtOldPassword.Text, g.gRS(2)))
        {
            MessageBox.Show(" 이전 비밀번호가 틀립니다, 재입력");
            gSql = " exec common.dbo.sp_id_pwd_check 'E','" + GlobalSetting.gUserID + "','',''";
            g = new GRS(gSql);
            txtNewPassword.Text = "";
            txtRetryPassword.Text = "";
            return;
        }

        if (enc.IsCorectPassword(txtNewPassword.Text, g.gRS(3)) ||
            enc.IsCorectPassword(txtNewPassword.Text, g.gRS(4)) ||
            enc.IsCorectPassword(txtNewPassword.Text, g.gRS(5)))
        {
            MessageBox.Show(" 4회 이전 비밀번호는 재사용 합니다, 재입력");
            txtNewPassword.Text = "";
            txtRetryPassword.Text = "";
            return;
        }

        gSql = "EXEC common.dbo.sp_id_pwd_check 'U','" + GlobalSetting.gUserID + "','" + enc.EncryptPassword(txtOldPassword.Text) + "','" + enc.EncryptPassword(txtNewPassword.Text) + "'";
        g = new GRS(gSql);
        if (g.RowCount == 0)
        {
            MessageBox.Show("Error:" + gSql);
            return;

        }

        if (g.gRSInt(0) == 0)
        {
            GlobalSetting.gUserPwd = txtNewPassword.Text;
            MessageBox.Show("패스워드가 변경 되었습니다.");
            GlobalSetting.gIsValidUser = true;
        }
        else
            MessageBox.Show(g.gRS(1));


        Close();
    }

    private void cmd3DCancel_Click(object sender, EventArgs e)
    {
        if (GlobalSetting.gMustBeChanged)
            GlobalSetting.gIsValidUser = false;
        Close();
    }

    private void F_ChangePW_Load(object sender, EventArgs e)
    {
        this.CenterToParent();
    }
}

