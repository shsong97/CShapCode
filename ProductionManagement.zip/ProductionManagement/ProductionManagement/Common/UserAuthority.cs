﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Windows.Forms;

class UserAuthority
{

    public static string[] GetMenuList(string lDomainName, string lAppName, string userId, string lOption)
    {
        string[] menuList=null;
        string sql = "exec common.dbo.sp_notaccessible_progs '" + lDomainName + "', '" + lAppName + "', '" + userId + "', '" + lOption + "'";
        GRS g = new GRS(sql);
        if (g.RowCount > 0)
        {
            menuList = new string[g.RowCount];
            for (int i = 0; i < g.RowCount; i++)
            {
                menuList[i] = g.gRS("program");
                g.MoveNext();
            }
        }
        return menuList;
    }

    public static bool IsAccessible(string lUserId, string AppProgram)
    {
        // 아래 쿼리는 CEM 체크용으로 의미가 없음
        string sql=" exec common.dbo.sp_get_token_for_access '" + lUserId + "','" + AppProgram + "'";

        GRS g=new GRS(sql);

        if (g.RowCount == 0)
            return false;

        if( !g.gRS("access_token").Equals("1") )
        {
            MessageBox.Show("현사용자(" + lUserId + ")는 시스템(" + AppProgram + ")에 접근 불가 합니다.전산실 문의 바람!!!!");
            return false;
        }

        return true;
    }
    public static int UserLevel(string lUserId)
    {
        string sql=" exec common.dbo.sp_get_security_level '" + lUserId + "','',''";
        GRS g=new GRS(sql);

        if(g.RowCount==0)
            return -1;

        return g.gRSInt("min_securith_level");
    }
}

