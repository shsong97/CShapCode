﻿
partial class F_PassInit
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_PassInit));
        this.label1 = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.label3 = new System.Windows.Forms.Label();
        this.txtIDNo = new System.Windows.Forms.TextBox();
        this.txtSSN1 = new System.Windows.Forms.TextBox();
        this.txtSSN2 = new System.Windows.Forms.TextBox();
        this.label4 = new System.Windows.Forms.Label();
        this.cboReason = new System.Windows.Forms.ComboBox();
        this.btnOk = new System.Windows.Forms.Button();
        this.btnCancel = new System.Windows.Forms.Button();
        this.SuspendLayout();
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Location = new System.Drawing.Point(12, 20);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(69, 13);
        this.label1.TabIndex = 0;
        this.label1.Text = "사용자     ID";
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Location = new System.Drawing.Point(12, 50);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(79, 13);
        this.label2.TabIndex = 1;
        this.label2.Text = "주민등록번호";
        // 
        // label3
        // 
        this.label3.AutoSize = true;
        this.label3.Location = new System.Drawing.Point(12, 82);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(67, 13);
        this.label3.TabIndex = 2;
        this.label3.Text = "사            유";
        // 
        // txtIDNo
        // 
        this.txtIDNo.Location = new System.Drawing.Point(105, 17);
        this.txtIDNo.Name = "txtIDNo";
        this.txtIDNo.Size = new System.Drawing.Size(134, 20);
        this.txtIDNo.TabIndex = 3;
        // 
        // txtSSN1
        // 
        this.txtSSN1.Location = new System.Drawing.Point(105, 47);
        this.txtSSN1.Name = "txtSSN1";
        this.txtSSN1.Size = new System.Drawing.Size(72, 20);
        this.txtSSN1.TabIndex = 4;
        // 
        // txtSSN2
        // 
        this.txtSSN2.Location = new System.Drawing.Point(203, 47);
        this.txtSSN2.Name = "txtSSN2";
        this.txtSSN2.Size = new System.Drawing.Size(74, 20);
        this.txtSSN2.TabIndex = 5;
        // 
        // label4
        // 
        this.label4.AutoSize = true;
        this.label4.Font = new System.Drawing.Font("굴림체", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label4.Location = new System.Drawing.Point(183, 49);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(14, 13);
        this.label4.TabIndex = 6;
        this.label4.Text = "-";
        // 
        // cboReason
        // 
        this.cboReason.FormattingEnabled = true;
        this.cboReason.Location = new System.Drawing.Point(105, 79);
        this.cboReason.Name = "cboReason";
        this.cboReason.Size = new System.Drawing.Size(179, 21);
        this.cboReason.TabIndex = 7;
        // 
        // btnOk
        // 
        this.btnOk.Location = new System.Drawing.Point(15, 116);
        this.btnOk.Name = "btnOk";
        this.btnOk.Size = new System.Drawing.Size(123, 34);
        this.btnOk.TabIndex = 8;
        this.btnOk.Text = "확     인";
        this.btnOk.UseVisualStyleBackColor = true;
        this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
        // 
        // btnCancel
        // 
        this.btnCancel.Location = new System.Drawing.Point(144, 117);
        this.btnCancel.Name = "btnCancel";
        this.btnCancel.Size = new System.Drawing.Size(110, 33);
        this.btnCancel.TabIndex = 9;
        this.btnCancel.Text = "취  소";
        this.btnCancel.UseVisualStyleBackColor = true;
        this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
        // 
        // F_PassInit
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(320, 166);
        this.Controls.Add(this.btnCancel);
        this.Controls.Add(this.btnOk);
        this.Controls.Add(this.cboReason);
        this.Controls.Add(this.label4);
        this.Controls.Add(this.txtSSN2);
        this.Controls.Add(this.txtSSN1);
        this.Controls.Add(this.txtIDNo);
        this.Controls.Add(this.label3);
        this.Controls.Add(this.label2);
        this.Controls.Add(this.label1);
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.Name = "F_PassInit";
        this.Text = "패스워드 초기화";
        this.Load += new System.EventHandler(this.F_PassInit_Load);
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox txtIDNo;
    private System.Windows.Forms.TextBox txtSSN1;
    private System.Windows.Forms.TextBox txtSSN2;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.ComboBox cboReason;
    private System.Windows.Forms.Button btnOk;
    private System.Windows.Forms.Button btnCancel;
}
