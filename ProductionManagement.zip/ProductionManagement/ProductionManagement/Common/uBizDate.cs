﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Forms;
using System.Data;
using Microsoft.VisualBasic;

public class uBizDate
{
    public static string gClose_Date_A;
    public static string gClose_Date_B;
    public static string gClose_Date_C;
    public static string gClose_Date_E;
    public static string gClose_Date_G;
    public static string gClose_Date_H;
    public static string gClose_Date_J;
    public static string gClose_Date_X;

    public bool g_Close_Date_Check(string Flag, string sDate)
    {
        return g_Close_Date_Check(Flag, sDate,"Y");
    }
    public bool g_Close_Date_Check(string Flag, string sDate, string display_flag) 
    {
        string t_date="";
        int slen = sDate.Length;

        if (sDate.CompareTo("0")<0)
        {
            return false;
        }

        if(!g_Date_Check(sDate))
        {
            MessageBox.Show("Please Check Date ????");
            return false;
        }
        
        string sql = "exec el_cd.dbo.s_close_check '" + Flag + "','19500101'";
        GRS g=new GRS(DBManager.Query(sql));


        if(g.RowCount==0)
            return false;

        t_date=g.gRS(1);

        switch (Flag)
        {
            case "A":
                uBizDate.gClose_Date_A = t_date;
                break;
            case "B":
                uBizDate.gClose_Date_B = t_date;
                break;
            case "C":
                uBizDate.gClose_Date_C = t_date;
                break;
            case "E":
                uBizDate.gClose_Date_E = t_date;
                break;
            case "G":
                uBizDate.gClose_Date_G = t_date;
                break;
            case "H":
                uBizDate.gClose_Date_H = t_date;
                break;
            case "J":
                uBizDate.gClose_Date_J = t_date;
                break;
            case "X":
                uBizDate.gClose_Date_X = t_date;
                break;

        }

        bool Close_Date_Check = true;

        if (slen == 8)
        {
            if (sDate.CompareTo(t_date)<=0) 
            {
                Close_Date_Check= false;
            }
        }
        else if (slen == 10) 
        {
            if (sDate.CompareTo(g_Date_format(t_date))<=0) 
            {
                Close_Date_Check= false;
            }
        }
        else
        {
            if (string.Format("yyyymmdd",sDate).CompareTo(t_date)<=0) 
            {
                Close_Date_Check= false;
            }
        }
        
        
        
        if( !Close_Date_Check && !display_flag.Equals("N") )
        {
            MessageBox.Show("Already Closed.., Job Impossible ");
        }

        return Close_Date_Check;
    }
    public static string g_Date_format(string sstr)
    {
        // 20120101을 2012-01-01 format 변경
        if (sstr.Length != 8)
            return sstr;

        return sstr.Substring(0, 4) + "-" + sstr.Substring(4, 2) + "-" + sstr.Substring(6, 2);
    }
    public static bool g_Date_Check(string sstr)
    {
        if (sstr.Length == 8)
            return IsDate(g_Date_format(sstr));
        else
            return IsDate(sstr);
            
    }

    public static bool IsDate(string date)
    {
        return Information.IsDate(date);
    }

}

