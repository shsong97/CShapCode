﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace ProductionManagement
{
    public class LForm : Form
    {
        public string isButton = "";
        public MainMDI mdi;

        public LForm()
        {
        }
        public virtual void F_NEW()
        {

        }
        public virtual void F_SEARCH()
        {

        }
        public virtual void F_SAVE()
        {

        }
        public virtual void F_DELETE()
        {

        }
        public virtual void F_PRINT()
        {

        }
        public virtual void F_CLOSE()
        {
            // 자식이 먼저 컨트롤 하고 close 하는 경우는???
            Close();
        }
    }
}
