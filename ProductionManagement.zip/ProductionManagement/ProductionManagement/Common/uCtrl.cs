﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Windows.Forms;

public class uCtrl
{
    public static void FillCombo(ComboBox Combo, string CodeSelect,string code)
    {
        uCtrl.FillCombo(Combo, CodeSelect, code, "", "  ");
    }
    public static void FillCombo(ComboBox Combo, string CodeSelect,string code, string sstable, string process_flag)
    {
        string Total_Diplay_flag = "";
        string BA_flag="";
        string Gsql="";
        string ttable="";
        string items = "";
        
        if (code.Equals(""))
            code = " ";
        Total_Diplay_flag = process_flag.Substring(0,1);

        if(process_flag.Substring(1,1).CompareTo("0")>0)
            BA_flag=process_flag.Substring(1,1);
        else
            BA_flag="A";

        if (sstable.CompareTo("0") > 0)
            ttable = sstable;
        else
            ttable = "T_EX_000";

        if (CodeSelect.Length > 10)
            Gsql = CodeSelect;
        else
            Gsql = "EXEC el_cd.dbo.s_ex_code_1 '" + ttable + "','" + CodeSelect + "'";

        GRS g=new GRS(DBManager.Query(Gsql));
        if (g.RowCount==0)
            return;

        Combo.Items.Clear();
        if (Total_Diplay_flag.Equals("A"))
        {
            if(BA_flag.Equals("B"))
                Combo.Items.Add("        전체");
            else
                Combo.Items.Add("전체                   ");
        }

        for(int i=0;i<g.RowCount;i++)
        {
            if(BA_flag.Equals("B"))
                items = g.gRS(0) + "-" + g.gRS(1);
            else
                items = g.gRS(1) + "          " + g.gRS(0);
            Combo.Items.Add(items);
            g.MoveNext();
        }
        uCtrl.SetCboIndex(Combo, code,code.Length,"A");
    }

    public static void SetCboIndex(ComboBox Combo, string code)
    {
        uCtrl.SetCboIndex(Combo, code, code.Length, "A");
    }
    public static void SetCboIndex(ComboBox Combo, string code, int length, string Direct_flag)
    {
        string i_code="";
        string subCode = "";

        if(length<1)
            length=1;
      
        Combo.SelectedIndex = 0;
        for(int k = 0;k<Combo.Items.Count - 1;k++)
        {
            subCode = Combo.Items[k].ToString();
            if (Direct_flag.Equals("B"))
                i_code = subCode.Substring(1, length);
            else
                i_code = subCode.Substring(subCode.Length-length, length);
            if(i_code.Equals(code))
            {
                Combo.SelectedIndex = k;
            }
        }
    }

    
}

