﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

public class Encrypt
{
    public bool IsCorectPassword(string original, string encrypt)
    {
        //sha256 알고리즘으로 패스워드 비교후 일치하면 true
        /*
         * 알고리즘 삽입
         * */

        byte[] data = Encoding.UTF8.GetBytes(original);
        byte[] result;;
        SHA256 shaM = new SHA256Managed();
        result = shaM.ComputeHash(data);

        string enc_original = Convert.ToBase64String(result);

        return true;

        //if (enc_original.Equals(encrypt))
        //    return true;
        //else
        //    return false;
    }
    public string EncryptPassword(string password)
    {
        byte[] data = Encoding.UTF8.GetBytes(password);
        byte[] result;

        SHA256 shaM = new SHA256Managed();
        result = shaM.ComputeHash(data);

        return Convert.ToBase64String(result);
    }
}

