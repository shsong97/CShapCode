﻿
partial class F_ChangePW
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_ChangePW));
        this.lblOldPassword = new System.Windows.Forms.Label();
        this.lblNewPassword = new System.Windows.Forms.Label();
        this.lblRetryPassword = new System.Windows.Forms.Label();
        this.txtOldPassword = new System.Windows.Forms.TextBox();
        this.txtNewPassword = new System.Windows.Forms.TextBox();
        this.txtRetryPassword = new System.Windows.Forms.TextBox();
        this.cmd3DOk = new System.Windows.Forms.Button();
        this.cmd3DCancel = new System.Windows.Forms.Button();
        this.label1 = new System.Windows.Forms.Label();
        this.SuspendLayout();
        // 
        // lblOldPassword
        // 
        this.lblOldPassword.AutoSize = true;
        this.lblOldPassword.Location = new System.Drawing.Point(12, 46);
        this.lblOldPassword.Name = "lblOldPassword";
        this.lblOldPassword.Size = new System.Drawing.Size(88, 13);
        this.lblOldPassword.TabIndex = 0;
        this.lblOldPassword.Text = "이  전 패스워드";
        // 
        // lblNewPassword
        // 
        this.lblNewPassword.AutoSize = true;
        this.lblNewPassword.Location = new System.Drawing.Point(12, 77);
        this.lblNewPassword.Name = "lblNewPassword";
        this.lblNewPassword.Size = new System.Drawing.Size(94, 13);
        this.lblNewPassword.TabIndex = 1;
        this.lblNewPassword.Text = "새로운 패스워드";
        // 
        // lblRetryPassword
        // 
        this.lblRetryPassword.AutoSize = true;
        this.lblRetryPassword.Location = new System.Drawing.Point(12, 105);
        this.lblRetryPassword.Name = "lblRetryPassword";
        this.lblRetryPassword.Size = new System.Drawing.Size(94, 13);
        this.lblRetryPassword.TabIndex = 2;
        this.lblRetryPassword.Text = "재확인 패스워드";
        // 
        // txtOldPassword
        // 
        this.txtOldPassword.Location = new System.Drawing.Point(106, 43);
        this.txtOldPassword.Name = "txtOldPassword";
        this.txtOldPassword.Size = new System.Drawing.Size(172, 20);
        this.txtOldPassword.TabIndex = 3;
        this.txtOldPassword.UseSystemPasswordChar = true;
        // 
        // txtNewPassword
        // 
        this.txtNewPassword.Location = new System.Drawing.Point(106, 74);
        this.txtNewPassword.Name = "txtNewPassword";
        this.txtNewPassword.Size = new System.Drawing.Size(172, 20);
        this.txtNewPassword.TabIndex = 4;
        this.txtNewPassword.UseSystemPasswordChar = true;
        // 
        // txtRetryPassword
        // 
        this.txtRetryPassword.Location = new System.Drawing.Point(106, 102);
        this.txtRetryPassword.Name = "txtRetryPassword";
        this.txtRetryPassword.Size = new System.Drawing.Size(172, 20);
        this.txtRetryPassword.TabIndex = 5;
        this.txtRetryPassword.UseSystemPasswordChar = true;
        // 
        // cmd3DOk
        // 
        this.cmd3DOk.Location = new System.Drawing.Point(296, 43);
        this.cmd3DOk.Name = "cmd3DOk";
        this.cmd3DOk.Size = new System.Drawing.Size(110, 36);
        this.cmd3DOk.TabIndex = 6;
        this.cmd3DOk.Text = "변경";
        this.cmd3DOk.UseVisualStyleBackColor = true;
        this.cmd3DOk.Click += new System.EventHandler(this.cmd3DOk_Click);
        // 
        // cmd3DCancel
        // 
        this.cmd3DCancel.Location = new System.Drawing.Point(296, 88);
        this.cmd3DCancel.Name = "cmd3DCancel";
        this.cmd3DCancel.Size = new System.Drawing.Size(110, 34);
        this.cmd3DCancel.TabIndex = 7;
        this.cmd3DCancel.Text = "취소";
        this.cmd3DCancel.UseVisualStyleBackColor = true;
        this.cmd3DCancel.Click += new System.EventHandler(this.cmd3DCancel_Click);
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Location = new System.Drawing.Point(94, 9);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(184, 13);
        this.label1.TabIndex = 8;
        this.label1.Text = "사용자의 패스워드를 변경합니다.";
        
        // 
        // F_ChangePW
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(423, 137);
        this.Controls.Add(this.label1);
        this.Controls.Add(this.cmd3DCancel);
        this.Controls.Add(this.cmd3DOk);
        this.Controls.Add(this.txtRetryPassword);
        this.Controls.Add(this.txtNewPassword);
        this.Controls.Add(this.txtOldPassword);
        this.Controls.Add(this.lblRetryPassword);
        this.Controls.Add(this.lblNewPassword);
        this.Controls.Add(this.lblOldPassword);
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.Name = "F_ChangePW";
        this.Text = "패스워드 변경";
        this.Load += new System.EventHandler(this.F_ChangePW_Load);
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label lblOldPassword;
    private System.Windows.Forms.Label lblNewPassword;
    private System.Windows.Forms.Label lblRetryPassword;
    private System.Windows.Forms.TextBox txtOldPassword;
    private System.Windows.Forms.TextBox txtNewPassword;
    private System.Windows.Forms.TextBox txtRetryPassword;
    private System.Windows.Forms.Button cmd3DOk;
    private System.Windows.Forms.Button cmd3DCancel;
    private System.Windows.Forms.Label label1;
}
