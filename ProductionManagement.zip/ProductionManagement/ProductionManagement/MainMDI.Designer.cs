﻿namespace ProductionManagement
{
    partial class MainMDI
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMDI));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mMENU1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.M_P_CA_060 = new System.Windows.Forms.ToolStripMenuItem();
            this.M_P_CE_100 = new System.Windows.Forms.ToolStripMenuItem();
            this.기준정보관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.M_P_EX_000 = new System.Windows.Forms.ToolStripMenuItem();
            this.M_P_EX_020 = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.newWindowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cascadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileVerticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileHorizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arrangeIconsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.M_P_EA_040 = new System.Windows.Forms.ToolStripMenuItem();
            this.NewButton = new System.Windows.Forms.ToolStripButton();
            this.SaveButton = new System.Windows.Forms.ToolStripButton();
            this.DeleteButton = new System.Windows.Forms.ToolStripButton();
            this.PrintButton = new System.Windows.Forms.ToolStripButton();
            this.SearchButton = new System.Windows.Forms.ToolStripButton();
            this.CloseButton = new System.Windows.Forms.ToolStripButton();
            this.M_P_EA_010 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mMENU1ToolStripMenuItem,
            this.기준정보관리ToolStripMenuItem,
            this.windowsMenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.windowsMenu;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(632, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // mMENU1ToolStripMenuItem
            // 
            this.mMENU1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.M_P_CA_060,
            this.M_P_CE_100,
            this.M_P_EA_040,
            this.M_P_EA_010});
            this.mMENU1ToolStripMenuItem.Name = "mMENU1ToolStripMenuItem";
            this.mMENU1ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.mMENU1ToolStripMenuItem.Text = "제번정보";
            // 
            // M_P_CA_060
            // 
            this.M_P_CA_060.Name = "M_P_CA_060";
            this.M_P_CA_060.Size = new System.Drawing.Size(168, 22);
            this.M_P_CA_060.Tag = "M_P_CA_060";
            this.M_P_CA_060.Text = "제번일반정보";
            this.M_P_CA_060.Click += new System.EventHandler(this.M_P_CA_060_Click);
            // 
            // M_P_CE_100
            // 
            this.M_P_CE_100.Name = "M_P_CE_100";
            this.M_P_CE_100.Size = new System.Drawing.Size(168, 22);
            this.M_P_CE_100.Tag = "M_P_CE_100";
            this.M_P_CE_100.Text = "Worksbilling";
            this.M_P_CE_100.Click += new System.EventHandler(this.M_P_CE_100_Click);
            // 
            // 기준정보관리ToolStripMenuItem
            // 
            this.기준정보관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.M_P_EX_000,
            this.M_P_EX_020});
            this.기준정보관리ToolStripMenuItem.Name = "기준정보관리ToolStripMenuItem";
            this.기준정보관리ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.기준정보관리ToolStripMenuItem.Text = "기준정보";
            // 
            // M_P_EX_000
            // 
            this.M_P_EX_000.Name = "M_P_EX_000";
            this.M_P_EX_000.Size = new System.Drawing.Size(152, 22);
            this.M_P_EX_000.Tag = "M_P_EX_000";
            this.M_P_EX_000.Text = "코드종류 정의";
            this.M_P_EX_000.Click += new System.EventHandler(this.M_P_EX_000_Click);
            // 
            // M_P_EX_020
            // 
            this.M_P_EX_020.Name = "M_P_EX_020";
            this.M_P_EX_020.Size = new System.Drawing.Size(152, 22);
            this.M_P_EX_020.Tag = "M_P_EX_020";
            this.M_P_EX_020.Text = "코드관리";
            this.M_P_EX_020.Click += new System.EventHandler(this.M_P_EX_020_Click);
            // 
            // windowsMenu
            // 
            this.windowsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newWindowToolStripMenuItem,
            this.cascadeToolStripMenuItem,
            this.tileVerticalToolStripMenuItem,
            this.tileHorizontalToolStripMenuItem,
            this.closeAllToolStripMenuItem,
            this.arrangeIconsToolStripMenuItem});
            this.windowsMenu.Name = "windowsMenu";
            this.windowsMenu.Size = new System.Drawing.Size(49, 20);
            this.windowsMenu.Text = "창(&W)";
            // 
            // newWindowToolStripMenuItem
            // 
            this.newWindowToolStripMenuItem.Name = "newWindowToolStripMenuItem";
            this.newWindowToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.newWindowToolStripMenuItem.Text = "새 창(&N)";
            // 
            // cascadeToolStripMenuItem
            // 
            this.cascadeToolStripMenuItem.Name = "cascadeToolStripMenuItem";
            this.cascadeToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.cascadeToolStripMenuItem.Text = "계단식 배열(&C)";
            this.cascadeToolStripMenuItem.Click += new System.EventHandler(this.CascadeToolStripMenuItem_Click);
            // 
            // tileVerticalToolStripMenuItem
            // 
            this.tileVerticalToolStripMenuItem.Name = "tileVerticalToolStripMenuItem";
            this.tileVerticalToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.tileVerticalToolStripMenuItem.Text = "세로 바둑판식 배열(&V)";
            this.tileVerticalToolStripMenuItem.Click += new System.EventHandler(this.TileVerticalToolStripMenuItem_Click);
            // 
            // tileHorizontalToolStripMenuItem
            // 
            this.tileHorizontalToolStripMenuItem.Name = "tileHorizontalToolStripMenuItem";
            this.tileHorizontalToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.tileHorizontalToolStripMenuItem.Text = "가로 바둑판식 배열(&H)";
            this.tileHorizontalToolStripMenuItem.Click += new System.EventHandler(this.TileHorizontalToolStripMenuItem_Click);
            // 
            // closeAllToolStripMenuItem
            // 
            this.closeAllToolStripMenuItem.Name = "closeAllToolStripMenuItem";
            this.closeAllToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.closeAllToolStripMenuItem.Text = "모두 닫기(&L)";
            this.closeAllToolStripMenuItem.Click += new System.EventHandler(this.CloseAllToolStripMenuItem_Click);
            // 
            // arrangeIconsToolStripMenuItem
            // 
            this.arrangeIconsToolStripMenuItem.Name = "arrangeIconsToolStripMenuItem";
            this.arrangeIconsToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.arrangeIconsToolStripMenuItem.Text = "아이콘 정렬(&A)";
            this.arrangeIconsToolStripMenuItem.Click += new System.EventHandler(this.ArrangeIconsToolStripMenuItem_Click);
            // 
            // toolStrip
            // 
            this.toolStrip.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NewButton,
            this.SaveButton,
            this.DeleteButton,
            this.PrintButton,
            this.SearchButton,
            this.toolStripSeparator2,
            this.CloseButton});
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(632, 39);
            this.toolStrip.TabIndex = 1;
            this.toolStrip.Text = "ToolStrip";
            this.toolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip_ItemClicked);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 431);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(632, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(29, 17);
            this.toolStripStatusLabel.Text = "상태";
            // 
            // M_P_EA_040
            // 
            this.M_P_EA_040.Name = "M_P_EA_040";
            this.M_P_EA_040.Size = new System.Drawing.Size(168, 22);
            this.M_P_EA_040.Tag = "M_P_EA_040";
            this.M_P_EA_040.Text = "제작 통고서 조회";
            this.M_P_EA_040.Click += new System.EventHandler(this.M_P_EA_040_Click);
            // 
            // NewButton
            // 
            this.NewButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.NewButton.Image = ((System.Drawing.Image)(resources.GetObject("NewButton.Image")));
            this.NewButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.NewButton.Name = "NewButton";
            this.NewButton.Size = new System.Drawing.Size(36, 36);
            this.NewButton.Text = "toolStripButton1";
            // 
            // SaveButton
            // 
            this.SaveButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SaveButton.Image = global::ProductionManagement.Properties.Resources.SaveImg;
            this.SaveButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(36, 36);
            this.SaveButton.Text = "toolStripButton1";
            // 
            // DeleteButton
            // 
            this.DeleteButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.DeleteButton.Image = global::ProductionManagement.Properties.Resources.DeleteImg;
            this.DeleteButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(36, 36);
            this.DeleteButton.Text = "toolStripButton2";
            // 
            // PrintButton
            // 
            this.PrintButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.PrintButton.Image = global::ProductionManagement.Properties.Resources.PrintImg;
            this.PrintButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.PrintButton.Name = "PrintButton";
            this.PrintButton.Size = new System.Drawing.Size(36, 36);
            this.PrintButton.Text = "toolStripButton3";
            // 
            // SearchButton
            // 
            this.SearchButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SearchButton.Image = global::ProductionManagement.Properties.Resources.SearchImg;
            this.SearchButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(36, 36);
            this.SearchButton.Text = "toolStripButton4";
            // 
            // CloseButton
            // 
            this.CloseButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.CloseButton.Image = global::ProductionManagement.Properties.Resources.CloseImg;
            this.CloseButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(36, 36);
            this.CloseButton.Text = "toolStripButton5";
            // 
            // M_P_EA_010
            // 
            this.M_P_EA_010.Name = "M_P_EA_010";
            this.M_P_EA_010.Size = new System.Drawing.Size(168, 22);
            this.M_P_EA_010.Tag = "M_P_EA_010";
            this.M_P_EA_010.Text = "제통 업로드";
            this.M_P_EA_010.Click += new System.EventHandler(this.M_P_EA_010_Click);
            // 
            // MainMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 453);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MainMDI";
            this.Text = "생산진척";
            this.Load += new System.EventHandler(this.MainMDI_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainMDI_FormClosed);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem tileHorizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowsMenu;
        private System.Windows.Forms.ToolStripMenuItem newWindowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cascadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileVerticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arrangeIconsToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripButton SaveButton;
        private System.Windows.Forms.ToolStripButton NewButton;
        private System.Windows.Forms.ToolStripButton DeleteButton;
        private System.Windows.Forms.ToolStripButton PrintButton;
        private System.Windows.Forms.ToolStripButton SearchButton;
        private System.Windows.Forms.ToolStripButton CloseButton;
        private System.Windows.Forms.ToolStripMenuItem mMENU1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem M_P_CA_060;
        private System.Windows.Forms.ToolStripMenuItem M_P_CE_100;
        private System.Windows.Forms.ToolStripMenuItem 기준정보관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem M_P_EX_000;
        private System.Windows.Forms.ToolStripMenuItem M_P_EX_020;
        private System.Windows.Forms.ToolStripMenuItem M_P_EA_040;
        private System.Windows.Forms.ToolStripMenuItem M_P_EA_010;
    }
}



