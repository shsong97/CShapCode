﻿namespace ProductionManagement
{
    partial class F_EX_020
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType2 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType4 = new FarPoint.Win.Spread.CellType.TextCellType();
            this.sprList = new FarPoint.Win.Spread.FpSpread();
            this.sprList_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.label1 = new System.Windows.Forms.Label();
            this.cboCodeFlag = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.sprList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprList_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // sprList
            // 
            this.sprList.AccessibleDescription = "sprList, Sheet1, Row 0, Column 0, ";
            this.sprList.Location = new System.Drawing.Point(12, 33);
            this.sprList.Name = "sprList";
            this.sprList.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprList_Sheet1});
            this.sprList.Size = new System.Drawing.Size(532, 360);
            this.sprList.TabIndex = 0;
            this.sprList.Change += new FarPoint.Win.Spread.ChangeEventHandler(this.sprList_Change);
            // 
            // sprList_Sheet1
            // 
            this.sprList_Sheet1.Reset();
            this.sprList_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprList_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprList_Sheet1.ColumnCount = 4;
            this.sprList_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Code";
            this.sprList_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Code Description";
            this.sprList_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "수정자";
            this.sprList_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "수정일자";
            this.sprList_Sheet1.Columns.Get(0).CellType = textCellType1;
            this.sprList_Sheet1.Columns.Get(0).Label = "Code";
            this.sprList_Sheet1.Columns.Get(0).Width = 66F;
            this.sprList_Sheet1.Columns.Get(1).CellType = textCellType2;
            this.sprList_Sheet1.Columns.Get(1).Label = "Code Description";
            this.sprList_Sheet1.Columns.Get(1).Width = 220F;
            this.sprList_Sheet1.Columns.Get(2).CellType = textCellType3;
            this.sprList_Sheet1.Columns.Get(2).Label = "수정자";
            this.sprList_Sheet1.Columns.Get(2).Width = 80F;
            this.sprList_Sheet1.Columns.Get(3).CellType = textCellType4;
            this.sprList_Sheet1.Columns.Get(3).Label = "수정일자";
            this.sprList_Sheet1.Columns.Get(3).Width = 107F;
            this.sprList_Sheet1.LockBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(213)))), ((int)(((byte)(213)))));
            this.sprList_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprList_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "코드종류";
            // 
            // cboCodeFlag
            // 
            this.cboCodeFlag.FormattingEnabled = true;
            this.cboCodeFlag.Location = new System.Drawing.Point(73, 6);
            this.cboCodeFlag.Name = "cboCodeFlag";
            this.cboCodeFlag.Size = new System.Drawing.Size(196, 21);
            this.cboCodeFlag.TabIndex = 2;
            this.cboCodeFlag.SelectedIndexChanged += new System.EventHandler(this.cboCodeFlag_SelectedIndexChanged);
            this.cboCodeFlag.Click += new System.EventHandler(this.cboCodeFlag_Click);
            // 
            // F_EX_020
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 397);
            this.Controls.Add(this.cboCodeFlag);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sprList);
            this.Name = "F_EX_020";
            this.Text = "코드 관리(일반) (F_EX_020)";
            this.Load += new System.EventHandler(this.F_EX_020_Load);
            this.Activated += new System.EventHandler(this.F_EX_020_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.sprList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprList_Sheet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FarPoint.Win.Spread.FpSpread sprList;
        private FarPoint.Win.Spread.SheetView sprList_Sheet1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboCodeFlag;
    }
}