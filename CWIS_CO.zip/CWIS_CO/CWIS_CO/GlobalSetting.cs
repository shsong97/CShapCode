﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices; //dll import를 위해 필요함

class GlobalSetting
{
    #region Dll declaration
    /* Declare Function GetPrivateProfileStringByKeyName& Lib "kernel32" 
     * Alias "GetPrivateProfileStringA" 
     * (ByVal lpApplicationName$, 
     * ByVal lpszKey$, 
     * ByVal lpszDefault$, 
     * ByVal lpszReturnBuffer$, 
     * ByVal cchReturnBuffer&, 
     * ByVal lpszFile$)
     */
    [DllImport("kernel32.dll", EntryPoint = "GetPrivateProfileStringA", CharSet = CharSet.Ansi)]
    static extern uint GetPrivateProfileStringByKeyName(
     string lpAppName,
     string lpKeyName,
     string lpDefault,
     StringBuilder lpReturnedString,
     uint nSize,
     string lpFileName);

    /* Public Declare Function WritePrivateProfileStringByKeyName& Lib "kernel32" 
     * Alias "WritePrivateProfileStringA" 
     * (ByVal lpApplicationName As String, 
     * ByVal lpKeyName As String, 
     * ByVal lpString As String, 
     * ByVal lplFileName As String)
     */

    [DllImport("kernel32.dll", EntryPoint = "WritePrivateProfileStringA", CharSet = CharSet.Ansi)]
    static extern uint WritePrivateProfileStringByKeyName(
     string lpAppName,
     string lpKeyName,
     string lpString,
     string lpFileName);

    /* Declare Function FindWindow& Lib "user32" 
     * Alias "FindWindowA" _
     * (ByVal lpClassName As String, 
     * ByVal lpWindowName As String)
     */
    [DllImport("user32.dll", EntryPoint = "FindWindowA", CharSet = CharSet.Ansi)]
    static extern uint FindWindow(
     string lpClassName,
     string lpWindowName);

    #endregion

    public static string gUserID = "";
    public static string gUserPwd = "";
    public static string gGaijung = "";
    public static string gLastLoginDate = "";

    public static bool gIsValidUser = false;
    public static bool gCancelFlag = true;
    public static bool gMustBeChanged = false;
    public static bool gTestEnvironment = false;
    public static bool gProdEnvConfig = false;

    public static string gCo_Server = "";
    public static string gBcpExeFile = "";

    public static string gCur_Week = "";
    public static string gPrev_Week = "";
    public static string gNext_Week = "";
    public static string gm_sys_data_convert = "";
    public static string gm_Sys_Date = "";

    public static string GetProfileString(string Section, string Key, string ProfileName)
    {
        StringBuilder KeyValue = new StringBuilder(128);
        uint Characters = GetPrivateProfileStringByKeyName(Section, Key, "", KeyValue, 127, ProfileName);
        return KeyValue.ToString();
    }

    public static void SetProfileString(string Section, string Key, string KeyValue, string ProfileName)
    {
        WritePrivateProfileStringByKeyName(Section, Key, KeyValue, ProfileName);
    }
}

