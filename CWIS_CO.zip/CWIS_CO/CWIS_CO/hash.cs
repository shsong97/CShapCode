﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

public class Hash
{
    public static string GetSHA256(string param)
    {
        byte[] data = System.Text.Encoding.UTF8.GetBytes(param); //1byte
        byte[] hash = SHA256.Create().ComputeHash(data);
        string hex = "";
        foreach (byte x in hash)
        {
            hex += String.Format("{0:x2}", x);
        }
        return hex;
    }
}

