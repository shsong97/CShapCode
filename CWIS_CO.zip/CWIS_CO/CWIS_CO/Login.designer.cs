﻿
partial class Login
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
        this.cmdOk = new System.Windows.Forms.Button();
        this.label1 = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.txtUserID = new System.Windows.Forms.TextBox();
        this.txtPassword = new System.Windows.Forms.TextBox();
        this.txtDSN = new System.Windows.Forms.TextBox();
        this.label3 = new System.Windows.Forms.Label();
        this.cmd3DCancel = new System.Windows.Forms.Button();
        this.BtnPassInit = new System.Windows.Forms.Button();
        this.label4 = new System.Windows.Forms.Label();
        this.lblTestEnv = new System.Windows.Forms.Label();
        this.pictureBox1 = new System.Windows.Forms.PictureBox();
        this.btnPassChange = new System.Windows.Forms.Button();
        ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
        this.SuspendLayout();
        // 
        // cmdOk
        // 
        this.cmdOk.Location = new System.Drawing.Point(339, 34);
        this.cmdOk.Name = "cmdOk";
        this.cmdOk.Size = new System.Drawing.Size(110, 27);
        this.cmdOk.TabIndex = 0;
        this.cmdOk.Text = "확인";
        this.cmdOk.UseVisualStyleBackColor = true;
        this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Font = new System.Drawing.Font("굴림체", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label1.Location = new System.Drawing.Point(48, 40);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(70, 13);
        this.label1.TabIndex = 1;
        this.label1.Text = "사용자 ID";
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Font = new System.Drawing.Font("굴림체", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label2.Location = new System.Drawing.Point(48, 74);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(70, 13);
        this.label2.TabIndex = 2;
        this.label2.Text = "패스 워드";
        // 
        // txtUserID
        // 
        this.txtUserID.Location = new System.Drawing.Point(132, 37);
        this.txtUserID.Name = "txtUserID";
        this.txtUserID.Size = new System.Drawing.Size(195, 20);
        this.txtUserID.TabIndex = 3;
        // 
        // txtPassword
        // 
        this.txtPassword.Location = new System.Drawing.Point(132, 67);
        this.txtPassword.Name = "txtPassword";
        this.txtPassword.Size = new System.Drawing.Size(195, 20);
        this.txtPassword.TabIndex = 4;
        this.txtPassword.UseSystemPasswordChar = true;
        // 
        // txtDSN
        // 
        this.txtDSN.Enabled = false;
        this.txtDSN.Location = new System.Drawing.Point(132, 101);
        this.txtDSN.Name = "txtDSN";
        this.txtDSN.Size = new System.Drawing.Size(195, 20);
        this.txtDSN.TabIndex = 5;
        // 
        // label3
        // 
        this.label3.AutoSize = true;
        this.label3.Font = new System.Drawing.Font("굴림체", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label3.Location = new System.Drawing.Point(48, 104);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(84, 13);
        this.label3.TabIndex = 6;
        this.label3.Text = "SERVER 이름";
        // 
        // cmd3DCancel
        // 
        this.cmd3DCancel.Location = new System.Drawing.Point(339, 67);
        this.cmd3DCancel.Name = "cmd3DCancel";
        this.cmd3DCancel.Size = new System.Drawing.Size(110, 31);
        this.cmd3DCancel.TabIndex = 7;
        this.cmd3DCancel.Text = "취소";
        this.cmd3DCancel.UseVisualStyleBackColor = true;
        this.cmd3DCancel.Click += new System.EventHandler(this.cmd3DCancel_Click);
        // 
        // BtnPassInit
        // 
        this.BtnPassInit.Location = new System.Drawing.Point(339, 104);
        this.BtnPassInit.Name = "BtnPassInit";
        this.BtnPassInit.Size = new System.Drawing.Size(110, 30);
        this.BtnPassInit.TabIndex = 8;
        this.BtnPassInit.Text = "패스워드 초기화";
        this.BtnPassInit.UseVisualStyleBackColor = true;
        this.BtnPassInit.Click += new System.EventHandler(this.BtnPassInit_Click);
        // 
        // label4
        // 
        this.label4.AutoSize = true;
        this.label4.Location = new System.Drawing.Point(48, 9);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(274, 13);
        this.label4.TabIndex = 9;
        this.label4.Text = "시스템에 로그온 하려면 사용자 정보를 입력하세요";
        // 
        // lblTestEnv
        // 
        this.lblTestEnv.AutoSize = true;
        this.lblTestEnv.Font = new System.Drawing.Font("굴림체", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.lblTestEnv.Location = new System.Drawing.Point(323, 11);
        this.lblTestEnv.Name = "lblTestEnv";
        this.lblTestEnv.Size = new System.Drawing.Size(155, 11);
        this.lblTestEnv.TabIndex = 10;
        this.lblTestEnv.Text = "테스환경으로 Login합니다.";
        this.lblTestEnv.Visible = false;
        // 
        // pictureBox1
        // 
        this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
        this.pictureBox1.Location = new System.Drawing.Point(4, 8);
        this.pictureBox1.Name = "pictureBox1";
        this.pictureBox1.Size = new System.Drawing.Size(38, 33);
        this.pictureBox1.TabIndex = 11;
        this.pictureBox1.TabStop = false;
        this.pictureBox1.DoubleClick += new System.EventHandler(this.pictureBox1_DoubleClick);
        // 
        // btnPassChange
        // 
        this.btnPassChange.Location = new System.Drawing.Point(339, 141);
        this.btnPassChange.Name = "btnPassChange";
        this.btnPassChange.Size = new System.Drawing.Size(110, 30);
        this.btnPassChange.TabIndex = 12;
        this.btnPassChange.Text = "패스워드 변경";
        this.btnPassChange.UseVisualStyleBackColor = true;
        this.btnPassChange.Click += new System.EventHandler(this.btnPassChange_Click);
        // 
        // Login
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(481, 178);
        this.Controls.Add(this.btnPassChange);
        this.Controls.Add(this.pictureBox1);
        this.Controls.Add(this.lblTestEnv);
        this.Controls.Add(this.label4);
        this.Controls.Add(this.BtnPassInit);
        this.Controls.Add(this.cmd3DCancel);
        this.Controls.Add(this.label3);
        this.Controls.Add(this.txtDSN);
        this.Controls.Add(this.txtPassword);
        this.Controls.Add(this.txtUserID);
        this.Controls.Add(this.label2);
        this.Controls.Add(this.label1);
        this.Controls.Add(this.cmdOk);
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.Name = "Login";
        this.Text = "Login";
        this.Load += new System.EventHandler(this.Login_Load);
        ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button cmdOk;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Button cmd3DCancel;
    private System.Windows.Forms.Button BtnPassInit;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label lblTestEnv;
    private System.Windows.Forms.PictureBox pictureBox1;
    public System.Windows.Forms.TextBox txtUserID;
    public System.Windows.Forms.TextBox txtPassword;
    private System.Windows.Forms.Button btnPassChange;
    public System.Windows.Forms.TextBox txtDSN;
}
