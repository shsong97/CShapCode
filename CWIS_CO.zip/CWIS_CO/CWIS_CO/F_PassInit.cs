﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;


public partial class F_PassInit : Form
{
    public F_PassInit()
    {
        InitializeComponent();
    }

    private void btnOk_Click(object sender, EventArgs e)
    {
        string empno = "";
        string EncryptPWD;
        string UserName, description, requestNo;

        string RandPWD = InitPass();
        string server = GlobalSetting.gCo_Server;

        int result = 0;
        string mail = "";

        //'check logic
        if (txtIDNo.Text == "")
        {
            MessageBox.Show("아이디를 입력하십시요!");
            return;
        }
        else if (txtSSN1.Text == "" || txtSSN2.Text == "")
        {
            MessageBox.Show("주민등록번호를 입력하십시오!");
            return;
        }
        else if (!Information.IsNumeric(txtSSN1.Text) || !Information.IsNumeric(txtSSN2.Text))
        {
            MessageBox.Show("주민등록번호에 문자가 있습니다");
            return;
        }
        else if (txtSSN1.Text.Length != 6 || txtSSN2.Text.Length != 7)
        {
            MessageBox.Show("주민등록번호 길이가 맞지않습니다!");
            return;
        }


        string SQL = " select emp_num, active_flag,user_name_k from common.dbo.user_info where user_id='" + txtIDNo.Text + "'";
        GRS g = new GRS(SQL);
        if (g.RowCount > 0)
        {

            if (g.gRS(1) == "D")
            {
                MessageBox.Show("180일이상 미사용하여 ID가 삭제되었으니 BICS에 신규 ID등록바랍니다!");
                return;
            }
            else if (g.gRS(1) == "T")
            {
                MessageBox.Show("ID가 삭제되었으니 BICS에 신규 ID등록바랍니다!");
                return;
            }
            else
            {
                empno = g.gRS(0);
                UserName = g.gRS(2);
            }
        }
        else
        {
            MessageBox.Show("사번이 존재하지 않습니다!");
            return;
        }

        //아래는 인사서버에서 처리함.
        SQL = " EXEC COMMON.dbo.S_CHK_EMP '" + empno + "','" +
                txtSSN1.Text + txtSSN2.Text + "','" + result + "' ,'" + mail + "' ";

        g = new GRS(SQL);

        result = g.gRSInt(0);
        mail = g.gRS(1);

        if (result == 1)
        {
            MessageBox.Show("재직중이 아닌 사번입니다");
            return;
        }
        else if (result == 2)
        {
            MessageBox.Show("등록되지 않은 주민등록번호 입니다!");
            return;
        }
        else if (result == 3)
        {
            MessageBox.Show("등록되어 있는 메일 ID가 없습니다. BICS 시스템에 문의하십시요!");
            return;
        }

        //'request 등록
        description = cboReason.SelectedItem.ToString();
        string date = DateTime.Now.Year + "-" + Strings.Format(DateTime.Now.Month, "00") + "-" + Strings.Format(DateTime.Now.Day, "00");
        SQL = " EXEC common.dbo.sp_request_mgt '"
             + UserName + "','"
             + date + "','Password자동초기화','"
             + description + "','','',NULL,'"
             + txtIDNo.Text + "'";

        g = new GRS(SQL);

        requestNo = g.gRS(0);

        //'초기화 시킴
        Encrypt enc = new Encrypt();
        EncryptPWD = enc.EncryptPassword(RandPWD);

        SQL = "EXEC common.dbo.sp_user_password_edit '"
            + txtIDNo.Text + "','"
            + txtIDNo.Text + "','"
            + RandPWD + "','"
            + EncryptPWD + "','"
            + requestNo + "','Y'";

        g = new GRS(SQL);
        MessageBox.Show("초기화된 패스워드가 등록된 메일계정으로 전달되었습니다\n패스워드 :" + RandPWD, "메일 발송");

        this.Close();
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    private string InitPass()
    {
        int inx, int_cnt, char_cnt, spcl_cnt;
        bool init_flag;
        string[] spcl = new string[11];
        string init_pass = "";
        //Randomize
        Random rand = new Random();
        spcl[0] = "~";
        spcl[1] = "!";
        spcl[2] = "@";
        spcl[3] = "#";
        spcl[4] = "$";
        spcl[5] = "%";
        spcl[6] = "^";
        spcl[7] = "+";
        spcl[8] = "*";
        spcl[9] = "(";
        spcl[10] = ")";

        init_flag = false;

        while (!init_flag)
        {
            string temp = "00000000" + rand.Next(0, 99999999).ToString();
            init_pass = temp.Substring(temp.Length - 8, 8);

            inx = rand.Next(1, 7);
            init_pass = init_pass.Substring(0, inx - 1) + Microsoft.VisualBasic.Strings.Chr(rand.Next(0, 25) + 65) + init_pass.Substring(init_pass.Length - 8 + inx, 8 - inx);

            inx = rand.Next(1, 7);
            init_pass = init_pass.Substring(0, inx - 1) + Strings.Chr(rand.Next(0, 25) + 97) + init_pass.Substring(init_pass.Length - 8 + inx, 8 - inx);

            inx = rand.Next(1, 7);
            init_pass = init_pass.Substring(0, inx - 1) + Strings.Chr(rand.Next(0, 25) + 65) + init_pass.Substring(init_pass.Length - 8 + inx, 8 - inx);

            inx = rand.Next(1, 7);
            init_pass = init_pass.Substring(0, inx - 1) + Strings.Chr(rand.Next(0, 25) + 97) + init_pass.Substring(init_pass.Length - 8 + inx, 8 - inx);

            inx = rand.Next(1, 7);
            init_pass = init_pass.Substring(0, inx - 1) + spcl[rand.Next(0, 10)] + init_pass.Substring(init_pass.Length - 8 + inx, 8 - inx);

            inx = rand.Next(1, 7);
            init_pass = init_pass.Substring(0, inx - 1) + spcl[rand.Next(0, 10)] + init_pass.Substring(init_pass.Length - 8 + inx, 8 - inx);

            int_cnt = 0;
            char_cnt = 0;
            spcl_cnt = 0;
            for (int i = 0; i < init_pass.Length; i++)
            {
                if (Information.IsNumeric(init_pass.Substring(i, 1)))
                    int_cnt++;
                else if ((init_pass.Substring(i, 1).CompareTo("A") >= 0 && init_pass.Substring(i, 1).CompareTo("Z") <= 0)
                    || (init_pass.Substring(i, 1).CompareTo("a") >= 0 && init_pass.Substring(i, 1).CompareTo("z") <= 0))
                    char_cnt++;
                else
                    spcl_cnt++;
            }

            if (int_cnt >= 2 && char_cnt >= 2 && spcl_cnt >= 2)
                init_flag = true;
        }

        return init_pass;
    }

    private void F_PassInit_Load(object sender, EventArgs e)
    {
        cboReason.Items.Add("1. 암호분실");
        cboReason.Items.Add("2. Password 5회 오입력");
        cboReason.Items.Add("3. 장기미사용");
        cboReason.SelectedIndex = 0;

        txtIDNo.Text = "";
        txtSSN1.Text = "";
        txtSSN2.Text = "";
    }
}


