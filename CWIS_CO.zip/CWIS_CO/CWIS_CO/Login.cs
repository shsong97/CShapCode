﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

public partial class Login : Form
{
    public string Section = "";
    public string gPgmTargetPath = "";
    public string gPgmConfigFile = "";

    Encrypt enc = new Encrypt();

    public Login()
    {
        InitializeComponent();
    }

    private void cmdOk_Click(object sender, EventArgs e)
    {
        GlobalSetting.gCancelFlag = true;
        GlobalSetting.gIsValidUser = false;
        txtUserID.Text = txtUserID.Text.ToUpper();

        string SQL = "exec common.dbo.s_last_login_check '" + txtUserID.Text + "'";
        GRS g = new GRS(SQL);

        if (g.RowCount == 0)
        {
            MessageBox.Show("아이디가 존재하지 않습니다");
            return;
        }

        GlobalSetting.gLastLoginDate = g.gRS(0);

        GlobalSetting.gCo_Server = txtDSN.Text.ToUpper().Trim();
        if (!gSystemLogin(GlobalSetting.gCo_Server, txtUserID.Text, txtPassword.Text))
            return;

        if (GlobalSetting.gMustBeChanged)
        {
            if (!gPasswordChange(GlobalSetting.gCo_Server, txtUserID.Text))
                return;
            else
                GlobalSetting.gMustBeChanged = false;
        }

        GlobalSetting.gUserID = txtUserID.Text;
        GlobalSetting.gUserPwd = txtPassword.Text;
        GlobalSetting.gIsValidUser = true;
        GlobalSetting.gCancelFlag = false;
        Close();
    }

    public bool lIsPasswordCheck(string userid, string password)
    {
        string Sql = "EXEC common.dbo.sp_id_pwd_check 'P','" + userid + "','',''";
        GRS g = new GRS(Sql);
        if (g.RowCount == 0)
        {
            MessageBox.Show("사용자 암호 Check하는 SP(" + Sql + ") 수행중 에러발생.");
            return false;
        }

        if (g.gRSInt(0) != 0)
        {
            MessageBox.Show(g.gRS(1));
            return false;
        }

        if (!enc.IsCorectPassword(password, g.gRS(2)))
        {
            Sql = "EXEC common.dbo.sp_id_pwd_check 'E','" + userid + "','',''";
            g = new GRS(Sql);
            if (g.RowCount == 0)
            {
                MessageBox.Show("사용자 암호 샐패Seting SP(" + Sql + ") 수행중 에러발생.");
                return false;
            }

            MessageBox.Show("비밀번호가 틀립니다. 재입력....");
            return false;
        }

        return true;
    }

    public bool LoginCheckWithoutForm(string server, string userid, string password)
    {
        GlobalSetting.gCancelFlag = true;
        GlobalSetting.gIsValidUser = false;

        string SQL = "exec common.dbo.s_last_login_check '" + userid + "'";
        GRS g = new GRS(SQL);

        if (g.RowCount == 0)
        {
            MessageBox.Show("아이디가 존재하지 않습니다");
            return false;
        }

        GlobalSetting.gLastLoginDate = g.gRS(0);
        GlobalSetting.gCo_Server = server;
        GlobalSetting.gUserPwd = password;

        if (!gSystemLogin(server, userid, password))
        {
            //error
            return false;
        }

        if (GlobalSetting.gMustBeChanged)
        {
            if (!gPasswordChange(GlobalSetting.gCo_Server, userid))
                return false;
            else
                GlobalSetting.gMustBeChanged = false;
        }

        GlobalSetting.gUserID = userid;
        GlobalSetting.gIsValidUser = true;
        GlobalSetting.gCancelFlag = false;

        return true;
    }

    public bool lLoginEtcCheck(string userid, string password)
    {
        string encpyt_password = enc.EncryptPassword(password);
        string Sql = "EXEC common.dbo.sp_id_pwd_check '" + "C" + "','" + userid + "','" + encpyt_password + "'";
        GRS g = new GRS(Sql);

        if (g.RowCount == 0)
        {
            MessageBox.Show("암호 Check SP(" + Sql + ")수행중 에러발생.");
            return false;
        }

        if (g.gRSInt(0) == 7)
        {
            GlobalSetting.gMustBeChanged = true;
            return true;
        }

        if (g.gRSInt(0) == 0)
            return true;

        MessageBox.Show(g.gRS(1));
        return false;
    }
    public bool gSystemLogin(string server, string userid, string password)
    {
        if (server.Length == 0)
        {
            MessageBox.Show("서버명을 입력하세요");
            return false;
        }
        if (!lIsPasswordCheck(userid, password))
            return false;

        if (!lLoginEtcCheck(userid, password))
            return false;

        GlobalSetting.gIsValidUser = true;
        return true;
    }
    public bool gPasswordChange(string server, string userid)
    {
        GlobalSetting.gUserID = txtUserID.Text;
        F_ChangePW chPw = new F_ChangePW();
        chPw.ShowDialog();
        return chPw.result;
    }
    private void cmd3DCancel_Click(object sender, EventArgs e)
    {
        GlobalSetting.gCancelFlag = true;
        Close();
    }

    private void BtnPassInit_Click(object sender, EventArgs e)
    {
        F_PassInit passinit = new F_PassInit();
        passinit.ShowDialog();
    }

    private void pictureBox1_DoubleClick(object sender, EventArgs e)
    {
        txtDSN.Enabled = !txtDSN.Enabled;
    }

    private void Login_Load(object sender, EventArgs e)
    {
        string lKeyValue;

        this.CenterToParent();
        GlobalSetting.gCancelFlag = true;

        Section = GlobalSetting.gTestEnvironment ? "Test" : "Prod";
        lblTestEnv.Visible = GlobalSetting.gTestEnvironment?true:false;

        if (!File.Exists(gPgmTargetPath + gPgmConfigFile))
            return;

        lKeyValue = GlobalSetting.GetProfileString("Co_Server", Section, gPgmTargetPath + gPgmConfigFile);

        txtDSN.Enabled = false;
        txtDSN.Text = lKeyValue;
        GlobalSetting.gCancelFlag = false;

    }

    private void btnPassChange_Click(object sender, EventArgs e)
    {
        GlobalSetting.gUserID = txtUserID.Text;
        F_ChangePW changePw = new F_ChangePW();
        changePw.ShowDialog();
    }
}

