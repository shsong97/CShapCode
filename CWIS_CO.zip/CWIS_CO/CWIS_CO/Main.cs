﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.Devices;
using System.Diagnostics;



public partial class Main : Form
{
    #region Vairable declaration
    // 공통
    string gs_DomainName = "일반 프로그램";
    const string cDefaultBackgroundPicFile = "prod_main.bmp";
    const string cMainUpUsedAvifile = "FILECOPY.AVI";
    const string cMainPgmCopyTool = "MainUp.exe";
    const string gDefaultDB = "COMMON";

    // CWIS_CO 설정
    string gs_AppName = "CWIS_CO";
    const string cPgmSourcePath = @"\produsedfile$\";
    const string cPgmTargetPath = @"C:\CWIS_CO\";
    const string cPgmConfigFile = "LGIE_CO.INI";

    const string cMainSystemID = "CWIS_CO";
    const string cProdDbLogonID = "AppCwis";
    const string cProdDbLogonPwd = "app@.2012.04.CW";
    const string cTestDbLogonID = "AppCwis";
    const string cTestDbLogonPwd = "AppCwis";
    string Co_Server = "CWDBS03";



    string cPgmSourceServerPath = "";
    string cPgmTargetServerPath = "";

    // 업그레이드파일이 있는 서버 경로
    // 상위 폴더의 하위 디렉토리 구조
    string gSourceRootDir = "";
    string gSourceDataPath = "";
    string gSourceDllPath = "";
    string gSourceExePath = "";
    string gSourceIconPath = "";
    string gSourceReportPath = "";

    // Prod/Test인지에 따라 상수에서 결정됨.
    string gDbLogonID = "";
    string gDbLogonPwd = "";
    string gApplicationDomain = "";

    bool CancelFalg = false;

    string lAppSource;
    bool lMustBeUpgraded;
    string lOldVersion;
    string lNewVersion;
    bool lIsMainSystem;

    frm_App f = new frm_App();
    // 프로그램 Button 정보(Button, text, label)
    string[] ia_DomainApps;
    string[] ia_AppNames;
    string[] ia_AppStatus;
    Button[] cmdApp;
    Button[] lbl_Domain;

    // button 위치
    int buttonWidth = 160;
    int buttonHeight = 30;
    int startWidth = 30;
    int startHeight = 20;
    int leftMargin = 20;
    int topMargin = 15;

    #endregion

    public Main()
    {
        InitializeComponent();

        MainSub();
    }

    private void MainSub()
    {
        string lCommandLine = "";

        CancelFalg = true;
        Process aProcess = Process.GetCurrentProcess();
        string aProcName = aProcess.ProcessName;

        if (Process.GetProcessesByName(aProcName).Length > 1)
        {
            if (MessageBox.Show("프로그램이 이미 실행되어 있습니다.\n\n현 실행의 중단이 바람직합니다. ", "확인", MessageBoxButtons.OK) == DialogResult.OK)
            {
                return;
            }
        }


        //'Config화일에서 Client환경을 찾는다.
        if (!lGetEnvironmentConfig(lCommandLine))
            return;

        //'Common서버에 연결한다.
        DBManager.SetConnectionString("ODBC", GlobalSetting.gCo_Server, gDefaultDB, gDbLogonID, gDbLogonPwd);
        if (!DBManager.Open())
            return;

        //'사용자가 시스템에 Login한다.
        if (!gLogOn(lCommandLine, GlobalSetting.gProdEnvConfig))
            return;

        //'현재 Client의 버전과 서버의 버전을 비교해서 버전이 다르면 Upgrade한다.
        if (!gVerSionCheck(gs_DomainName, gs_AppName.ToUpper()))
            return;

        //lMustBeUpgraded = true;
        if (lMustBeUpgraded)
            if (!gFileSystemUpgrade(GlobalSetting.gCo_Server, GlobalSetting.gUserID, GlobalSetting.gUserPwd, gs_DomainName, gs_AppName.ToUpper(), lAppSource, lOldVersion, lNewVersion, lIsMainSystem))
                return;


        MessageBox.Show("마지막 접속일은 " + GlobalSetting.gLastLoginDate + " 입니다.", "시스템 접속", MessageBoxButtons.OK, MessageBoxIcon.Information);
        
        CancelFalg = false;

    }

    private bool gLogOn(string lCommandLine, bool gProdEnvConfig)
    {
        GlobalSetting.gTestEnvironment = !gProdEnvConfig;

        //Login form load
        Login login = new Login();
        login.gPgmTargetPath = cPgmTargetPath;
        login.gPgmConfigFile = cPgmConfigFile;
        login.ShowDialog();

        CancelFalg = GlobalSetting.gCancelFlag;

        if (CancelFalg)
            return false;

        if (!IsSystemAccessible(GlobalSetting.gUserID, gs_AppName))
            return false;

        return true; ;
    }

    private bool IsSystemAccessible(string UserID, string AppName)
    {
        if (UserID.Length == 0 || AppName.Length == 0)
            return false;

        if (!DBManager.IsOpen())
        {
            if (!DBManager.Open())
            {
                MessageBox.Show("시스템 접속 에러:IsSystemAccessible");
                return false;
            }
        }
        string SQL = " exec common.dbo.sp_get_token_for_access '" + UserID + "','" + AppName + "'";
        GRS g = new GRS(SQL);
        if (g.RowCount > 0)
        {
            if (g.gRS("access_token") == "1")
                return true;
            else
                return false;
        }
        else
        {
            MessageBox.Show("현사용자(" + UserID + ")는 시스템(" + AppName + ")에 접근 불가 합니다.");
            return false;
        }
    }

    private bool lGetEnvironmentConfig(string lCommandLine)
    {

        string lConfigValue = "";
        //Strings 클래스는 VisualBasic namespace안에 있음.
        if (Strings.InStr(lCommandLine, ",", CompareMethod.Text) > 1)
            GlobalSetting.gCo_Server = lCommandLine.Substring(0, Strings.InStr(lCommandLine, ",", CompareMethod.Text) - 1);

        lConfigValue = GlobalSetting.GetProfileString("ENVIRONMENT", "Config", cPgmTargetPath + cPgmConfigFile);

        if (lConfigValue == "")
            GlobalSetting.SetProfileString("ENVIRONMENT", "Config", "PROD", cPgmTargetPath + cPgmConfigFile);

        if (lConfigValue.ToUpper() == "TEST")
            GlobalSetting.gProdEnvConfig = false;
        else
            GlobalSetting.gProdEnvConfig = true;

        if (!GlobalSetting.gProdEnvConfig)
            gApplicationDomain = "appsTest";
        else
            gApplicationDomain = "apps";

        if (GlobalSetting.gProdEnvConfig)
        {
            gDbLogonID = cProdDbLogonID;
            gDbLogonPwd = cProdDbLogonPwd;
            GlobalSetting.gCo_Server = GlobalSetting.GetProfileString("Co_Server", "Prod", cPgmTargetPath + cPgmConfigFile);
        }
        else
        {
            gDbLogonID = cTestDbLogonID;
            gDbLogonPwd = cTestDbLogonPwd;
            GlobalSetting.gCo_Server = GlobalSetting.GetProfileString("Co_Server", "Test", cPgmTargetPath + cPgmConfigFile);
        }

        cPgmTargetServerPath = cPgmTargetPath + GlobalSetting.gCo_Server + @"\";
        cPgmSourceServerPath = @"\\" + GlobalSetting.gCo_Server + cPgmSourcePath; // 서버 경로설정

        gSourceRootDir = cPgmSourceServerPath;
        gSourceExePath = gSourceRootDir + @"Exe\";
        gSourceIconPath = gSourceRootDir + @"Icon\";
        gSourceDataPath = gSourceRootDir + @"Data\";
        gSourceReportPath = gSourceRootDir + @"Report\";
        gSourceDllPath = gSourceRootDir + @"Dll\";

        return true; ;
    }

    private void btnPwChange_Click(object sender, EventArgs e)
    {
        F_ChangePW changePw = new F_ChangePW();
        changePw.ShowDialog();
    }

    private void btnClose_Click(object sender, EventArgs e)
    {
        Close();
    }

    private void ButtonClickEvent(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        int index = (int)btn.Tag;
        cmdAppClick(index);
    }

    private void cmdAppClick(int index)
    {
        //각시스템 버튼 클릭시
        string lDomain = "";
        string lApplicationID = "";
        string lCommandExe = "";
        string lCommandLine = "";
        string errorMessage = "";

        string cmdAppLabel = cmdApp[index].Text;// index button 의 text

        if (!DBManager.IsOpen())
        {
            MessageBox.Show("현재 서버와의 연결이 끊어졌습니다.다시 시스템을 다시 시작 하세요.");
            Close();
        }

        lDomain = ia_DomainApps[index].Substring(0, 15).Trim();
        lApplicationID = ia_DomainApps[index].Substring(15, ia_DomainApps[index].Length - 15).Trim().ToUpper();

        if (lApplicationID.ToUpper() == "NEWMRP")
        {
            string target = "http://" + "okrcwa01" + "/Main.aspx?user_id=" + GlobalSetting.gUserID;
            System.Diagnostics.Process.Start(target);
            return;
        }

        errorMessage = "시스템(" + lDomain + "의" + lApplicationID + ")을 수행하던 중 에러가 발생하였습니다!!!!\n";
        errorMessage += "위치:cmdApp_Click(Index As Integer)\n";

        if (!CheckDuplicateLogon(GlobalSetting.gUserID, lApplicationID))
        {
            errorMessage += "Error Desc: CheckDuplicateLogon";
            MessageBox.Show(errorMessage);
            return;
        }
        if (!gVerSionCheck(lDomain, lApplicationID))
        {

            errorMessage += "Error Desc: gVerSionCheck";
            MessageBox.Show(errorMessage);
            return;
        }

        if (lMustBeUpgraded)
        {
            if (!gFileSystemUpgrade(GlobalSetting.gCo_Server, GlobalSetting.gUserID,
                GlobalSetting.gUserPwd,
                lDomain, lApplicationID,
                lAppSource, lOldVersion, lNewVersion, false))
            {
                errorMessage += "Error Desc: gVerSionCheck";
                MessageBox.Show(errorMessage);
                return;
            }
        }
        
        lCommandExe = cPgmTargetServerPath + lApplicationID + ".exe ";

        if (!File.Exists(lCommandExe))
        {
            MessageBox.Show("시스템(" + cmdAppLabel + ")에 대한 실행화일(" + lCommandExe + ")이 없습니다.\n전산실로 문의 바랍니다!!!");
            return;
        }

        lCommandLine = lCommandExe + GlobalSetting.gCo_Server + "," + GlobalSetting.gUserID + "," + GlobalSetting.gUserPwd;

        if (Interaction.Shell(lCommandLine, AppWinStyle.NormalFocus, false, -1) == 0)
        {
            MessageBox.Show("정상적으로 시스템(" + cmdAppLabel + ")을 수행하지 못하였습니다.");
        }

        this.WindowState = FormWindowState.Minimized;
    }

    private bool CheckDuplicateLogon(string UserID, string lApplicationID)
    {
        string GetCmpName = SystemInformation.ComputerName;
        string SQL = " exec common.dbo.sp_check_duplication_login_v2 '" +
            UserID.ToUpper() + "','" + lApplicationID.ToUpper() + "','" + GetCmpName + "'";

        GRS g = new GRS(SQL);
        if (g.RowCount > 0)
        {
            if (g.gRSInt(0) != 0)
            {
                MessageBox.Show("해당시스템에 이미 로그인된 상태입니다.\n" + g.gRS(1), "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        else
        {
            return false;
        }

        return true;
    }

    private bool gVerSionCheck(string lDomain, string lApplicationID)
    {
        string lProfileRtnValue = "";
        string lClientPCVersion = "";
        string lDatabaseVersion = "";
        string lCheckedFileName = "";

        lMustBeUpgraded = false;
        lCheckedFileName = lApplicationID + ".exe";

        string gSql = " select * from app_prog_info where domain = '" + lDomain +
            "' and app_program = '" + lApplicationID + "'";

        GRS g = new GRS(gSql);

        if (g.RowCount != 1)
        {
            MessageBox.Show("gVerSionCheck:\n프로그램에 대한 정보가 등록되지 않았습니다. (" + lDomain + ":" + lApplicationID + ")");
            return false;
        }


        if ((g.gRS("Status") == "T" || g.gRS("Status") == "P") &&
            lApplicationID != gs_AppName)
        {
            MessageBox.Show("gVerSionCheck:지금 실행할 수 없는 상태입니다!\n만약 급히 처리해야할 일이 있다면 전산실로 문의바랍니다.");
            return false;
        }

        lDatabaseVersion = g.gRS("version");
        lAppSource = g.gRS("source_path");

        // 마지막 \ 문자를 찾아서 그 앞까지는 디렉토리 
        lAppSource = lAppSource.Substring(0, lAppSource.Length - (Strings.InStr(1, Strings.StrReverse(lAppSource), @"\", CompareMethod.Text) - 1));

        if (lApplicationID == gs_AppName)
        {
            lProfileRtnValue = GlobalSetting.GetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID, cPgmTargetPath + cPgmConfigFile);
        }
        else
        {
            lProfileRtnValue = GlobalSetting.GetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID, cPgmTargetServerPath + cPgmConfigFile);
        }

        if (lProfileRtnValue == "")
        {
            if (lApplicationID == gs_AppName)
            {
                GlobalSetting.SetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID, cPgmTargetPath + lCheckedFileName, cPgmTargetPath + cPgmConfigFile);
                GlobalSetting.SetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID + "_Ver", "Init", cPgmTargetPath + cPgmConfigFile);
            }
            else
            {
                GlobalSetting.SetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID, cPgmTargetServerPath + lCheckedFileName, cPgmTargetServerPath + cPgmConfigFile);
                GlobalSetting.SetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID + "_Ver", "Init", cPgmTargetServerPath + cPgmConfigFile);
            }

            lClientPCVersion = "Init";
        }
        else
        {
            if (lApplicationID == gs_AppName)
            {
                lClientPCVersion = GlobalSetting.GetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID + "_ver", cPgmTargetPath + cPgmConfigFile);
            }
            else
            {
                lClientPCVersion = GlobalSetting.GetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID + "_ver", cPgmTargetServerPath + cPgmConfigFile);
            }
            if (lClientPCVersion == "")
            {
                GlobalSetting.SetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID + "_ver", "init", cPgmTargetPath + cPgmConfigFile);
            }
        }

        if (lDatabaseVersion != lClientPCVersion)
            lMustBeUpgraded = true;
        else
            lMustBeUpgraded = false;

        if (lApplicationID == cMainSystemID)
            lIsMainSystem = true;
        else
            lIsMainSystem = false;

        if (lApplicationID != cMainSystemID)
            f.lblVersion.Text = lClientPCVersion;

        lNewVersion = lDatabaseVersion;
        lOldVersion = lClientPCVersion;

        return true;
    }

    private bool gFileSystemUpgrade(string Co_Server, string UserID, string UserPwd,
        string lDomain, string lApplicationID, string lAppSource,
        string lOldVersion, string lNewVersion, bool lIsMainSystem)
    {

        string lUpgradedFileName = lApplicationID + ".exe";
        string errorMessage = "";

        if (!lIsMainSystem)
        {
            f = new frm_App();
            f.lblApp_program.Text = lApplicationID + "를 업그레이드 중입니다";
            f.lblVersion.Text ="Version : "+ lOldVersion + "===>" + lNewVersion;
            f.Show();
            Application.DoEvents();
        }

        #region if
        if (lIsMainSystem)
        {
            if (lOldVersion != lNewVersion)
            {
                MessageBox.Show("Main System을 Upgrade합니다." + lOldVersion + "에서 " + lNewVersion + "으로......", "Main 업그레이드");
            }
            if (!lUpdateMainSystem(lDomain, lApplicationID, Co_Server, UserID, UserPwd,
                gSourceExePath + cMainPgmCopyTool, cPgmTargetPath + cPgmConfigFile,
                gSourceIconPath + cMainUpUsedAvifile, gSourceExePath + lUpgradedFileName,
                cPgmTargetPath + lUpgradedFileName, lNewVersion))
            {
                errorMessage += "gFileSystemUpgrade->lUpdateMainSystem";
                errorMessage += "\n //Parameter=> lDomain:" + lDomain;
                errorMessage += "\n lApplicationID:" + lApplicationID;
                errorMessage += "\n lAppSource:" + lAppSource;
                errorMessage += "\n lNewVersion:" + lNewVersion;

                MessageBox.Show(errorMessage);
                return false;
            }
        }
        #endregion
        #region else-if:zip-version
        else if (lApplicationID == "PROD_PROJECT")
        {
            if (!lZIpVersionUp(lAppSource, cPgmTargetPath, lApplicationID))
            {
                errorMessage += "gFileSystemUpgrade->lZIpVersionUp";
                errorMessage += "\n //Parameter=> lDomain:" + lDomain;
                errorMessage += "\n lApplicationID:" + lApplicationID;
                errorMessage += "\n lAppSource:" + lAppSource;
                errorMessage += "\n lNewVersion:" + lNewVersion;

                MessageBox.Show(errorMessage);
                return false;
            }
            File.Copy(cPgmTargetPath + "prod_project.exe", cPgmTargetServerPath + "prod_project.exe", true);
            f.Hide();
        }
        #endregion
        #region else
        else
        {
            
            //if (GlobalSetting.gProdEnvConfig)
            //{
            //    if (!lUpdateSubSystem(lAppSource, cPgmTargetServerPath, lApplicationID))
            //    {
            //        errorMessage += "gFileSystemUpgrade->lUpdateSubSystem";
            //        errorMessage += "\n //Parameter=> lDomain:" + lDomain;
            //        errorMessage += "\n lApplicationID:" + lApplicationID;
            //        errorMessage += "\n lAppSource:" + lAppSource;
            //        errorMessage += "\n lNewVersion:" + lNewVersion;

            //        MessageBox.Show(errorMessage);
            //        return false;
            //    }
            //}
            //else
            //{
            //    if (!lUpdateSubSystem(lAppSource, cPgmTargetPath, lApplicationID + "_T"))
            //    {
            //        errorMessage += "gFileSystemUpgrade->lUpdateSubSystem";
            //        errorMessage += "\n //Parameter=> lDomain:" + lDomain;
            //        errorMessage += "\n lApplicationID:" + lApplicationID;
            //        errorMessage += "\n lAppSource:" + lAppSource;
            //        errorMessage += "\n lNewVersion:" + lNewVersion;

            //        MessageBox.Show(errorMessage);
            //        return false;
            //    }
            //}
            System.Threading.Thread.Sleep(30000);
            f.Close();
        }
        #endregion
        GlobalSetting.SetProfileString(gApplicationDomain, lDomain + "_" + lApplicationID + "_Ver", lNewVersion, cPgmTargetServerPath + cPgmConfigFile);

        return true;
    }


    private void Main_FormClosed(object sender, FormClosedEventArgs e)
    {
        DBManager.Close();
    }

    private void Main_Load(object sender, EventArgs e)
    {
        int li_Cnt2 = 0;
        string lTempStr = "";
        string lProfileRtnValue = "";

        string errorMessage = "위치:Form_Load()\n";

        if (CancelFalg)
        {
            Close();
            return;
        }

        lProfileRtnValue = GlobalSetting.GetProfileString("apps", "일반 프로그램_Picture", cPgmTargetPath + cPgmConfigFile);
        if (lProfileRtnValue.Equals(""))
        {
            if (File.Exists(cPgmTargetPath + cDefaultBackgroundPicFile))
            {
                // pictureBox1 image 경로에 배경화면 load
                this.BackgroundImage = Image.FromFile(cPgmTargetPath + cDefaultBackgroundPicFile);
            }
        }
        else
        {
            if (File.Exists(lProfileRtnValue))
            {
                this.BackgroundImage = Image.FromFile(lProfileRtnValue);
            }
        }

        //'사용가능한 프로그램을 select
        if (!lGetAcceessibleApp())
        {
            errorMessage += "Error Desc: lGetAcceessibleApp : 사용가능한 프로그램이 없습니다.";
            MessageBox.Show(errorMessage);
            return;
        }

        //    '화면에 나타나는 Button의 위치와 크기를 결정한다 -Start
        for (int li_Cnt = 0; li_Cnt < ia_AppNames.Length; li_Cnt++)
        {
            if (li_Cnt != 0)
            {
                cmdApp[li_Cnt].Top = cmdApp[li_Cnt - 1].Top + buttonHeight + topMargin;
            }
            else
            {
                cmdApp[li_Cnt].Top = lbl_Domain[0].Top + buttonHeight + topMargin;
            }

            if (lTempStr != ia_DomainApps[li_Cnt].Substring(0, 15).Trim())
            {
                lTempStr = ia_DomainApps[li_Cnt].Substring(0, 15).Trim();
                if (li_Cnt != 0)
                {
                    li_Cnt2 = li_Cnt2 + 1;
                }
                lbl_Domain[li_Cnt2].Top = startHeight;
                lbl_Domain[li_Cnt2].Left = startWidth + li_Cnt2 * (buttonWidth + leftMargin);
                lbl_Domain[li_Cnt2].Text = ia_DomainApps[li_Cnt].Substring(0, 15).Trim();
                lbl_Domain[li_Cnt2].Visible = true;
                lbl_Domain[li_Cnt2].Enabled = false;
                cmdApp[li_Cnt].Top = lbl_Domain[0].Top + buttonHeight + topMargin;

            }

            cmdApp[li_Cnt].Left = lbl_Domain[li_Cnt2].Left;
            cmdApp[li_Cnt].Text = ia_AppNames[li_Cnt];
            cmdApp[li_Cnt].Tag = li_Cnt; // ia_DomainApps[li_Cnt];
            cmdApp[li_Cnt].Visible = true;
            if (ia_AppStatus[li_Cnt] == "P")
                cmdApp[li_Cnt].Enabled = false;
            else
                cmdApp[li_Cnt].Enabled = true;
        }
        //    '화면에 나타나는 Button의 위치와 크기를 결정한다 -End

        //'서버명 directory가 존재하지 않으면 폴더 생성 및 환경파일 복사
        if (!Directory.Exists(cPgmTargetServerPath))
        {
            Directory.CreateDirectory(cPgmTargetServerPath);
            File.Copy(cPgmSourceServerPath + cPgmConfigFile, cPgmTargetServerPath + cPgmConfigFile, true);
        }

        lblTestContent.Text = lblTestContent.Text + "(" + GlobalSetting.gCo_Server + ")";
        if (GlobalSetting.gCo_Server == Co_Server)
            lblTestContent.Visible = false;
        else
            lblTestContent.Visible = true;

    }

    private bool lGetAcceessibleApp()
    {
        string SQL = " exec common.dbo.sp_accessible_apps '" + GlobalSetting.gUserID + "' ";
        GRS g = new GRS(SQL);
        if (g.RowCount > 0)
        {
            ia_DomainApps = new string[g.RowCount];
            ia_AppNames = new string[g.RowCount];
            ia_AppStatus = new string[g.RowCount];
            cmdApp = new Button[g.RowCount];
            lbl_Domain = new Button[g.RowCount];
            
            for (int i = 0; i < g.RowCount; i++)
            {
                ia_DomainApps[i] = g.gRS(0) + "               " + g.gRS(1);
                ia_AppNames[i] = g.gRS(2);
                ia_AppStatus[i] = g.gRS(3);
                cmdApp[i] = new Button();
                cmdApp[i].Size = new System.Drawing.Size(buttonWidth, buttonHeight);
                cmdApp[i].Visible = false;
                //click event 등록
                cmdApp[i].Click += new System.EventHandler(ButtonClickEvent);

                lbl_Domain[i] = new Button();
                lbl_Domain[i].Size = new System.Drawing.Size(buttonWidth, buttonHeight);
                lbl_Domain[i].Visible = false;
                this.Controls.Add(this.cmdApp[i]);
                this.Controls.Add(this.lbl_Domain[i]);
                g.MoveNext();
                
            }
            

        }
        else
            return false;

        return true;
    }

    private bool lZIpVersionUp(string lSourceDir, string lToDir, string lFileName)
    {
        string lSvrZipName = lSourceDir + lFileName + "_z.exe";
        string lPcZipName = lToDir + lFileName + "_z.exe";

        if (!File.Exists(lSvrZipName))
        {
            MessageBox.Show("소스화일(" + lSvrZipName + ")이 존재하지 않습니다. \n전산실로 연락바랍니다.");
            return false;
        }

        if (File.Exists(lToDir + lFileName + ".EXE"))
        {
            try
            {
                File.Delete(lToDir + lFileName + ".EXE");
            }
            catch (Exception e)
            {
                MessageBox.Show("PC화일(" + lToDir + lFileName + ".EXE" + ")이 메모리상에 상주하고 있습니다.해당 프로그램을 종료하고 다시 수행하십시요!!!!\n Error Desc : " + e.Message);
                return false;
            }
        }

        if (File.Exists(lPcZipName))
        {
            try
            {
                File.Delete(lPcZipName);
            }
            catch (Exception e)
            {
                MessageBox.Show("PC화일(" + lPcZipName + ")이 비정상적입니다.해당 화일(" + lPcZipName + ")을 직접 삭제후 수행하십시요.\n Error Desc : " + e.Message);
                return false;
            }
        }

        File.Copy(lSvrZipName, lPcZipName, true);

        if (!File.Exists(lPcZipName))
        {
            MessageBox.Show("Zip화일(" + lPcZipName + ")이 PC로 Copy되지 않았습니다!!. \n전산실로 연락바랍니다.");
            return false;
        }

        if (Interaction.Shell(lPcZipName, AppWinStyle.NormalFocus, false, -1) == 0)
        {
            MessageBox.Show("Zip 화일(" + lPcZipName + ")이 정상적이지 않습니다!!! 전산실 문의 바람.");
            return false;
        }

        return true;
    }

    private bool lUpdateMainSystem(string lDomain, string lApplicationID, string lCoServer, string lUserId,
        string lUserPwd, string lMainPgmCopyTool, string lPgmConfigFile,
        string lMainUpUsedAvifile, string lMainSourceFile, string lMainTargetFile, string lNewVersion)
    {
        // Main시스템을 종료하고 업그레이드 하는 로직

        string lCommandArgumentStr;

        if (lDomain.Length == 0 || lApplicationID.Length == 0 ||
            lMainSourceFile.Length == 0 || lMainTargetFile.Length == 0 ||
            lNewVersion.Length == 0 || lCoServer.Length == 0 ||
            lUserId.Length == 0 || lUserPwd.Length == 0)
        {
            MessageBox.Show("데이타 중에 빈 값이 있습니다!!!");
            return false;
        }
        //신규 방식
        lCommandArgumentStr = lMainPgmCopyTool + " " +
            lMainSourceFile + "," +
            lMainTargetFile + "," +
            lNewVersion + "," +
            lCoServer + "," +
            lUserId + "," +
            lUserPwd;

        if (!File.Exists(lMainSourceFile))
        {
            MessageBox.Show("서버에 화일(" + lMainSourceFile + ")이 존재하지 않습니다. \n전산실로 연락바랍니다.");
            return false;
        }

        if (!File.Exists(lMainPgmCopyTool))
        {
            MessageBox.Show("main_up.exe 화일(" + lMainPgmCopyTool + ")이 존재하지 않습니다. \n전산실로 연락바랍니다.");
            return false;
        }

        if (!File.Exists(lPgmConfigFile))
        {
            MessageBox.Show("main_up에서 사용되어지는 화일(" + lPgmConfigFile + ")이 존재하지 않습니다. \n전산실로 연락바랍니다.");
            return false;
        }

        if (Interaction.Shell(lCommandArgumentStr, AppWinStyle.NormalFocus, false, -1) == 0)
        {
            MessageBox.Show("Error!!");
        }

        return true;
    }

    private bool lUpdateSubSystem(string lSourceDir, string lToDir, string lFileName)
    {
        string lFileNameExe = lFileName + ".exe";

        if (!File.Exists(lSourceDir + lFileNameExe))
        {
            MessageBox.Show("소스화일(" + lSourceDir + lFileNameExe + ")이 존재하지 않습니다.전산실로 연락바랍니다.", "확인");
            return false;
        }
        File.Copy(lSourceDir + lFileNameExe, lToDir + lFileNameExe, true);

        return true;
    }


}

