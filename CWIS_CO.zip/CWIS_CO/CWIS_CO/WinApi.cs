﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

public class WinApi
{


    //flag Values 



    //왼쪽에서 오른쪽 

    public const int AW_HOR_POSITIVE = 0x1;

    //오른쪽에서 왼쪽 

    public const int AW_HOR_NEGATIVE = 0x2;

    //위에서 아래 

    public const int AW_VER_POSITIVE = 0x4;

    //아래에서 위로 

    public const int AW_VER_NEGATIVE = 0x08;

    //안쪽에서 접히면서(무너지면서) 

    public const int AW_CENTER = 0x10;

    //숨김 

    public const int AW_HIDE = 0x10000;

    //펼쳐지는 효과 

    public const int AW_ACTIVATE = 0x20000;

    //효과 설정 

    public const int AW_SLIDE = 0x40000;

    //흐려지는 효과 

    public const int AW_BLEND = 0x80000;





    [DllImport("user32.dll")]

    public static extern int AnimateWindow(IntPtr hwand, int dwTime, int dwFlags); 

}
