﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

public class Encrypt
{
    public bool IsCorectPassword(string original, string encrypt)
    {
        //sha256 알고리즘으로 패스워드 비교후 일치하면 true
        /*
         * 알고리즘 삽입
         * */

        string EncryptPassword = Hash.GetSHA256(original);

        if (EncryptPassword.Equals(encrypt))
            return true;
        else
            return false;
    }
    public string EncryptPassword(string password)
    {
        return Hash.GetSHA256(password);
    }
}

