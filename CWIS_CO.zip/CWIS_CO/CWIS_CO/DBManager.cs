﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.Configuration;
using System.Windows.Forms;
/// <summary>
/// DB 관련 공통 모듈.
/// </summary>
public class DBManager
{
    /*
     * SQL 디버깅을 사용할 수 있는 SqlConnection을 열려면 
     * .NET Framework Data Provider for SQL Server에 "Allows calls to unmanaged assemblies"를 사용할 수 있는 
     * Security 권한(SecurityPermissionFlag가 UnmanagedCode로 설정된 SecurityPermission)이 있어야 합니다.
    */
    public static SqlConnection SqlCon = null;
    public static OdbcConnection OdbcCon = null;

    public static string ErrorMessage = "";
    public static string ConnectionType = "ODBC";

    public static string ConnString = "";

    public DBManager()
    {
        DBManager.ConnectionType = "ODBC";
    }


    public DBManager(string ConnectionType)
    {
        DBManager.ConnectionType = ConnectionType;
    }

    public static void SetConnectionString(string connectionType, string servername, string dbname, string id, string password)
    {
        DBManager.ConnectionType = connectionType;
        switch (connectionType)
        {
            case "SqlConnection":
                ConnString = "Persist Security Info=False;Integrated Security=false;" +
                    "Initial Catalog=" + dbname +
                    ";server=" + servername +
                    ";UID=" + id +
                    ";PWD=" + password;
                break;
            case "ODBC":
                ConnString = "Driver={SQL Server};Server=" + servername +
                    ";Database=" + dbname +
                    ";Uid=" + id +
                    ";Pwd=" + password;
                break;
        }
    }

    public static bool IsOpen()
    {
        bool result = false;
        switch (DBManager.ConnectionType)
        {
            case "SqlConnection":
                if (SqlCon.State != ConnectionState.Open)
                    result = false;
                else
                    result = true;
                break;
            case "ODBC":
                if (OdbcCon.State != ConnectionState.Open)
                    result = false;
                else
                    result = true;
                break;
            default:
                break;

        }
        return result;
    }

    public static bool Open()
    {
        bool returnValue = true;
        switch (DBManager.ConnectionType)
        {
            case "SqlConnection":
                #region SqlConnection방식
                //default SqlConnection 방식
                try
                {
                    // Sql Connection 객체 생성
                    if (SqlCon == null)
                        SqlCon = new SqlConnection(DBManager.ConnString);

                    // DB 연결 상태가 Open이 아닐 경우에는 DB 연결을 종료한다.
                    if (SqlCon.State != ConnectionState.Open)
                    {
                        // DB에 연결되어 있으면 접속을 종료한다.
                        if (SqlCon.State == ConnectionState.Connecting)
                            SqlCon.Close();

                        // DB에 연결
                        SqlCon.Open();
                    }

                }
                catch (SqlException se)
                {
                    // 오류 메시지 저장
                    DBManager.ErrorMessage = se.Message.ToString();
                    returnValue = false;
                }
                catch (Exception e)
                {
                    DBManager.ErrorMessage = e.Message.ToString();
                    returnValue = false;
                }
                break;
                #endregion

            case "ODBC":
                #region ODBC방식
                //default SqlConnection 방식
                try
                {
                    // ODBC Connection 객체 생성
                    if (OdbcCon == null)
                        OdbcCon = new OdbcConnection(DBManager.ConnString);

                    // DB 연결 상태가 Open이 아닐 경우에는 DB 연결을 종료한다.
                    if (OdbcCon.State != ConnectionState.Open)
                    {
                        // DB에 연결되어 있으면 접속을 종료한다.
                        if (OdbcCon.State == ConnectionState.Connecting)
                            OdbcCon.Close();

                        // DB에 연결
                        OdbcCon.Open();
                    }

                }
                catch (OdbcException se)
                {
                    // 오류 메시지 저장
                    DBManager.ErrorMessage = se.Message.ToString();
                    returnValue = false;
                }
                catch (Exception e)
                {
                    DBManager.ErrorMessage = e.Message.ToString();
                    returnValue = false;
                }
                break;
                #endregion

        }
        return returnValue;
    }

    public static bool Close()
    {
        bool returnValue = true;
        switch (ConnString)
        {
            case "SqlConnection":
                #region SqlConnection방식
                try
                {
                    if (SqlCon != null)
                    {
                        // DB 연결이 Closed가 아니면 DB 연결을 종료한다.
                        if (SqlCon.State != ConnectionState.Closed)
                            SqlCon.Close();
                    }
                }
                catch (SqlException se)
                {
                    DBManager.ErrorMessage = se.Message.ToString();
                    returnValue = false;
                }
                catch (Exception e)
                {
                    DBManager.ErrorMessage = e.Message.ToString();
                    returnValue = false;
                }
                break;
                #endregion

            case "ODBC":
                #region ODBC방식
                try
                {
                    if (OdbcCon != null)
                    {
                        // DB 연결이 Closed가 아니면 DB 연결을 종료한다.
                        if (OdbcCon.State != ConnectionState.Closed)
                            OdbcCon.Close();
                    }
                }
                catch (OdbcException se)
                {
                    DBManager.ErrorMessage = se.Message.ToString();
                    returnValue = false;
                }
                catch (Exception e)
                {
                    DBManager.ErrorMessage = e.Message.ToString();
                    returnValue = false;
                }
                break;
                #endregion

        }
        return returnValue;
    }

    public static int Execute(string strQuery)
    {
        int iResult = 0;
        switch (ConnectionType)
        {
            case "SqlConnection":
                #region SqlConnection방식
                //DbOpen();

                try
                {
                    if (SqlCon == null)
                        return -1;
                    SqlCommand SqlCmd = new SqlCommand();
                    SqlCmd.Connection = SqlCon;
                    // Sql 쿼리 문자열 설정
                    SqlCmd.CommandText = strQuery;
                    // Sql 쿼리 실행 한뒤 결과값을 리턴 받는다.
                    iResult = SqlCmd.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    DBManager.ErrorMessage = se.Message.ToString();
                    return -1;
                }

                //DbClose();
                break;
                #endregion

            case "ODBC":
                #region ODBC방식
                //DbOpen();

                try
                {
                    if (OdbcCon == null)
                        return -1;
                    OdbcCommand SqlCmd = new OdbcCommand();
                    SqlCmd.Connection = OdbcCon;
                    // Sql 쿼리 문자열 설정
                    SqlCmd.CommandText = strQuery;
                    // Sql 쿼리 실행 한뒤 결과값을 리턴 받는다.
                    iResult = SqlCmd.ExecuteNonQuery();
                }
                catch (OdbcException se)
                {
                    DBManager.ErrorMessage = se.Message.ToString();
                    return -1;
                }

                //DbClose();
                break;
                #endregion

        }

        return iResult;
    }


    public static DataSet Query(string strQuery)
    {
        DataSet dataSet = new DataSet();
        switch (ConnectionType)
        {
            case "SqlConnection":
                #region SqlConnection방식
                //DbOpen();

                try
                {
                    if (SqlCon == null)
                        return null;
                    SqlCommand SqlCmd = new SqlCommand();
                    SqlCmd.Connection = SqlCon;
                    SqlCmd.CommandText = strQuery;
                    SqlCmd.CommandTimeout = 90;
                    //SqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                    // Sql 쿼리를 실행하고 결과값을 DataSet에 저장한다.
                    SqlDataAdapter SqlAdapter = new SqlDataAdapter(SqlCmd);

                    SqlAdapter.Fill(dataSet);
                }
                catch (SqlException se)
                {
                    DBManager.ErrorMessage = se.Message.ToString();
                }

                //DbClose();
                break;
                #endregion

            case "ODBC":
                #region ODBC방식
                //DbOpen();

                try
                {
                    if (OdbcCon == null)
                        return null;
                    OdbcCommand SqlCmd = new OdbcCommand();
                    SqlCmd.Connection = OdbcCon;
                    SqlCmd.CommandText = strQuery;
                    SqlCmd.CommandTimeout = 90;
                    //SqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                    // Sql 쿼리를 실행하고 결과값을 DataSet에 저장한다.
                    OdbcDataAdapter SqlAdapter = new OdbcDataAdapter(SqlCmd);

                    SqlAdapter.Fill(dataSet);
                }
                catch (OdbcException se)
                {
                    DBManager.ErrorMessage = se.Message.ToString();
                    MessageBox.Show(DBManager.ErrorMessage);
                }

                //DbClose();

                break;
                #endregion

        }

        return dataSet;
    }


}
