﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace CrmConvert
{
    public partial class NE_CRM : Form
    {
        string ProjectNumber = "";
        string deleteTableSP = "S_ELOG_DELETE_CRM"; // 테스트할때는 S_ELOG_DELETE_CRM_NEW 로 하세요
        Dictionary<string, string> tableList = new Dictionary<string, string>();
        Dictionary<string, int> fieldList = new Dictionary<string, int>();
        bool stopflag = false;
        int totalcount = 0;
        int currentcount = 0;

        public NE_CRM()
        {
            InitializeComponent();
            /*
                P	T_Crm_Project_Record	39
                PLI	T_Crm_Project_Local_Info_Record	7
                PAD	T_Crm_Project_Address_Record	16
                PAC	T_Crm_Project_Account_Record	31
                PC	T_Crm_Project_Account_Contact_Record	9
                SRP	T_Crm_Project_Sales_Rep_Record	6
                PR	T_Crm_Proposal_Record	34
                CAE	T_Crm_Proposal_Configurable_Other_Expenses_Record	8
                PRL	T_Crm_Proposal_Local_Info_Record	8
                S	T_Crm_Solution_Record	17
                SLI	T_Crm_Solution_Local_Info_Record	9
                U	T_Crm_Unit_Record	82
                ULI	T_Crm_Unit_Local_Info_Record	10
                PPC	T_Crm_Proposal_level_price_and_cost_detail_Record	7
                UPC	T_Crm_Unit_level_price_and_cost_detail_Record	14
                PF	T_Crm_Proposal_level_Factor_Record	12
                UF	T_Crm_Unit_level_Factor_Record	15
            */
            fieldList.Add("P", 39);
            fieldList.Add("PLI", 7);
            fieldList.Add("PAD", 16);
            fieldList.Add("PAC", 31);
            fieldList.Add("PC", 9);
            fieldList.Add("SRP", 6);
            fieldList.Add("PR", 34);
            fieldList.Add("CAE", 8);
            fieldList.Add("PRL", 8);
            fieldList.Add("S", 17);
            fieldList.Add("SLI", 9);
            fieldList.Add("U", 82);
            fieldList.Add("ULI", 10);
            fieldList.Add("PPC", 7);
            fieldList.Add("UPC", 14);
            fieldList.Add("PF", 12);
            fieldList.Add("UF", 15);

            tableList.Add("P", "T_Crm_Project_Record");
            tableList.Add("PLI", "T_Crm_Project_Local_Info_Record");
            tableList.Add("PAD", "T_Crm_Project_Address_Record");
            tableList.Add("PAC", "T_Crm_Project_Account_Record");
            tableList.Add("PC", "T_Crm_Project_Account_Contact_Record");
            tableList.Add("SRP", "T_Crm_Project_Sales_Rep_Record");
            tableList.Add("PR", "T_Crm_Proposal_Record");
            tableList.Add("CAE", "T_Crm_Proposal_Configurable_Other_Expenses_Record");
            tableList.Add("PRL", "T_Crm_Proposal_Local_Info_Record");
            tableList.Add("S", "T_Crm_Solution_Record");
            tableList.Add("SLI", "T_Crm_Solution_Local_Info_Record");
            tableList.Add("U", "T_Crm_Unit_Record");
            tableList.Add("ULI", "T_Crm_Unit_Local_Info_Record");
            tableList.Add("PPC", "T_Crm_Proposal_level_price_and_cost_detail_Record");
            tableList.Add("UPC", "T_Crm_Unit_level_price_and_cost_detail_Record");
            tableList.Add("PF", "T_Crm_Proposal_level_Factor_Record");
            tableList.Add("UF", "T_Crm_Unit_level_Factor_Record");

            //tableList.Add("P", "T_Crm_Project_Record_new");
            //tableList.Add("PLI", "T_Crm_Project_Local_Info_Record_new");
            //tableList.Add("PAD", "T_Crm_Project_Address_Record_new");
            //tableList.Add("PAC", "T_Crm_Project_Account_Record_new");
            //tableList.Add("PC", "T_Crm_Project_Account_Contact_Record_new");
            //tableList.Add("SRP", "T_Crm_Project_Sales_Rep_Record_new");
            //tableList.Add("PR", "T_Crm_Proposal_Record_new");
            //tableList.Add("CAE", "T_Crm_Proposal_Configurable_Other_Expenses_Record_new");
            //tableList.Add("PRL", "T_Crm_Proposal_Local_Info_Record_new");
            //tableList.Add("S", "T_Crm_Solution_Record_new");
            //tableList.Add("SLI", "T_Crm_Solution_Local_Info_Record_new");
            //tableList.Add("U", "T_Crm_Unit_Record_new");
            //tableList.Add("ULI", "T_Crm_Unit_Local_Info_Record_new");
            //tableList.Add("PPC", "T_Crm_Proposal_level_price_and_cost_detail_Record_new");
            //tableList.Add("UPC", "T_Crm_Unit_level_price_and_cost_detail_Record_new");
            //tableList.Add("PF", "T_Crm_Proposal_level_Factor_Record_new");
            //tableList.Add("UF", "T_Crm_Unit_level_Factor_Record_new");
        }
        private void folderSearch_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            textFolderName.Text = folderBrowserDialog1.SelectedPath;
        }
        private void btnFileSearch_Click(object sender, EventArgs e)
        {
            if (textFolderName.Text == "")
            {
                MessageBox.Show("폴더를 선택하세요");
                return;
            }

            try
            {
                string searchOption = "02O101SK0101ELOG_CRM0*" + textFileOption.Text + "*.rdy";
                string[] filePaths = Directory.GetFiles(textFolderName.Text, searchOption);
                if (filePaths.Length == 0)
                {
                    dataGridView1.RowCount = 1;
                    dataGridView1[0, 0].Value = false;
                    dataGridView1[1, 0].Value = "";
                    dataGridView1[2, 0].Value = "";

                    dataGridView1[3, 0].Value = "";
                    dataGridView1[3, 0].Style.BackColor = Color.White;
                    dataGridView1[4, 0].Value = "";
                    dataGridView1[4, 0].Style.BackColor = Color.White;
                    dataGridView1[5, 0].Value = "";
                    dataGridView1[5, 0].Style.BackColor = Color.White;
                    dataGridView1[6, 0].Value = "";
                    dataGridView1[6, 0].Style.BackColor = Color.White;
                    return;
                }
                totalcount = filePaths.Length;
                dataGridView1.RowCount = totalcount;

                for (int i = 0; i < filePaths.Length; i++)
                {
                    string[] file_name = filePaths[i].Split('\\');

                    dataGridView1[0, i].Value = false;
                    dataGridView1[1, i].Value = file_name[file_name.Length - 1];
                    dataGridView1[2, i].Value = filePaths[i];

                    dataGridView1[3, i].Value = "Ready";
                    dataGridView1[3, i].Style.BackColor = Color.White;
                    dataGridView1[4, i].Value = "Ready";
                    dataGridView1[4, i].Style.BackColor = Color.White;
                    dataGridView1[5, i].Value = "Ready";
                    dataGridView1[5, i].Style.BackColor = Color.White;
                    dataGridView1[6, i].Value = "Ready";
                    dataGridView1[6, i].Style.BackColor = Color.White;
                    dataGridView1[7, i].Value = (i+1);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("파일 경로가 이상합니다.\n" + exception.StackTrace);
            }

        }
        private void btnRun_Click(object sender, EventArgs e)
        {
            stopflag = false;
            bWorker.RunWorkerAsync(100);
            setControl(false);
        }
        private void setControl(bool enable)
        {
            btnRun.Enabled = enable;
            btnFileSearch.Enabled = enable;
            folderSearch.Enabled = enable;
            btnSelectAll.Enabled = enable;            
        }
        private void excute(object sender, DoWorkEventArgs e)
        {
            try
            {
                //BackgroundWorker worker = sender as BackgroundWorker;
                for (int i = 0; i < dataGridView1.RowCount; i++)
                {
                    currentcount = i + 1;
                    if (bWorker.CancellationPending)
                    {
                        stopflag = true;
                    }
                    if (stopflag)
                    {
                        e.Cancel = true;
                        bWorker.ReportProgress(0);
                        break;
                    }
                    //컨트롤에 Text값을 할당하면 예외발생함. Microsoft.VisualStudio.Debugger.Runtime.CrossThreadMessagingException
                    //lblCurrent.Invoke((MethodInvoker)delegate { lblCurrent.Text = i.ToString(); });
                    bWorker.ReportProgress(100 * (i) / dataGridView1.RowCount);
                    Thread.Sleep(100);
                    if (!isCheckBoxChecked(i)) continue;

                    string filename = (string)dataGridView1[1, i].Value;
                    string full_filename = (string)dataGridView1[2, i].Value;
                    // CRM 수행대상 등록
                    if (!CrmFileRegister(filename))
                    {
                        dataGridView1[0, i].Value = false;
                        dataGridView1[3, i].Value = "Error";
                        dataGridView1[3, i].Style.BackColor = Color.Red;
                        continue;
                    }
                    dataGridView1[3, i].Value = "Completed";
                    dataGridView1[3, i].Style.BackColor = Color.Yellow;
                    this.ProjectNumber = "";
                    // 기존에 있는 내용 삭제
                    DeleteCrmTable(filename);
                    // CRM 테이블 Table insert
                    if (CrmTableInsert(filename, full_filename))
                    {
                        dataGridView1[4, i].Value = "Completed";
                        dataGridView1[4, i].Style.BackColor = Color.Yellow;
                        bool canRegisterProject = isRegisterProject(filename);
                        if (canRegisterProject)
                        {
                            // 프로젝트, 제번, 호기등록
                            CreateProject(filename);
                            Thread.Sleep(1000);
                            //dataGridView1[5, i].Value = "Completed";
                            //dataGridView1[5, i].Style.BackColor = Color.Yellow;
                            // Cost 수행
                            if (isRegisterSuccess(filename))
                            {
                                dataGridView1[5, i].Value = "Completed";
                                dataGridView1[5, i].Style.BackColor = Color.Yellow;
                                // Cost 수행
                                CalculationCost(filename, this.ProjectNumber);
                                Thread.Sleep(1000);
                                dataGridView1[6, i].Value = "Completed";
                                dataGridView1[6, i].Style.BackColor = Color.Yellow;

                                // CRM완료일자 셋팅
                                CrmFileRegisterComplete(filename);
                            }
                            else
                            {
                                dataGridView1[5, i].Value = "Error";
                                dataGridView1[5, i].Style.BackColor = Color.Red;
                            }
                        }
                    }
                    else
                    {
                        dataGridView1[4, i].Value = "Error";
                        dataGridView1[4, i].Style.BackColor = Color.Red;
                    }
                    dataGridView1[0, i].Value = false;
                }


            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.StackTrace);
            }
            finally
            {
                bWorker.ReportProgress(100);
            }
        }
        private bool isCheckBoxChecked(int i)
        {
            if (dataGridView1[0, i].Value == null)
                return false;

            return (bool)dataGridView1[0, i].Value;
        }
        private bool isRegisterSuccess(string crmFileName)
        {
            GRS grs = new GRS("select * from t_han_elog where rdy_name='" + crmFileName + "'");
            if (grs.RowCount > 0)
                return true;
            return false;
        }
        //수정대상
        private void DeleteCrmTable(string crmFileName)
        {
            GRS grs = new GRS("EXEC EL_BDH.dbo." + deleteTableSP + " '" + crmFileName + "'");
        }
        private bool CrmFileRegister(string crmFileName)
        {
            // CRM 파일을 T_FILE_UPLOAD에 등록한다.
            if (crmFileName.Contains("02O101SK0101ELOG_CRM0"))
            {
                string sql = " delete from EL_BDH.dbo.T_file_upload where sdata='" + crmFileName + "'";
                GRS grs = new GRS(sql);

                sql = " INSERT INTO EL_BDH.dbo.T_file_upload values ('" + crmFileName + "',2,null)";
                grs = new GRS(sql);
                return true;
            }
            else
            {
                //MessageBox.Show("CRM파일 형식이 아닙니다");
                return false;
            }
        }
        private bool CrmTableInsert(string crmFileName, string full_filename)
        {
            // T_CRM_UPLOAD 내용을 CRM_ 테이블로 insert한다
            // 텍스트 파일을 읽어서 각 테이블에 넣는다.
            // SP : S_ELOG_MAKE_CRM_TABLE
            // usp_SplitByDelimiterForTabPos 는 2를 빼고
            // usp_ExtractStrForTabs 는 1을 뺀다
            string[] lines = System.IO.File.ReadAllLines(full_filename, Encoding.Default);
            //lblTotal.Text = lines.Length.ToString();

            for (int index = 0; index < lines.Length; index++)
            {
                //lblCurrent.Text = index.ToString();
                string sdata = lines[index];
                string[] array = sdata.Split('\t');

                if (array.Length < 5)
                    continue;

                string record_type = array[0].ToUpper();
                this.ProjectNumber = array[1];
                string tableName="";
                int fieldCount=0;

                if (record_type == "B")
                    continue;
                try
                {
                    tableName = tableList[record_type];
                    fieldCount = fieldList[record_type];
                }
                catch (Exception e)
                {
                    //MessageBox.Show(record_type);
                    // 테이블에 정의되어있지 않으면 스킵
                    continue;
                }
                string query = "";
                GRS grs = null;
                
                if (record_type == "P")
                {
                    string project_status = array[5];
                    if (project_status == "10" || project_status == "40") // project_status 10, 40은 skip
                        return true;
                }
                else if (record_type == "SRP")
                {
                    string Sales_Rep = array[2];
                    query = "delete from T_Crm_Project_Sales_Rep_Record where rdy_name = '" +
                        crmFileName + "' and Project_Number = '" + this.ProjectNumber + "' and Sales_Rep = '" + Sales_Rep + "'";
                    grs = new GRS(query);
                }
                createCRMData(crmFileName, tableName, fieldCount, array);
            }
            return true;
        }
        //수정불요
        private void createCRMData(string crmFileName, string tablename, int filedCount, string[] array)
        {
            string query = "insert into "+ tablename;
            query += " select '" + crmFileName + "'";
            for (int i = 0; i < filedCount; i++)
            {
                query += "," + "'" + array[i] + "'";
            }
            GRS grs = new GRS(query);
        }
        private bool isRegisterProject(string crmFileName)
        {
            // 프로젝트 등록대상인지 확인한다.
            string sql = "EXEC EL_BDH.dbo.S_ELOG_PROJECT_CHECK '" + crmFileName + "'";
            GRS grs = new GRS(sql);
            string result=grs.gRS(0);
            if (result == "Y")
                return true;
            else if (result == "X")
            {
                //MessageBox.Show("영업담당자가 지정되지 않았습니다. 등록불가합니다.");
                return false;
            }
            else
            {
                //if (MessageBox.Show("Partial 제번일 수 있습니다. 그래도 등록하시겠습니까?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                //    return true;
                //else
                    return false;
            }
            //return false;
        }
        private void CreateProject(string crmFileName)
        {
            // S_ELOG_MAKE_PJTMFG 를 수행한다.
            string sql = "EXEC EL_BDH.dbo.S_ELOG_MAKE_PJTMFG '" + crmFileName + "'";
            GRS grs = new GRS(sql); 
        }
        private void CalculationCost(string crmFileName, string ProjectNumber)
        {
            // S_ELOG_MAKE_EST 를 수행한다.
            string sql = "EXEC EL_BDH.dbo.S_ELOG_MAKE_EST '" + crmFileName + "','" + ProjectNumber + "','%'";
            GRS grs = new GRS(sql); 
        }
        private void CrmFileRegisterComplete(string crmFileName)
        {
            // T_FILE_UPLOAD에 완료일자를 셋팅한다.
            string sql = "UPDATE A SET DONE_DATE = GETDATE()  FROM EL_BDH.dbo.T_file_upload A WHERE sData = '" + crmFileName + "'";
            GRS grs = new GRS(sql); 
        }
        /*
         * backgroudworker 실행
         * */
        private void bWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            excute(sender, e);
        }
        private void bWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pBar.Value = e.ProgressPercentage;
            lblTotal.Text = "전체 " + totalcount.ToString() + "개 중 " + currentcount.ToString() + "개 수행중입니다.";
        }
        private void bWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show("작업수행중 에러 발생 :" + e.Error.Message);
            }
            else if (e.Cancelled == true)
            {
                MessageBox.Show("작업이 취소되었습니다.");
            }
            else
            {
                MessageBox.Show("작업 완료되었습니다.");
            }
            setControl(true);
        }
        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1[0, i].Value = true;
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (bWorker.IsBusy)
            {
                bWorker.CancelAsync();
                stopflag = true;
            }
        }
         
    }
}
