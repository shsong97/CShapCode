﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace CrmConvert
{
    public partial class FileSearch : Form
    {
        bool stopflag = false;
        int totalcount = 0;
        int currentcount = 0;

        public FileSearch()
        {
            InitializeComponent();
        }
        private void folderSearch_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            textFolderName.Text = folderBrowserDialog1.SelectedPath;
        }
        private void btnFileSearch_Click(object sender, EventArgs e)
        {
            if (textFolderName.Text == "")
            {
                MessageBox.Show("폴더를 선택하세요");
                return;
            }

            try
            {
                string searchOption = "02O101SK0101ELOG_CRM0*" + textFileOption.Text + "*.rdy";
                string[] filePaths = Directory.GetFiles(textFolderName.Text, searchOption);
                if (filePaths.Length == 0)
                {
                    dataGridView1.RowCount = 1;
                    dataGridView1[0, 0].Value = false;
                    dataGridView1[1, 0].Value = "";
                    dataGridView1[2, 0].Value = "";

                    dataGridView1[3, 0].Value = "";
                    dataGridView1[3, 0].Style.BackColor = Color.White;

                    return;
                }
                totalcount = filePaths.Length;
                dataGridView1.RowCount = totalcount;

                for (int i = 0; i < filePaths.Length; i++)
                {
                    string[] file_name = filePaths[i].Split('\\');

                    dataGridView1[0, i].Value = false;
                    dataGridView1[1, i].Value = file_name[file_name.Length - 1];
                    dataGridView1[2, i].Value = filePaths[i];

                    dataGridView1[3, i].Value = "Ready";
                    dataGridView1[3, i].Style.BackColor = Color.White;
                    dataGridView1[4, i].Value = (i + 1);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("파일 경로가 이상합니다.\n" + exception.StackTrace);
            }

        }
        private void btnRun_Click(object sender, EventArgs e)
        {
            stopflag = false;
            bWorkerFileSearch.RunWorkerAsync(100);
            setControl(false);
        }
        private void setControl(bool enable)
        {
            btnRun.Enabled = enable;
            btnFileSearch.Enabled = enable;
            folderSearch.Enabled = enable;
            btnSelectAll.Enabled = enable;
        }
        private void excute(object sender, DoWorkEventArgs e)
        {
            try
            {
                //BackgroundWorker worker = sender as BackgroundWorker;
                for (int i = 0; i < dataGridView1.RowCount; i++)
                {
                    currentcount = i + 1;
                    if (bWorkerFileSearch.CancellationPending)
                    {
                        stopflag = true;
                    }
                    if (stopflag)
                    {
                        e.Cancel = true;
                        bWorkerFileSearch.ReportProgress(0);
                        break;
                    }
                    bWorkerFileSearch.ReportProgress(100 * (i) / dataGridView1.RowCount);
                    Thread.Sleep(100);

                    string filename = (string)dataGridView1[1, i].Value;
                    string full_filename = (string)dataGridView1[2, i].Value;
                    // CRM 수행대상 등록
                    if ((bool)dataGridView1[0, i].Value)
                    {
                        if (!CrmFIleSearch(full_filename))
                        {
                            dataGridView1[0, i].Value = false;
                            dataGridView1[3, i].Value = "Error";
                            dataGridView1[3, i].Style.BackColor = Color.Red;
                        }
                        else
                        {
                            dataGridView1[0, i].Value = false;
                            dataGridView1[3, i].Value = "Find";
                            dataGridView1[3, i].Style.BackColor = Color.White;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.StackTrace);
            }
            finally
            {
                bWorkerFileSearch.ReportProgress(100);
            }
        }
        private bool CrmFIleSearch(string full_filename)
        {
            string[] lines = System.IO.File.ReadAllLines(full_filename, Encoding.Default);
            
            string sdata = lines[1];
            string[] array = sdata.Split('\t');

            if (array.Length < 5)
                return false;

            if (lines[1].Contains(txtProjectNumber.Text))
                return true;
            else
                return false;
        }
         
        /*
         * backgroudworker 실행
         * */
        private void bWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            excute(sender, e);
        }
        private void bWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pBar.Value = e.ProgressPercentage;
            lblTotal.Text = "전체 " + totalcount.ToString() + "개 중 " + currentcount.ToString() + "개 수행중입니다.";
        }
        private void bWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show("작업수행중 에러 발생 :" + e.Error.Message);
            }
            else if (e.Cancelled == true)
            {
                MessageBox.Show("작업이 취소되었습니다.");
            }
            else
            {
                MessageBox.Show("작업 완료되었습니다.");
            }
            setControl(true);
        }
        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1[0, i].Value = true;
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (bWorkerFileSearch.IsBusy)
            {
                bWorkerFileSearch.CancelAsync();
                stopflag = true;
            }
        }

    }
}
