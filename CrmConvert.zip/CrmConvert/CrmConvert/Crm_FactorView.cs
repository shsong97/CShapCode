﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CrmConvert
{
    public partial class Crm_FactorView : Form
    {
        public Crm_FactorView()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtProjectNo.Text.Length != 14)
            {
                MessageBox.Show("프로젝트는 14자리입니다.");
                return;
            }

            string query = "select * from t_han_elog where project_no='" + txtProjectNo.Text.Substring(0,11) + "' and mfg_no='" + txtProjectNo.Text.Substring(11,3) + "' order by unit_no";
            GRS g = new GRS(query);

            if (g.RowCount > 0)
            {
                txtProjectNumber.Text = g.gRS("project_number");
                cboUnitNo.Items.Clear();
                for (int i = 0; i < g.RowCount; i++)
                {
                    cboUnitNo.Items.Add(g.gRS("unit_no"));
                    g.MoveNext();
                }
                cboUnitNo.SelectedIndex = 0;

                query = "select rdy_name from T_CRM_PROJECT_RECORD where project_number='"+txtProjectNumber.Text+"' order by rdy_name";
                g = new GRS(query);
                if (g.RowCount > 0)
                {
                    cboRdyFile.Items.Clear();
                    for (int i = 0; i < g.RowCount; i++)
                    {
                        cboRdyFile.Items.Add(g.gRS("rdy_name"));
                        g.MoveNext();
                    }
                    cboRdyFile.SelectedIndex = 0;
                }
            }
            else
            {
                MessageBox.Show("데이터가 없습니다.");
            }
        }

        private void btnCalcFactor_Click(object sender, EventArgs e)
        {
            string query = "EXEC S_ELOG_CRM_FACTOR_VIEW '" + cboRdyFile.SelectedItem + "','" + 
                txtProjectNumber.Text + "','" +
                cboUnitNo.SelectedItem + "'";
 
            GRS g = new GRS(query);

            if (g.RowCount == 0)
            {
                MessageBox.Show("데이터가 없습니다.");
                return;
            }

            fpSpread1_Sheet1.DataSource = g.GetDS().Tables[0];
            fpSpread2.DataSource = g.GetDS().Tables[1];
        }
    }
}
