﻿namespace CrmConvert
{
    partial class SpecCopy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtBiddingNo = new System.Windows.Forms.TextBox();
            this.txtBiddingSeq = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtProjectNo = new System.Windows.Forms.TextBox();
            this.txtMfgNo = new System.Windows.Forms.TextBox();
            this.btnSpecCopy = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "견적제번";
            // 
            // txtBiddingNo
            // 
            this.txtBiddingNo.Location = new System.Drawing.Point(71, 14);
            this.txtBiddingNo.MaxLength = 10;
            this.txtBiddingNo.Name = "txtBiddingNo";
            this.txtBiddingNo.Size = new System.Drawing.Size(88, 21);
            this.txtBiddingNo.TabIndex = 1;
            // 
            // txtBiddingSeq
            // 
            this.txtBiddingSeq.Location = new System.Drawing.Point(164, 14);
            this.txtBiddingSeq.MaxLength = 3;
            this.txtBiddingSeq.Name = "txtBiddingSeq";
            this.txtBiddingSeq.Size = new System.Drawing.Size(59, 21);
            this.txtBiddingSeq.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(229, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "=>";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(254, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "프로젝트";
            // 
            // txtProjectNo
            // 
            this.txtProjectNo.Location = new System.Drawing.Point(313, 14);
            this.txtProjectNo.MaxLength = 11;
            this.txtProjectNo.Name = "txtProjectNo";
            this.txtProjectNo.Size = new System.Drawing.Size(86, 21);
            this.txtProjectNo.TabIndex = 5;
            // 
            // txtMfgNo
            // 
            this.txtMfgNo.Location = new System.Drawing.Point(405, 14);
            this.txtMfgNo.MaxLength = 3;
            this.txtMfgNo.Name = "txtMfgNo";
            this.txtMfgNo.Size = new System.Drawing.Size(57, 21);
            this.txtMfgNo.TabIndex = 6;
            // 
            // btnSpecCopy
            // 
            this.btnSpecCopy.Location = new System.Drawing.Point(468, 12);
            this.btnSpecCopy.Name = "btnSpecCopy";
            this.btnSpecCopy.Size = new System.Drawing.Size(77, 23);
            this.btnSpecCopy.TabIndex = 7;
            this.btnSpecCopy.Text = "복사";
            this.btnSpecCopy.UseVisualStyleBackColor = true;
            this.btnSpecCopy.Click += new System.EventHandler(this.btnSpecCopy_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(624, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "견적제번에 D1234 항번에 E01을 넣고 복사할 수주프로젝트를 2014F  0001 E01에 넣으신 다음 복사버튼을 누릅니다.";
            // 
            // SpecCopy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 200);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnSpecCopy);
            this.Controls.Add(this.txtMfgNo);
            this.Controls.Add(this.txtProjectNo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBiddingSeq);
            this.Controls.Add(this.txtBiddingNo);
            this.Controls.Add(this.label1);
            this.Name = "SpecCopy";
            this.Text = "화물견적시방복사";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBiddingNo;
        private System.Windows.Forms.TextBox txtBiddingSeq;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtProjectNo;
        private System.Windows.Forms.TextBox txtMfgNo;
        private System.Windows.Forms.Button btnSpecCopy;
        private System.Windows.Forms.Label label4;
    }
}