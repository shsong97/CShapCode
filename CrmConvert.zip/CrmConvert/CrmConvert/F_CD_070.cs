﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CrmConvert
{
    public partial class F_CD_070 : Form
    {
        public F_CD_070()
        {
            InitializeComponent();
        }

        private void cmdSearch_Click(object sender, EventArgs e)
        {
            string sqlFlag="";
            string sSql="";
            if(txtProject_noFrom.Text.Length==0)
            {
                MessageBox.Show("견적번호를 입력하세요.");
                return;
            }
            Cursor.Current=Cursors.WaitCursor;
            
            if(txtProject_noTo.Text.Length==0)
            {
                txtProject_noTo.Text=txtProject_noFrom.Text;
            }

            if(OptProject.Checked)
                sqlFlag="A";
            else
                sqlFlag="S";

            sSql="exec S_CD_070 '"+sqlFlag+"','"+txtProject_noFrom.Text+"','"+txtProject_noTo.Text+"'";
            GRS g=new GRS(sSql);

            if(g.RowCount==0)
            {
                MessageBox.Show("조회된 자료가 없습니다.");
                Cursor.Current=Cursors.Default;
                return;
            }
            dataGridView1.RowCount = g.RowCount;
            //dataGridView1.ColumnCount = g.ColCount;
            for(int row=0;row<g.RowCount;row++)
            {
                for(int col=0;col<g.ColCount;col++)
                {
                    dataGridView1.Rows[row].Cells[col].Value = g.gRS(col);
                }
                g.MoveNext();
            }

            Cursor.Current=Cursors.Default;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select max(project_no) from t_han_elog_st10 where project_number like '" + txtProjectNumber.Text + "%' or proposal_name like '"+txtProjectNumber.Text+"%'";
            GRS g = new GRS(sql);
            if (g.RowCount > 0)
            {
                txtProject_noFrom.Text = g.gRS(0);
                txtProject_noTo.Text = g.gRS(0);
            }
        }
        //private void gSpread_Header_Setup()
        //{
        //    string sSql = "exec S_CD_070";
        //    GRS g = new GRS(sSql);
        //}
    }
}
