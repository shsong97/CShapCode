﻿namespace CrmConvert
{
    partial class FileCopy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType2 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType4 = new FarPoint.Win.Spread.CellType.TextCellType();
            this.label1 = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.textFolderName = new System.Windows.Forms.TextBox();
            this.folderSearch = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textFolderName2 = new System.Windows.Forms.TextBox();
            this.folderSearch2 = new System.Windows.Forms.Button();
            this.btnCopyButton = new System.Windows.Forms.Button();
            this.fpSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 40;
            this.label1.Text = "폴더명";
            // 
            // textFolderName
            // 
            this.textFolderName.Location = new System.Drawing.Point(58, 16);
            this.textFolderName.Name = "textFolderName";
            this.textFolderName.Size = new System.Drawing.Size(230, 21);
            this.textFolderName.TabIndex = 39;
            // 
            // folderSearch
            // 
            this.folderSearch.Location = new System.Drawing.Point(294, 13);
            this.folderSearch.Name = "folderSearch";
            this.folderSearch.Size = new System.Drawing.Size(86, 24);
            this.folderSearch.TabIndex = 38;
            this.folderSearch.Text = "폴더지정";
            this.folderSearch.UseVisualStyleBackColor = true;
            this.folderSearch.Click += new System.EventHandler(this.folderSearch_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(390, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 12);
            this.label2.TabIndex = 41;
            this.label2.Text = "=>";
            // 
            // textFolderName2
            // 
            this.textFolderName2.Location = new System.Drawing.Point(415, 15);
            this.textFolderName2.Name = "textFolderName2";
            this.textFolderName2.Size = new System.Drawing.Size(230, 21);
            this.textFolderName2.TabIndex = 43;
            // 
            // folderSearch2
            // 
            this.folderSearch2.Location = new System.Drawing.Point(651, 12);
            this.folderSearch2.Name = "folderSearch2";
            this.folderSearch2.Size = new System.Drawing.Size(86, 24);
            this.folderSearch2.TabIndex = 42;
            this.folderSearch2.Text = "폴더지정";
            this.folderSearch2.UseVisualStyleBackColor = true;
            this.folderSearch2.Click += new System.EventHandler(this.folderSearch2_Click);
            // 
            // btnCopyButton
            // 
            this.btnCopyButton.Location = new System.Drawing.Point(58, 43);
            this.btnCopyButton.Name = "btnCopyButton";
            this.btnCopyButton.Size = new System.Drawing.Size(131, 26);
            this.btnCopyButton.TabIndex = 44;
            this.btnCopyButton.Text = "파일 복사";
            this.btnCopyButton.UseVisualStyleBackColor = true;
            this.btnCopyButton.Click += new System.EventHandler(this.btnCopyButton_Click);
            // 
            // fpSpread1
            // 
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpread1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.fpSpread1.Location = new System.Drawing.Point(12, 75);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(725, 309);
            this.fpSpread1.TabIndex = 45;
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 3;
            this.fpSpread1_Sheet1.RowCount = 100;
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "File Name";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Copy";
            this.fpSpread1_Sheet1.Columns.Get(0).CellType = checkBoxCellType2;
            this.fpSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 39F;
            textCellType3.BackgroundImage = new FarPoint.Win.Picture(null, FarPoint.Win.RenderStyle.Normal, System.Drawing.Color.Empty, 0, FarPoint.Win.HorizontalAlignment.Left, FarPoint.Win.VerticalAlignment.Center);
            this.fpSpread1_Sheet1.Columns.Get(1).CellType = textCellType3;
            this.fpSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.General;
            this.fpSpread1_Sheet1.Columns.Get(1).Label = "File Name";
            this.fpSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 360F;
            this.fpSpread1_Sheet1.Columns.Get(2).CellType = textCellType4;
            this.fpSpread1_Sheet1.Columns.Get(2).Label = "Copy";
            this.fpSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // FileCopy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 396);
            this.Controls.Add(this.fpSpread1);
            this.Controls.Add(this.btnCopyButton);
            this.Controls.Add(this.textFolderName2);
            this.Controls.Add(this.folderSearch2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textFolderName);
            this.Controls.Add(this.folderSearch);
            this.Name = "FileCopy";
            this.Text = "FileCopy";
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.TextBox textFolderName;
        private System.Windows.Forms.Button folderSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textFolderName2;
        private System.Windows.Forms.Button folderSearch2;
        private System.Windows.Forms.Button btnCopyButton;
        private FarPoint.Win.Spread.FpSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;

    }
}