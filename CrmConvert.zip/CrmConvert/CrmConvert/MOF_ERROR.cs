﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CrmConvert
{
    public partial class MOF_ERROR : Form
    {
        public MOF_ERROR()
        {
            InitializeComponent();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            string query = "select * from t_mof_error";
            GRS g = new GRS(query);

            dataGridView1.DataSource = g.GetDS().Tables[0];
            if(g.RowCount==0)
            {
                MessageBox.Show("대상이없습니다");
            }
        }

        private void buttonComplete_Click(object sender, EventArgs e)
        {
            string query = "exec S_ESS_CONV_ERROR_BATCH";
            GRS g = new GRS(query, true);
            MessageBox.Show("처리완료되었습니다");
            buttonSearch_Click(sender, e);
        }
    }
}
