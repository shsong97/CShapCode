﻿namespace CrmConvert
{
    partial class MainProg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nECRMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iBDCRMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.화물견적시방복사ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cRMFactor조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cRM에러리스트ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.project찾기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.파일복사ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.nECRM견적ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.견적원가조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mOFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mOF에러리스트ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.계단식ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.바둑판식수평ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.바둑판식수직ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.cRMFactorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rdyFactor계산ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.mOFToolStripMenuItem,
            this.cRMFactorToolStripMenuItem,
            this.windowsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(783, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nECRMToolStripMenuItem,
            this.iBDCRMToolStripMenuItem,
            this.화물견적시방복사ToolStripMenuItem,
            this.cRMFactor조회ToolStripMenuItem,
            this.cRM에러리스트ToolStripMenuItem,
            this.project찾기ToolStripMenuItem,
            this.파일복사ToolStripMenuItem,
            this.toolStripSeparator1,
            this.nECRM견적ToolStripMenuItem,
            this.견적원가조회ToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.menuToolStripMenuItem.Text = "&CRM";
            // 
            // nECRMToolStripMenuItem
            // 
            this.nECRMToolStripMenuItem.Name = "nECRMToolStripMenuItem";
            this.nECRMToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.nECRMToolStripMenuItem.Text = "NE CRM";
            this.nECRMToolStripMenuItem.Click += new System.EventHandler(this.nECRMToolStripMenuItem_Click);
            // 
            // iBDCRMToolStripMenuItem
            // 
            this.iBDCRMToolStripMenuItem.Name = "iBDCRMToolStripMenuItem";
            this.iBDCRMToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.iBDCRMToolStripMenuItem.Text = "IBD CRM";
            this.iBDCRMToolStripMenuItem.Click += new System.EventHandler(this.iBDCRMToolStripMenuItem_Click);
            // 
            // 화물견적시방복사ToolStripMenuItem
            // 
            this.화물견적시방복사ToolStripMenuItem.Name = "화물견적시방복사ToolStripMenuItem";
            this.화물견적시방복사ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.화물견적시방복사ToolStripMenuItem.Text = "견적시방복사/1차GO";
            this.화물견적시방복사ToolStripMenuItem.Click += new System.EventHandler(this.화물견적시방복사ToolStripMenuItem_Click);
            // 
            // cRMFactor조회ToolStripMenuItem
            // 
            this.cRMFactor조회ToolStripMenuItem.Name = "cRMFactor조회ToolStripMenuItem";
            this.cRMFactor조회ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.cRMFactor조회ToolStripMenuItem.Text = "CRM Factor 조회";
            this.cRMFactor조회ToolStripMenuItem.Click += new System.EventHandler(this.cRMFactor조회ToolStripMenuItem_Click);
            // 
            // cRM에러리스트ToolStripMenuItem
            // 
            this.cRM에러리스트ToolStripMenuItem.Name = "cRM에러리스트ToolStripMenuItem";
            this.cRM에러리스트ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.cRM에러리스트ToolStripMenuItem.Text = "CRM 에러리스트";
            this.cRM에러리스트ToolStripMenuItem.Click += new System.EventHandler(this.cRM에러리스트ToolStripMenuItem_Click);
            // 
            // project찾기ToolStripMenuItem
            // 
            this.project찾기ToolStripMenuItem.Name = "project찾기ToolStripMenuItem";
            this.project찾기ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.project찾기ToolStripMenuItem.Text = "Project 찾기";
            this.project찾기ToolStripMenuItem.Click += new System.EventHandler(this.project찾기ToolStripMenuItem_Click);
            // 
            // 파일복사ToolStripMenuItem
            // 
            this.파일복사ToolStripMenuItem.Name = "파일복사ToolStripMenuItem";
            this.파일복사ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.파일복사ToolStripMenuItem.Text = "파일 복사";
            this.파일복사ToolStripMenuItem.Click += new System.EventHandler(this.파일복사ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(184, 6);
            // 
            // nECRM견적ToolStripMenuItem
            // 
            this.nECRM견적ToolStripMenuItem.Name = "nECRM견적ToolStripMenuItem";
            this.nECRM견적ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.nECRM견적ToolStripMenuItem.Text = "NE CRM 견적";
            this.nECRM견적ToolStripMenuItem.Click += new System.EventHandler(this.nECRM견적ToolStripMenuItem_Click);
            // 
            // 견적원가조회ToolStripMenuItem
            // 
            this.견적원가조회ToolStripMenuItem.Name = "견적원가조회ToolStripMenuItem";
            this.견적원가조회ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.견적원가조회ToolStripMenuItem.Text = "견적원가조회";
            this.견적원가조회ToolStripMenuItem.Click += new System.EventHandler(this.견적원가조회ToolStripMenuItem_Click);
            // 
            // mOFToolStripMenuItem
            // 
            this.mOFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mOF에러리스트ToolStripMenuItem});
            this.mOFToolStripMenuItem.Name = "mOFToolStripMenuItem";
            this.mOFToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.mOFToolStripMenuItem.Text = "&MOF";
            // 
            // mOF에러리스트ToolStripMenuItem
            // 
            this.mOF에러리스트ToolStripMenuItem.Name = "mOF에러리스트ToolStripMenuItem";
            this.mOF에러리스트ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.mOF에러리스트ToolStripMenuItem.Text = "MOF에러리스트";
            this.mOF에러리스트ToolStripMenuItem.Click += new System.EventHandler(this.mOF에러리스트ToolStripMenuItem_Click);
            // 
            // windowsToolStripMenuItem
            // 
            this.windowsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.계단식ToolStripMenuItem,
            this.바둑판식수평ToolStripMenuItem,
            this.바둑판식수직ToolStripMenuItem});
            this.windowsToolStripMenuItem.Name = "windowsToolStripMenuItem";
            this.windowsToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.windowsToolStripMenuItem.Text = "Windows";
            // 
            // 계단식ToolStripMenuItem
            // 
            this.계단식ToolStripMenuItem.Name = "계단식ToolStripMenuItem";
            this.계단식ToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.계단식ToolStripMenuItem.Text = "계단식";
            this.계단식ToolStripMenuItem.Click += new System.EventHandler(this.계단식ToolStripMenuItem_Click);
            // 
            // 바둑판식수평ToolStripMenuItem
            // 
            this.바둑판식수평ToolStripMenuItem.Name = "바둑판식수평ToolStripMenuItem";
            this.바둑판식수평ToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.바둑판식수평ToolStripMenuItem.Text = "바둑판식(수평)";
            this.바둑판식수평ToolStripMenuItem.Click += new System.EventHandler(this.바둑판식수평ToolStripMenuItem_Click);
            // 
            // 바둑판식수직ToolStripMenuItem
            // 
            this.바둑판식수직ToolStripMenuItem.Name = "바둑판식수직ToolStripMenuItem";
            this.바둑판식수직ToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.바둑판식수직ToolStripMenuItem.Text = "바둑판식(수직)";
            this.바둑판식수직ToolStripMenuItem.Click += new System.EventHandler(this.바둑판식수직ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 298);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(783, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(31, 17);
            this.toolStripStatusLabel1.Text = "상태";
            // 
            // cRMFactorToolStripMenuItem
            // 
            this.cRMFactorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rdyFactor계산ToolStripMenuItem});
            this.cRMFactorToolStripMenuItem.Name = "cRMFactorToolStripMenuItem";
            this.cRMFactorToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.cRMFactorToolStripMenuItem.Text = "CRM Factor";
            // 
            // rdyFactor계산ToolStripMenuItem
            // 
            this.rdyFactor계산ToolStripMenuItem.Name = "rdyFactor계산ToolStripMenuItem";
            this.rdyFactor계산ToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.rdyFactor계산ToolStripMenuItem.Text = "Rdy Factor 계산";
            this.rdyFactor계산ToolStripMenuItem.Click += new System.EventHandler(this.rdyFactor계산ToolStripMenuItem_Click);
            // 
            // MainProg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 320);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainProg";
            this.Text = "CRM & MOF Solution";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nECRMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iBDCRMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 화물견적시방복사ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cRMFactor조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cRM에러리스트ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mOFToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem windowsToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem mOF에러리스트ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 계단식ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 바둑판식수평ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 바둑판식수직ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem nECRM견적ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 견적원가조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem project찾기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 파일복사ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cRMFactorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rdyFactor계산ToolStripMenuItem;
    }
}