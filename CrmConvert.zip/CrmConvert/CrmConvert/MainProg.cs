﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CrmConvert
{
    public partial class MainProg : Form
    {
        public MainProg()
        {
            InitializeComponent();
            Common c = new Common();
            DBManager.SetConnectionString(c.ConType, c.ServerName, c.DbName, c.ID, c.password);
            if (!DBManager.Open())
            {
                MessageBox.Show("시스템 접속 에러");
                return;
            }
        }

        private void nECRMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new NE_CRM());
        }

        private void iBDCRMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new IBD_CRM());
        }
        public void F_FormShow(Form form)
        {
            Form f = null;

            foreach (Form child in MdiChildren)
            {
                if (child.Name.Equals(form.Name))
                {
                    f = child;
                    form.Close();
                }
            }

            if (f == null)
                f = form;

            f.MdiParent = this;
            f.Activate();
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void 화물견적시방복사ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new SpecCopy());
        }

        private void cRMFactor조회ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new CRM_FACTOR());
        }

        private void cRM에러리스트ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new CRM_ERROR());
        }

        private void mOF에러리스트ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new MOF_ERROR());
        }

        private void 계단식ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void 바둑판식수평ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void 바둑판식수직ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void nECRM견적ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new NE_CRM_10());
        }

        private void 견적원가조회ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new F_CD_070());
        }

        private void project찾기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new FileSearch());
        }

        private void 파일복사ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new FileCopy());
        }

        private void rdyFactor계산ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F_FormShow(new Crm_FactorView());
        }
    }
}
