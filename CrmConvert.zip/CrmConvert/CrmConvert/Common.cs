﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CrmConvert
{
    class Common
    {
        public string ConType="SqlConnection";
        public string DbName="EL_BDH";
        public string ID = "APPsalesUser";
        
        public string TestServerName = "OTKRSEFIB01\\OTKRSEHAB03";
        public string TestPassword = "$JACoNUBGHCPMWSD!"; //"$eou1HAB030622!";

        public string ServerName = "OTKRSEHAM02";
        public string password = "$JACoNUBGHCPMWSD!"; //"$eou1HAM020622!";
    }
}
