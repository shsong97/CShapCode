﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CrmConvert
{
    public partial class CRM_FACTOR : Form
    {
        public CRM_FACTOR()
        {
            InitializeComponent();
        }

        private void buttonRdySearch_Click(object sender, EventArgs e)
        {
            /*
select *  from T_Crm_Project_Record where rdy_name = @FileName
select *  from T_Crm_Project_Local_Info_Record where rdy_name = @FileName
select *  from T_Crm_Project_Address_Record where rdy_name = @FileName
select *  from T_Crm_Project_Account_Record where rdy_name = @FileName
select *  from T_Crm_Project_Account_Contact_Record where rdy_name = @FileName
select *  from T_Crm_Project_Sales_Rep_Record where rdy_name = @FileName
select *  from T_Crm_Proposal_Record where rdy_name = @FileName
select *  from T_Crm_Proposal_Configurable_Other_Expenses_Record where rdy_name = @FileName
select *  from T_Crm_Proposal_Local_Info_Record where rdy_name = @FileName
select *  from T_Crm_Solution_Record where rdy_name = @FileName
select *  from T_Crm_Solution_Local_Info_Record where rdy_name = @FileName
select *  from T_Crm_Unit_Record where rdy_name = @FileName
select *  from T_Crm_Unit_Local_Info_Record where rdy_name = @FileName
select *  from T_Crm_Proposal_level_price_and_cost_detail_Record where rdy_name = @FileName
select *  from T_Crm_Unit_level_price_and_cost_detail_Record where rdy_name = @FileName
select *  from T_Crm_Proposal_level_Factor_Record where rdy_name = @FileName
select *  from T_Crm_Unit_level_Factor_Record where rdy_name = @FileName
             * */
            string query = "exec S_ELOG_SEARCH_CRM '" + textRdyName.Text + "','" + textJebun.Text + "'";
            GRS g = new GRS(query);
            if (g.RowCount > 0)
            {
                dataGridView1.DataSource = g.GetDS().Tables[0];
                dataGridView2.DataSource = g.GetDS().Tables[1];
                dataGridView3.DataSource = g.GetDS().Tables[2];
                dataGridView4.DataSource = g.GetDS().Tables[3];
                //dataGridView5.DataSource = g.GetDS().Tables[4];
                dataGridView6.DataSource = g.GetDS().Tables[4];
                dataGridView7.DataSource = g.GetDS().Tables[5];
                //dataGridView8.DataSource = g.GetDS().Tables[7];
                dataGridView9.DataSource = g.GetDS().Tables[6];
                dataGridView10.DataSource = g.GetDS().Tables[7];
                //dataGridView11.DataSource = g.GetDS().Tables[10];
                dataGridView12.DataSource = g.GetDS().Tables[8];
                dataGridView13.DataSource = g.GetDS().Tables[9];
                dataGridView14.DataSource = g.GetDS().Tables[10];
                dataGridView15.DataSource = g.GetDS().Tables[11];
                dataGridView16.DataSource = g.GetDS().Tables[12];
                dataGridView17.DataSource = g.GetDS().Tables[13];
            }

        }

        private void buttonProjectSearch_Click(object sender, EventArgs e)
        {
            string query ="";
            GRS g = null;
            if (textProjectNumber.Text != "")
                query = "select MAX(rdy_name) from t_han_elog where Project_Number='"+textProjectNumber.Text+"'";
            else if(textJebun.Text != "")
                query = "select MAX(rdy_name) from t_han_elog where project_no='" + textJebun.Text.Substring(0, 11) + "' and mfg_no='" + textJebun.Text.Substring(11) + "'";
            
            g = new GRS(query);
            if (g.RowCount > 0)
            {
                textRdyName.Text = g.gRS(0);
            }
        }
    }
}
