﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CrmConvert
{
    public partial class SpecCopy : Form
    {
        public SpecCopy()
        {
            InitializeComponent();
            Common c = new Common();
            DBManager.SetConnectionString(c.ConType, c.ServerName, c.DbName, c.ID, c.password);

            if (!DBManager.Open())
            {
                MessageBox.Show("시스템 접속 에러");
                return;
            }
        }

        private void btnSpecCopy_Click(object sender, EventArgs e)
        {
            string query = "exec EL_BDH.dbo.S_ELOG_SPEC_COPY '" + txtBiddingNo.Text + "','" + txtBiddingSeq.Text + "','" + txtProjectNo.Text + "','" + txtMfgNo.Text + "'";
            GRS g = new GRS(query);
            if (DBManager.ErrorMessage.Equals(""))
            {
                MessageBox.Show("처리완료되었습니다.");
            }
            else
            {
                MessageBox.Show("에러가 발생했습니다.\n" + DBManager.ErrorMessage);
            }
        }
    }  
}
