﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CrmConvert
{
    public partial class CRM_ERROR : Form
    {
        public CRM_ERROR()
        {
            InitializeComponent();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            string query = "select * from t_file_upload where DONE_DATE is null order by sData";
            GRS g = new GRS(query);
            dataGridView1.RowCount = 1;
            dataGridView1[1, 0].Value = "";
            if (g.RowCount > 0)
            {
                dataGridView1.RowCount = g.RowCount;
                for (int i = 0; i < g.RowCount; i++)
                {
                    dataGridView1[0, i].Value = false;
                    dataGridView1[1, i].Value = g.gRS("sData");
                    g.MoveNext();
                }
            }
            else
            {
                MessageBox.Show("대상이없습니다");
            }
        }

        private void buttonComplete_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount-1; i++)
            {
                if ((bool)dataGridView1[0, i].Value)
                {
                    if (dataGridView1[1, i].Value != null)
                    {
                        string filename = dataGridView1[1, i].Value.ToString();
                        string query = "update T_file_upload set done_date=GETDATE() where sData='" + filename + "'";
                        GRS g = new GRS(query);
                    }
                }
            }
            buttonSearch_Click(sender,e);
        }
    }
}
