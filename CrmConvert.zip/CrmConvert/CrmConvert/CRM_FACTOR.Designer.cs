﻿namespace CrmConvert
{
    partial class CRM_FACTOR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textRdyName = new System.Windows.Forms.TextBox();
            this.buttonRdySearch = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.T_Crm_Project_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Project_Local_Info_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Project_Address_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Project_Account_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Project_Sales_Rep_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Proposal_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Proposal_Local_Info_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Solution_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Unit_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Unit_Local_Info_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Proposal_level_price_and_cost_detail_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Unit_level_price_and_cost_detail_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Proposal_level_Factor_Record = new System.Windows.Forms.TabPage();
            this.T_Crm_Unit_level_Factor_Record = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.dataGridView12 = new System.Windows.Forms.DataGridView();
            this.dataGridView13 = new System.Windows.Forms.DataGridView();
            this.dataGridView14 = new System.Windows.Forms.DataGridView();
            this.dataGridView15 = new System.Windows.Forms.DataGridView();
            this.dataGridView16 = new System.Windows.Forms.DataGridView();
            this.dataGridView17 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.textProjectNumber = new System.Windows.Forms.TextBox();
            this.buttonProjectSearch = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textJebun = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.T_Crm_Project_Record.SuspendLayout();
            this.T_Crm_Project_Local_Info_Record.SuspendLayout();
            this.T_Crm_Project_Address_Record.SuspendLayout();
            this.T_Crm_Project_Account_Record.SuspendLayout();
            this.T_Crm_Project_Sales_Rep_Record.SuspendLayout();
            this.T_Crm_Proposal_Record.SuspendLayout();
            this.T_Crm_Proposal_Local_Info_Record.SuspendLayout();
            this.T_Crm_Solution_Record.SuspendLayout();
            this.T_Crm_Unit_Record.SuspendLayout();
            this.T_Crm_Unit_Local_Info_Record.SuspendLayout();
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.SuspendLayout();
            this.T_Crm_Unit_level_price_and_cost_detail_Record.SuspendLayout();
            this.T_Crm_Proposal_level_Factor_Record.SuspendLayout();
            this.T_Crm_Unit_level_Factor_Record.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rdy Name";
            // 
            // textRdyName
            // 
            this.textRdyName.Location = new System.Drawing.Point(83, 6);
            this.textRdyName.Name = "textRdyName";
            this.textRdyName.Size = new System.Drawing.Size(214, 21);
            this.textRdyName.TabIndex = 1;
            // 
            // buttonRdySearch
            // 
            this.buttonRdySearch.Location = new System.Drawing.Point(314, 6);
            this.buttonRdySearch.Name = "buttonRdySearch";
            this.buttonRdySearch.Size = new System.Drawing.Size(115, 29);
            this.buttonRdySearch.TabIndex = 2;
            this.buttonRdySearch.Text = "Factor 조회";
            this.buttonRdySearch.UseVisualStyleBackColor = true;
            this.buttonRdySearch.Click += new System.EventHandler(this.buttonRdySearch_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.T_Crm_Project_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Project_Local_Info_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Project_Address_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Project_Account_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Project_Sales_Rep_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Proposal_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Proposal_Local_Info_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Solution_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Unit_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Unit_Local_Info_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Proposal_level_price_and_cost_detail_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Unit_level_price_and_cost_detail_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Proposal_level_Factor_Record);
            this.tabControl1.Controls.Add(this.T_Crm_Unit_level_Factor_Record);
            this.tabControl1.Location = new System.Drawing.Point(14, 61);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(731, 395);
            this.tabControl1.TabIndex = 3;
            // 
            // T_Crm_Project_Record
            // 
            this.T_Crm_Project_Record.Controls.Add(this.dataGridView1);
            this.T_Crm_Project_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Project_Record.Name = "T_Crm_Project_Record";
            this.T_Crm_Project_Record.Padding = new System.Windows.Forms.Padding(3);
            this.T_Crm_Project_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Project_Record.TabIndex = 0;
            this.T_Crm_Project_Record.Text = "T_Crm_Project_Record";
            this.T_Crm_Project_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Project_Local_Info_Record
            // 
            this.T_Crm_Project_Local_Info_Record.Controls.Add(this.dataGridView2);
            this.T_Crm_Project_Local_Info_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Project_Local_Info_Record.Name = "T_Crm_Project_Local_Info_Record";
            this.T_Crm_Project_Local_Info_Record.Padding = new System.Windows.Forms.Padding(3);
            this.T_Crm_Project_Local_Info_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Project_Local_Info_Record.TabIndex = 1;
            this.T_Crm_Project_Local_Info_Record.Text = "T_Crm_Project_Local_Info_Record";
            this.T_Crm_Project_Local_Info_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Project_Address_Record
            // 
            this.T_Crm_Project_Address_Record.Controls.Add(this.dataGridView3);
            this.T_Crm_Project_Address_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Project_Address_Record.Name = "T_Crm_Project_Address_Record";
            this.T_Crm_Project_Address_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Project_Address_Record.TabIndex = 2;
            this.T_Crm_Project_Address_Record.Text = "T_Crm_Project_Address_Record";
            this.T_Crm_Project_Address_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Project_Account_Record
            // 
            this.T_Crm_Project_Account_Record.Controls.Add(this.dataGridView4);
            this.T_Crm_Project_Account_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Project_Account_Record.Name = "T_Crm_Project_Account_Record";
            this.T_Crm_Project_Account_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Project_Account_Record.TabIndex = 3;
            this.T_Crm_Project_Account_Record.Text = "T_Crm_Project_Account_Record";
            this.T_Crm_Project_Account_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Project_Sales_Rep_Record
            // 
            this.T_Crm_Project_Sales_Rep_Record.Controls.Add(this.dataGridView6);
            this.T_Crm_Project_Sales_Rep_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Project_Sales_Rep_Record.Name = "T_Crm_Project_Sales_Rep_Record";
            this.T_Crm_Project_Sales_Rep_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Project_Sales_Rep_Record.TabIndex = 5;
            this.T_Crm_Project_Sales_Rep_Record.Text = "T_Crm_Project_Sales_Rep_Record";
            this.T_Crm_Project_Sales_Rep_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Proposal_Record
            // 
            this.T_Crm_Proposal_Record.Controls.Add(this.dataGridView7);
            this.T_Crm_Proposal_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Proposal_Record.Name = "T_Crm_Proposal_Record";
            this.T_Crm_Proposal_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Proposal_Record.TabIndex = 6;
            this.T_Crm_Proposal_Record.Text = "T_Crm_Proposal_Record";
            this.T_Crm_Proposal_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Proposal_Local_Info_Record
            // 
            this.T_Crm_Proposal_Local_Info_Record.Controls.Add(this.dataGridView9);
            this.T_Crm_Proposal_Local_Info_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Proposal_Local_Info_Record.Name = "T_Crm_Proposal_Local_Info_Record";
            this.T_Crm_Proposal_Local_Info_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Proposal_Local_Info_Record.TabIndex = 8;
            this.T_Crm_Proposal_Local_Info_Record.Text = "T_Crm_Proposal_Local_Info_Record";
            this.T_Crm_Proposal_Local_Info_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Solution_Record
            // 
            this.T_Crm_Solution_Record.Controls.Add(this.dataGridView10);
            this.T_Crm_Solution_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Solution_Record.Name = "T_Crm_Solution_Record";
            this.T_Crm_Solution_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Solution_Record.TabIndex = 9;
            this.T_Crm_Solution_Record.Text = "T_Crm_Solution_Record";
            this.T_Crm_Solution_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Unit_Record
            // 
            this.T_Crm_Unit_Record.Controls.Add(this.dataGridView12);
            this.T_Crm_Unit_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Unit_Record.Name = "T_Crm_Unit_Record";
            this.T_Crm_Unit_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Unit_Record.TabIndex = 11;
            this.T_Crm_Unit_Record.Text = "T_Crm_Unit_Record";
            this.T_Crm_Unit_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Unit_Local_Info_Record
            // 
            this.T_Crm_Unit_Local_Info_Record.Controls.Add(this.dataGridView13);
            this.T_Crm_Unit_Local_Info_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Unit_Local_Info_Record.Name = "T_Crm_Unit_Local_Info_Record";
            this.T_Crm_Unit_Local_Info_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Unit_Local_Info_Record.TabIndex = 12;
            this.T_Crm_Unit_Local_Info_Record.Text = "T_Crm_Unit_Local_Info_Record";
            this.T_Crm_Unit_Local_Info_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Proposal_level_price_and_cost_detail_Record
            // 
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.Controls.Add(this.dataGridView14);
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.Name = "T_Crm_Proposal_level_price_and_cost_detail_Record";
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.TabIndex = 13;
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.Text = "T_Crm_Proposal_level_price_and_cost_detail_Record";
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Unit_level_price_and_cost_detail_Record
            // 
            this.T_Crm_Unit_level_price_and_cost_detail_Record.Controls.Add(this.dataGridView15);
            this.T_Crm_Unit_level_price_and_cost_detail_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Unit_level_price_and_cost_detail_Record.Name = "T_Crm_Unit_level_price_and_cost_detail_Record";
            this.T_Crm_Unit_level_price_and_cost_detail_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Unit_level_price_and_cost_detail_Record.TabIndex = 14;
            this.T_Crm_Unit_level_price_and_cost_detail_Record.Text = "T_Crm_Unit_level_price_and_cost_detail_Record";
            this.T_Crm_Unit_level_price_and_cost_detail_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Proposal_level_Factor_Record
            // 
            this.T_Crm_Proposal_level_Factor_Record.Controls.Add(this.dataGridView16);
            this.T_Crm_Proposal_level_Factor_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Proposal_level_Factor_Record.Name = "T_Crm_Proposal_level_Factor_Record";
            this.T_Crm_Proposal_level_Factor_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Proposal_level_Factor_Record.TabIndex = 15;
            this.T_Crm_Proposal_level_Factor_Record.Text = "T_Crm_Proposal_level_Factor_Record";
            this.T_Crm_Proposal_level_Factor_Record.UseVisualStyleBackColor = true;
            // 
            // T_Crm_Unit_level_Factor_Record
            // 
            this.T_Crm_Unit_level_Factor_Record.Controls.Add(this.dataGridView17);
            this.T_Crm_Unit_level_Factor_Record.Location = new System.Drawing.Point(4, 22);
            this.T_Crm_Unit_level_Factor_Record.Name = "T_Crm_Unit_level_Factor_Record";
            this.T_Crm_Unit_level_Factor_Record.Size = new System.Drawing.Size(723, 369);
            this.T_Crm_Unit_level_Factor_Record.TabIndex = 16;
            this.T_Crm_Unit_level_Factor_Record.Text = "T_Crm_Unit_level_Factor_Record";
            this.T_Crm_Unit_level_Factor_Record.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(714, 360);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(714, 360);
            this.dataGridView2.TabIndex = 0;
            // 
            // dataGridView3
            // 
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(3, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(717, 363);
            this.dataGridView3.TabIndex = 0;
            // 
            // dataGridView4
            // 
            this.dataGridView4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(3, 3);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(717, 363);
            this.dataGridView4.TabIndex = 0;
            // 
            // dataGridView6
            // 
            this.dataGridView6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(3, 3);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowTemplate.Height = 23;
            this.dataGridView6.Size = new System.Drawing.Size(717, 363);
            this.dataGridView6.TabIndex = 0;
            // 
            // dataGridView7
            // 
            this.dataGridView7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Location = new System.Drawing.Point(3, 3);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowTemplate.Height = 23;
            this.dataGridView7.Size = new System.Drawing.Size(717, 363);
            this.dataGridView7.TabIndex = 0;
            // 
            // dataGridView9
            // 
            this.dataGridView9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Location = new System.Drawing.Point(3, 3);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.RowTemplate.Height = 23;
            this.dataGridView9.Size = new System.Drawing.Size(717, 363);
            this.dataGridView9.TabIndex = 0;
            // 
            // dataGridView10
            // 
            this.dataGridView10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Location = new System.Drawing.Point(3, 3);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.RowTemplate.Height = 23;
            this.dataGridView10.Size = new System.Drawing.Size(717, 363);
            this.dataGridView10.TabIndex = 0;
            // 
            // dataGridView12
            // 
            this.dataGridView12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView12.Location = new System.Drawing.Point(3, 3);
            this.dataGridView12.Name = "dataGridView12";
            this.dataGridView12.RowTemplate.Height = 23;
            this.dataGridView12.Size = new System.Drawing.Size(717, 363);
            this.dataGridView12.TabIndex = 0;
            // 
            // dataGridView13
            // 
            this.dataGridView13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView13.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView13.Location = new System.Drawing.Point(3, 3);
            this.dataGridView13.Name = "dataGridView13";
            this.dataGridView13.RowTemplate.Height = 23;
            this.dataGridView13.Size = new System.Drawing.Size(717, 363);
            this.dataGridView13.TabIndex = 0;
            // 
            // dataGridView14
            // 
            this.dataGridView14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView14.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView14.Location = new System.Drawing.Point(3, 3);
            this.dataGridView14.Name = "dataGridView14";
            this.dataGridView14.RowTemplate.Height = 23;
            this.dataGridView14.Size = new System.Drawing.Size(717, 363);
            this.dataGridView14.TabIndex = 0;
            // 
            // dataGridView15
            // 
            this.dataGridView15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView15.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView15.Location = new System.Drawing.Point(3, 3);
            this.dataGridView15.Name = "dataGridView15";
            this.dataGridView15.RowTemplate.Height = 23;
            this.dataGridView15.Size = new System.Drawing.Size(717, 363);
            this.dataGridView15.TabIndex = 0;
            // 
            // dataGridView16
            // 
            this.dataGridView16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView16.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView16.Location = new System.Drawing.Point(3, 3);
            this.dataGridView16.Name = "dataGridView16";
            this.dataGridView16.RowTemplate.Height = 23;
            this.dataGridView16.Size = new System.Drawing.Size(717, 363);
            this.dataGridView16.TabIndex = 1;
            // 
            // dataGridView17
            // 
            this.dataGridView17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView17.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView17.Location = new System.Drawing.Point(3, 3);
            this.dataGridView17.Name = "dataGridView17";
            this.dataGridView17.RowTemplate.Height = 23;
            this.dataGridView17.Size = new System.Drawing.Size(717, 363);
            this.dataGridView17.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(461, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "Project Number";
            // 
            // textProjectNumber
            // 
            this.textProjectNumber.Location = new System.Drawing.Point(560, 6);
            this.textProjectNumber.Name = "textProjectNumber";
            this.textProjectNumber.Size = new System.Drawing.Size(109, 21);
            this.textProjectNumber.TabIndex = 5;
            // 
            // buttonProjectSearch
            // 
            this.buttonProjectSearch.Location = new System.Drawing.Point(675, 7);
            this.buttonProjectSearch.Name = "buttonProjectSearch";
            this.buttonProjectSearch.Size = new System.Drawing.Size(70, 26);
            this.buttonProjectSearch.TabIndex = 6;
            this.buttonProjectSearch.Text = "Rdy찾기";
            this.buttonProjectSearch.UseVisualStyleBackColor = true;
            this.buttonProjectSearch.Click += new System.EventHandler(this.buttonProjectSearch_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(461, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "제번";
            // 
            // textJebun
            // 
            this.textJebun.Location = new System.Drawing.Point(560, 33);
            this.textJebun.Name = "textJebun";
            this.textJebun.Size = new System.Drawing.Size(108, 21);
            this.textJebun.TabIndex = 8;
            // 
            // CRM_FACTOR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 468);
            this.Controls.Add(this.textJebun);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonProjectSearch);
            this.Controls.Add(this.textProjectNumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.buttonRdySearch);
            this.Controls.Add(this.textRdyName);
            this.Controls.Add(this.label1);
            this.Name = "CRM_FACTOR";
            this.Text = "CRM_FACTOR";
            this.tabControl1.ResumeLayout(false);
            this.T_Crm_Project_Record.ResumeLayout(false);
            this.T_Crm_Project_Local_Info_Record.ResumeLayout(false);
            this.T_Crm_Project_Address_Record.ResumeLayout(false);
            this.T_Crm_Project_Account_Record.ResumeLayout(false);
            this.T_Crm_Project_Sales_Rep_Record.ResumeLayout(false);
            this.T_Crm_Proposal_Record.ResumeLayout(false);
            this.T_Crm_Proposal_Local_Info_Record.ResumeLayout(false);
            this.T_Crm_Solution_Record.ResumeLayout(false);
            this.T_Crm_Unit_Record.ResumeLayout(false);
            this.T_Crm_Unit_Local_Info_Record.ResumeLayout(false);
            this.T_Crm_Proposal_level_price_and_cost_detail_Record.ResumeLayout(false);
            this.T_Crm_Unit_level_price_and_cost_detail_Record.ResumeLayout(false);
            this.T_Crm_Proposal_level_Factor_Record.ResumeLayout(false);
            this.T_Crm_Unit_level_Factor_Record.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textRdyName;
        private System.Windows.Forms.Button buttonRdySearch;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage T_Crm_Project_Record;
        private System.Windows.Forms.TabPage T_Crm_Project_Local_Info_Record;
        private System.Windows.Forms.TabPage T_Crm_Project_Address_Record;
        private System.Windows.Forms.TabPage T_Crm_Project_Account_Record;
        private System.Windows.Forms.TabPage T_Crm_Project_Sales_Rep_Record;
        private System.Windows.Forms.TabPage T_Crm_Proposal_Record;
        private System.Windows.Forms.TabPage T_Crm_Proposal_Local_Info_Record;
        private System.Windows.Forms.TabPage T_Crm_Solution_Record;
        private System.Windows.Forms.TabPage T_Crm_Unit_Record;
        private System.Windows.Forms.TabPage T_Crm_Unit_Local_Info_Record;
        private System.Windows.Forms.TabPage T_Crm_Proposal_level_price_and_cost_detail_Record;
        private System.Windows.Forms.TabPage T_Crm_Unit_level_price_and_cost_detail_Record;
        private System.Windows.Forms.TabPage T_Crm_Proposal_level_Factor_Record;
        private System.Windows.Forms.TabPage T_Crm_Unit_level_Factor_Record;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.DataGridView dataGridView12;
        private System.Windows.Forms.DataGridView dataGridView13;
        private System.Windows.Forms.DataGridView dataGridView14;
        private System.Windows.Forms.DataGridView dataGridView15;
        private System.Windows.Forms.DataGridView dataGridView16;
        private System.Windows.Forms.DataGridView dataGridView17;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textProjectNumber;
        private System.Windows.Forms.Button buttonProjectSearch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textJebun;
    }
}