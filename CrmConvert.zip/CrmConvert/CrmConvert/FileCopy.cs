﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FarPoint.Win.Spread;
namespace CrmConvert
{
    public partial class FileCopy : Form
    {
        public FileCopy()
        {
            InitializeComponent();
        }

        private void folderSearch_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            textFolderName.Text = folderBrowserDialog1.SelectedPath;
        }

        private void folderSearch2_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            textFolderName2.Text = folderBrowserDialog1.SelectedPath;
        }

        private void btnCopyButton_Click(object sender, EventArgs e)
        {
            SheetView sv = fpSpread1_Sheet1;
            for (int i = 0; i < sv.RowCount; i++)
            {
                string filename = (string)sv.Cells[i, 1].Value;
                string souce_file = textFolderName.Text+@"\"+filename;
                string target_folder = textFolderName2.Text + @"\" + filename;
                // CRM 수행대상 등록
                if (sv.Cells[i,0].Value == null)
                    continue;
                if ((bool)sv.Cells[i, 0].Value)
                {
                    if (!FileCopyComplete(souce_file, target_folder))
                    {
                        sv.Cells[i, 0].Value = false;
                        sv.Cells[i, 2].Value = "Error";
                    }
                    else
                    {
                        sv.Cells[i, 0].Value = false;
                        sv.Cells[i, 2].Value = "Copy";
                    }
                }
            }
        }

        private bool FileCopyComplete(string source_file, string target_folder)
        {
            try
            {
                System.IO.File.Copy(source_file, target_folder);
            }
            catch (Exception except)
            {
                MessageBox.Show(except.Message);
                return false;
            }
            return true;
        }
    }
}
